////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
// All rights reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @file camxcoredefs.h
///
/// @brief CamX common definitions
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// NOWHINE FILE PR002: Allow #if define

#ifndef CAMXCOREDEFS_H
#define CAMXCOREDEFS_H

#include "camxdefs.h"
#include "camxtypes.h"

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Constants
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// These constant values used outside camx namespace as well
const UINT   MaxPipelinesPerSession     = 16;               ///< Max pipelines per session
const UINT   MaxNumLogicalCameras       = 16;               ///< Max number of logical cameras

/// Variables used with CamX namespace
CAMX_NAMESPACE_BEGIN

const UINT   TimeoutMilliseconds        = 1000;                     ///< Time out value in millisec
const UINT   RequestQueueDepth          = 38;                       ///< Maximum camera pipeline depth
const UINT   DefaultRequestQueueDepth   = 8;                        ///< Default camera pipeline depth
const UINT   MaxRequestQueueDepth       = RequestQueueDepth + 2;    ///< Maximum Req Queue Depth
const UINT   NumProcReqData             = MaxRequestQueueDepth;     ///< Count of old requests to queue
const UINT   MaxNodeType                = 16;                       ///< Maximum number of different node types

// Max extral HAL buffers for some high loading scene, e.g. 8KEIS, DMM, SWMCTF, HFR ...
const UINT   MaxExtraHALBuffer          = 2;                ///< Max extral HAL buffers

// Default per-frame property pool window size - DefaultRequestQueueDepth for default amount of requests in pipeline
// and another DefaultRequestQueueDepth for another set of requests that may have queued up
const UINT   DefaultPerFramePoolWindowSize = DefaultRequestQueueDepth * 2; ///< Default per-frame property pool window size

/// @brief String representation of No Camera Event Type
static const CHAR* CameraHwStateStrings[] =
{
    "NO_CAMERA_PRESENT",
    "FULL_CAMERA_PRESENT",
    "PARTIAL_CAMERA_PRESENT",
    "LIMITED_CAMERA_PRESENT"
};

#if defined (_LINUX)

/// The directory from which to read configuration files
#if (!defined(LE_CAMERA))
static const CHAR CoreDumpDirectory[]       = "/data/vendor/camera/coredump";
static const CHAR FileDumpPath[]            = "/data/vendor/camera";
static const CHAR MetadataDumpDirectory[]   = "/data/vendor/camera/metadata";
static const CHAR MmSensorModulesPath[]     = "/data/vendor/camera";
#else
static const CHAR CoreDumpDirectory[]       = "/var/cache/camera/coredump";
static const CHAR FileDumpPath[]            = "/var/cache/camera";
static const CHAR MetadataDumpDirectory[]   = "/var/cache/camera/metadata";
static const CHAR MmSensorModulesPath[]     = "/var/cache/camera";
#endif // !LE_CAMERA


#if defined (LE_CAMERA)
static const CHAR SensorModulesPath[]       = "/usr/lib/camera";
#else // LE_CAMERA
#if defined (_LP64)
static const CHAR SensorModulesPath[]       = "/vendor/lib64/camera";
#else // defined (_LP64)
static const CHAR SensorModulesPath[]       = "/vendor/lib/camera";
#endif // defined (_LP64)
#endif // LE_CAMERA

#elif defined (_WIN32)

static const CHAR ConfigFileDirectory[]     = ".";
static const CHAR CoreDumpDirectory[]       = ".";
static const CHAR FileDumpPath[]            = ".";
static const CHAR MetadataDumpDirectory[]   = ".";
static const CHAR MmSensorModulesPath[]     = ".";
static const CHAR SensorModulesPath[]       = ".";
#endif // defined(_LINUX) || defined(_WIN32)

CAMX_NAMESPACE_END

#endif // CAMXCOREDEFS_H
