// NOWHINE ENTIRE FILE
//----------------------------------------------------------------------------
// Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
// All rights reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
//---------------------------------------------------------------------------

#pragma once

#include <stdint.h>
#include <cassert>

/// @brief Holds the necessary HW/chip version.
///        Needs to be set at start and then can be used by other SW components.
class NcLibChipInfo
{
public:

    enum TitanVersion
    {
        TITAN_180  = 0x00010800,
        TITAN_175  = 0x00010705,
        TITAN_170  = 0x00010700,
        TITAN_160  = 0x00010600,
        TITAN_150  = 0x00010500,
        TITAN_140  = 0x00010400,
        TITAN_120  = 0x00010200,
        TITAN_480  = 0x00040800,
        TITAN_580  = 0x00050800,
        TITAN_660  = 0x00060600,   // Fillmore
        TITAN_680  = 0x00060800,
        CAMERA_690 = 0x00060900,  // Lemans
        CAMERA_692 = 0x00060902,  // Monaco
        TITAN_780  = 0x00070800,
        TITAN_880  = 0x00080800,   // Lanai
        TITAN_570  = 0x00050700,
        TITAN_165  = 0x00010605,
        TITAN_497  = 0x00040907,
        TITAN_498  = 0x00040908,
        CAMERA_640 = 0x00060400,
        CAMERA_665 = 0x00060605,   // Milos
        CAMERA_670 = 0x00070700,   // Camano
        TITAN_860  = 0x00080600,   // Palawan
    };

    struct Capabilities
    {
        uint32_t IcaMajorVer                   : 3;
        uint32_t IcaMinorVer                   : 2;
        uint32_t IcaGridExtrapolationCorners   : 1;
        uint32_t IcaHighResGrid                : 1;
        uint32_t AiDecoder      : 1;
        uint32_t IpeDsx         : 1;
        uint32_t ALGM           : 1;
        uint32_t HDR            : 1;
        uint32_t PpsOutApp      : 1;
        uint32_t GceMNDS        : 1;

        // The rest is only used in wrapper, feel free to remove if need more bits

        uint32_t IfeDsx         : 1;
        uint32_t TfMajorVer     : 3;
        uint32_t TfMinorVer     : 2;
        uint32_t GeoLib         : 1;
        uint32_t VBSE           : 1;
        uint32_t TemporalDeblur : 1;
        uint32_t TfLmc          : 1;
        uint32_t                : 9;
    };

    /// @brief  Required initializer
    /// @param  titanVersion The version of the camera platform
    /// @param  reserved     Not used, will be removed in future releases
    /// @return None
    static void Set(uint32_t titanVersion, uint32_t reserved = 0);

    /// @brief  Camera platform version accessor
    /// @return The version of the camera platform
    static inline TitanVersion GetTitanVersion()
    {
        assert(s_titanVersion != INVALID_TITAN_VERSION);
        return s_titanVersion;
    }

    /// @brief  Tests whether running on Napali
    /// @return True if running on Napali
    static inline bool IsNapali() { return GetTitanVersion() == TITAN_170; }

    /// @brief  Tests whether running on Napali or Talos
    /// @return True if running on Napali or Talos
    static inline bool IsNapaliFamily() { return (GetTitanVersion() == TITAN_170) || (GetTitanVersion() == TITAN_150); }

    /// @brief  Tests whether running on Hana
    /// @return True if running on Hana
    static inline bool IsHana()   { return GetTitanVersion() == TITAN_175; }

    /// @brief  Tests whether running on Kodiak
    /// @return True if running on Kodiak
    static inline bool IsKodiak()   { return GetTitanVersion() == TITAN_165; }
    static inline bool IsKodiakQCM()   { return GetTitanVersion() == TITAN_497; }
    static inline bool IsKodiakQCS()   { return GetTitanVersion() == TITAN_498; }

    /// @brief  Tests whether running on Kona
    /// @return True if running on Kona
    static inline bool IsKona()   { return GetTitanVersion() == TITAN_480; }

    /// @brief  Tests whether running on Lahaina
    /// @return True if running on Lahaina
    static inline bool IsLahaina() { return GetTitanVersion() == TITAN_580; }

    /// @brief  Tests whether running on Lahaina, Cedros or Fillmore
    /// @return True if running on Lahaina, Cedros or Fillmore
    static inline bool IsLahainaFamily() { return GetTitanVersion() == TITAN_580 || GetTitanVersion() == TITAN_570 || GetTitanVersion() == TITAN_660; }

    /// @brief  Tests whether running on Waipio
    /// @return True if running on Waipio
    static inline bool IsWaipio() { return GetTitanVersion() == TITAN_680; }

    /// @brief  Tests whether running on Kailua
    /// @return True if running on Kailua
    static inline bool IsKailua() { return GetTitanVersion() == TITAN_780; }

    /// @brief  Tests whether running on Palawan
    /// @return True if running on Palawan
    static inline bool IsPalawan() { return GetTitanVersion() == TITAN_860; }

    /// @brief  Tests whether running on Lanai
    /// @return True if running on Lanai
    static inline bool IsLanai() { return GetTitanVersion() == TITAN_880; }

    /// @brief  Tests whether running on Lanai or Palawan
    /// @return True if running on Lanai or Palawan
    static inline bool IsLanaiFamily() { return GetTitanVersion() == TITAN_880 || GetTitanVersion() == TITAN_860; }

    /// @brief  Tests whether running on Talos
    /// @return True if running on Talos
    static inline bool IsTalos()  { return GetTitanVersion() == TITAN_150; }

    /// @brief  Tests whether running on Cedros
    /// @return True if running on Cedros
    static inline bool IsCedros() { return GetTitanVersion() == TITAN_570; }


    /// @brief  Tests whether running on Fillmore
    /// @return True if running on Fillmore
    static inline bool IsFillmore() { return GetTitanVersion() == TITAN_660; }

    /// @brief  Tests whether running on Milos
    /// @return True if running on Milos
    static inline bool IsMilos() { return GetTitanVersion() == CAMERA_665; }

    /// @brief  Tests whether running on Camano
    /// @return True if running on Camano
    static inline bool IsCamano() { return GetTitanVersion() == CAMERA_670; }

    /// @brief  Tests whether running on Netrani
    /// @return True if running on Netrani
    static inline bool IsNetrani() { return GetTitanVersion() == CAMERA_640; }

    /// @brief  Tests whether running on LeMans
    /// @return True if running on LeMans
    static inline bool IsLeMans() { return GetTitanVersion() == CAMERA_690; } // enum renaming CAMERA_690 alias TITAN_690

    /// @brief  Tests whether running on Monaco
    /// @return True if running on Monaco
    static inline bool IsMonaco() { return GetTitanVersion() == CAMERA_692; }

    /// @brief  Current HW/SW capabilities accessor
    /// @return Current HW/SW capabilities structure
    static inline Capabilities GetCapabilities() { return s_capabilities; }

    /// @brief  Get NcLib Version
    /// @return none
    static void GetNcLibVersion(char* version, unsigned int size);

private:
    NcLibChipInfo() = delete;

private:
    static const TitanVersion INVALID_TITAN_VERSION = (TitanVersion)0;

    static TitanVersion s_titanVersion;
    static Capabilities s_capabilities;
};
