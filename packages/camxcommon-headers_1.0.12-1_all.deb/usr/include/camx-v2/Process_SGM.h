// NOWHINE ENTIRE FILE
//-------------------------------------------------------------------------
// Copyright (c) 2020-2021 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
//------------------------------------------------------------------------

#ifndef __PROCESS_SGM_H__
#define __PROCESS_SGM_H__

#include "SGM_Chromatix_v10.h"
#include "CommonDefs.h"

typedef struct _evaSgmFrameConfigInfo evaSgmFrameConfigInfo;
typedef struct _evaSgmFrameConfigData evaSgmFrameConfigData;

// SGM mode as defined in HW
enum SGM_HW_MODE
{
    SGM_MODE_DFS = 0,
    SGM_MODE_DS8_16 = 1,
    SGM_MODE_DS4 = 2,
    SGM_MODE_1_1 = 3
};

// SGM pass numbering as defined in Chromatix
typedef enum
{
    SGM_PASS_1_1 = 0,
    SGM_PASS_1_4 = 1,
    SGM_PASS_CONFIDENCE = 2,
    SGM_PASS_DFS = 3,

    SGM_PASS_NUM,  // for SW purpose only
} SGM_PASS;

// Enable multiply on final MV output.
typedef enum
{
    MV_MULTIPLY_FACTOR_1 = 0,    // disable
    MV_MULTIPLY_FACTOR_2 = 1,    // multiply by 2
    MV_MULTIPLY_FACTOR_4 = 2,    // multiply by 4

    MV_MULTIPLY_FACTORS_NUM      // for SW purpose only
} MV_MULTIPLY_FACTOR;

static const NcLibImageSize NCLIB_SGM_PASS_1_1_MIN_SIZE = { 128, 128 };
static const NcLibImageSize NCLIB_SGM_PASS_1_1_MAX_SIZE = { 1920, 1440 };
static const NcLibImageSize NCLIB_SGM_PASS_1_4_MIN_SIZE = { 32, 32 };
static const NcLibImageSize NCLIB_SGM_PASS_1_4_MAX_SIZE = { 480, 360 };
static const NcLibImageSize NCLIB_SGM_CONFIDENCE_PASS_MIN_SIZE = { 16, 16 };
static const NcLibImageSize NCLIB_SGM_CONFIDENCE_PASS_MAX_SIZE = { 144, 144 };
static constexpr NcLibImageSize NCLIB_DFS_PASS_MIN_SIZE = { 64, 64 };
static constexpr NcLibImageSize NCLIB_DFS_PASS_MAX_SIZE = { 1280, 1280 };

struct NCLIB_CONTEXT_SGM
{
    /**< pass activation mode, must be equal to the SGM pass in Chromatix structure */
    SGM_PASS pass;

    /**<  Pass width in pixel units. the value needs to be a multiple of 2.
      In SGM_PASS_DFS it needs to be multiple of 4 if dfs_direction =1
      Valid ranges: See as passWidth
      and a multiple of 8 when SGM_PASS_1_1
      Valid ranges:
      SGM_PASS_1_1 minimal: NCLIB_SGM_PASS_1_1_MIN_SIZE maximal: NCLIB_SGM_PASS_1_1_MAX_SIZE
      SGM_PASS_1_4: minimal: NCLIB_SGM_PASS_1_4_MIN_SIZE maximal: NCLIB_SGM_PASS_1_4_MAX_SIZE
      SGM_PASS_CONFIDENCE: minimal: NCLIB_SGM_CONFIDENCE_PASS_MIN_SIZE maximal: NCLIB_SGM_CONFIDENCE_PASS_MAX_SIZE
      SGM_PASS_DFS: minimal: NCLIB_DFS_PASS_MIN_SIZE maximal: NCLIB_DFS_PASS_MAX_SIZE  */
    uint32_t passWidth;
    /**<  Pass height in pixel units; The value needs to be a multiple of 2 when SGM_PASS_1_4/SGM_PASS_CONFIDENCE/SGM_PASS_DFS */
    uint32_t passHeight;

    uint32_t ds4Height;   /**< relevant if (pass == SGM_PASS_1_1), else 0 is expected */
    uint32_t ds4Width;    /**< relevant if (pass == SGM_PASS_1_1), else 0 is expected */

    /**< subsample SGM output by factor 2, based on geometrical decisions*/
    bool isSubsampleEnabled;

    /**<  Relevant fro DFS only.
      Indicate whether confidence map is output (8 bit per pixel)*/
    bool isDfsOutputConfidenceMap;

    /**<  Relevant fro DFS only.
      Indicate whether slic map is output (8 bit per pixel)*/
    bool isDfsOutputSlicMap;

    /**<  Relevant fro DFS only.
    Indicate whether slic map is output (8 bit per pixel)*/
    MV_MULTIPLY_FACTOR dfsMvMultiplyFactor;
};

/**
*  @brief   Get size of evaSgmFrameConfigInfo struct for "blind" memory allocation
*
*  @return evaSgmFrameConfigInfo size
*/
size_t NcLibGetSize_evaSgmFrameConfigInfo();

/**
*  @brief   Get size of evaSgmFrameConfigData struct for "blind" memory allocation
*
*  @return evaSgmFrameConfigData size
*/
size_t NcLibGetSize_evaSgmFrameConfigData();

/**
*  @brief   Calculate SGM configurations
*
*  @param [in]      context         Pointer to the pass SW context
*  @param [in]      sgmChx          Pointer to the pass Chromatix struct
*  @param [out]     sgmStruct       Output struct filled by the function.
*  @param [out]     sgmData         Per-stage DMM output struct filled by the function.
*
*  @return NC_LIB_SUCCESS in case of success, otherwise failed.
*/
int32_t NcLibProcessSGM(
    const NCLIB_CONTEXT_SGM* context,
    const SGM_Chromatix_v10* sgmChx,
    evaSgmFrameConfigInfo* sgmStruct,
    evaSgmFrameConfigData* sgmData);

/**
*  @brief   Validates the config structure
*
*  @param [in]  sgmStruct                SGM FW struct to validate.
*  @param [in]  sgmData                  Per-stage SGM Config Data FW struct to validate.
*
*  @return NC_LIB_SUCCESS in case of success, otherwise return the number of failures.
*/
int32_t ValidateSgmConfig(evaSgmFrameConfigInfo* sgmStruct, evaSgmFrameConfigData* sgmData);

/**
*  @brief   Sets the config structures with default values
*
*  @param [in]  sgmStruct                SGM FW struct to fill.
*  @param [in]  sgmData                  Per-stage SGM Config Data FW struct to fill.
*/
void SetDefaultValSgmConfig(evaSgmFrameConfigInfo* sgmStruct, evaSgmFrameConfigData* sgmData);

#endif // __PROCESS_SGM_H__
