// NOWHINE ENTIRE FILE
//-------------------------------------------------------------------------
// Copyright (c) 2021 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
//------------------------------------------------------------------------


#ifndef __DEPTH_CHROMATIX_V10_H__
#define __DEPTH_CHROMATIX_V10_H__

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct DEPTH_TOP_TAG
{
    // Desired DFS resolution. Will be limited by performance and other considerations including dfs_max_extra_scale_x.
    // Entry point to the LUT is determined based on the IFE output crop at zoom x1 projected to the sensor domain.
    // First LUT entry will be used when this projection takes 100% of the full resolution sensor crop.
    // Second is for 75% and third for 50% or less.
    // When set to 0, full_resolution IFE_out_size/4 will be used.
    // Valid range otherwise is 64:1280.
    // Either all values are 0 or all values are in the range 64:1280.
    // format: 16u
    uint32_t dfs_width[3];

    // Desired DFS resolution. Will be limited by performance and other considerations including dfs_max_extra_scale_y.
    // Entry point to the LUT is determined based on the IFE output crop at zoom x1 projected to the sensor domain.
    // First LUT entry will be used when this projection takes 100% of the full resolution sensor crop.
    // Second is for 75% and third for 50% or less.
    // When set to 0, full_resolution IFE_out_size/4 will be used.
    // Valid range otherwise is 64:1280.
    // Either all values are 0 or all values are in the range 64:1280.
    // format: 16u
    uint32_t dfs_height[3];

    // Limits the maximal upscale before DFS. Too much upscale may hurt quality
    // format: float
    float dfs_max_extra_scale_x;

    // Limits the maximal upscale before DFS. Too much upscale may hurt quality
    // format: float
    float dfs_max_extra_scale_y;

    // Extra margins on top of zoom window in auxiliary IFE in favor of stereo rectification
    // 0 - no margin
    // 1 - 100% margin
    // format: float
    float aux_margin_ratio;

    // Reserved Parameter 1
    // format: float
    float reserved1;

    // Reserved Parameter 2
    // format: float
    float reserved2;

    // Reserved Parameter 3
    // format: float
    float reserved3;

    // Reserved Parameter 4
    // format: float
    float reserved4;

    // Reserved Parameter 5
    // format: float
    float reserved5;

    // Reserved Parameter 6
    // format: float
    float reserved6;

    // Reserved Parameter 7
    // format: float
    float reserved7;

    // Reserved Parameter 8
    // format: float
    float reserved8;

    // Reserved Parameter 9
    // format: float
    float reserved9;

    // Reserved Parameter 10
    // format: float
    float reserved10;

} DEPTH_TOP;

typedef struct DEPTH_REPROJECTION_TAG
{
    // Enables depth to motion vector conversion LUT
    // format: 1u
    uint32_t ctc_lmc_lut_en;

    // Depth to motion vector conversion LUT configuration
    // format: 11u
    uint32_t ctc_lmc_depth_min;

    // Depth to motion vector conversion LUT configuration
    // format: 11uQ6
    uint32_t ctc_lmc_depth_mult;

    // Depth to motion vector conversion LUT configuration
    // format: 12s
    int32_t ctc_lmc_lut_data[65];

} DEPTH_REPROJECTION;

typedef struct DEPTH_CALC_FOCUS_DISPARITY_TAG
{
    // Mode of operation:
    // 0 - Range
    // 1 - Average
    // 2 - Center
    // format: 8u
    uint32_t focused_disparity_calc_mode;

} DEPTH_CALC_FOCUS_DISPARITY;

typedef struct DEPTH_CALC_FOCUS_ROI_TAG
{
    // A value in the defocus map is considered "in focus" when it lies in the interval [min_focus_val,max_focus_val]
    // Must be <= max_focus_val
    // format: 16s
    int32_t min_focus_val;

    // A value in the defocus map is considered "in focus" when it lies in the interval [min_focus_val,max_focus_val]
    // Must be >= min_focus_val
    // format: 16s
    int32_t max_focus_val;

    // Blend factor for current and previous ROIs.
    // Close to 1 takes a lot from current frame and close to zero takes a lot from previous decision
    // format: float
    float smooth_alpha;

    // Minimum confidence value to participate in the focus ROI calc
    // format: 16u
    uint32_t min_valid_confidence;

    // largest filter size in focus map resolution
    // format: 8u
    uint32_t mask_size;

} DEPTH_CALC_FOCUS_ROI;

typedef struct Depth_Chromatix_v10_TAG
{
    DEPTH_TOP top;
    DEPTH_REPROJECTION reprojection;
    DEPTH_CALC_FOCUS_DISPARITY calc_focus_disparity;
    DEPTH_CALC_FOCUS_ROI calc_focus_roi;
} Depth_Chromatix_v10;

// ############ Functions ############
int32_t Validate_Depth_Chromatix_v10( const Depth_Chromatix_v10* regStruct );
void SetDefaultVal_Depth_Chromatix_v10( Depth_Chromatix_v10* regStruct );
// ###################################
#ifdef __cplusplus
}
#endif


#endif //__DEPTH_CHROMATIX_V10_H__
