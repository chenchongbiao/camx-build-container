// NOWHINE ENTIRE FILE
//-------------------------------------------------------------------------
// Copyright (c) 2017-2022 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
//------------------------------------------------------------------------

#ifndef __PROCESS_ICA_H__
#define __PROCESS_ICA_H__

#include "NcLibWarpCommonDef.h"
#include "ICA_Chromatix.h"
#include "NcLibContext.h"
#include "ipe_data.h"

#ifdef __cplusplus
extern "C" {
#endif

struct GeoLibIcaPassMapping;
struct GeoLib2IcaPassMapping;


enum NCLIB_YInterpolationMode
{
    NCLIB_YINTERPOLATIONMODE_NONE = 0,
    NCLIB_YINTERPOLATIONMODE_CATMAP = 1,
    NCLIB_YINTERPOLATIONMODE_DEPTHMAP = 2,

    NCLIB_YINTERPOLATIONMODE_NUM,
};


struct NcLibIcaContext
{
    uint32_t    numPasses;                              /**< Number of passes. */
    ImageFormat inputFormat[PASS_NAME_MAX];             /**< Image input format for each pass. */
    NcLibIcaLmcPassParams lmcPassParams[PASS_NAME_MAX]; /**< LMC parameters for each pass. */
    NCLIB_YInterpolationMode YInterpolationModeMap;     /**< Luma interpolation mode indication - Nearest Neighbor, CatMap, or Depth Map. */
};

struct NcLibIcaWarp
{
    // Grid value for x
    // format: 18sQ4
    int32_t CTC_GRID_X[3417];

    // Grid value for y
    // format: 18sQ4
    int32_t CTC_GRID_Y[3417];

    // mantissa of perspective param. Allowed values: -131071:-65536 | 0 | 65536:131071
    // format: 18s
    int32_t CTC_PERSPECTIVE_PARAMS_M[72];

    // exponent of perspective param
    // format: 6s
    int32_t CTC_PERSPECTIVE_PARAMS_E[72];

    // Depth to motion vector conversion LUT
    // format: 12s
    int32_t CTC_LMC_LUT_DATA[65];
};

/**
*  @brief   Legacy API to calculate ICA registers and FW struct.
*           Use ICA_ProcessNcLib2 unless need to use GeoLib1 mapping struct.
*/
int32_t ICA_ProcessNcLib(
    const ICA_Chromatix* chromatixStruct,
    const NcLibIcaGrid* chromatixGrid,
    const NcLibWarpGrid* inGridFlow,
    const NcLibWarpMatrices* persp,
    const GeoLibIcaPassMapping* geo,
    const NcLibIcaContext* context,
    uint8_t icaIsGridEnabledByFlow,
    uint32_t icaVersion,
    NcLibIcaWarp* warpStruct,
    IcaParameters* fwStruct,
    IcaPassParameters fwRegStruct[]);

/**
*  @brief   Calculate ICA registers and FW struct. Two revisions of the functions are provided:
*           1. Legacy version receives GeoLib1 mapping and does not output LMC FW struct
*           2. Newer version receives GeoLib2 mapping and outputs LMC FW struct
*
*  @param [in]      chromatixStruct             pointer to the pass Chromatix struct
*  @param [in]      chromatixGrid               pointer to grid from Chromatix, used if icaIsGridEnabledByFlow == 0.
*                                               If using LDC Chromatix 1.1 or above, use u2i_grid* from LDC Chromatix.
*                                               Else, if using ICA Chromatix v3.0 and below - use ld_u2i_grid* from ICA Chromatix.
*                                               For ICA v10, grid corners can be either in gridCorners[] or appended to grid[].
*  @param [in]      inGridFlow                  pointer to grid. Has to be grid of exact size of ICA grid :
*                                                 Napali (ICA v1.0): ICA_GRID_TRANSFORM_WIDTH_V10 x ICA_V10_GRID_TRANSFORM_HEIGHT
*                                                 Hana (ICA v2.0): ICA_V20_GRID_TRANSFORM_WIDTH x ICA_V20_GRID_TRANSFORM_HEIGHT
*                                                 Kona and Lahaina (ICA v3.0) - one of:
*                                                   ICA_V30_GRID_TRANSFORM_LOW_RES_WIDTH x ICA_V30_GRID_TRANSFORM_LOW_RES_HEIGHT
*                                                   ICA_V30_GRID_TRANSFORM_HI_RES_WIDTH x ICA_V30_GRID_TRANSFORM_HI_RES_HEIGHT
*  @param [in]      persp                       pointer to perspective transform matrices.
*                                               There are up to be max 9 matrices.
*  @param [in]      geo                         pointer to Multi-pass ICA geometrical mapping struct.
*  @param [in]      context                     SW context relevant for configuration
*  @param [in]      icaIsGridEnabledByFlow      indication if Grid is set by Chromatix or SW.
*                                               if it is set to 0, it is taken from Chromatix
*                                               else it is set by SW.
*  @param [in]      icaVersion                  ICA HW version: 10 for Napali, 20 for Hana, 20 or 30 for Kona and Lahaina, 40 for Waipio.
*                                               For Kailua both 41 (IPE ICAs) and 40 (EVA GCE) are used.
*                                               For Lanai 43.
*  @param [out]     warpStruct                  pointer to the ICA warp struct
*  @param [out]     fwStruct                    FW struct that is filled by the function.
*  @param [out]     fwRegStruct                 FW Registers structs for each pass that is filled by the function.
*
*  @return NC_LIB_SUCCESS in case of success, otherwise failed.
*/
int32_t ICA_ProcessNcLib2(
    const ICA_Chromatix* chromatixStruct,
    const NcLibIcaGrid* chromatixGrid,
    const NcLibWarpGrid* inGridFlow,
    const NcLibWarpMatrices* persp,
    const GeoLib2IcaPassMapping* geo,
    const NcLibIcaContext* context,
    uint8_t icaIsGridEnabledByFlow,
    uint32_t icaVersion,
    NcLibIcaWarp* warpStruct,
    IcaParameters* fwStruct,
    IcaPassParameters fwRegStruct[]);

/**
*  @brief   Gets the non-Chromatix parameters of ICA_ProcessNcLib and return true or false if they are valid for ICA
*
*  @param [in]      inGridFlow                  pointer to grid. Has to be grid of exact size of ICA grid :
*                                                 Napali (ICA v1.0): ICA_GRID_TRANSFORM_WIDTH_V10 x ICA_V10_GRID_TRANSFORM_HEIGHT
*                                                 Hana (ICA v2.0): ICA_V20_GRID_TRANSFORM_WIDTH x ICA_V20_GRID_TRANSFORM_HEIGHT
*                                                 Kona, Lahaina (ICA v3.0)  and Waipio (ICA v4.0) - one of:
*                                                   ICA_V30_GRID_TRANSFORM_LOW_RES_WIDTH x ICA_V30_GRID_TRANSFORM_LOW_RES_HEIGHT
*                                                   ICA_V30_GRID_TRANSFORM_HI_RES_WIDTH x ICA_V30_GRID_TRANSFORM_HI_RES_HEIGHT
*  @param [in]      persp                       pointer to perspective transform matrices.
*                                               There are up to be max 9 matrices.
*  @param [in]      icaIsGridEnabledByFlow      indication if Grid is set by Chromatix or SW.
*                                               if it is set to 0, it is taken from Chromatix (ICA_ProcessNcLib)
*                                               else it is set by SW (this function).
*  @param [in]      icaVersion                  ICA HW version: 10 for Napali, 20 for Hana, 20 or 30 for Kona and Lahaina, 40 for Waipio.
*                                               For Kailua both 41 (IPE ICAs) and 40 (EVA GCE) are used.
*                                               For Lanai 43.
*
*  @return NC_LIB_SUCCESS in case of success, otherwise failed.
*/
int32_t ValidateIcaNonChromatixParams(
    const NcLibWarpGrid* inGridFlow,
    const NcLibWarpMatrices* persp,
    uint8_t  icaIsGridEnabledByFlow,
    uint32_t icaVersion);


/**
*  @brief   Set default values for ICA FW struct
*
*  @param [out]     fwStruct               The FW struct that is set.
*  @param [in]      enable                 Whether to enable invalidPixelModeInterpolation and Perspective
*
*  @return void
*/
void SetDefaultsForIcaStruct(IcaParameters* fwStruct, bool enable = true);

/**
*  @brief   Get ICA version typical for current chip
*
*  @return 10 for Napali, 20 for Hana, 30 for Kona and Lahaina, 40 for Waipio, 41 for Kailua, 43
*  for Lanai.
*/
uint32_t NcLibGetIpeIcaVersion();

#ifdef __cplusplus
}
#endif


#endif //__PROCESS_ICA_H__
