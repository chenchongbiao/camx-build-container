// NOWHINE ENTIRE FILE
//-------------------------------------------------------------------------
// Copyright (c) 2017-2023 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
//------------------------------------------------------------------------


#ifndef __ICA_CHROMATIX_H__
#define __ICA_CHROMATIX_H__

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct ICA_TOP_TAG
{
    // 0: 4x4 kernel
    // 1: Bi-linear (2x2)
    // 2: Nearest - supported only from v41 (this setting is not allowed in previous versions).
    // format: 2u
    uint32_t y_interpolation_type;

} ICA_TOP;

typedef struct ICA_CTC_TAG
{
    // 0: Disabled, 1: Enabled
    // format: 1u
    uint32_t ctc_transform_grid_enable;

    // Used by LMC 1:4 to 1:1 upscaler, defines the amount of blending between distant motion vectors.
    // When CTC_TRANSFORM_LMC_MODE != 5, this field is don't care.
    // Relevant for ica v43 instances and above.
    // format: 4u
    uint32_t ctc_lmc_blend_level;

} ICA_CTC;

typedef struct ICA_OPG_TAG
{
    // 0: Out-of-frame pixel is populated with a predefined value.
    // 1: Out-of-frame pixel is populated using duplication.
    // format: 1u
    uint32_t opg_invalid_output_treatment_calculate;

    // Y Output sample values for out-of-input-frame pixels, in case opg_invalid_output_treatment_calculate is equal to 0.
    // format: 16u
    uint32_t opg_invalid_output_treatment_y;

    // Cb Output sample values for out-of-input-frame pixels, in case opg_invalid_output_treatment_calculate is equal to 0.
    // format: 16u
    uint32_t opg_invalid_output_treatment_cb;

    // Cr Output sample values for out-of-input-frame pixels, in case opg_invalid_output_treatment_calculate is equal to 0.
    // format: 16u
    uint32_t opg_invalid_output_treatment_cr;

    // LUT(0)
    // format: 14s
    int32_t opg_interpolation_lut_0[16];

    // LUT(1)
    // format: 14s
    int32_t opg_interpolation_lut_1[16];

    // LUT(2)
    // format: 14s
    int32_t opg_interpolation_lut_2[16];

} ICA_OPG;

typedef struct ICA_Chromatix_TAG
{
    ICA_TOP top;
    ICA_CTC ctc;
    ICA_OPG opg;
    // Full pass X threshold to use nearest neighbor in coordinate generation instead of bicubic and bilinear
    // format: 8u
    uint32_t full_ctc_diff_thr_x;

    // Full pass Y threshold to use nearest neighbor in coordinate generation instead of bicubic and bilinear
    // format: 8u
    uint32_t full_ctc_diff_thr_y;

    // DC4 pass X threshold to use nearest neighbor in coordinate generation instead of bicubic and bilinear
    // format: 8u
    uint32_t dc4_ctc_diff_thr_x;

    // DC4 pass Y threshold to use nearest neighbor in coordinate generation instead of bicubic and bilinear
    // format: 8u
    uint32_t dc4_ctc_diff_thr_y;

    // DC16 pass X threshold to use nearest neighbor in coordinate generation instead of bicubic and bilinear
    // format: 8u
    uint32_t dc16_ctc_diff_thr_x;

    // DC16 pass Y threshold to use nearest neighbor in coordinate generation instead of bicubic and bilinear
    // format: 8u
    uint32_t dc16_ctc_diff_thr_y;

    // DC64 pass X threshold to use nearest neighbor in coordinate generation instead of bicubic and bilinear
    // format: 8u
    uint32_t dc64_ctc_diff_thr_x;

    // DC64 pass Y threshold to use nearest neighbor in coordinate generation instead of bicubic and bilinear
    // format: 8u
    uint32_t dc64_ctc_diff_thr_y;

    // Reserved parameter 1
    // format: float
    float res_param_1;

    // Reserved parameter 2
    // format: float
    float res_param_2;

    // Reserved parameter 3
    // format: float
    float res_param_3;

    // Reserved parameter 4
    // format: float
    float res_param_4;

    // Reserved parameter 5
    // format: float
    float res_param_5;

    // Reserved parameter 6
    // format: float
    float res_param_6;

    // Reserved parameter 7
    // format: float
    float res_param_7;

    // Reserved parameter 8
    // format: float
    float res_param_8;

    // Reserved parameter 9
    // format: float
    float res_param_9;

    // Reserved parameter 10
    // format: float
    float res_param_10;

    // Reserved Lut parameter 1
    // format: float
    float res_lut_param_1[32];

    // Reserved Lut parameter 2
    // format: float
    float res_lut_param_2[32];

} ICA_Chromatix;

// ############ Functions ############
int32_t Validate_ICA_Chromatix( const ICA_Chromatix* regStruct, uint32_t hwVersion );
void SetDefaultVal_ICA_Chromatix( ICA_Chromatix* regStruct, uint32_t hwVersion );
// ###################################
#ifdef __cplusplus
}
#endif


#endif //__ICA_CHROMATIX_H__
