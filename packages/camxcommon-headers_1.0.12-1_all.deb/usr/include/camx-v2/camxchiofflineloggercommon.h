////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2019, 2022 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @file  camxchiofflineloggercommon.h
/// @brief Debug Print related defines
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef CAMXCHIOFFLINELOGGERCOMMON_H
#define CAMXCHIOFFLINELOGGERCOMMON_H

// NOWHINE FILE NC004c: No CamX prefix since we're including in both CamX and CHI-CDK

#define OFFLINELOG_MAX_TYPE (static_cast<UINT>(OfflineLoggerType::NUM_OF_TYPE))

// Offline logger status
enum class OfflineLoggerStatus
{
    ACTIVE,          ///< Offlinelogger is active mode
    CAMERA_CLOSING,  ///< Offlinelogger is a special mode while camera close.
    DISABLE          ///< Offlinelogger is disable
};

// Offline logger type
enum class OfflineLoggerType
{
    ASCII,           ///< Offlinelogger type for ASCII
    BINARY,          ///< Offlinelogger type for Binary
    COREDUMP_TEXT,   ///< Offlinelogger type for Text Coredump
    COREDUMP_BINARY, ///< Offlinelogger type for Binary Coredump
    NUM_OF_TYPE      ///< Calculate total number of offlinelogger type, do not remove it
};

#endif // CAMXCHIOFFLINELOGGERCOMMON_H
