// NOWHINE ENTIRE FILE
//-------------------------------------------------------------------------
// Copyright (c) 2017-2023 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
//------------------------------------------------------------------------

#ifndef __COMMON_DEFS_H__
#define __COMMON_DEFS_H__

#include <stdio.h>
#include <stdint.h>
#include <inttypes.h>

/** Return Values */
#define NC_LIB_SUCCESS                  (0)                             /**< Success return value */

#define NC_LIB_ERRORE_BASE              (0x04000000)
#define NC_LIB_GENERAL_ERROR            (NC_LIB_ERRORE_BASE + 1)        /**< General error return value */
#define NC_LIB_INVALID_INPUT            (NC_LIB_ERRORE_BASE + 2)        /**< Invalid input */

#define NC_LIB_WARN_INVALID_INPUT       (NC_LIB_ERRORE_BASE + 0x100)    /**< Warning: Invalid input, possible performance or IQ degradation*/

// PASS_TYPE is the power of 4 of the scale of the pass. 4^PASS_TYPE. example: 4^0 = 1. example: 4^3 = 64.
typedef enum
{
    PASS_TYPE_FULL = 0,
    PASS_TYPE_DC4  = 1,
    PASS_TYPE_DC16 = 2,
    PASS_TYPE_DC64 = 3,
    PASS_TYPE_NUM
} PASS_TYPE;

///////////////////////////////////////////////////
// Common struct definitions                     //
///////////////////////////////////////////////////

/** Two dimensional coordinate or window */
typedef struct NcLibImageSize_t
{
    uint32_t                    widthPixels;        /**< can be coordinate or window width   */
    uint32_t                    heightLines;        /**< can be coordinate or window height  */
} NcLibImageSize;

/** ROI or zoom window */
typedef struct NcLibWindowRegion_t
{
    uint32_t    fullWidth;
    uint32_t    fullHeight;
    int32_t     windowLeft;
    int32_t     windowTop;
    uint32_t    windowWidth;
    uint32_t    windowHeight;
} NcLibWindowRegion;

/**< Two dimensional coordinate or window */
typedef struct NcLibFloat2_t
{
    float          x;                      /**< coordinate or window width   */
    float          y;                      /**< coordinate or window height  */
} NcLibFloat2;

/**< Fractional ROI or FOV rectangle on an image domain */
typedef struct NcLibROI_t
{
    NcLibImageSize imageSize;
    NcLibFloat2    offset;                 /**< offset from the image top-left corner to the ROI top-left corner */
    NcLibFloat2    size;                   /**< ROI size */
} NcLibROI;

#endif
