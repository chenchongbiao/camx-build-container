////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2019-2023 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @file  camxcommondecltypes.h
/// @brief Common type declarations
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef CAMXCOMMONDECLTYPES_H
#define CAMXCOMMONDECLTYPES_H

// NOWHINE CP006: Need whiner update: allow std::map
#include <map>
#include <vector>
#include <list>
#include <unordered_map>
#include "camxdefs.h"

CAMX_NAMESPACE_BEGIN


///< This forward declaration will help to decouple dependency on header file
class  HAL3Stream;
typedef HAL3Stream  ChiStreamWrapper;

/// @brief resourceId, deviceId pair
typedef std::pair<UINT32, UINT32> ResourceIdDeviceIdPair;

/// @brief ResourceIdDeviceIdPair to cost map
// NOWHINE CP006: Need whiner update: allow std::map
typedef std::map<ResourceIdDeviceIdPair, UINT32> ResourceCostMap;

/// @brief resource type
enum ResourceType
{
    SensorHw             = 1,       ///< Sensor HW resource type
    IFEHw                = 2,       ///< IFE resource type
    TFEHw                = IFEHw,   ///< TFE HW resource type
    IPEHw                = 3,       ///< IPE resource type
    BPSHw                = 4,       ///< BPS resource type
    CSIPHYHw             = 5,       ///< CSIPHY HW resource type
    AONI2C               = 6,       ///< AON I2C resource type
    ResourceTypeMax      = 7,       ///< Maximum Value for Resource Type.
    Reserved             = 100,     ///< Values [0-100] are reserved for internal use.
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// IFETYPE
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
enum IFETYPE
{
    IFETYPE_NORMAL = 0,   ///< default IFE
    IFETYPE_LITE,         ///< IFE Lite

    IFETYPE_COUNT         ///< Max
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// IPETYPE
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
enum IPETYPE
{
    IPETYPE_NORMAL = 0,   ///< IPE
};


CAMX_NAMESPACE_END

#endif // CAMXCOMMONDECLTYPES_H
