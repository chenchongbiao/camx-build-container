// NOWHINE ENTIRE FILE
//-------------------------------------------------------------------------
// Copyright (c) 2021 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
//------------------------------------------------------------------------


#ifndef __DME_CHROMATIX_V30_H__
#define __DME_CHROMATIX_V30_H__

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct DME_Chromatix_v30_TAG
{
    // Enable image based registration
    // format: 1u
    uint32_t image_based_alignment_enable;

    // Maximum allowed NCC If NCC exceeds this threshold the block will be marked invalid (probably ME problem due to occlusion, too fast motion, etc).
    // format: 11u
    uint32_t robustness_max_allowed_ncc;

    // Minimum allowed tar variance value. If below this value (non-informative block) - the block will be marked invalid.
    // format: 16u
    uint32_t robustness_min_allowed_tar_var;

    // Locations with NCC difference below this threshold are considered to have exactly the same similarity measure
    // format: 11u
    uint32_t robustness_meaningful_ncc_diff;

    // Provides a requirement on minimal normalized difference of SADs at distance 1-8 pixels (for big distances the expected differences should be big). Default values: 0, 128, 128, 128, 128, 128, 128, 128 (no penalty to single pixel distance; afterwards same penalty for all other distances)
    // format: 9u
    uint32_t robustness_measure_dist_map[8];

    // Enable 5x5 filtering before calculating descriptor
    // format: 1u
    uint32_t descriptor_lpf;

    // Control the sensitivity of the harris detector to edge vs corner. Reasonable values [10 , 32]. Lower value recognize "less significant" corner.
    // format: 8u
    uint32_t fpx_kappa;

    // Corner with Harris measure value lower than this value will be ignored.
    // format: 32u
    uint32_t fpx_threshold;

    // Hamming distance between two descriptors below which the blocks are considered as match.
    // Camera SW Should force the number to be module 4.
    // format: 8u
    uint32_t desc_match_threshold;

    // Robustness value above indicate valid Motion vector.
    // format: 4s
    int32_t robustness_threshold;

    // Enabling inlier tracking, Improve decision's coherency between frames.
    // format: 1u
    uint32_t inlier_track_enable;

    // Defines which transform model to use during transform estimation stage (0=projective, 1=affine, 2=rigid, 4-AutoDetect )
    // format: 2u
    uint32_t transform_model;

    // L2 distacne between model estimation and measured motion vector below which MV will be considered as inlier.
    // format: float
    float model_match_thr;

    // This Parameter is relevant for multi frame flows. The parameter defines the input resolution of the alignment process. 0:1440p, 1:1280p, 2:1080p, 3:960p, 4:720p, 5:540p 6:270p. If requested resolution width is > 1920, the largest resolution with width <=1920 will be used.
    // format: 4u
    uint32_t multi_frame_input_resolution;

    // In order to reduce the noise level, extra down scale is performed before registration. The parameter sets the downscale ratio. In case value == 1 no downscaling is done before registration.
    // format: float
    float down_scale_ratio;

    // Identity transform detection mode: 0 - disabled, 1 : 4 predefine calibration. 1- tend to avoid identity detection, 4 - detect identity in more permissive way. 5- expert mode, in this mode identity detection will use directly the identity_detect_* parameters.
    // format: 4u
    uint32_t auto_identity_detect_mode;

    // Enabling Identity detection - relevant only if auto_detect_Identity_mode == 5
    // format: 1u
    uint32_t identity_detect_enable;

    // consistency measure above which the motion is not considered as identity - relevant only if auto_detect_Identity_mode == 5
    // format: 7u
    uint32_t identity_detect_consistency_mesure_th;

    // relevant only if auto_detect_Identity_mode == 5.
    // format: float
    float identity_detection_mvs_avg_size_th;

    // Threshold percentage of big motion vector that was used to calculate the transform. Above this percentage threshold the motion is not considered as identity- relevant only if auto_detect_Identity_mode == 5.
    // format: 17u
    uint32_t identity_detect_big_mvs_percent_th;

    // Enforce temporal consistency - if identify less than "parameter" out 5 frames the transform is not considered as identity - relevant only if auto_detect_Identity_mode == 5
    // format: 7u
    uint32_t identity_detect_temporal_consistency;

    // Threshold over transform complexity( significant rotation/perspective), identity transform is considered only if complexity is less than threshold - relevant only if auto_detect_Identity_mode == 5- relevant only if auto_detect_Identity_mode == 5
    // format: 10u
    uint32_t identity_detect_complexity_th;

    // Threshold over the number of Motion vector that are in use, identity transform is considered only if number of motion vector is less than threshold - relevant only if auto_detect_Identity_mode == 5
    // format: 10u
    uint32_t identity_detect_max_num_mvs_th;

    // Enabling screening obvious motion outlier vector based on size
    // format: 1u
    uint32_t motion_vector_screen_enable;

    // Enabling motion vector screening only if motion vector std is larger than motion_vector_screen_min_std_th
    // format: float
    float motion_vector_screen_min_std_th;

    // Reject motion vector which are longer than median by motion_vector_screen_std_factor_th times std
    // format: float
    float motion_vector_screen_std_factor_th;

    // conf1
    // format: float
    float conf1;

    // conf2
    // format: float
    float conf2;

    // conf3
    // format: float
    float conf3;

    // conf4
    // format: float
    float conf4;

    // conf5
    // format: float
    float conf5;

    // gain factor to improve contrast
    // format: float
    float contrast_gain_factor;

    // reserved1
    // format: float
    float reserved1;

    // reserved2
    // format: float
    float reserved2;

    // reserved3
    // format: float
    float reserved3;

    // reserved4
    // format: float
    float reserved4;

    // reserved5
    // format: float
    float reserved5;

    // filtering setting in CVP ICA
    // format: float
    float ica_filtering;

} DME_Chromatix_v30;

// ############ Functions ############
int32_t Validate_DME_Chromatix_v30( const DME_Chromatix_v30* regStruct );
void SetDefaultVal_DME_Chromatix_v30( DME_Chromatix_v30* regStruct );
// ###################################
#ifdef __cplusplus
}
#endif


#endif //__DME_CHROMATIX_V30_H__
