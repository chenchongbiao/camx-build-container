// NOWHINE ENTIRE FILE
//-------------------------------------------------------------------------
// Copyright (c) 2020-2022 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
//------------------------------------------------------------------------


#ifndef __SGM_CHROMATIX_V10_H__
#define __SGM_CHROMATIX_V10_H__

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct SGM_Chromatix_v10_TAG
{
    // 0-Disable SLIC block
    // 1-Enable SLIC block
    // If SLIC_EN = 1, then SLIC_EXT_IN must be 0
    // format: 1u
    uint32_t slic_en;

    // Enable 3x3 average filter in Descriptor block.
    // 0-Disable Descriptor 3x3 average filter
    // 1-Enable Descriptor 3x3 average filter
    // format: 1u
    uint32_t descriptor_avg_en;

    // Enable median filter block.
    // 0-Bypass median filter block
    // 1-Enable median filter block
    // format: 1u
    uint32_t median_en;

    // Relevant for DFS pass only.
    // Enable post-processing adaptive median/block filter block.
    // 0: Bypass mode;
    // 1: Enable adaptive median;
    // Ignored unless HOLE_FILL_EN is set to 0 or 1 and MODE is set to 0 or 3.
    // format: 1u
    uint32_t dfs_adap_median_en;

    // Relevant only for 1:1 and DS4 modes.
    // Enable global fallback block.
    // 0-Bypass global fallback block
    // 1-Enable global fallback block
    // format: 1u
    uint32_t global_fallback_en;

    // Relevant only for 1:1 mode.
    // Indicate whether coherence detector for global fallback is enabled. Ignored when GLOBAL_FALLBACK_EN=0
    // 0: Disable
    // 1: Enable
    // format: 1u
    uint32_t gf_coherency_en;

    // Relevant only for 1:1 mode.
    // Indicate whether coherence Morphology filter is enabled. Ignored when GLOBAL_FALLBACK_EN=0 or COHERENCY_EN=0
    // 0: Disable
    // 1: Enable
    // format: 1u
    uint32_t gf_coherency_morph_en;

    // Relevant only for 1:1 and DS4 modes.
    // Indicate whether spatial IIR filter for global fallback is enabled. Ignored when GLOBAL_FALLBACK_EN=0
    // 0: Disable
    // 1: Enable
    // format: 1u
    uint32_t gf_iir_filter_en;

    // Relevant only for 1:1 and DS4 modes.
    // Indicate whether SAD detector for global fallback is enabled. Ignored when GLOBAL_FALLBACK_EN=0
    // 0: Disable
    // 1: Enable
    // Required to be the same value as GF_ALPHA_BLEND_EN
    // format: 1u
    uint32_t gf_sad_en;

    // Relevant only for 1:1 and DS4 modes.
    // Indicate whether morphology filter on SAD detector for global fallback is enabled. Ignored when GLOBAL_FALLBACK_EN=0 or GF_SAD_EN=0
    // 0: Disable
    // 1: Enable
    // format: 1u
    uint32_t gf_sad_morph_en;

    // Relevant only for 1:1 and DS4 modes.
    // Indicate whether box filter for global fallback is enabled. Ignored when GLOBAL_FALLBACK_EN=0
    // 0: Disable
    // 1: Enable
    // format: 1u
    uint32_t gf_box_filter_en;

    // Threshold in SLIC block, value=m/s*8
    // format: 6u
    uint32_t slic_th;

    // This field is DFS only.
    // 0: search left to right;
    // 1: search right to left
    // format: 1u
    uint32_t dfs_direction;

    // This field is DFS only.
    // 0: no vertical search;
    // 1: +-3 vertical search
    // format: 1u
    uint32_t dfs_vertical;

    // Threshold for flatness check in SGM block.
    // format: 3u
    uint32_t flatness_th;

    // Default P1 value
    // format: 6u
    uint32_t p1_init;

    // P1 value if edge detection is true
    // format: 6u
    uint32_t p1_edge;

    // P1 value if smooth detection is true
    // format: 6u
    uint32_t p1_smooth;

    // Default P2 value, P2_INIT value should be larger than or equal to P1_INIT
    // format: 7u
    uint32_t p2_init;

    // P2 value if edge detection is true, P2_EDGE value should be larger than or equal to P1_EDGE
    // format: 7u
    uint32_t p2_edge;

    // P2 value if smooth detection is true, P2_SMOOTH should be larger than or equal to P1_SMOOTH
    // format: 7u
    uint32_t p2_smooth;

    // Relevant for DFS pass only.
    // Threshold offset for MV variance.
    // format: 2u
    uint32_t dfs_conf_th_offset_mvvar;

    // Relevant for DFS pass only.
    // Weight parameter used in confidence combine block to generate final 8 bit confidence.
    // conf_weight restriction: dfs_conf_weight_occ + dfs_conf_weight_mvvar + dfs_conf_weight_flat <= 32
    // format: 6u
    uint32_t dfs_conf_weight_occ;

    // Relevant for DFS pass only.
    // Weight parameter used in confidence combine block to generate final 8 bit confidence.
    // conf_weight restriction: dfs_conf_weight_occ + dfs_conf_weight_mvvar + dfs_conf_weight_flat <= 32
    // format: 6u
    uint32_t dfs_conf_weight_mvvar;

    // Relevant for DFS pass only.
    // Weight parameter used in confidence combine block to generate final 8 bit confidence
    // conf_weight restriction: dfs_conf_weight_occ + dfs_conf_weight_mvvar + dfs_conf_weight_flat <= 32
    // format: 6u
    uint32_t dfs_conf_weight_flat;

    // Relevant for DFS pass only.
    // High confidence threshold used in holefilling
    // format: 8u
    uint32_t dfs_hf_conf_th_h;

    // Relevant for DFS pass only.
    // Fill confidence threshold used in holefilling
    // format: 8u
    uint32_t dfs_hf_conf_th_f;

    // Relevant for DFS pass only.
    // Parameters used to right shift all valid counter
    // format: 2u
    uint32_t dfs_hf_min_valid;

    // Relevant for DFS pass only.
    // Indicate whether to override to 0 if no valid super pixel value to be filled with
    // format: 1u
    uint32_t dfs_hf_override_en;

    // Relevant for DFS pass only.
    // Confidence threshold used in adaptive median filter
    // format: 8u
    uint32_t dfs_am_conf_th;

    // Threshold in illumination change detection. Refer to HDD section
    // Range: 0 to 1023 when ILLUM_CHANGE_TH_PREC = 10
    // Range: 0 to 4095 when ILLUM_CHANGE_TH_PREC = 12
    // format: 12u
    uint32_t illum_change_th;

    // Define the fractional precision
    // format: 4u
    uint32_t illum_change_th_prec;

    // Define minimal intensity range threshold to allow normalization
    // format: 8u
    uint32_t min_range_th;

    // Define minimal intensity range difference threshold to allow normalization
    // format: 8u
    uint32_t min_range_diff_th;

    // Effective threshold value for eigen value ratio condition
    // format: 15uQ10
    uint32_t valid_div_th;

    // Define the minimal eigenvalue threshold
    // format: 10u
    uint32_t valid_min_eig_th;

    // Control the behavior in case of non-valid optical flow result.
    // 0:  OF result is used nonetheless;
    // 1: USE_ZERO - zero MV is used;
    // 2: USE_SGM - Input SGM sub pixel MV is used
    // format: 2u
    uint32_t non_valid_fallback;

    // Define the threshold to detect close MVs to enable IIR filter
    // format: 12u
    uint32_t spatial_iir_th;

    // Center pixel neighbors (#0, #1, #3) weight
    // format: 3u
    uint32_t spatial_iir_neighbor_weight;

    // Define the Global SAD vs Frac SAD Threshold
    // format: 15u
    uint32_t sad_detect_sad_th;

    // Small global SAD value threshold
    // format: 15u
    uint32_t sad_detect_small_sad_th;

    // Factor blend for SAD detected MVs
    // format: 11u
    uint32_t global_blend_value;

    // Global Blend LUT
    // format: 11u
    uint32_t global_blend_lut[17];

    // Relevant only for 1:1
    //
    // Define threshold used for detail detection
    // format: 16u
    uint32_t detail_detect_th;

    // Reference Image Descriptor noise threshold scale (scale*Luma+offset)
    // format: float
    float noise_scale_ref;

    // Reference Image Descriptor noise threshold offset (scale*Luma+offset)
    // format: 7u
    uint32_t noise_offset_ref;

    // Target Image Descriptor noise threshold scale (scale*Luma+offset)
    // format: float
    float noise_scale_curr;

    // Target Image Descriptor noise threshold offset (scale*Luma+offset)
    // format: 7u
    uint32_t noise_offset_curr;

    //  MV pruning mode in SGM candidate search:
    // 0 - Spatial>DS4>(0,0)
    // 1 - Spatial>(0,0)>DS4
    // 2- (0,0)>Spatial>DS4
    // 3- (0,0)>DS4>Spatial
    // format: 2u
    uint32_t mv_pruning_mode;

    // Coherency bucket threshold
    // format: 7u
    uint32_t non_coherent_th[5];

    // Define the coherency bucket boundaries
    // format: 10u
    uint32_t non_coherent_index_th[5];

    // 0: SGM_PASS_1_1
    // 1: SGM_PASS_1_4
    // 2: SGM_PASS_COFIDENCE
    // 3: SGM_PASS_DFS
    // format: 2u
    uint32_t pass_type;

    // Enable adaptive layer
    // 0: Disable adaptive
    // 1: Enable adaptive
    // format: 1u
    uint32_t adap_en;

    // Threshold used for edge detection
    // format: 5u
    uint32_t adap_edge_th;

    // Threshold used for smooth detection
    // format: 4u
    uint32_t adap_smooth_th;

    // Relevant for DFS pass only.
    // Enable post-processing hole-filling/factional mv block.
    // 0: Bypass mode;
    // 1: Enable hole filling;
    // format: 2u
    uint32_t dfs_hole_fill_en;

    // Reserved Parameter 1
    // format: float
    float reserved1;

    // Reserved Parameter 2
    // format: float
    float reserved2;

    // Reserved Parameter 3
    // format: float
    float reserved3;

    // Reserved Parameter 4
    // format: float
    float reserved4;

    // Reserved Parameter 5
    // format: float
    float reserved5;

    // Reserved Parameter 6
    // format: float
    float reserved6;

    // Reserved Parameter 7
    // format: float
    float reserved7;

    // Reserved array parameter 1
    // format: float
    float reserved_arr_1[10];

    // Reserved array parameter 2
    // format: float
    float reserved_arr_2[10];

} SGM_Chromatix_v10;

// ############ Functions ############
int32_t Validate_SGM_Chromatix_v10( const SGM_Chromatix_v10* regStruct );
void SetDefaultVal_SGM_Chromatix_v10( SGM_Chromatix_v10* regStruct );
// ###################################
#ifdef __cplusplus
}
#endif


#endif //__SGM_CHROMATIX_V10_H__
