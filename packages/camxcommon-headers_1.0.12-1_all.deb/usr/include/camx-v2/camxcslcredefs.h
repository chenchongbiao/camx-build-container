////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2021 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @file  camxcslcredefs.h
/// @brief CRE Hardware Interface Definiation
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef CAMXCSLCREDEFS_H
#define CAMXCSLCREDEFS_H

#include "camxcsl.h"
#include "camxcslresourcedefs.h"
#include "camxdefs.h"

CAMX_BEGIN_PACKED

static const UINT CREDevNameSize   = 128;

static const UINT CreHwTypeCre     = 1;
static const UINT CreHwTypeMax     = 1;

static const UINT CREInputImage      = 1;
static const UINT CREInputImageMax   = 2;
static const UINT CREOutputImage     = 1;
static const UINT CREOutputImageMax  = 2;

static const UINT CREMaxPlanes    = 2;
static const UINT CREMaxBatchSize = 16;

static const UINT CREDevTypeNrt    = 1;
static const UINT CREDevTypeRt     = 2;
static const UINT CREDevTypeMax    = 3;

static const UINT CSLCREMetaGenericBlob = 1;
static const UINT CSLCREGenericBlobCmdBufferClkV2 = 1;

/// @brief CRE hardware version information
struct CSLCREDeviceVersion
{
    CSLVersion  version;    ///< Device version
} CAMX_PACKED;

/// @brief CRE resource characteristics (dimension and format) information
struct CSLCREResourceInfo
{
    UINT32      direction;  ///< Image direction
    UINT32      resId;      ///< Image ResId
    UINT32      numPlanes;  ///< Number of planes
    UINT32      width;      ///< Image width
    UINT32      height;     ///< Image height
    UINT32      stride;     ///< Image stride
    UINT32      fence;      ///< Fence
    UINT32      format;     ///< Image format
    UINT32      alignment;  ///< Alignment
    UINT32      reserved;   ///< Reserve field
} CAMX_PACKED;

/// @brief CRE acquire device information
struct CSLCREAcquireDeviceInfo
{
    CHAR                  devName[CREDevNameSize];            ///< Device name
    UINT32                devType;                            ///< Resource type (RT NRT)
    UINT32                secureFlag;                        ///< Input frame is secure buf or not
    UINT32                batchSize;                          ///< Batch size
    UINT32                numInRes;                           ///< Number of input resource
    UINT32                numOutRes;                          ///< Number of output resource
    UINT32                reserved;                           ///< Reserved field
    CSLCREResourceInfo    inputResource[CREInputImageMax];    ///< Input resource info struct
    CSLCREResourceInfo    outputResource[CREInputImageMax];   ///< Output resource info struct
} CAMX_PACKED;

/// @brief CRE clock and bandwidth request
struct CSLCREClockBandwidthRequest
{
    UINT64               budgetNS;         ///< Maximum duration to process a frame in Nano Seconds
    UINT32               frameCycles;      ///< FrameCycles Info
    UINT32               realtimeFlag;     ///< Flag for Realtime stream
    UINT32               reserved;         ///< Reserved field
    UINT32               numPaths;         ///< Flag for Realtime stream
    CSLAXIperPathBWVote  axiPath[1];       ///< Per path axi vote info
} CAMX_PACKED;
#endif // CAMXCSLCREDEFS_H
