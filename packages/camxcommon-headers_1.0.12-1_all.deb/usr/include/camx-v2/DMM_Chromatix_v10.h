// NOWHINE ENTIRE FILE
//-------------------------------------------------------------------------
// Copyright (c) 2020-2021 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
//------------------------------------------------------------------------


#ifndef __DMM_CHROMATIX_V10_H__
#define __DMM_CHROMATIX_V10_H__

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct DMM_TOP_V10_TAG
{
    // Enable image based registration ( Previously image_based_alignment_enable)
    // format: 1u
    uint32_t enable;

    // Enable Dense image based registration
    // format: 1u
    uint32_t dense_image_based_alignment_enable;

    // Reserved Parameter 1
    // format: float
    float reserved1;

    // Reserved Parameter 2
    // format: float
    float reserved2;

    // Reserved Parameter 3
    // format: float
    float reserved3;

    // Reserved Parameter 4
    // format: float
    float reserved4;

    // Reserved Parameter 5
    // format: float
    float reserved5;

    // Reserved Parameter 6
    // format: float
    float reserved6;

    // Reserved Parameter 7
    // format: float
    float reserved7;

    // Reserved Parameter 8
    // format: float
    float reserved8;

    // Reserved Parameter 9
    // format: float
    float reserved9;

    // Reserved Parameter 10
    // format: float
    float reserved10;

} DMM_TOP_V10;

typedef struct DMM_FUSION_V10_TAG
{
    // Alignment mode
    // 0: image based only
    // 1: gyro based only
    // 2: auto calculate
    // format: 2u
    uint32_t mode ;

    // RANSAC confidence high threshold.
    // Will switch from gyro to image based only if RANSAC confidence is above this threshold.
    // If both image_conf_high_threshold and image_conf_low_threshold are both equal to 257, gyro based alignment is always taken. If both of these parameters are set to -1, image based alignment is always taken.
    // format: 10s
    int32_t image_conf_high_threshold;

    // Low threshold of RANSAC confidence.
    // Will switch from image based to gyro only if RANSAC confidence is below this threshold.
    // If both image_conf_high_threshold and image_conf_low_threshold are both equal to 257, gyro based alignment is always taken. If both of these parameters are set to -1, image based alignment is always taken.
    // format: 10s
    int32_t image_conf_low_threshold ;

    // Threshold in pixels in 8Kx6K resolution. Absolute motion below this value will be considered as no motion
    // format: float
    float absolute_motion_threshold ;

    // Threshold above which absolute motion is valid.
    // format: 9u
    uint32_t absolute_motion_confidence_threshold ;

    // Threshold below which need to avoid dense alignment, ignoring age based hysteresis.
    // format: float
    float sgm_conf_force_disable_dense_threshold;

    // If SGM confidence is below this threshold, it is no "good" SGM activation.
    // format: float
    float sgm_confidence_low_threshold;

    // If SGM confidence is above this threshold, it is "good" SGM activation if SGM age is big enough.
    // format: float
    float sgm_confidence_high_threshold;

    // Threshold below which global image based transform is ignored.
    // format: float
    float sgm_global_detail_low_threshold;

    // Threshold above which global image based alignment is valid.
    // format: float
    float sgm_global_detail_high_threshold;

    // When calculated transform confidence (before mapping) is below this threshold, the transform is ignored and replaced by identity transform.
    // format: 9u
    uint32_t transform_confidence_thr_to_force_identity_transform;

    // Threshold over SGM confidence, below which image based alignment is forced to be identity transform.
    // format: float
    float sgm_conf_thr_to_force_identity_transform;

    // When calculated transform confidence (before mapping) is below this threshold, the transform is ignored and replaced by identity transform. Hysteresis is used on this parameter to avoid excessive switching
    // format: 9u
    uint32_t gyro_transform_confidence_thr_to_force_identity_transform;

    // Time hysteresis - for switch between image based alignment to gyro based alignment. This parameter defines the number of frame needed to pass before the algorithm can switch back to gyro based alignment.
    // format: 32u
    uint32_t image_to_gyro_min_age_threshold;

    // Time hysteresis - for switch between gyro based alignment to image based alignment. This parameter defines the number of frame needed to pass before the algorithm can switch back to image based alignment.
    // format: 32u
    uint32_t gyro_to_image_min_age_threshold;

    // SGM threshold set in Chromatix. Defines the minimal age to enable SGM. Will enable SGM after enabling_sgm_min_age_threshold "good" SGM frame.
    // format: 32u
    uint32_t enabling_sgm_min_age_threshold;

    // SGM threshold set in Chromatix. Define the minimal age to disable SGM. Will disable SGM after ignoring_sgm_min_age_threshold "bad" SGM frame.
    // format: 32u
    uint32_t ignoring_sgm_min_age_threshold;

    // SGM threshold set in Chromatix. Define the number of consecutive good SGM frames needed before moving back to SGM (>= 1). Should be smaller or equal to 0xFFFFFFFD.
    // format: 32u
    uint32_t consecutive_good_sgm_frames_threshold;

    // Confidence to be set in case identity transform was detected by "identity detection" algorithm
    // format: 9u
    uint32_t confidence_auto_identity_detect;

} DMM_FUSION_V10;

typedef struct DMM_Chromatix_v10_TAG
{
    DMM_TOP_V10 top;
    DMM_FUSION_V10 fusion;
} DMM_Chromatix_v10;

// ############ Functions ############
int32_t Validate_DMM_Chromatix_v10( const DMM_Chromatix_v10* regStruct );
void SetDefaultVal_DMM_Chromatix_v10( DMM_Chromatix_v10* regStruct );
// ###################################
#ifdef __cplusplus
}
#endif


#endif //__DMM_CHROMATIX_V10_H__
