////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2020-2023 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @file  bitmlengineinterfacev2.h
/// @brief Interface definition for BITMLEngine
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef BITMLENGINEINTERFACEV2_H
#define BITMLENGINEINTERFACEV2_H

#include "camxdefs.h"

CAMX_NAMESPACE_BEGIN
#ifdef __cplusplus
extern "C"
{
#endif // end of #ifdef __cplusplus

typedef UINT32 BITMLEngineV2Result;
static const BITMLEngineV2Result BITMLEngineV2Success             = 0;  ///< Success
static const BITMLEngineV2Result BITMLEngineV2NetworkNotPrepared  = 1;  ///< Execute or deregister before register
static const BITMLEngineV2Result BITMLEngineV2InvalidTensorSize   = 2;  ///< Tensor size incorrect
static const BITMLEngineV2Result BITMLEngineV2InvalidTensorBuf    = 3;  ///< Tensor invalid buffer
static const BITMLEngineV2Result BITMLEngineV2NetworkFailure      = 4;  ///< BITMLEngine network general failure
static const BITMLEngineV2Result BITMLEngineV2SSR                 = 5;  ///< Non-recoverable NSP failure
static const BITMLEngineV2Result BITMLEngineV2InvalidPickleFile   = 6;  ///< Invalid pickle file
static const BITMLEngineV2Result BITMLEngineV2MemAllocFailure     = 7;  ///< Mem allocation failure

static const BITMLEngineV2Result BITMLEngineV2Failure             = 10;  ///< BITMLEngine general failure
static const BITMLEngineV2Result BITMLEngineV2InvalidName         = 11;  ///< Unsupported feature name
static const BITMLEngineV2Result BITMLEngineV2InvalidClientID     = 12;  ///< Invalid BITMLEngine Client ID
static const BITMLEngineV2Result BITMLEngineV2InvalidNetworkID    = 13;  ///< Invalid BITMLEngine Network ID
static const BITMLEngineV2Result BITMLEngineV2StateError          = 14;  ///< BITMLEngine in error state
static const BITMLEngineV2Result BITMLEngineV2SSRRecoverFailure   = 15;  ///< Failed to recover from DSP crash
static const BITMLEngineV2Result BITMLEngineV2InvalidFrameInfo    = 16;  ///< Invalid frame information
static const BITMLEngineV2Result BITMLEngineV2InitFailure         = 17;  ///< Init failure
static const BITMLEngineV2Result BITMLEngineV2SSRRecovering       = 19;  ///< During recovery
static const BITMLEngineV2Result BITMLEngineV2UnsigedPDUnsupport  = 20;  ///< remote_session_control interface unsupport

typedef UINT32 BITMLClientID;

/// @brief Tensor structure definition
struct BITMLTensor
{
    UINT32 size;   ///< Size of the tensor in number of bytes
    UINT32 batch;  ///< Batch of tensor
    UINT32 width;  ///< Width of tensor
    UINT32 height; ///< Height of tensor
    UINT32 depth;  ///< Depth of tensor
    UINT8* buffer; ///< Pointer to tensor buffer
};

/// @brief Execute parameter definition
struct ExecuteParams
{
    UINT32 frameNum;
    UINT32 totalFrames;
    void* net_meta_in;
    void* net_meta_out;
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// BITMLV2Init
///
/// @brief Initialize BITMLEngine v2
///
/// @return
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void BITMLV2Init();

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// BITMLV2Register
///
/// @brief Registers network in BITMLEngine v2
///
/// @param  networkName input, Name of the network to be registered
/// @param  clientID    output, Will be populated with a client ID
///
/// @return corresponding BITMLEngineV2Result
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
BITMLEngineV2Result BITMLV2Register(
    const CHAR* networkName,
    BITMLClientID* clientID);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// BITMLV2Execute
///
/// @brief Executes network associated with client id
///
/// @param  clientID  input, ID of the client which network should be executed
/// @param  inTensor  input, Input data
/// @param  outTensor output, Will be populated with output data form the network's execution
/// @param  params    input, Parameter passed in for execution, can be omitted
///
/// @return corresponding BITMLEngineV2Result
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
BITMLEngineV2Result BITMLV2Execute(
    const BITMLClientID clientID,
    const BITMLTensor* inTensor,
    BITMLTensor* outTensor,
    ExecuteParams* params = NULL);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// BITMLV2Deregister
///
/// @brief Deregisters network in BITMLEngine v2
///
/// @param  clientID input, ID of the client to deregister
///
/// @return corresponding BITMLEngineV2Result
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
BITMLEngineV2Result BITMLV2Deregister(
    const BITMLClientID clientID);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// BITMLV2Deinit
///
/// @brief De-initialize BITMLEngine v2
///
/// @return
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void BITMLV2Deinit();

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// BITMLV2QueryNetwork
///
/// @brief Checks to see if network associated with client ID is ready for execution
///
/// @param  clientID input, ID of client to query
///
/// @return corresponding BITMLEngineV2Result
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
BITMLEngineV2Result BITMLV2QueryNetwork(
    const BITMLClientID clientID);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// BITMLEngineV2QueryVersion
///
/// @brief Get version of BITMLEngine
///
/// @param  major     output, major number of version
/// @param  minor     output, minor number of version
///
/// @return
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void BITMLEngineV2QueryVersion(
    INT32* major,
    INT32* minor);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// BITMLV2QueryTensorSize
///
/// @brief Returs expected input and output tensor size for a given client
///
/// @param  networkName input, Name of the network to be registered
/// @param  inNum       output, the number of input tensors
/// @param  inBatch     output, input tensor batch
/// @param  inDepth     output, input tensor depth
/// @param  inHeight    output, input tensor height
/// @param  inWidth     output, input tensor width
/// @param  inSize      output, input tensor size in bytes
/// @param  outNum      output, the number of output tensors
/// @param  outBatch    output, output tensor batch
/// @param  outDepth    output, output tensor depth
/// @param  outHeight   output, output tensor height
/// @param  outWidth    output, output tensor width
/// @param  outSize     output, output tensor size in bytes
///
/// @return corresponding BITMLEngineV2Result
///         output will be valid only when return value is BitMLEngineSuccess
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
BITMLEngineV2Result BITMLV2QueryTensorSize(
    const CHAR* networkName,
    UINT32* inNum,
    UINT32* inBatch,
    UINT32* inDepth,
    UINT32* inHeight,
    UINT32* inWidth,
    UINT32* inSize,
    UINT32* outNum,
    UINT32* outBatch,
    UINT32* outDepth,
    UINT32* outHeight,
    UINT32* outWidth,
    UINT32* outSize);



#ifdef __cplusplus
}
#endif // __cplusplus

CAMX_NAMESPACE_END

#endif // end of #ifndef BITMLENGINEINTERFACEV2_H
