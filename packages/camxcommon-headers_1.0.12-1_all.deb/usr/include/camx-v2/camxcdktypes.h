///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2017-2023 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @file  camxcdktypes.h
/// @brief CDK common types
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// NOWHINE ENTIRE FILE - Doxygen Deliverable


#ifndef CAMXSCDKTYPES_H
#define CAMXSCDKTYPES_H

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Linux Primitive Data Type Abstractions
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#if defined(_LINUX)
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus


typedef int                 BOOL;
typedef char                CHAR;
typedef uint8_t             SBYTE;
typedef unsigned char       UCHAR;
typedef int                 INT;
typedef unsigned int        UINT;
typedef float               FLOAT;

typedef uint8_t             UINT8;
typedef int8_t              INT8;
typedef uint16_t            UINT16;
typedef int16_t             INT16;
typedef uint32_t            UINT32;
typedef int32_t             INT32;
typedef uint64_t            UINT64;
typedef int64_t             INT64;

typedef max_align_t         MAXALIGN_T;
typedef size_t              SIZE_T;
typedef void                VOID;

#if !defined (TRUE)
#define TRUE                1
#endif // !defined (TRUE)

#if !defined (FALSE)
#define FALSE               0
#endif // !defined (FALSE)

#ifdef __cplusplus
}
#endif // __cplusplus

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Windows Primitive Data Type Abstractions
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#elif defined (_WIN32)

#if !defined(WIN32_LEAN_AND_MEAN)
#define WIN32_LEAN_AND_MEAN 1
#endif // !defined(WIN32_LEAN_AND_MEAN)

#include <Windows.h>
#include <stddef.h>

#ifdef __cplusplus
#include <cstddef>
typedef std::max_align_t    MAXALIGN_T;
#endif // __cplusplus

#else

// #error Unsupported target

#endif // defined (_LINUX)

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Result Codes
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/** @addtogroup chi_common_cdk_results
    @xreflabel{hdr:resultMessages}
@{ */

typedef INT32               CDKResult;                    ///< Resulting code type to be returned from functions.
                                                          ///
                                                          ///  This value must match the ordering and size of the result
                                                          ///  strings.

static const CDKResult CDKResultSuccess           = 0;    ///< Operation was successful.
static const CDKResult CDKResultEFailed           = 1;    ///< Operation encountered an unspecified error.
static const CDKResult CDKResultEUnsupported      = 2;    ///< Operation is not supported.
static const CDKResult CDKResultEInvalidState     = 3;    ///< Invalid state.
static const CDKResult CDKResultEInvalidArg       = 4;    ///< Invalid argument.
static const CDKResult CDKResultEInvalidPointer   = 5;    ///< Invalid memory pointer.
static const CDKResult CDKResultENoSuch           = 6;    ///< No such item exists or it is invalid.
static const CDKResult CDKResultEOutOfBounds      = 7;    ///< Out of bounds.
static const CDKResult CDKResultENoMemory         = 8;    ///< Out of memory.
static const CDKResult CDKResultETimeout          = 9;    ///< Operation timed out.
static const CDKResult CDKResultENoMore           = 10;   ///< No more items are available.
static const CDKResult CDKResultENeedMore         = 11;   ///< Operation requires more.
static const CDKResult CDKResultEExists           = 12;   ///< Item exists.
static const CDKResult CDKResultEPrivLevel        = 13;   ///< Privileges are insufficient for the requested operation.
static const CDKResult CDKResultEResource         = 14;   ///< Resources are insufficient for the requested operation.
static const CDKResult CDKResultEUnableToLoad     = 15;   ///< Unable to load the library or object.
static const CDKResult CDKResultEInProgress       = 16;   ///< Operation is already in progress.
static const CDKResult CDKResultETryAgain         = 17;   ///< Could not complete the request; try again.
static const CDKResult CDKResultEBusy             = 18;   ///< Device or resource is busy.
static const CDKResult CDKResultEReentered        = 19;   ///< Non-re-entrant API was re-entered.
static const CDKResult CDKResultEReadOnly         = 20;   ///< Cannot change a read-only object or parameter.
static const CDKResult CDKResultEOverflow         = 21;   ///< Value is too large for the defined data type.
static const CDKResult CDKResultEOutOfDomain      = 22;   ///< Math argument or the result is out of domain.
static const CDKResult CDKResultEInterrupted      = 23;   ///< Waitable call is interrupted.
static const CDKResult CDKResultEWouldBlock       = 24;   ///< Operation will block.
static const CDKResult CDKResultETooManyUsers     = 25;   ///< Too many users.
static const CDKResult CDKResultENotImplemented   = 26;   ///< Function or method is not implemented.
static const CDKResult CDKResultEDisabled         = 27;   ///< Feature is disabled.
static const CDKResult CDKResultECancelledRequest = 28;   ///< Request is in a Canceled state.
static const CDKResult CDKResultECoreNullMetadata = 29;   ///< Metadata is NULL.
static const CDKResult CDKResultEInducedError     = 30;   ///< Induced error using the error inducement framework.
static const CDKResult CDKResultEFenceGroupError  = 31;   ///< Configuration of a composite fence group is incorrect.
static const CDKResult CDKResultECSLStreamOn      = 32;   ///< Streaming Camera Services Layer is ON.
static const CDKResult CDKResultEAlreadyCompleted = 33;   ///< Error indicating the request is already completed
static const CDKResult CDKResultEOEMStatus1       = 34;   ///< Error used by OEMs for customizations
static const CDKResult CDKResultEOEMStatus2       = 35;   ///< Error used by OEMs for customizations
static const CDKResult CDKResultEOEMStatus3       = 36;   ///< Error used by OEMs for customizations
static const CDKResult CDKResultEProviderNotExist = 37;   ///< No such provider exists

#ifndef DOXYGEN_SHOULD_SKIP_THIS
// Increment the count below if adding additional result codes.
static const CDKResult CDKResultCount             = 38;   // number of result codes. Not to be used.
#endif /* DOXYGEN_SHOULD_SKIP_THIS */

static const CDKResult CDKResultChiBase               = 20000;               ///< Base for all CHI system event errors.
static const CDKResult CDKResultExceedThreshold       = CDKResultChiBase+1;  ///< Request object exceeds the maximum lifetime.
static const CDKResult CDKResultUnProcessedRequest    = CDKResultChiBase+2;  ///< Request was not completed.
static const CDKResult CDKResultFwkDump               = CDKResultChiBase+3;  ///< Framework-requested data dump.
static const CDKResult CDKResultPCRTimeout            = CDKResultChiBase+4;  ///< Maximum number of pending requests arrived and
                                                                             /// the PCR timed out.
static const CDKResult CDKResultMetadataClientExhaust = CDKResultChiBase+5;  ///< CHI metadata manager client has no more free
                                                                             /// buffers.
static const CDKResult CDKResultHALTimeout            = CDKResultChiBase+6;  ///< HAL API timed out.

static const CDKResult CDKResultHMSJobTimeOut         = CDKResultChiBase+7;  ///< Timeout of runtime job detected by HMS

static const CDKResult CDKResultOEMChiBase            = 40000;  ///< Base for all OEM CHI system event errors.


#ifndef DOXYGEN_SHOULD_SKIP_THIS
// The string name of the type of the memory allocation. Must be in order of CamxResult codes.
#if __GNUC__
static const CHAR* CDKResultStrings[] __attribute__((unused)) =
#else // __GNUC__
static const CHAR* CDKResultStrings[] =
#endif // _GNUC__
{
    "CDKResultSuccess",
    "CDKResultEFailed",
    "CDKResultEUnsupported",
    "CDKResultEInvalidState",
    "CDKResultEInvalidArg",
    "CDKResultEInvalidPointer",
    "CDKResultENoSuch",
    "CDKResultEOutOfBounds",
    "CDKResultENoMemory",
    "CDKResultETimeout",
    "CDKResultENoMore",
    "CDKResultENeedMore",
    "CDKResultEExists",
    "CDKResultEPrivLevel",
    "CDKResultEResource",
    "CDKResultEUnableToLoad",
    "CDKResultEInProgress",
    "CDKResultETryAgain",
    "CDKResultEBusy",
    "CDKResultEReentered",
    "CDKResultEReadOnly",
    "CDKResultEOverflow",
    "CDKResultEOutOfDomain",
    "CDKResultEInterrupted",
    "CDKResultEWouldBlock",
    "CDKResultETooManyUsers",
    "CDKResultENotImplemented",
    "CDKResultEDisabled",
    "CDKResultECancelledRequest",
    "CDKResultECoreNullMetadata",
    "CDKResultEInducedError",
    "CDKResultEFenceGroupError",
    "CDKResultECSLStreamOn",
    "CDKResultEAlreadyCompleted",
    "CDKResultEOEMStatus1",
    "CDKResultEOEMStatus2",
    "CDKResultEOEMStatus3",
    "CDKResultEProviderNotExist"

};
#endif /* DOXYGEN_SHOULD_SKIP_THIS */

static const UINT   CDKInvalidId                    = 0xFFFFFFFF;   ///< Defines an invalid handle.
                                                                    ///  @newpage
static const UINT64 longExposureTimeThresholdInS    = 2;            ///< Long exposure time threshold unit in second.

#define CDK_UNREFERENCED_PARAM(param) (void)param                 ///< Macro helper for an unreferenced parameter.

#define CDK_MAYBE_UNUSED_FUNCTION [[maybe_unused]]                ///< Macro helper for an unused function.

/// @brief Types of frameworks. Each type is a CHI override ID remapping to use.
enum CameraIdRemapMode
{
    IdRemapCamera      = 0,      ///< Remap logic for camera functionality.
    IdRemapTorch       = 1,      ///< Remap logic for torch functionality.
    IdReverseMapCamera = 2,      ///< Remap logic for the HAL internal camera ID to an external camera ID.
};

/// @brief Types of information to retrieve.
enum CDKGetInfoCmd
{
    CDKGetInfoNumPhysicalCameras,        ///< Number of physical cameras associated with a specified logical camera ID.
    CDKGetInfoPhysicalCameraIds,         ///< Physical camera IDs for a specified logical camera ID.
    CDKGetInfoSensorModes,               ///< Get the Sensor modes for a given logical camera ID.
    CDKGetInfoUsecaseId,                 ///< Get the selected use case ID for a given logical camera ID.
    CDKGetInfoFwkCamId,                  ///< Get the framework camera ID for a given logical camera ID.
    CDKGetInfoLogicalCamAffectedByFold,  ///< Camera is affected by a fold event.
    CDKGetInfoMax                        ///< Indicates the last item.
};

/// @brief Information on how a camera is affected by a fold event.
enum CameraFoldInfo
{
    UnaffectedByFold,                       ///< Camera is not affected by the fold event.
    AvailableOnlyInFoldedState,             ///< Camera is available only in the Folded state.
    AvailableOnlyInUnfoldedState            ///< Camera is available only in the Unfolded state.
};

/// @brief Defines the parameter used when passing a camera ID.
struct CDKInfoCameraId
{
    UINT32      cameraId;    ///< Unique identifier for the camera.
};

/// @brief Parameters used for passing the number of cameras.
struct CDKLogicalCamsAffectedByFold
{
    BOOL     deviceFolded;                      ///< Fold status of the device.
    UINT     numCamMadeAvailable;               ///< Number of available cameras.
    UINT     numCamMadeUnavailable;             ///< Number of unavailable cameras.
    UINT32*  pLogicalCamIdsMadeAvailable;       ///< Array of logical camera IDs that are available.
    UINT32*  pLogicalCamIdsMadeUnavailable;     ///< Array of logical camera IDs that are unavailable.
};

/// @brief Used for passing the number of cameras.
struct CDKInfoNumCameras
{
    UINT        numCameras;  ///< Number of cameras.
};

/// @brief Used for getting a list of physical camera IDs.
struct CDKInfoPhysicalCameraIds
{
    UINT        numCameras;         ///< Number of cameras.
    UINT32*     physicalCameraIds;  ///< Pointer to the physical camera IDs.
};

/// @brief Used for getting a list of Sensor modes.
struct CDKInfoSensorMode
{
    UINT        numCameras;  ///< Number of cameras.
    UINT32*     left;        ///< Pointer to the left frame dimention.
    UINT32*     top;         ///< Pointer to the top frame dimention.
    UINT32*     width;       ///< Pointer to the frame width.
    UINT32*     height;      ///< Pointer to the frame height.
};

/// @brief Used for getting the use case ID.
struct CDKInfoUsecaseId
{
    UINT32      usecaseId;  ///< Unique identifier for the use case.
};

/// @brief Used for getting the framework camera ID.
struct CDKInfoFwkCamId
{
    INT      frameworkCameraId;  ///< Unique identifier of the camera.
                                 ///  @newpagetable
};


#ifndef DOXYGEN_SHOULD_SKIP_THIS
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// OS Agnostic Primitive Data Type Abstractions
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef unsigned int    BIT;
typedef double          DOUBLE;

typedef intptr_t        INTPTR_T;
typedef uintptr_t       UINTPTR_T;
typedef ptrdiff_t       PTRDIFF_T;

#ifdef __cplusplus
}
#endif // __cplusplus

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// CDK interface data structure packing information
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#define CDK_PACK_SIZE 8

#define CDK_UNUSED_PARAM(x) (VOID)x

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Sometimes variable or function is not used in all libraries or scenarios. This macro will help to bypass compilation error
// for such arguments.
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#if defined(_LINUX)
#define CDK_MAYBE_UNUSED_ARG [[maybe_unused]]
#else
#define CDK_MAYBE_UNUSED_ARG
#endif

#if defined(__GNUC__)
#define CDK_VISIBILITY_PUBLIC __attribute__ ((visibility ("default")))
#define CDK_VISIBILITY_LOCAL  __attribute__ ((visibility ("hidden")))
#else
#define CDK_VISIBILITY_PUBLIC __declspec(dllexport)
#define CDK_VISIBILITY_LOCAL
#endif // defined(__GNUC__)

#endif /* DOXYGEN_SHOULD_SKIP_THIS */

/** @} */ /* end_addtogroup chi_common_cdk_results */

#endif // CAMXSCDKTYPES_H
