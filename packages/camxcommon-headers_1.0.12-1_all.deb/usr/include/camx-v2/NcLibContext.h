// NOWHINE ENTIRE FILE
//-------------------------------------------------------------------------
// Copyright (c) 2017-2023 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
//------------------------------------------------------------------------

#ifndef __NCLIB_CONTEXT_H__
#define __NCLIB_CONTEXT_H__

#include <stdint.h>
#include "CommonDefs.h"

/** Unset optical center */
#define CONTEXT_OPTICAL_CENTER_NOT_SET (-1)

/** ANR, TF optical center is provided in logical values [0,1]
    format: 15uQ14
    top left is [0,0], bottom right is [1, 1] - which is translated in fixed point to:
    [OPTICAL_CENTER_LOGICAL_MAX, OPTICAL_CENTER_LOGICAL_MAX] */
#define OPTICAL_CENTER_LOGICAL_MAX_SHIFT (14)
#define OPTICAL_CENTER_LOGICAL_MAX (1<<OPTICAL_CENTER_LOGICAL_MAX_SHIFT)


/** Flow modes */
enum EIPEConfigOption
{
    IPE_CONFIG_VIDEO,                   /**< normal video processing */
    IPE_CONFIG_STILL,                   /**< normal still-image processing */
    IPE_CONFIG_MF_PRE,                  /**< multi-frame processing; pre-filtering */
    IPE_CONFIG_MF_TEMPORAL,             /**< multi-frame processing; temporal blending */
    IPE_CONFIG_MF_NOISE_EQUALIZATION,   /**< multi-frame processing; noise equalization */
    IPE_CONFIG_VIDEO_PASSTHROUGH,       /**< video processing with pass through */
    IPE_CONFIG_VIDEO_BLEND,             /**< video processing with constant blending */

    IPE_CONFIG_NUM           /**< only for SW purpose */
};

/** ICA minimal output restriction */
#define ICA_MIN_WIDTH_PIXELS (30)
#define ICA_MIN_HEIGHT_PIXELS (26)

/** ICA Array dimensions*/
enum EICAArraySizes
{
    ICA_MAX_PERSPECTIVE_TRANSFORMS = 9,                                                                                 /**< max number of perspective transforms */
    ICA_PARAMETERS_PER_PERSPECTIVE_TRANSFORM = 9,                                                                       /**< number of parameters per perspective transform */
    ICA_V10_GRID_TRANSFORM_WIDTH = 33,                                                                                  /**< ICA v1.0 grid width */
    ICA_V10_GRID_TRANSFORM_HEIGHT = 25,                                                                                 /**< ICA v1.0 grid height */
    ICA_V20_GRID_TRANSFORM_WIDTH = 35,                                                                                  /**< ICA v2.0 grid width */
    ICA_V20_GRID_TRANSFORM_HEIGHT = 27,                                                                                 /**< ICA v2.0 grid height */
    ICA_V20_GRID_TRANSFORM_SIZE = ICA_V20_GRID_TRANSFORM_WIDTH * ICA_V20_GRID_TRANSFORM_HEIGHT,                         /**< ICA v2.0 grid size */
    ICA_V30_GRID_TRANSFORM_LOW_RES_WIDTH = 35,                                                                          /**< ICA v3.0 low resolution grid width */
    ICA_V30_GRID_TRANSFORM_LOW_RES_HEIGHT = 27,                                                                         /**< ICA v3.0 low resolution grid height */
    ICA_V30_GRID_TRANSFORM_LOW_RES_SIZE = ICA_V30_GRID_TRANSFORM_LOW_RES_WIDTH * ICA_V30_GRID_TRANSFORM_LOW_RES_HEIGHT, /**< ICA v3.0 low resolution grid size */
    ICA_V30_GRID_TRANSFORM_HI_RES_WIDTH = 67,                                                                           /**< ICA v3.0 high resolution grid width */
    ICA_V30_GRID_TRANSFORM_HI_RES_HEIGHT = 51,                                                                          /**< ICA v3.0 high resolution grid height */
    ICA_V30_GRID_TRANSFORM_HI_RES_SIZE = ICA_V30_GRID_TRANSFORM_HI_RES_WIDTH * ICA_V30_GRID_TRANSFORM_HI_RES_HEIGHT     /**< ICA v3.0 high resolution grid size */
};

enum NcLibLmcInputFormat
{
    NCLIB_LMC_INVALID = 0,
    NCLIB_LMC_LINEAR_P012_MA,
    NCLIB_LMC_LINEAR_P012_LA,
    NCLIB_LMC_UBWC_P016,
    NCLIB_LMC_INPUT_FORMATS_NUM
};

/** ICA LMC configuration */
struct NcLibIcaLmcPassParams
{
    float                  mvxMult;    /**< Motion vector scale ratio, X-value. */
    float                  mvyMult;    /**< Motion vector scale ratio, Y-value. */
    float                  offsetX;    /**< MV compensation between input/output image sizes, X-value. */
    float                  offsetY;    /**< MV compensation between input/output image sizes, Y-value. */
    NcLibLmcInputFormat    format;     /**< LMC data byte format. */
    int32_t                fracBits;   /**< LMC calculation precision.
                                            In Waipio and Kailua valid range is -3:7.
                                            In Lanai valid range is -3:15.*/
};

/** Struct that describes up to five faces */
typedef struct FD_CONFIG_CONTEXT_TAG
{
    uint32_t faceNum;            /**< Number of faces. Valid range is 0 - 5 */
    uint32_t faceCenterX[5];     /**< array that contain the X axis of faces center  */
    uint32_t faceCenterY[5];     /**< array that contain the Y axis of faces center  */
    uint32_t faceRadius[5];      /**< array that contain the radius of faces */
} FD_CONFIG_CONTEXT;

/** Struct that describes ANR SW context */
typedef struct NCLIB_CONTEXT_ANR_TAG
{
    uint32_t frameNumber;       /**< used for MF and may be used also for seed */
    FD_CONFIG_CONTEXT fdConfig; /**< Face Detection for ANR. Deprecated in v14.*/
    int32_t optical_center_x;   /**< Optical Center X.
                                 * logic value 0 is start of the image, OPTICAL_CENTER_LOGICAL_MAX is the end of
                                 * the image. format: 15uQ14.
                                 * If value == CONTEXT_OPTICAL_CENTER_NOT_SET then it is not
                                 * SET and we take from Chromatix. */
    int32_t optical_center_y;   /**< Optical Center Y.
                                 * logic value 0 is start of the image, OPTICAL_CENTER_LOGICAL_MAX is the end of
                                 * the image. format: 15uQ14.
                                 * If value == CONTEXT_OPTICAL_CENTER_NOT_SET then it is not
                                 * SET and we take from Chromatix. */
    bool aiEnable;              /**< Flag whether there is valid Catmap data input to pass downstream CLCs
                                     Should be set to false if Ai camera is not supported */

} NCLIB_CONTEXT_ANR;

/** Struct that describes TF SW context */
typedef struct NCLIB_CONTEXT_TF_TAG
{
    uint32_t frameNumber;                    /**< used for MF and may be used also for seed */

    uint32_t numberOfFrames;                 /**< Number of images to process, used for MF */

    uint32_t maxNumberOfFrames;              /**< Number of images for which the tuning was generated, used for MF.
                                                  Defined in Chromatix (MF::top:max_num_of_frames) */

    uint8_t tfHasReferenceInput;             /**< indication if TF has reference input */
    enum EIPEConfigOption tfConfigOption;    /**< flow mode */

    // upscalingFactor & DZ parameters are for MFSR use only and should be zeros on video.
    float upscalingFactorMFSR_ICA;           /**<  used for SR calculations (affects size of ICA out,
                                              *    thus affects refinement calculations etc) */

    /**< Digital zoom window (at full resolution) - affects refinement settings */
    uint8_t isDigitalZoomEnabled;            /**< 1 if Digital zoom is enabled, else 0 */
    uint32_t dzStartX;                       /**< Digital zoom start X */
    uint32_t dzStartY;                       /**< Digital zoom start Y */
    uint32_t dzSizeX;                        /**< Digital zoom width */
    uint32_t dzSizeY;                        /**< Digital zoom height */
    uint8_t preferPaddingByReflection;       /**< FW settings, indicate how to handle missing data.
                                              *   if 1 padding, else reflection*/
    uint32_t fullPassIcaOutputFrameWidth;    /**<  Calculated full pass ICA out width at ICA output of full pass,
                                              *    assuming no scaling  (e.g. may account for EIS margins but not
                                              *    for MFSR scaling) */
    uint32_t fullPassIcaOutputFrameHeight;   /**<  Calculated full pass ICA out height at ICA output of full pass,
                                              *    assuming no scaling  (e.g. may account for EIS margins but not
                                              *    for MFSR scaling) */
    uint8_t enableALGM;                      /**< 1 if ALGM is enabled, else 0 */
    uint32_t testMode;                       /**<  Reserved for developer options, must be 0. */
    uint8_t isDmmEnabled;                    /**<  1 if DMM is used in this flow, else 0.
                                              *    Relevant in case of Video flow.
                                              *    Can be set to 1 only if EVA SGM is supported by HW.
                                              *    Should be set to 0 in case of alignment fallback from DMM to DME*/
    bool aiEnable;                           /**< Flag whether there is valid Catmap data input to pass downstream CLCs
                                                  Should be set to false if Ai camera is not supported */

} NCLIB_CONTEXT_TF;

enum NCLIB_DSX_HOST_TYPE
{
    NCLIB_DSX_IFE,
    NCLIB_DSX_IPE,
    NCLIB_DSX_GCE,
    NCLIB_DSX_HOST_TYPES_NUM
};

/** Struct that describes DSX SW context */
typedef struct NCLIB_CONTEXT_DSX_TAG
{
    uint32_t inW;                         /**< Input width [16, 8190] */
    uint32_t inH;                         /**< Input height [16, 16384] */
    uint32_t outW;                        /**< Output width [2, 1696] */
    uint32_t outH;                        /**< Output width [2, 13108] */
    float downscaleX;                     /**< Step size X [1.25, 4] */
    float downscaleY;                     /**< Step size Y [1.25, 4] */
    float offsetX;                        /**< input offset X [0, 0.8*inW] */
    float offsetY;                        /**< input offset Y [0, 0.8*inH] */
    NCLIB_DSX_HOST_TYPE host;             /**< In which HW this DSX is integrated. */
} NCLIB_CONTEXT_DSX;

typedef struct NCLIB_CONTEXT_LCAC_TAG
{
    uint32_t imageHeight;   /**< The image's height */
    uint32_t imageWidth;    /**< The image's width */
    bool isIFE;             /**< Used to define the resolution restriction */
} NCLIB_CONTEXT_LCAC;

/** Input struct for configuring TF confidence.*/
struct NcLibConfidenceConfig
{
    uint32_t enable_transform_confidence;                           /**< Whether to calculate and apply transform confidence. */
    uint32_t transform_confidence_mapping_base;                     /**< Base to define mapping from calculated confidence to actual confidence. */
    uint32_t transform_confidence_mapping_c1;                       /**< Threshold on using calculated confidence. */
    uint32_t transform_confidence_mapping_c2;                       /**< Threshold on extrapolating from calculated confidence. */
    uint32_t transform_confidence_thr_to_force_identity_transform;  /**< Confidence threshold to use identity transform instead. */
};

/**
*  @brief   Calculate TF confidence based on actual transform confidence
*
*  @param [in]      configStruct                 Chromatix configuration
*  @param [in]      transformConfidence          Original transform confidence calculated by transform provider.
*  @param [out]     tfTransformConfidence        Will receive the updated transform confidence.
*                                                Should be passed to FW in TfPassParameters::transformConfidenceVal.
*  @param [in,out]  isTransformForcedToIdentity  optional parameter (pass NULL to disable it).
*                                                if enabled (not NULL) state of "transform forced to identity" for
*                                                hysteresis implementation.
*                                                By default should be set to 0.
*
*  @return NC_LIB_SUCCESS in case of success, otherwise failed.
*/
int32_t NcLibAlignmentConfidenceToTfConfidence(
    const NcLibConfidenceConfig* configStruct,
    uint32_t transformConfidence,
    int32_t* tfTransformConfidence,
    uint8_t* isTransformForcedToIdentity);


#endif //__NCLIB_CONTEXT_H__
