////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2020-2021 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @file  camxchiofflinedumpcommon.h
/// @brief Offline Dump related defines
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef CAMXCHIOFFLINEDUMPCOMMON_H
#define CAMXCHIOFFLINEDUMPCOMMON_H

// NOWHINE FILE NC004c: No CamX prefix since we're including in both CamX and CHI-CDK

#define OFFLINEDUMP_MAX_TYPE (static_cast<INT>(OfflineDumpType::NUM_OF_TYPE))

enum class OfflineDumpStatus
{
    DISABLE,        ///< OfflineDump is disabled
    STOP,           ///< OfflineDump is stopping to wait for input or flush
    ACTIVE          ///< OfflineDump is actively dumping
};

enum class OfflineDumpType
{
    INVALID = -1,    ///< Invalid type
    IMAGE,           ///< OfflineDump type for image formats
    NUM_OF_TYPE      ///< Calculate total number of OfflineDump type, do not remove it
};

#endif // CAMXCHIOFFLINEDUMPCOMMON_H
