// NOWHINE ENTIRE FILE
//-------------------------------------------------------------------------
// Copyright (c) 2019-2022 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
//------------------------------------------------------------------------

#ifndef GEOLIBUTILS_H
#define GEOLIBUTILS_H

#include "GeoLib.h"

const GeoLibMultiFrameMode ValidKonaLahainaMfModes[] = { GEOLIB_MF_ANCHOR, GEOLIB_MF_BLEND, GEOLIB_MF_FINAL };
const GeoLibStillFlowMode ValidKonaLahainaFlowModes[] = { GEOLIB_STILL_SNAPSHOT, GEOLIB_STILL_MFNR, GEOLIB_STILL_MFSR };
const GeoLibStillFlowMode ValidWaipioFlowModes[] = { GEOLIB_STILL_SNAPSHOT, GEOLIB_STILL_MMF };

// Video dump

void Dump_GeoLibVideoStreamInput(
    const GeoLibVideoFlowMode       flowMode,
    const GeoLibHdrFlowMode         hdrMode,
    const GeoLibSensorData          sensorData[],
    const uint32_t                  numSensors,
    const uint32_t                  curSensorIdx,
    const GeoLibVideoStreamIfePort  ifeOutPort,
    const GeoLibImageSize*          ifeOutMinSize,
    const GeoLibImageSize*          fdOutSize,
    const NcLibIcaGrid*             ldFullOutToIn,
    const NcLibIcaGrid*             ldFullInToOut,
    const GeoLibIpeParams           ipeParams[],
    const uint32_t                  ipeParamsLen,
    const float                     maxVsrScaling,
    const GeoLibEisParams*          eisParameters,
    const float                     fovcMarginRatio,
    const uint32_t                  overrideFlags,
    const GeoLibVideoIfeStreamCfg*  secIfeConfig,
    FILE*                           dumpFile);

void Dump_GeoLibVideoIfeStreamCfg(
    const GeoLibVideoIfeStreamCfg*  streamConfig,
    FILE*                           dumpFile);

void Dump_GeoLibVideoIpeStreamCfg(
    const GeoLibVideoIpeStreamCfg*  streamConfig,
    FILE*                           dumpFile);

void Dump_GeoLibVideoCvpStreamCfg(
    const GeoLibVideoCvpStreamCfg*  streamConfig,
    FILE*                           dumpFile);

void Dump_GeoLibVideoIfeFrameCfg(
    const GeoLibVideoIfeFrameCfg*   geoLibIfe,
    const GeoLibROI*                zoomWindow,
    const GeoLibWindowSize*         satWindowSize,
    const float                     eisVsVsrFactor,
    const float                     vsrLimit,
    FILE*                           dumpFile);

void Dump_GeoLibVideoIpeFrameCfg(
    const GeoLibVideoIpeFrameCfg*   geoLibIpe,
    const float                     fovcRatio,
    FILE*                           dumpFile);
void Dump_GeoLibVideoIpeFrameCfg(
    const GeoLibVideoIpeFrameCfg*   geoLibIpe,
    const char*                     prefix,
    FILE*                           dumpFile);

void Dump_GeoLibVideoCvpFrameCfg(
    const GeoLibVideoCvpFrameCfg*   geoLibCvp,
    const float                     cvpDsRatio,
    FILE*                           dumpFile);

void Dump_GeoLibVideoEisFrameCfg(
    const GeoLibVideoEisFrameCfg*   geoLibEis,
    const float                     fovcRatio,
    const char*                     prefix,
    FILE*                           dumpFile);

// Waipio video dump

void Dump_GeoLibVideoStreamInput(
    const GeoLib2InitIn* initIn,
    const NcLibAiIpeInitIn* aiInitIn,
    FILE* dumpFile);

void Dump_GeoLib2StreamCfg(
    const GeoLib2StreamCfg*         streamConfig,
    FILE*                           dumpFile);

void Dump_GeoLibVideoIpeFrameCfg(
    const GeoLib2IpeFrameCfg*  geoLibIpe,
    const char*                prefix,
    FILE*                      dumpFile);

void Dump_GeoLib2FrameIn(
    const GeoLib2CalcFrameIn*       frameIn,
    FILE*                           dumpFile,
    const GeoLib2EvaCalcFrameIn*    evaIn = NULL,
    const NcLibROI*                 segInRoi = NULL
    );

void Dump_GeoLib2FrameCfg(
    const GeoLib2FrameCfg*    frameCfg,
    FILE*                     dumpFile);

void Dump_GeoLib2EvaCalcFrameIn(
    const GeoLib2EvaCalcFrameIn* evaIn,
    FILE*                     dumpFile);

void Dump_GeoLib2EvaFrameCfg(
    const GeoLib2EvaCalcFrameIn* evaFrameIn, // Not dumped, only needed for requestId
    const GeoLib2IcaMapping*     evaFrameCfg,
    FILE*                        dumpFile);

// Kailua video dump

void Dump_NcLibAiIpeCfg(
    NcLibAiIpeCfg*              aiConfig,
    FILE*                       dumpFile);

void Dump_GeoLib2AiIpeFrameCfg(
    const GeoLib2AiFrameIn*     aiFrameIn, // Not dumped, only needed for requestId
    const GeoLib2IcaMapping*    aiFrameCfg,
    FILE*                       dumpFile);

void Dump_GeoLib2AiDisplayFrameCfg(
    const GeoLib2IcaMapping*    aiFrameCfg,
    const uint64_t              requestID,
    FILE*                       dumpFile);

// Kona Still dump

void Dump_GeoLibStillFrameInput(
    const GeoLibStillFlowMode       flowMode,
    const GeoLibMultiFrameMode      mfMode,
    const GeoLibImageSize*          sensorSize,
    const NcLibIcaGrid*             ldFullOutToIn,
    const NcLibIcaGrid*             ldFullInToOut,
    const GeoLibImageSize*          outSize,
    const GeoLibImageSize*          dispSize,
    const GeoLibImageSize*          regOutSize,
    const GeoLibROI*                zoomWindow,
    FILE*                           dumpFile);

void Dump_GeoLibStillFrameConfig(
    const GeoLibStillFrameConfig*   frameCfg,
    FILE*                           dumpFile);

// Lahaina Still dump

void Dump_GeoLibStillFrameInput(
    const bool                      isMultiFrame,
    const bool                      isMultiFrameExp2,
    const bool                      isMultiFrameExp3,
    const float                     maxSRScaling,
    const float                     fovcRatio,
    const GeoLibImageSize*          sensorSize,
    const NcLibIcaGrid*             ldFullOutToIn,
    const GeoLibImageSize*          stillOutSize,
    const GeoLibImageSize*          dispOutSize,
    const GeoLibImageSize*          regOutSize,
    const GeoLibImageSize*          regOutSizeExp2,
    const GeoLibImageSize*          regOutSizeExp3,
    const GeoLibROI*                zoomWindow,
    const uint32_t                  overrideFlags,
    FILE*                           dumpFile);

void Dump_GeoLibStillMFFrameConfig(
    const GeoLibStillMFFrameConfig* frameCfg,
    const uint32_t                  expId,
    FILE*                           dumpFile);

void Dump_GeoLibStillIpeHdrFrameConfig(
    const GeoLibStillIPEHDRBlendFrameConfig*    ipeHdrBlend,
    FILE*                                       dumpFile);

void Dump_GeoLibStillEvaHdrFrameConfig(
    const GeoLibStillEVAHDRBlendFrameConfig*    evaHdrBlend,
    FILE*                                       dumpFile);

void Dump_GeoLibStillFinalHdrFrameConfig(
    const GeoLibStillIPEFrameConfig*      hdrLast,
    FILE*                                 dumpFile
);

void Dump_GeoLibStillHdrFrameConfig(
    const GeoLibStillHDRBlendFrameConfig* hdrBlend,
    const GeoLibStillIPEFrameConfig*      hdrLast,
    FILE*                                 dumpFile);

// Waipio Still dump

void Dump_GeoLibStillFrameInput(
    const bool                      isMultiFrame,
    const bool                      isMultiFrameExp2,
    const bool                      isMultiFrameExp3,
    const float                     maxSRScaling,
    const float                     fovcRatio,
    const GeoLibImageSize*          sensorSize,
    const NcLibIcaGrid*             ldFullOutToIn,
    const GeoLib2IpeParams*         ipeOutSizes,
    const GeoLibImageSize*          regOutSize,
    const GeoLibImageSize*          regOutSizeExp2,
    const GeoLibImageSize*          regOutSizeExp3,
    const NcLibROI*                 zoomWindow,
    const uint32_t                  overrideFlags,
    const float                     qllMLds,
    FILE*                           dumpFile);

void Dump_GeoLibStillMFFrameConfig(
    const GeoLib2StillMFFrameConfig* frameCfg,
    const uint32_t                   expId,
    FILE*                            dumpFile);

void Dump_GeoLibStillDzFOVs(
    const GeoLib2ResidualFovs* dzFOVs,
    const uint32_t             expId,
    const bool                 isHdr,
    FILE*                      dumpFile);

// Kailua Still dump

void Dump_GeoLib2StillFrameConfig(
    const GeoLib2StillFrameConfig* frameCfg,
    const uint32_t                 expId,
    FILE*                          dumpFile);

// Kailua EVA31 dump

void Dump_GeoLib2FrameCfg(
    const GeoLib2Eva31CalcFrameIn* frameIn,
    FILE*                          dumpFile);

void Dump_GeoLib2Eva31FrameCfg(
    const GeoLib2Eva31CalcFrameOut* vsrGce,
    uint64_t                        requestID,
    FILE*                           dumpFile);

// Video validation

bool Validate_GeoLibVideoIfeStreamInit(
    const GeoLibVideoFlowMode       flowMode,
    const GeoLibHdrFlowMode         hdrMode,
    const GeoLibSensorData          sensorData[],
    const uint32_t                  numSensors,
    const uint32_t                  curSensorIdx,
    const GeoLibVideoStreamIfePort  ifeOutPort,
    const GeoLibImageSize*          ifeOutMinSize,
    const GeoLibImageSize*          fdOutSize,
    const GeoLibIpeParams           ipeParams[],
    const uint32_t                  ipeParamsLen,
    const float                     maxVsrScaling,
    const GeoLibEisParams*          eisParameters,
    const float                     fovcMarginRatio,
    const uint32_t                  overrideFlags,
    const GeoLibVideoIfeStreamCfg*  secIfeConfig,
    GeoLibVideoIfeStreamCfg*        ifeConfig
);

bool Validate_GeoLibVideoIpeInit(
    const GeoLibIpeParams*          ipeParams,
    GeoLibVideoIpeStreamCfg*        ipeConfig
);

bool Validate_GeoLibVideoCvpInit(
    GeoLibVideoCvpStreamCfg*        cvpConfig
);

bool Validate_GeoLibVideoIfeCalcFrame(
    const GeoLibVideoFlowMode       flowMode,
    const float                     digitalZoom,
    const bool                      isSatEnabled,
    const GeoLibVideoIfeFrameCfg*   frameConfig
);

bool Validate_GeoLibVideoIpeCalcFrame(
    const GeoLibVideoIpeFrameCfg*         frameConfig
);

bool Validate_GeoLibVideoIpeHdrCalcFrame(
    GeoLibVideoIpeFrameCfg*         mExpOut,
    GeoLibVideoIpeFrameCfg*         slExpOut
);

bool Validate_GeoLibVideoEisCalcFrame(
    GeoLibVideoEisFrameCfg*         frameConfig
);

bool Validate_GeoLibVideoCvpCalcFrame(
    const GeoLibVideoCvpFrameCfg* frameConfig
);


// Kona Still validation

bool Validate_GeoLibStillCalcFrameInput(
    const GeoLibStillFlowMode      flowMode,
    const GeoLibMultiFrameMode     mfMode,
    const GeoLibImageSize*         sensorSize,
    const NcLibIcaGrid*            ldFullOutToIn,
    const NcLibIcaGrid*            ldFullInToOut,
    const GeoLibImageSize*         ldFullOutSize,
    const GeoLibImageSize*         stillOutSize,
    const GeoLibImageSize*         dispOutSize,
    const GeoLibImageSize*         regOutSize,
    const float                    digitalZoom);

bool Validate_GeoLibStillCalcFrameOutput(
    const GeoLibStillFlowMode       flowMode,
    const GeoLibMultiFrameMode      mfMode,
    const GeoLibImageSize*          dispSize,
    const GeoLibStillFrameConfig*   frameConfig
);


// Lahaina Still validation

bool Validate_GeoLibStillCalcFrameInput(
    const GeoLibStillFlowMode       flowMode,
    const GeoLibHdrFlowMode         hdrMode,
    const GeoLibSensorData*         sensorData,
    const NcLibIcaGrid*             ldFullOutToIn,
    const GeoLibImageSize*          ldFullOutSize,
    const GeoLibIpeParams*          ipeParams,
    const GeoLibImageSize*          regOutSize,
    const GeoLibROI*                zoomWindow,
    const float                     fovcRatio
);

bool Validate_GeoLibStillHdrCalcFrameInput(
    const GeoLibSensorData*         sensorData,
    const NcLibIcaGrid*             ldFullOutToIn,
    const GeoLibImageSize*          ldFullOutSize,
    const GeoLibImageSize*          regOutSizeExp1,
    const GeoLibImageSize*          regOutSizeExp2,
    const GeoLibImageSize*          regOutSizeExp3,
    const GeoLibIpeParams*          ipeParams,
    const GeoLibROI*                zoomWindow,
    const float                     fovcRatio
);

bool Validate_GeoLibStillCalcFrameOutput(
    const bool                      isMultiFrame,
    const bool                      isHDRFlow,
    const GeoLibImageSize*          dispOutSize,
    const GeoLibStillMFFrameConfig* stillConfig
);

bool Validate_GeoLibStillIpeHdrBlendFrameOutput(
    const uint32_t                              expNum,
    const GeoLibStillIPEHDRBlendFrameConfig*    ipeHdrBlend
);

bool Validate_GeoLibStillEvaHdrBlendFrameOutput(
    const uint32_t                              expNum,
    const GeoLibStillEVAHDRBlendFrameConfig*    evaHdrBlend
);

bool Validate_GeoLibStillLastHdrCalcFrameOutput(
    const GeoLibStillIPEFrameConfig*      hdrLast
);

bool Validate_GeoLibStillHdrCalcFrameOutput(
    const uint32_t                        expNum,
    const GeoLibStillHDRBlendFrameConfig* hdrBlend,
    const GeoLibStillIPEFrameConfig*      hdrLast
);


// Waipio Still validation

bool Validate_GeoLibStillCalcFrameInput(
    const GeoLibStillFlowMode        flowMode,
    const GeoLibHdrFlowMode          hdrMode,
    const GeoLibSensorData*          sensorData,
    const NcLibIcaGrid*              ldFullOutToIn,
    const GeoLibImageSize*           ldFullOutSize,
    const GeoLibIpeParams*           ipeParams,
    const GeoLibImageSize*           regOutSize,
    const NcLibROI*                  zoomWindow,
    const float                      fovcRatio
);

bool Validate_GeoLibStillCalcFrameOutput(
    const bool                       isMultiFrame,
    const bool                       isHDRFlow,
    const bool                       isQllEnabled,
    const uint32_t                   numPasses,
    const GeoLibImageSize*           dispOutSize,
    const GeoLib2StillMFFrameConfig* stillConfig
);

// Waipio Video validation

bool Validate_GeoLibVideoIpeCalcFrame(
    const GeoLib2IpeFrameCfg* frameCfg
);

bool Validate_GeoLib2Init(
    const GeoLib2InitIn* initIn,
    const GeoLib2StreamCfg* streamConfig
);

bool Validate_GeoLib2CalcFrame(
    const GeoLibHdrFlowMode hdrMode,
    const GeoLib2CalcFrameIn* calcFrameIn,
    const GeoLib2FrameCfg* frameConfig,
    const bool allowResidual = true
);

// Kailua Video validation

bool Validate_NcLibAiIpeInit(
    const NcLibAiIpeInitIn* initIn,
    const NcLibAiIpeCfg* initCfg
);


// Kailua Still validation

bool Validate_GeoLib2StillCalcFrameOutput(bool isHDR, bool isMultiFrame, bool isQllEnabled,
                                          bool mainOut, bool dispOut, bool appOut, uint32_t numPasses,
                                          const GeoLib2StillFrameConfig* stillConfig);

// Misc

void SetDefaultsForGeoLibIcaPassMapping(GeoLibIcaPassMapping* icaPassMapping, uint32_t numOfPasses);

#endif // GEOLIBUTILS_H
