//-------------------------------------------------------------------------
// Copyright (c) 2015-2020 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
//------------------------------------------------------------------------

#ifndef IPE_STRIPE_ALLOCATION_COMMON_H_
#define IPE_STRIPE_ALLOCATION_COMMON_H_

#include "ipe_stripe_internal_structs.h"
#include "stripeNPSPPS.h"

void deriveOutputTargetLeft(const PassInput1D * pInput, const PassVar1D * pParams, const int stripeIdx, ipeStripeAllocationControl *allocationCtrl);

int deriveOutputLeftBound(const PassVar1D *pParams, const int preallocatedStripeCount, const int stripeIdx,
                          const int fovStartInSrc, const int fovDimInSrc, const int fovOutDim, const int formatConstraint, BOOL isSIMO);

int genOutputRightBound(const int lastUngeneratedOutput, const int minOutputSize, const int outputLeftBound,
                        const int outDim, const int formatConstraint);

//deriveFetchRange:
//decide the fetch range based on desired output ranges (right: aligns with the left edge of the previous stripe with the exception of the extension to 130B
//left: aligns to a pre-determined even-sized grid and can be conditionally relaxed)
//it outputs the fetchStart and fetchEnd of pStripe and the desired upscalar input range and output right bound (used to specify the output_l of upscalar)
void deriveFetchRange(const PassInput1D * pInput, const PassVar1D * pParams, ipeStripeAllocationControl *allocationCtrl,
                      IpeStripeAllocationResultPerStripe *allocationResult, const int stripeIdx );


BOOL passDone1D(const PassInput1D * pInput, const PassVar1D * pParams, const ipeStripeAllocationControl *allocationCtrl);
void deriveStripeRangesGivenFetch(const PassInput1D * pInput, const PassVar1D * pParams, ipeStripeAllocationControl *allocationCtrl, IpeStripeAllocationResultPerStripe *allocationResult,
                                  const int fetchLeft, const int fetchRight );
void initAllocationCtrl_1D(const PassInput1D* pInput, const BOOL is_horizontal, ipeStripeAllocationControl *allocationCtrl);
void initScalers(const PassInput1D * pInput, PassVar1D * pParams);
void backwardPropagateGivenIPEout(const PassInput1D * pInput, const PassVar1D * pParams, IpeStripeAllocationResultPerStripe *allocationResult );
void updateAllocationCtrl_1D(const PassInput1D* pInput, const PassVar1D * pParams,
                             const IpeStripeAllocationResultPerStripe *pAllocationResult_x, ipeStripeAllocationControl *allocationCtrl);
int deriveMinRightBoundsFromOutputs(const PassInput1D * pInput, const PassVar1D * pParams, ipeStripeAllocationControl *allocationCtrl);

//deriveLeftBoundsFromOutputs
//returns the (unbounded) left fetch coordinate required by the output left bounds of output ports
//it also sets the target output left bound at the upscalar output (upscalar_out_left)
int deriveLeftBoundsFromOutputs(const PassInput1D * pInput, const PassVar1D * pParams, ipeStripeAllocationControl *allocationCtrl);


//required_fetch_right_from_tf_refine:
//this function derives the (bounded) fetch end required by the allocated tf refinement processing range
int required_fetch_right_from_tf_refine(const PassInput1D * pInput, const PassVar1D * pParams, const IpeStripeAllocationResultPerStripe *allocationResult);

//required_fetch_left_from_tf_refine:
//this function derives the (bounded) fetch start required by the allocated tf refinement processing range
int required_fetch_left_from_tf_refine(const PassInput1D * pInput, const PassVar1D * pParams, const IpeStripeAllocationResultPerStripe *allocationResult);
int16_t FormatConstraintTFI(const BOOL horizontal, const BOOL is_write, const int16_t chip );
int16_t FormatConstraintAlgm(const BOOL is_horizontal, const BOOL is_write, const int16_t chip);

#endif // !IPE_STRIPE_ALLOCATION_COMMON_H_
