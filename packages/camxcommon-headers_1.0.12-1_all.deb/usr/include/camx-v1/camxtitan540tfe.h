////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2020-2021, 2024 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @file  camxtitan540tfe.h
/// @brief Titan540 TFE pipeline Class
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef CAMXTITAN540TFE_H
#define CAMXTITAN540TFE_H
#include "camxcsltfedefs.h"

CAMX_NAMESPACE_BEGIN

static const UINT32 MaxTFEFlushDumpRegions   = 32;                                           ///< Max TFE Flush Dump regions

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief Base Class for all Titan540 TFE Pipeline setup
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
class Titan540TFE final : public ISPPipeline
{
public:
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// ProgramIQModuleEnableConfig
    ///
    /// @brief  Reprogram the Module enable settings for the IQ Modules
    ///
    /// @param  pInputData          Pointer to the input data
    /// @param  pISPData            Pointer to the ISP internal data
    /// @param  pTFEOutputPathInfo  Pointer to the TFE output path data
    ///
    /// @return CamxResult True on successful execution else False on failure
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// @todo (CAMX-4913) Change IFEOutputPath to TFEOutputPath
    CamxResult ProgramIQModuleEnableConfig(
        ISPInputData*       pInputData,
        ISPInternalData*    pISPData,
        IFEOutputPath*      pTFEOutputPathInfo);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetISPIQModulesOfType
    ///
    /// @brief  Get ISP IQ module
    ///
    /// @param  moduleType  Module type
    /// @param  pModuleInfo Pointer to the module info
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    VOID GetISPIQModulesOfType(
        ISPIQModuleType moduleType,
        VOID*           pModuleInfo);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// PopulateGeneralTuningMetadata
    ///
    /// @brief  Helper to populate tuning data easily obtain at TFE node level
    ///
    /// @param  pInputData Pointer to the data input and output stuctures are inside
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    VOID PopulateGeneralTuningMetadata(
        ISPInputData* pInputData);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// DumpTuningMetadata
    ///
    /// @brief  Helper to publish tuning metadata
    ///
    /// @param  pInputData          Pointer to the input data
    /// @param  pDebugDataWriter    Pointer to tuning-data writer
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    VOID DumpTuningMetadata(
        ISPInputData*       pInputData,
        DebugDataWriter*    pDebugDataWriter);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// FillTFEIQModuleVersion
    ///
    /// @brief  Helper to Fill TFE IQ module Version
    ///
    /// @param  pModuleVersion Pointer to the module version
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    VOID FillTFEIQModuleVersion(
        TFEIQHWVersion*  pModuleVersion);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// FillTFEStatsModuleVersion
    ///
    /// @brief  Helper to Fill TFE Stats module Version
    ///
    /// @param  pModuleVersion Pointer to the module version
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    VOID FillTFEStatsModuleVersion(
        TFEStatsHWVersion*  pModuleVersion);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetBFHWCapability
    ///
    /// @brief  virtual method to get the isp pipeline BF HW capability
    ///
    /// @param  pCapabilityInfo Pointer to the structure into which capability info is filled
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual VOID GetBFHWCapability(
        AFBAFHardwareCapability* pCapabilityInfo);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetPDHWCapability
    ///
    /// @brief  virtual method to get the isp pipeline PDHW capability
    ///
    /// @param  pCapabilityInfo Pointer to the structure into which capability info is filled
    /// @param  profileID       IFE node profile
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    VOID GetPDHWCapability(
        PDHwAvailablity* pCapabilityInfo,
        IFEProfileId     profileID);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// SetupFlushRegDump
    ///
    /// @brief  virtual method to setup ISP Register Dump structures
    ///
    /// @param  pFlushBuffer Pointer to the flush dump Buffer
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    VOID SetupFlushRegDump(
        VOID* pFlushBuffer);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// ParseFlushRegDump
    ///
    /// @brief  Helper method to parse ISP Register Dump structures
    ///
    /// @param  pFlushBuffer Pointer to the flush dump Buffer
    /// @param  pBankUpdate  Pointer to the DMI Bank Update
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    VOID ParseFlushRegDump(
        VOID*             pFlushBuffer,
        VOID* pBankUpdate);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// UpdateDMIBankSelectValue
    ///
    /// @brief  Helper method to set all double banked DMI to a given bank value
    ///
    /// @param  pBankUpdate     Pointer to the DMI Bank Update
    /// @param  isBankValueZero True to select bank 0, otherwise, select bank 1
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual VOID UpdateDMIBankSelectValue(
        VOID*   pBankUpdate,
        BOOL    isBankValueZero);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// SetupHangRegDump
    ///
    /// @brief  Helper method to setup ISP Register Dump structures
    ///
    /// @param  pHangBuffer     Pointer to the hang dump Buffer
    /// @param  p_TFEMode       TFE Mode
    /// @param  isPerFrameDump  indicator for Per Frame Dump
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual VOID SetupHangRegDump(
        VOID*         pHangBuffer,
        VOID*         p_TFEMode,
        BOOL          isPerFrameDump);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// ParseHangRegDump
    ///
    /// @brief  Helper method to parse ISP Register Dump structures
    ///
    /// @param  pHangBuffer Pointer to the flush dump Buffer
    /// @param  leftHangFd  file descriptor fd for left Stripe
    /// @param  rightHangFd file descriptor fd for right Stripe
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual VOID ParseHangRegDump(
        VOID* pHangBuffer,
        INT   leftHangFd,
        INT   rightHangFd);


    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Titan540TFE
    ///
    /// @brief  Constructor
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    Titan540TFE();


    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// ~Titan540TFE
    ///
    /// @brief  Destructor
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ~Titan540TFE();

private:

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// FillTFERegReadInfo
    ///
    /// @brief  Helper function to fill Reg Read Info
    ///
    /// @param  pRegReadInfo  Pointer to the Register Read Info to be filled
    /// @param  offset        Reg Offset
    /// @param  numberOfReads number of DMI Data reads
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    CAMX_INLINE VOID FillTFERegReadInfo(
        CSLTFERegReadInfo*  pRegReadInfo,
        UINT32              offset,
        UINT32              numberOfReads)
    {
        if (NULL != pRegReadInfo)
        {
            pRegReadInfo->readType                                   = TFERegDumpReadTypeReg;
            pRegReadInfo->regDescriptor.regReadCmd.offset            = offset;
            pRegReadInfo->regDescriptor.regReadCmd.numberOfRegisters = numberOfReads;
        }
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// FillTFEDMIReadInfo
    ///
    /// @brief  Helper function to fill Reg Read Info
    ///
    /// @param  pDMIReadInfo  Pointer to the DMI Read Info to be filled
    /// @param  offset        DMI Reg Offset
    /// @param  bankOffset    DMI Bank Offset
    /// @param  numberOfReads number of DMI Data reads
    /// @param  bankSelect    bank Select
    /// @param  lutSelect     LUT Select
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    CAMX_INLINE VOID FillTFEDMIReadInfo(
        CSLTFERegReadInfo*  pDMIReadInfo,
        UINT32              offset,
        UINT32              bankOffset,
        UINT32              numberOfReads,
        UINT32              bankSelect,
        UINT32              lutSelect)
    {
        if (NULL != pDMIReadInfo)
        {
            pDMIReadInfo->readType = TFERegDumpReadTypeDMI;
            pDMIReadInfo->regDescriptor.dmiReadCmd.regWriteCmd[0].offset         = offset;
            pDMIReadInfo->regDescriptor.dmiReadCmd.regWriteCmd[0].value          = 0x100000;
            pDMIReadInfo->regDescriptor.dmiReadCmd.numberOfRegWrites++;
            pDMIReadInfo->regDescriptor.dmiReadCmd.regWriteCmd[1].offset         = offset + 0x4;
            pDMIReadInfo->regDescriptor.dmiReadCmd.regWriteCmd[1].value          = lutSelect;
            pDMIReadInfo->regDescriptor.dmiReadCmd.numberOfRegWrites++;
            pDMIReadInfo->regDescriptor.dmiReadCmd.regWriteCmd[2].offset         = bankOffset;
            pDMIReadInfo->regDescriptor.dmiReadCmd.regWriteCmd[2].value          = bankSelect;
            pDMIReadInfo->regDescriptor.dmiReadCmd.numberOfRegWrites++;
            pDMIReadInfo->regDescriptor.dmiReadCmd.regRangeCmd.numberOfRegisters = numberOfReads;
            pDMIReadInfo->regDescriptor.dmiReadCmd.regRangeCmd.offset            = offset + 0x8;
            pDMIReadInfo->regDescriptor.dmiReadCmd.postregWriteCmd[1].offset     = offset + 0x4;
            pDMIReadInfo->regDescriptor.dmiReadCmd.postregWriteCmd[1].value      = 0;
            pDMIReadInfo->regDescriptor.dmiReadCmd.numberOfPostWrites++;
        }
    }


    Titan540TFE(const Titan540TFE&)            = delete; ///< Disallow the copy constructor
    Titan540TFE& operator=(const Titan540TFE&) = delete; ///< Disallow assignment operator

    UINT32 m_hangDumpOutputBufferSize           = 0;  ///< Hnag Dump Buffer size in Bytes
    UINT32 m_perFrameDumpOutputBufferSize       = 0;  ///< Per Frame Dump Buffer size in Bytes

    TFECapabilityInfo    m_TFECapability;   ///< TFE Capability Info
};

CAMX_NAMESPACE_END

#endif // CAMXTFEPIPELINETITAN540_H
