////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2020-2022 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @file  camxgrallocutils.h
/// @brief CamX Gralloc utility implementation
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef CAMXGRALLOCUTILS_H
#define CAMXGRALLOCUTILS_H

// NOWHINE FILE NC004c: Gralloc Struct cannot prefix with Camx

#include "camxcommontypes.h"
#include "camxdebug.h"
#include "camxdefs.h"
#include "camxformats.h"
#include "camxhal3types.h"
#include "camxmem.h"
#include "camxtypes.h"

// Only when we are compiling for Windows' DLL.
#if (defined( WIN32 ) || defined( WIN64 ))
#include "qdMetaData.h"
#else /* WIN32 || WIN64 */
#if (!defined(LE_CAMERA))
// This macro needs to be undefined before accessing Gralloc header files
#undef LOG_INFO
#include "QtiGralloc.h"
#include "graphics.h"
#include "aidl/android/hardware/graphics/common/StandardMetadataType.h"
using aidl::android::hardware::graphics::common::StandardMetadataType;

#endif // !LE_CAMERA


/// @ brief Enums duplicated from Gralloc Legacy
/// To convert enum from legacy to Gralloc#4, use the new enum value
enum GrallocEnum
{
    #if (!defined(LE_CAMERA))
    COLOR_METADATA          = QTI_COLOR_METADATA,                                       ///< Set Color Metadata
    SET_CVP_METADATA        = QTI_CVP_METADATA,                                         ///< Set CVP Metadata
    SET_UBWC_CR_STATS_INFO  = QTI_UBWC_CR_STATS_INFO,                                   ///< UBWC Stats
    SET_VIDEO_PERF_MODE     = QTI_VIDEO_PERF_MODE,                                      ///< Set Video Perf mode
    SET_VT_TIMESTAMP        = QTI_VT_TIMESTAMP,                                         ///< Set VT Timestamp
    // This enum mapped to AIDL data enum in implementation later
    UPDATE_BUFFER_GEOMETRY  = QTI_SINGLE_BUFFER_MODE,                                   ///< Buffer Dimensions
    TIMED_RENDERING         = QTI_TIMED_RENDERING,                                      ///< Timed rendering
    SMPTE_2086              = static_cast<INT32>(StandardMetadataType::SMPTE2086),      ///< Smpte_2086 standard metadata
    SMPTE_2094_40           = static_cast<INT32>(StandardMetadataType::SMPTE2094_40),   ///< Smpte_2094_40 standard metadata
    #endif // !LE_CAMERA
};

/// @ brief struct duplicated from Gralloc Legacy
struct BufferDim_t
{
    UINT32 sliceWidth;  ///< Width
    UINT32 sliceHeight; ///< Height
};

#endif /* WIN32 || WIN64 */

CAMX_NAMESPACE_BEGIN

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief General Gralloc allocator class
///
/// Basic wrapping Gralloc alloc, free
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
class CAMX_VISIBILITY_PUBLIC Gralloc final
{
public:
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// CreateInstance
    ///
    /// @brief  This function returns the singleton instance of the Gralloc
    ///
    /// @return A pointer to the singleton instance of the Gralloc
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    static VOID CreateInstance();

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetInstance
    ///
    /// @brief  This function returns the singleton instance of the Gralloc
    ///
    /// @return A pointer to the singleton instance of the Gralloc
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    static Gralloc* GetInstance();

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// AllocateGrallocBuffer
    ///
    /// @brief  Method to allocate gralloc buffer
    ///
    /// @param  width               Width of the image buffer
    /// @param  height              Height of the image buffer
    /// @param  grallocFormat       Format of the image buffer
    /// @param  phAllocatedBuffer   Gralloc return pointer
    /// @param  pStride             Stride updated by gralloc
    /// @param  producerFlags       ProducerFlags for gralloc memory allocation
    /// @param  consumerFlags       ConsumerFlags for gralloc memory allocation
    ///
    /// @return CamxResultSuccess on success, CamxResultEFailed otherwise
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    CamxResult AllocateGrallocBuffer(
        UINT32           width,
        UINT32           height,
        UINT32           grallocFormat,
        BufferHandle*    phAllocatedBuffer,
        UINT32*          pStride,
        UINT64           producerFlags,
        UINT64           consumerFlags);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Destroy
    ///
    /// @brief  Method to Free gralloc buffer
    ///
    /// @param  hAllocatedBuffer   gralloc buffer handle
    ///
    /// @return CamxResultSuccess on success, CamxResultEFailed otherwise
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    CamxResult Destroy(
        BufferHandle hAllocatedBuffer);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Retain
    ///
    /// @brief  Method to Retain gralloc buffer
    ///
    /// @param  hAllocatedBuffer   gralloc buffer handle
    ///
    /// @return CamxResultSuccess on success, CamxResultEFailed otherwise
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    CamxResult Retain(
        BufferHandle hAllocatedBuffer);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// ConvertCamxFormatToGrallocFormat
    ///
    /// @brief  Convert Camx format to gralloc format.
    ///
    /// @param  camxFormat         Camx Format
    /// @param  pGrallocFormat     pointer to gralloc format
    ///
    /// @return CamxResult Enum
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    CamxResult ConvertCamxFormatToGrallocFormat(
        CamX::Format camxFormat,
        UINT32*      pGrallocFormat);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// SetGrallocMetaData
    ///
    /// @brief  API to set Metadata into Gralloc handle.
    ///
    /// @param  hNativehandle       Pointer to Native Handle
    /// @param  metadatatype        Metadata type
    /// @param  metadataSize        Metadata size
    /// @param  pMetadata           pointer to metadata structure
    ///
    /// @return CamxResult Enum
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    static CamxResult SetGrallocMetaData(
        BufferHandle        hNativehandle,
        UINT32              metadatatype,
        UINT32              metadataSize,
        VOID*               pMetadata);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetGrallocInterface
    ///
    /// @brief  API to get Gralloc Interface struct pointer. This is used in format mapper.
    ///
    /// @return Gralloc Interface
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    CAMX_INLINE VOID* GetGrallocInterface()
    {
        return m_pGrallocIntf;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetBufferId
    ///
    /// @brief  Method to get the buffer handle ID
    ///
    /// @param  phBufHandle     gralloc buffer handle
    ///
    /// @return UINT64 bufferID on success, -1 otherwise
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    UINT64 GetBufferId(
        VOID*   phBufHandle);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetBufferSize
    ///
    /// @brief  Method to get the buffer size for given handle
    ///
    /// @param  phBufHandle     gralloc buffer handle
    /// @param  rBufferSize     gralloc buffer Size
    ///
    /// @return CamxResultSuccess on success, CamxResultEFailed otherwise
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    CamxResult GetBufferSize(
        VOID*   phBufHandle,
        SIZE_T& rBufferSize);

private:
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// ~Gralloc
    ///
    /// @brief  Gralloc dtor
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ~Gralloc();

    Gralloc()                                   = default;  ///< Default constructor
    Gralloc(const Gralloc& rOther)              = delete;   ///< Disallow the copy constructor
    Gralloc(const Gralloc&& rrOther)            = delete;   ///< Disallow the move  constructor
    Gralloc& operator=(const Gralloc& rOther)   = delete;   ///< Disallow assignment operator
    Gralloc& operator=(const Gralloc&& rrOther) = delete;   ///< Disallow move assignment operator

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Initialize
    ///
    /// @brief  Sets gralloc interface functions.
    ///
    /// @return CamxResult Enum
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    CamxResult Initialize();

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// InitializeMapper4
    ///
    /// @brief  Initialize Mapper4.
    ///
    /// @return CamxResult Enum
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    CamxResult InitializeMapper4();

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// AllocateGrallocBufferWithMapper4
    ///
    /// @brief  Method to allocate gralloc buffer
    ///
    /// @param  width               Width of the image buffer
    /// @param  height              Height of the image buffer
    /// @param  grallocFormat       Format of the image buffer
    /// @param  phAllocatedBuffer   Gralloc return pointer
    /// @param  pStride             Stride updated by gralloc
    /// @param  producerFlags       ProducerFlags for gralloc memory allocation
    /// @param  consumerFlags       ConsumerFlags for gralloc memory allocation
    ///
    /// @return CamxResultSuccess on success, CamxResultEFailed otherwise
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    CamxResult AllocateGrallocBufferWithMapper4(
        UINT32           width,
        UINT32           height,
        UINT32           grallocFormat,
        BufferHandle*    phAllocatedBuffer,
        UINT32*          pStride,
        UINT64           producerFlags,
        UINT64           consumerFlags);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// ResetGrallocInterfaces
    ///
    /// @brief  API to reset Gralloc Interfaces
    ///
    /// @param  freeMemory  Flag to decide whether memory is free
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    VOID ResetGrallocInterfaces(
        BOOL freeMemory);

    VOID* m_pGrallocIntf;       ///< Gralloc Interface Object, Typecast to GrallocInterface
};

CAMX_NAMESPACE_END

#endif // CAMXGRALLOCUTILS_H
