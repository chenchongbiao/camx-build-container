////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2019-2020 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @file  camxtfestripinginterface.h
/// @brief camxtfestripinginterface class declarations
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


#ifndef CAMXTFESTRIPINGINTERFACE_H
#define CAMXTFESTRIPINGINTERFACE_H

#include "camxdefs.h"



// NOWHINE FILE GR035: CAMX_PACKED is inside CAMX_BEGIN_PACKED_ALIGN_N

CAMX_NAMESPACE_BEGIN

enum TFEStripeChipVersion
{
    SPECTRA_520 = 8,           // Kamorta
    SPECTRA_545 = 16,          // Mannar
};


struct TFEStripeWriteEnginePassParam
{
    INT32   bufStride1;               ///< bufStride1;
    INT32   stripeHeight1;            ///< stripeHeight1
    INT32   bufStride2;               ///< bufStride2;
    INT32   stripeHeight2;            ///< stripeHeight2
};

struct TFEStripeBDSInStructV10InputParams
{
    UINT16      inputP;                             ///< input for P MNDS
    UINT16      outputP;                            ///< output for P MNDS
    UINT32      phaseStepH;                         ///< phase step for Horizontal
    INT32       phaseInitHorizontalP;               ///< phase init for P MNDS
    UINT16      earlyTerminationHorizontalP;        ///< early termination for P MNDS
    INT32       roundingOptionHorizontalP;          ///< rounding for H P MNDS
    INT32       roundingOptionVerticalP;            ///< rounding for V P MNDS

    UINT16      inputTL;                            ///< input for TL MNDS
    UINT16      outputTL;                           ///< output for TL MNDS
    INT32       phaseInitHorizontalTL;              ///< phase init for TL MNDS
    INT32       roundingOptionHorizontalTL;         ///< rounding for H TL MNDS
    INT32       roundingOptionVerticalTL;           ///< rounding for V TL MNDS

    UINT16      inputTR;                            ///< input for TR MNDS
    UINT16      outputTR;                           ///< output for TR MNDS
    INT32       phaseInitHorizontalTR;              ///< phase init for TR MNDS
    INT32       roundingOptionHorizontalTR;         ///< rounding for H TR MNDS
    INT32       roundingOptionVerticalTR;           ///< rounding for V TR MNDS

    UINT16      inputBL;                            ///< input for BL MNDS
    UINT16      outputBL;                           ///< output for BL MNDS
    INT32       roundingOptionHorizontalBL;         ///< rounding for H BL MNDS
    INT32       roundingOptionVerticalBL;           ///< rounding for V BL MNDS

    UINT16      inputBR;                            ///< input for BR MNDS
    UINT16      outputBR;                           ///< output for BR MNDS
    INT32       roundingOptionHorizontalBR;         ///< rounding for H BR MNDS
    INT32       roundingOptionVerticalBR;           ///< rounding for V BR MNDS

    UINT8       preCropEn;                          ///< precrop enable
    UINT8       postCropEn;                         ///< postcrop enable
    UINT8       precropPEn;                         ///< precrop enable for P MNDS
    UINT16      precropHorizontalTLBLEn;            ///< precrop enable for horizontal TL/BL MNDS
    UINT16      precropHorizontalTRBREn;            ///< precrop enable for horizontal TR/BR MNDS
    UINT16      precropVerticalTLTREn;              ///< precrop enable for vertical TL/BL MNDS
    UINT16      precropVerticalBLBREn;              ///< precrop enable for vertical BL/BR MNDS

    UINT16      precropFirstPixel;                  ///< precrop first pixel
    UINT16      precropLastPixel;                   ///< precrop last pixel
    UINT16      postcropFirstPixel;                 ///< postcrop first pixel
    UINT16      postcropLastPixel;                  ///< postcrop last pixel

    UINT16      precropPFirstPixel;                 ///< precrop first pixel for P
    UINT16      precropPLastPixel;                  ///< precrop last pixel for P

    UINT16      precropHorizontalTLBLFirstPixel;    ///< precrop first pixel horizontal for TL/BL
    UINT16      precropHorizontalTLBLLastPixel;     ///< precrop last pixel horizontal for TL/BL
    UINT16      precropHorizontalTRBRFirstPixel;    ///< precrop first pixel horizontal for TR/BR
    UINT16      precropHorizontalTRBRLastPixel;     ///< precrop last pixel horizontal for TR/BR
    UINT16      precropVerticalTLTRFirstPixel;      ///< precrop first pixel vertical for TL/TR
    UINT16      precropVerticalTLTRLastPixel;       ///< precrop last pixel vertical for TL/TR
    UINT16      precropVerticalBLBRFirstPixel;      ///< precrop first pixel vertical for BL/BR
    UINT16      precropVerticalBLBRLastPixel;       ///< precrop last pixel vertical for BL/BR
};

struct TFEStripeBDSInStructV11InputParams
{
    UINT16      inputP;                             ///< input for P MNDS
    UINT16      outputP;                            ///< output for P MNDS
    UINT32      phaseStepH;                         ///< phase step for Horizontal
    INT32       phaseInitHorizontalP;               ///< phase init for P MNDS
    UINT16      overlapOriginal;                    ///< original overlap
    UINT16      overlap;                            ///< overlap
    UINT16      earlyTerminationHorizontalP;        ///< early termination for P MNDS
    INT32       roundingOptionHorizontalP;          ///< rounding for H P MNDS
    INT32       roundingOptionVerticalP;            ///< rounding for V P MNDS

    UINT16      inputTL;                            ///< input for TL MNDS
    UINT16      outputTL;                           ///< output for TL MNDS
    INT32       phaseInitHorizontalTL;              ///< phase init for TL MNDS
    INT32       roundingOptionHorizontalTL;         ///< rounding for H TL MNDS
    INT32       roundingOptionVerticalTL;           ///< rounding for V TL MNDS

    UINT16      inputTR;                            ///< input for TR MNDS
    UINT16      outputTR;                           ///< output for TR MNDS
    UINT32      phaseInitHorizontalTR;              ///< phase init for TR MNDS
    INT32       roundingOptionHorizontalTR;         ///< rounding for H TR MNDS
    INT32       roundingOptionVerticalTR;           ///< rounding for V TR MNDS

    UINT16      inputBL;                            ///< input for BL MNDS
    UINT16      outputBL;                           ///< output for BL MNDS
    INT32       roundingOptionHorizontalBL;         ///< rounding for H BL MNDS
    INT32       roundingOptionVerticalBL;           ///< rounding for V BL MNDS

    UINT16      inputBR;                            ///< input for BR MNDS
    UINT16      outputBR;                           ///< output for BR MNDS
    INT32       roundingOptionHorizontalBR;         ///< rounding for H BR MNDS
    INT32       roundingOptionVerticalBR;           ///< rounding for V BR MNDS

    UINT8       preCropEn;                          ///< precrop enable
    UINT8       postCropEn;                         ///< postcrop enable
    UINT8       precropPEn;                         ///< precrop enable for P MNDS
    UINT16      precropHorizontalTLBLEn;            ///< precrop enable for horizontal TL/BL MNDS
    UINT16      precropHorizontalTRBREn;            ///< precrop enable for horizontal TR/BR MNDS
    UINT16      precropVerticalTLTREn;              ///< precrop enable for vertical TL/BL MNDS
    UINT16      precropVerticalBLBREn;              ///< precrop enable for vertical BL/BR MNDS

    UINT16      precropFirstPixel;                  ///< precrop first pixel
    UINT16      precropLastPixel;                   ///< precrop last pixel
    UINT16      postcropFirstPixel;                 ///< postcrop first pixel
    UINT16      postcropLastPixel;                  ///< postcrop last pixel

    UINT16      precropPFirstPixel;                 ///< precrop first pixel for P
    UINT16      precropPLastPixel;                  ///< precrop last pixel for P

    UINT16      precropHorizontalTLBLFirstPixel;    ///< precrop first pixel horizontal for TL/BL
    UINT16      precropHorizontalTLBLLastPixel;     ///< precrop last pixel horizontal for TL/BL
    UINT16      precropHorizontalTRBRFirstPixel;    ///< precrop first pixel horizontal for TR/BR
    UINT16      precropHorizontalTRBRLastPixel;     ///< precrop last pixel horizontal for TR/BR
    UINT16      precropVerticalTLTRFirstPixel;      ///< precrop first pixel vertical for TL/TR
    UINT16      precropVerticalTLTRLastPixel;       ///< precrop last pixel vertical for TL/TR
    UINT16      precropVerticalBLBRFirstPixel;      ///< precrop first pixel vertical for BL/BR
    UINT16      precropVerticalBLBRLastPixel;       ///< precrop last pixel vertical for BL/BR
};

struct TFEStripeDS8InStruct
{
    UINT8       scaleDS8;                           ///< Scale
    UINT8       kernelDS8;                          ///< DS8 Kernel
    UINT8       preCropEn;                          ///< precrop enable
    UINT16      precropFirstPixel;                  ///< precrop first pixel
    UINT16      precropLastPixel;                   ///< precrop last pixel
};

struct TFEStripeMNScaleDownInputV16
{
    UINT16 enable;                    ///< en;
    UINT16 input;                     ///< input_l;
    UINT16 output;                    ///< output_l;
    UINT16 pixelOffset;               ///< pixel_offset;
    UINT16 cntInit;                   ///< cnt_init;
    UINT16 interpReso;                ///< interp_reso;
    UINT16 roundingOptionVer;         ///< rounding_option_v;
    UINT16 roundingOptionHor;         ///< rounding_option_h;
    UINT16 rightPadEnable;            ///< right_pad_en;
    UINT16 inputProcessedLength;      ///< input_processed_length;
    UINT32 phaseInit;                 ///< phase_init;
    UINT32 phaseStep;                 ///< phase_step;
};  // HW parameters

struct TFEStripeBayerFocusv26InputParam
{
    UINT16                          horizaltalRegionNum;                ///< horizontal region number
    UINT16                          verticalRegionNum;                  ///< vertical region number
    UINT16                          horizontalROIfset;                  ///< horizontal ROI number
    UINT16                          regionWidth;                        ///< region width
    UINT16                          firH1En;                            ///< fir H1 enable
    UINT16                          iirH1En;                            ///< iir H1 enable
    UINT16                          padding;                            ///< padding
    TFEStripeMNScaleDownInputV16    mndsParam;                          ///< MNDS parameters
    INT                             scaleRatio;                         ///< scale Ratio
    UINT16                          bankSel;                            ///< bank sel
    UINT16                          ROIXmin;                            ///< ROI X min
    UINT16                          ROIXmax;                            ///< ROI X max
    UINT16                          enableRegionSplit;                  ///< Enable region split
    UINT16                          regionWidthMax;                     ///< Max region width
    UINT16                          horizontalRegionNumMax;             ///< Max horizontal region number
    UINT16                          horizontalROIOffsetMax;             ///< Max horizontal ROI offset
    INT16                           fetchLeftStripeEnd;                 ///< Fetch coordinate
    INT16                           fetchRightStripeStart;              ///< Fetch coordinate
    INT16                           inputWidth;                         ///< Input Width
};

struct TFEStripeMNScaleDownInputV20
{
    INT32  phaseInit;                ///< phase_init;
    UINT32 phaseStep;                ///< phase_step;
    UINT16 enable;                   ///< en;
    UINT16 input;                    ///< input_l;
    UINT16 output;                   ///< output_l;
    UINT16 pixelOffset;              ///< pixel_offset;
    UINT16 interpReso;               ///< interp_reso;
    UINT16 roundingOptionVer;        ///< rounding_option_v;
    UINT16 roundingOptionHor;        ///< rounding_option_h;
    BOOL   dropFirstOutput;          ///< drop_first_output;
    UINT16 dummyFieldForBytePadding; ///< dummy_field_for_byte_padding
    UINT16 earlyTerminationHor;      ///< early_termination_h
    UINT16 overlap;                  ///< overlap
};  // HW params

struct TFEStripeMNScaleDownInputV23
{
    INT32  phaseInit;                ///< phase_init;
    UINT32 phaseStep;                ///< phase_step;
    UINT16 enable;                   ///< en;
    UINT16 input;                    ///< input_l;
    UINT16 output;                   ///< output_l;
    UINT16 pixelOffset;              ///< pixel_offset;
    UINT16 interpReso;               ///< interp_reso;
    UINT16 roundingOptionVer;        ///< rounding_option_v;
    UINT16 roundingOptionHor;        ///< rounding_option_h;
    BOOL   dropFirstOutput;          ///< drop_first_output;
    UINT16 dummyFieldForBytePadding; ///< dummy_field_for_byte_padding
    UINT16 earlyTerminationHor;      ///< early_termination_h
    UINT16 overlap;                  ///< overlap
};  // HW params

struct TFEZoomWindow
{
    UINT16 zoomEnable;              ///< zoom_enable;
    UINT16 startX;                  ///< start_x;
    UINT16 startY;                  ///< start_y;
    UINT16 width;                   ///< width;
    UINT16 height;                  ///< height;
};

struct TFEStripeStripeROI
{
    UINT16 startX;        ///< start X
    UINT16 endX;          ///< end X
};

struct TFEStripeRollOffv34InputParams
{
    BOOL   enable;                       ///< enable;
    UINT16 blockWidth;                   ///< Bwidth_l;
    UINT16 meshGridBwidth;               ///< MeshGridBwidth_l;
    UINT16 lxStart;                      ///< Lx_start_l;
    UINT16 bxStart;                      ///< Bx_start_l;
    UINT16 bx_d1_l;                      ///< Bx_d1_l;
    UINT16 numMeshgainHoriz;             ///< num_meshgain_h;
    UINT16 intp_factor_l;                ///< Bicubic interpolation factor (0:3)
};

struct TFEStripePDPCv20v30stripingInputParams
{
    BOOL  enable;                        ///< enable;
    INT32 PDAFGlobalOffsetX;             ///< pdaf_global_offset_x;
    INT32 PDAFTableoffsetX;              ///< pdaf_table_x_offset;
    INT32 PDAFEndX;                      ///< pdaf_x_end;
    INT32 PDAFzzHDRFirstRBExp;           ///< pdaf_zzHDR_first_rb_exp;
    INT16 PDAFPDPCEnable;                ///< pdaf_pdpc_en;
    INT16 PDAFdsbpcEnable;               ///< pdaf_dsbpc_en;
};

struct TFEStripeHDRBayerHistV13InputParams
{
    INT32 bihistEnabled;                ///< bihist_enabled;
    INT32 bihistROIHorOffset;           ///< bihist_roi_h_offset;
    INT32 bihistROIVerOffset;           ///< bihist_roi_v_offset
    INT32 bihistRgnHorNum;              ///< bihist_rgn_h_num;
};

struct TFEStripeBayerGridv15InputParam
{
    INT32 BGEnabled;                    ///< bg_enabled;
    INT32 BGRgnVertNum;                 ///< bg_rgn_v_num;
    INT32 BGRgnHorizNum;                ///< bg_rgn_h_num;
    INT32 BGRegionSampling;             ///< bg_region_sampling;
    INT32 BGRgnWidth;                   ///< bg_rgn_width;
    INT32 BGROIHorizOffset;             ///< bg_roi_h_offset;
    INT32 BGSatOutputEnable;            ///< bg_sat_output_enable;
    INT32 BGYOutputEnable;              ///< bg_Y_output_enable;
};

struct TFEStripeBayerExpv15InputParam
{
    INT32 BEEnable;                    ///< be_enable;
    INT32 BEzzHDRFirstRBExp;           ///< be_zHDR_first_rb_exp;
    INT32 BEROIHorizOffset;            ///< be_roi_h_offset;
    INT32 BERgnWidth;                  ///< be_rgn_width;
    INT32 BERgnHorizNum;               ///< be_rgn_h_num;
    INT32 BERgnVertNum;                ///< be_rgn_v_num;
    INT32 BESatOutputEnable;           ///< be_sat_output_enable;
    INT32 BEYOutputEnable;             ///< be_Y_output_enable;
};

struct TFEStripeCrop
{
    INT16 enable;     ///< enable;
    INT16 inDim;      ///< inDim;
    INT16 firstOut;   ///< firstOut
    INT16 lastOut;    ///< lastOut;
};

struct TFEStripeRollOffOutputParameters
{
    UINT32 gridIndex;                    ///< grid_index
    UINT32 subgridIndex;                 ///< subgrid_index
    UINT32 pixelIndexWithinSubgrid;      ///< pixel_index_within_subgrid
};

struct TFEStripePDPCv20v30stripingOutputParams
{
    INT32 PDAFGlobalOffset;             ///< pdaf_global_offset;
    INT32 PDAFTableOffset;              ///< pdaf_table_offset;
    INT32 PDAFEndX;                     ///< pdaf_x_end;
    INT32 PDAFzzHDRFirstRBExp;          ///< pdaf_zzHDR_first_rb_exp;
    INT16 PDAFPDPCEnable;               ///< pdaf_pdpc_en;
};

struct TFEStripeHDRBayerHistV13OutputParams
{
    INT32 bihistEnabled;                ///< bihist_enabled;
    INT32 bihistROIHorOffset;           ///< bihist_roi_h_offset;
    INT32 bihistRgnHorNum;              ///< bihist_rgn_h_num;
    INT32 bihistROIVerOffset;           ///< bihist_roi_v_offset
    INT32 writeEngineEnable;            ///< writeEngineEnable;
};

struct TFEStripeBayerGridv15OutputParam
{
    INT32 BGEnabled;                 ///< bg_enabled;
    INT32 gridOutStartX;             ///< gridOutStart_x;
    INT32 gridOutEndX;               ///< gridOutEnd_x;
    INT32 BGRgnNumFrameHor;          ///< bg_rgn_h_num_frame;
    INT32 BGROIHorizOffset;          ///< bg_roi_h_offset;
    INT32 BGRgnNumStripeHor;         ///< bg_rgn_h_num_stripe
};

struct TFEStripeBayerExpv15OutputParam
{
    INT32 BEEnable;              ///< be_enable;
    INT32 BEROIHorOffset;        ///< be_roi_h_offset;
    INT32 BERgnHorNum;           ///< be_rgn_h_num;
    INT32 BEzzHDRFirstRBExp;     ///< be_zHDR_first_rb_exp;
    INT32 gridOutStartX;         ///< gridOutStart_x;
};

struct TFEStripeWriteEngineStripeParam
{
    INT32 enable1;                   ///< enable1;
    INT32 hInit1;                    ///< hInit1;
    INT32 stripeWidth1;              ///< stripeWidth1
    INT32 enable2;                   ///< enable2;
    INT32 hInit2;                    ///< hInit2;
    INT32 stripeWidth2;              ///< stripeWidth2
};

struct TFEStripeBayerFocusv26OutputParam
{
    UINT16                          enable;                          ///< enable
    UINT16                          horizaltalRegionNum;             ///< horizontal region number
    UINT16                          horizontalROIfset;               ///< horizontal ROI number - 13u
    UINT16                          regionWidth;                     ///< region width - 10u
    UINT16                          padding;                         ///< padding
    TFEStripeMNScaleDownInputV16    mndsParam;                       ///< MNDS parameters
    UINT16                          bankSelection;                   ///< bank selection
    UINT16                          horizontalIn;                    ///< horizontal In
    UINT16                          horizontalOut;                   ///< horizontal Out
    INT                             scaleRatio;                      ///< scale Ratio
    UINT16                          ROIXmin;                         ///< ROI X min
    UINT16                          ROIXmax;                         ///< ROI X max
    BOOL                            validResult;                     ///< Valid result
};

struct TFEStripeInterfaceInput
{
    INT16                                   tiering;                        ///< tiering
    INT16                                   striping;                       ///< 0: no dual vfe,  1: dual vfe
    INT16                                   bdsVersion;                     ///< BDS version
    INT16                                   inputFormat;                    ///< input format
    INT16                                   inputWidth;                     ///< input width
    INT16                                   inputHeight;                    ///< input hight
    BOOL                                    useZoomSettingFromExternal;     ///< use_zoom_setting_from_external;
    TFEZoomWindow                           zoomWindow;                     ///< zoom_window;
    TFEStripeStripeROI                      roiMNDSoutfull;                 ///< roi_mnds_out_full
    INT16                                   fulloutFormat;                  ///< outFormat_full
    INT16                                   rdi2outFormat;                  ///< outFormat_rdi2
    INT16                                   idealRawoutFormat;              ///< outFormat_idealRaw
    INT16                                   fulloutWidth;                   ///< outWidth_video
    INT16                                   fulloutHeight;                  ///< outHeight_video
    INT16                                   videoDS8outFormat;              ///< outFormat_videoDS8
    INT16                                   videoDS8outWidth;               ///< outWidth_videoDS8
    INT16                                   videoDS8outHeight;              ///< outHeight_videoDS8
    INT16                                   snapshotDS8outFormat;           ///< outFormat_snapshotDS8
    INT16                                   snapshotDS8outWidth;            ///< outWidth_snapshotDS8
    INT16                                   snapshotDS8outHeight;           ///< outHeight_snapshotDS8
    INT16                                   rolloffEnable;                  ///< rolloff_enable
    INT16                                   bhistEnable;                    ///< bhist_enable
    INT16                                   bafEnable;                      ///< baf_enable
    INT16                                   beTintlessEnable;               ///< be_tintless_enable
    INT16                                   bgAWBEnable;                    ///< bg_awb_enable
    INT16                                   bgBEEnable;                     ///< bg_aec_enable
    INT16                                   pdafEnable;                     ///< pdaf_enable
    INT16                                   fetchLeftStripeEnd;             ///< fetchLeftStripeEnd
    INT16                                   fetchRightStripeStart;          ///< fetchRightStripeStart
    INT16                                   dummyFieldForBytePadding;       ///< dummy_field_for_byte_padding
    TFEStripeRollOffv34InputParams          rollOffParam;                   ///< rollOffParam
    TFEStripePDPCv20v30stripingInputParams  pdpcParam;                      ///< pdpc_in_v30
    TFEStripeBDSInStructV10InputParams      bdsParam;                       ///< BDSParam_v10
    TFEStripeBDSInStructV11InputParams      bds11Param;                     ///< BDSParam_v11
    TFEStripeDS8InStruct                    videoDS8Param;                  ///< DS8Param video
    TFEStripeDS8InStruct                    snapshotDS8Param;               ///< DS8Param snapshot
    TFEStripeHDRBayerHistV13InputParams     bhistInput;                     ///< bHist_input
    TFEStripeBayerGridv15InputParam         bgAWBInput;                     ///< bg_awb_input
    TFEStripeBayerGridv15InputParam         bgAECInput;                     ///< bg_aec_input
    TFEStripeBayerExpv15InputParam          beTintlessInput;                ///< be_tintless_input
    TFEStripeBayerFocusv26InputParam        bafInput;                       ///< baf_input
    INT16                                   bdsPreCropWidthSW;              ///< BDS Pre-crop width SW
    INT16                                   bdsPreCropHeightSW;             ///< BDS Pre-crop height SW
    BOOL                                    enableStripingDumps;            ///< enable_dump
    UINT32                                  instance;                       ///< Instance ID
    UINT64                                  requestID;                      ///<.Request ID
    UINT32                                  hours;                          ///< Time Stamp hours;
    UINT32                                  minutes;                        ///< Time Stamp minutes;
    UINT32                                  seconds;                        ///< Time Stamp seconds;

};

struct TFEStripeInterfaceOutput
{
    INT32                                   edgeStripeLT;                       ///< edgeStripeLT
    INT32                                   edgeStripeRB;                       ///< edgeStripeRB

    // fetch coordinates
    INT16                                   fetchFirstPixel;                    ///< relative to frame origin (0,0)
    INT16                                   fetchLastPixel;                     ///< fetchLastPixel
    INT16                                   fetchFirstLine;                     ///< relative to frame origin (0,0)
    INT16                                   fetchLastLine;                      ///< fetchLastLine

    INT16                                   outRangeFull[2];                    ///< outRange_video[2]
    INT16                                   outRangeDS8[2];                     ///< outRange_Vid_DS8[2]
    INT16                                   outRangeSnapDS8[2];                 ///< outRange_Snap_DS8[2]
    INT16                                   outRangeRDI2[2];                    ///< outRange_rdi2[2]
    INT16                                   outRangeIdealRaw[2];                ///< outRange_idealRaw[2]

    INT16                                   dbsScalerEn;                        ///< bds_scalar_en
    TFEStripeCrop                           bdsPreCropFull;                     ///< bdsPreCrop_video
    TFEStripeCrop                           bdsPostCropFull;                    ///< bdsPostCrop_video
    TFEStripeCrop                           outCropIdealRaw;                    ///< outCrop_idealRaw
    TFEStripeMNScaleDownInputV20            bdsConfigFullP;                     ///< bdsConfig_video_p
    TFEStripeMNScaleDownInputV20            bdsConfigFullTL;                    ///< bdsConfig_video_tl
    TFEStripeMNScaleDownInputV20            bdsConfigFullTR;                    ///< bdsConfig_video_tr
    TFEStripeMNScaleDownInputV23            bdsConfigFullPv23;                  ///< bdsConfig_video_p_v11
    TFEStripeMNScaleDownInputV23            bdsConfigFullTLv23;                 ///< bdsConfig_video_tl_v11
    TFEStripeMNScaleDownInputV23            bdsConfigFullTRv23;                 ///< bdsConfig_video_tr_v11
    INT16                                   earlyTerminationTL;                 ///< early_termination_tl
    INT16                                   earlyTerminationTR;                 ///< early_termination_tr
    TFEStripeCrop                           bdsPreCropFullP;                    ///< bdsPreCrop_video_p
    TFEStripeCrop                           bdsPreCropFullTL;                   ///< bdsPreCrop_video_tl
    TFEStripeCrop                           bdsPreCropFullTR;                   ///< bdsPreCrop_video_tr
    TFEStripeCrop                           bdsPostCropFullP;                   ///< bdsPostCrop_video_p
    TFEStripeCrop                           bdsPostCropFullTL;                  ///< bdsPostCrop_video_tl
    TFEStripeCrop                           bdsPostCropFullTR;                  ///< bdsPostCrop_video_tr
    TFEStripeCrop                           preDS8CropVideo;                    ///< preDS8Crop_Video
    TFEStripeCrop                           preDS8CropSnapshot;                 ///< preDS8Crop_Snap
    TFEStripeCrop                           postDS8CropVideoY;                  ///< preDS8Crop_Video_Y
    TFEStripeCrop                           postDS8CropSnapshotY;               ///< preDS8Crop_Snap_Y
    TFEStripeCrop                           postDS8CropVideoC;                  ///< postDS8Crop_Video_C
    TFEStripeCrop                           postDS8CropSnapshotC;               ///< preDS8Crop_Sxnap_C
    TFEStripeRollOffOutputParameters        rolloffOutStripe;                   ///< rolloffOutStripe
    TFEStripePDPCv20v30stripingOutputParams pdpcOut;                            ///< pdpc_out_v30
    TFEStripeBayerFocusv26OutputParam       bafOut;                             ///< baf_out
    TFEStripeHDRBayerHistV13OutputParams    bHistOut;                           ///< bHist_out
    TFEStripeBayerGridv15OutputParam        bgAECOut;                           ///< bHist_out
    TFEStripeBayerGridv15OutputParam        bgAWBOut;                           ///< bg_awb_out
    TFEStripeBayerExpv15OutputParam         beIintlessOut;                      ///< be_tintless_out
    TFEStripeWriteEngineStripeParam         bgAecWriteEngineStripeParam;        ///< bg_aecWriteEngineStripeParam
    TFEStripeWriteEngineStripeParam         bgAwbWriteEngineStripeParam;        ///< bg_awbWriteEngineStripeParam
    TFEStripeWriteEngineStripeParam         beTintlessWriteEngineStripeParam;   ///< be_tintlessWriteEngineStripeParam
    TFEStripeWriteEnginePassParam           bafWriteEnginePassParam;            ///< bafWriteEnginePassParam
    TFEStripeWriteEngineStripeParam         bafWriteEngineStripeParam;          ///< bafWriteEngineStripeParam
};

struct TFEStripingPassOutput
{
    INT16                                   numStripes;                         ///< numStripes
    INT16                                   dummyFieldForBytePadding0;          ///< dummy_field_for_byte_padding_0
    INT32                                   dummyFieldForBytePadding1;          ///< dummy_field_for_byte_padding_1
    TFEStripeInterfaceOutput*               pStripeOutput[2];                    ///< stripeOutput
    TFEStripeWriteEnginePassParam*          pBGAECWriteEnginePassParam;          ///< bg_aecWriteEnginePassParam
    TFEStripeWriteEnginePassParam*          pBGAWBWriteEnginePassParam;          ///< bg_awbWriteEnginePassParam
    TFEStripeWriteEnginePassParam*          pBETintlessWriteEnginePassParam;     ///< be_tintlessWriteEnginePassParam
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief Class that implements the tfeStripingInterface
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
class TFEStripingInterface
{
public:
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// DeriveStriping
    ///
    /// @brief  DeriveStriping
    ///
    /// @param  pStripingInput   Striping Input
    /// @param  pPassOut         Striping Output
    ///
    /// @return INT32
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    static INT32 DeriveStriping(
        TFEStripeInterfaceInput* pStripingInput,
        TFEStripingPassOutput*   pPassOut);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// DeriveFetchRange
    ///
    /// @brief  Derive Fectch Range
    ///
    /// @param  pStripingInput   Striping Input
    ///
    /// @return INT32
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    static INT32 DeriveFetchRange(
        TFEStripeInterfaceInput * pStripingInput);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// ReleaseDualTFEPassOutput
    ///
    /// @brief  Release Moemory allocated
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    static VOID ReleaseDualTFEPassOutput();

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetStripingLibVersion
    ///
    /// @brief  Get the current striping library version
    ///
    /// @return String
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    static const char* GetStripingLibVersion();
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// PrintTFEFrameInputOutput
    ///
    /// @brief  PrintTFEFrameInputOutput
    ///
    /// @param  pStripingInput   Striping Input
    /// @param  pPassOut         Striping Output
    ///
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    static VOID PrintTFEFrameInputOutput(
        TFEStripeInterfaceInput* pStripingInput,
        TFEStripingPassOutput*   pPassOut);

protected:
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// ~TFEStripingInterface
    ///
    /// @brief  Destructor
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual ~TFEStripingInterface();

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// TFEStripingInterface
    ///
    /// @brief  Constructor
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    TFEStripingInterface();

private:

    static VOID*     s_pTFEPassOut;                                   ///< Struct for IFE Passout

    TFEStripingInterface(const TFEStripingInterface&) = delete;       ///< Disallow the copy constructor
    TFEStripingInterface& operator=(const TFEStripingInterface&) = delete;       ///< Disallow assignment operator
};

#ifdef __cplusplus
extern "C" {
#endif    // end of _cplusplus

struct TFEStripeInterface
{

    INT32 (*DeriveStriping) (
        TFEStripeInterfaceInput* pStripingInput,
        TFEStripingPassOutput*   pPassOut);

    INT32 (*DeriveFetchRange)(
        TFEStripeInterfaceInput * pStripingInput);

    VOID (*ReleaseDualTFEPassOutput)();

    const CHAR* (*GetStripingLibVersion)();
    VOID (*PrintTFEFrameInputOutput) (
        TFEStripeInterfaceInput* pStripingInput,
        TFEStripingPassOutput*   pPassOut);
};

typedef CamxResult(*PFTFEStripeInterface) (TFEStripeInterface** pTFEStripeInterfaceCB);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// CreateTFEStripeInterface
///
/// @brief  CreateTFEStripeInterface
///
/// @param  ppTFEStripeInterface   pointer to TFE stripe Interface
///
/// @return CamxResult
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
CAMX_VISIBILITY_PUBLIC CamxResult CreateTFEStripeInterface(
    TFEStripeInterface** ppTFEStripeInterface);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// DestroyTFEStripeInterface
///
/// @brief  DestroyTFEStripeInterface
///
/// @param  ppTFEStripeInterface   pointer to TFE stripe Interface
///
/// @return CamxResult
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
CAMX_VISIBILITY_PUBLIC CamxResult DestroyTFEStripeInterface(
    TFEStripeInterface** ppTFEStripeInterface);

#ifdef __cplusplus
}
#endif    // end of _cplusplus

CAMX_NAMESPACE_END

#endif // end of CAMX_IFE_STRIPE_INTERFACE_H
