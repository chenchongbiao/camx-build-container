////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2020 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef __IS_INTERFACE_CAMX_UTILS_H__
#define __IS_INTERFACE_CAMX_UTILS_H__

/*------------------------------------------------------------------------
*       Include Files
* ----------------------------------------------------------------------- */

#include "is_interface.h"

/*------------------------------------------------------------------------
*       API Declarations
* ----------------------------------------------------------------------- */

#ifdef __cplusplus
extern "C" {
#endif

/**
*  @brief   Conversion function from CamX EIS 1.1.0 chromatix XML to EIS initialization input struct
*
*  @param [in]  eis_chromatix_per_sensor            EIS chromatix in CamX format
*  @param [in]  sizeof_eis_chromatix_per_sensor     Size of the first element in eis_chromatix_per_sensor, used for internal casing validation
*  @param [out] is_chromatix_info                   Chromatix info as passed into EIS initialization function
*
*  @return 0 in case of success, otherwise failed.
**/
EIS_VISIBILITY_PUBLIC
int32_t eis_camx_utility_v1_1_0_to_is_chromatix_info(
    void*                                       eis_chromatix_per_sensor,
    size_t                                      sizeof_eis_chromatix_per_sensor,
    is_chromatix_info_t*                        is_chromatix_info);

/**
*  @brief   Conversion function from CamX EIS 1.2.0 chromatix XML to EIS initialization input struct
*
*  @param [in]  eis_chromatix_per_sensor            EIS chromatix in CamX format
*  @param [in]  sizeof_eis_chromatix_per_sensor     Size of the first element in eis_chromatix_per_sensor, used for internal casing validation
*  @param [out] is_chromatix_info                   Chromatix info as passed into EIS initialization function
*
*  @return 0 in case of success, otherwise failed.
**/
EIS_VISIBILITY_PUBLIC
int32_t eis_camx_utility_v1_2_0_to_is_chromatix_info(
    void*                                       eis_chromatix_per_sensor,
    size_t                                      sizeof_eis_chromatix_per_sensor,
    is_chromatix_info_t*                        is_chromatix_info);

/**
*  @brief   Conversion function from CamX EIS 1.3.0 chromatix XML to EIS initialization input struct
*
*  @param [in]  eis_chromatix_per_sensor            EIS chromatix in CamX format
*  @param [in]  sizeof_eis_chromatix_per_sensor     Size of the first element in eis_chromatix_per_sensor, used for internal casing validation
*  @param [out] is_chromatix_info                   Chromatix info as passed into EIS initialization function
*
*  @return 0 in case of success, otherwise failed.
**/
EIS_VISIBILITY_PUBLIC
int32_t eis_camx_utility_v1_3_0_to_is_chromatix_info(
    void*                                       eis_chromatix_per_sensor,
    size_t                                      sizeof_eis_chromatix_per_sensor,
    is_chromatix_info_t*                        is_chromatix_info);

#ifdef __cplusplus
}
#endif

#endif /* __IS_INTERFACE_CAMX_UTILS_H__ */
