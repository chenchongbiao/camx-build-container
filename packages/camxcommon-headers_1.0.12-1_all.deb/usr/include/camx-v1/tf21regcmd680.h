// NOWHINE ENTIRE FILE
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2020 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @file  tf21regcmd680.h
/// @brief camxipetfregcmd structure definition
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef TF21REGCMD680_H
#define TF21REGCMD680_H
#include "titan680_ipe.h"
#include "tfbaseregcmd.h"

CAMX_BEGIN_PACKED

struct IPETFRegCmd680 : public IPETFRegCmd
{
    IPE_IPE_0_NPS_CLC_TF_TF_LM_CONFIG_0                   lmConfig0;              ///< LMC configuration params
    IPE_IPE_0_NPS_CLC_TF_TF_LM_CONFIG_1                   lmConfig1;              ///< LMC configuration params
    IPE_IPE_0_NPS_CLC_TF_TF_LM_CONFIG_2                   lmConfig2;              ///< LMC configuration params
    IPE_IPE_0_NPS_CLC_TF_TF_LM_CROP_VER                   lmCropVer;              ///< LMC configuration params
    IPE_IPE_0_NPS_CLC_TF_TF_LM_CROP_HOR                   lmCropHor;              ///< LMC configuration params
    IPE_IPE_0_NPS_CLC_TF_TF_ALGM_CFG                      algmCfg;                ///< ALGM configuration params
    IPE_IPE_0_NPS_CLC_TF_TF_ALGM_COR_FACTOR_CFG           algmCorFactorCfg;       ///< ALGM configuration params
} CAMX_PACKED;

CAMX_END_PACKED

#endif // TF21REGCMD680_H
