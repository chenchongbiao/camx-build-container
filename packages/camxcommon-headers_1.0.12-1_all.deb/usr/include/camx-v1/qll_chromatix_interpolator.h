// NOWHINE ENTIRE FILE
//-------------------------------------------------------------------------------------------------
// Copyright (c) 2020 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
//-------------------------------------------------------------------------------------------------
#ifndef QLL_CHROMATIX_INTERPOLATOR_H
#define QLL_CHROMATIX_INTERPOLATOR_H

#include "qll_interface.h"
#include "qll_1_0_0.h"

#ifdef __cplusplus
extern "C" {
#endif

struct QLL10InputDataExt
{
    qll_1_0_0::chromatix_qll10Type* pChromatix;             ///< Input Chromatix tunning data
    UINT32                          moduleEnable;           ///< Module enable flag
    FLOAT                           DRCGain;                ///< Input trigger value: DRC Gain data
    FLOAT                           exposureTime;           ///< Input trigger value: exposure time
    FLOAT                           AECSensitivity;         ///< Input trigger value: AEC sensitivity data
    FLOAT                           exposureGainRatio;      ///< Input trigger value: exposure gain ratio
    FLOAT                           luxIndex;               ///< Input trigger value: Lux index
    FLOAT                           AECGain;                ///< Input trigger value: QEC Gain data
    UINT16                          tableSel;               ///< 0 for 3A QLL, 1 for ML ISP QLL
};

/**
*  @brief Interpolate QLL Chromatix tuning data according to input triggers.
*
*  @param [in]  chromatix_in        Input Chromatix tunning data and trigger values.
*  @param [in]  chromatix_in_prev   Previous trigger values (tuning data is N/A).
*  @param [out] chromatix_out       Interpolated Chromatix data.
*
*  @return 0 in case of success, otherwise failed.
**/
QLL_VISIBILITY_PUBLIC
int32_t interpolate_qll_chromatix(
    const QLL10InputDataExt*    chromatix_in,
    const QLL10InputDataExt*    chromatix_in_prev,
    QLL_Chromatix*              chromatix_out);

typedef int32_t (*interpolate_qll_chromatix_func_t)(
    const QLL10InputDataExt*    chromatix_in,
    const QLL10InputDataExt*    chromatix_in_prev,
    QLL_Chromatix*              chromatix_out);

#ifdef __cplusplus
}
#endif

#endif // !QLL_CHROMATIX_INTERPOLATOR
