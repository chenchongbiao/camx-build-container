////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2020-2021 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @file camxreturntypes.h
/// @brief CamX Extended error types for module specific unique error codes
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef CAMXRETURNTYPES_H
#define CAMXRETURNTYPES_H


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Result Codes
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// The result code type to be returned from functions. Must match ordering and size CamxResultStrings.
typedef INT32 CamxResult;

static const CamxResult CamxResultSuccess           = 0;    ///< Operation was successful
static const CamxResult CamxResultEFailed           = 1;    ///< Operation encountered unspecified error
static const CamxResult CamxResultEUnsupported      = 2;    ///< Operation is not supported
static const CamxResult CamxResultEInvalidState     = 3;    ///< Invalid state
static const CamxResult CamxResultEInvalidArg       = 4;    ///< Invalid argument
static const CamxResult CamxResultEInvalidPointer   = 5;    ///< Invalid memory pointer
static const CamxResult CamxResultENoSuch           = 6;    ///< No such item exists or is valid
static const CamxResult CamxResultEOutOfBounds      = 7;    ///< Out of bounds
static const CamxResult CamxResultENoMemory         = 8;    ///< Out of memory
static const CamxResult CamxResultETimeout          = 9;    ///< Operation timed out
static const CamxResult CamxResultENoMore           = 10;   ///< No more items available
static const CamxResult CamxResultENeedMore         = 11;   ///< Operation requires more
static const CamxResult CamxResultEExists           = 12;   ///< Item exists
static const CamxResult CamxResultEPrivLevel        = 13;   ///< Privileges are insufficient for requested operation
static const CamxResult CamxResultEResource         = 14;   ///< Resources are insufficient for requested operation
static const CamxResult CamxResultEUnableToLoad     = 15;   ///< Unable to load library/object
static const CamxResult CamxResultEInProgress       = 16;   ///< Operation is already in progress
static const CamxResult CamxResultETryAgain         = 17;   ///< Could not complete request; try again
static const CamxResult CamxResultEBusy             = 18;   ///< Device or resource busy
static const CamxResult CamxResultEReentered        = 19;   ///< Non re-entrant API re-entered
static const CamxResult CamxResultEReadOnly         = 20;   ///< Cannot change read-only object or parameter
static const CamxResult CamxResultEOverflow         = 21;   ///< Value too large for defined data type
static const CamxResult CamxResultEOutOfDomain      = 22;   ///< Math argument or result out of domain
static const CamxResult CamxResultEInterrupted      = 23;   ///< Waitable call is interrupted
static const CamxResult CamxResultEWouldBlock       = 24;   ///< Operation would block
static const CamxResult CamxResultETooManyUsers     = 25;   ///< Too many users
static const CamxResult CamxResultENotImplemented   = 26;   ///< Function or method is not implemented
static const CamxResult CamxResultEDisabled         = 27;   ///< Feature disabled (by an override for example)
static const CamxResult CamxResultECancelledRequest = 28;   ///< Flush in progress
static const CamxResult CamxResultECoreNullMetadata = 29;   ///< Metadata is null
static const CamxResult CamxResultEInducedError     = 30;   ///< Induced error using error inducement framework
static const CamxResult CamxResultEFenceGroupError  = 31;   ///< Composite fence group configure incorrect
static const CamxResult CamxResultECSLStreamOn      = 32;   ///< Error Streaming CSL On

// Increment the count below if adding additional result codes.
static const CamxResult CamxResultCount             = 33;   ///< The number of result codes. Not to be used.

/// @brief The string name of the type of the memory allocation. Must be in order of CamxResult codes.
#if __GNUC__
static const CHAR* CamxResultStrings[] __attribute__((unused)) =
#else // __GNUC__
static const CHAR* CamxResultStrings[] =
#endif // _GNUC__
{
    "CamxResultSuccess",
    "CamxResultEFailed",
    "CamxResultEUnsupported",
    "CamxResultEInvalidState",
    "CamxResultEInvalidArg",
    "CamxResultEInvalidPointer",
    "CamxResultENoSuch",
    "CamxResultEOutOfBounds",
    "CamxResultENoMemory",
    "CamxResultETimeout",
    "CamxResultENoMore",
    "CamxResultENeedMore",
    "CamxResultEExists",
    "CamxResultEPrivLevel",
    "CamxResultEResource",
    "CamxResultEUnableToLoad",
    "CamxResultEInProgress",
    "CamxResultETryAgain",
    "CamxResultEBusy",
    "CamxResultEReentered",
    "CamxResultEReadOnly",
    "CamxResultEOverflow",
    "CamxResultEOutOfDomain",
    "CamxResultEInterrupted",
    "CamxResultEWouldBlock",
    "CamxResultETooManyUsers",
    "CamxResultENotImplemented",
    "CamxResultEDisabled",
    "CamxResultECancelledRequest",
    "CamxResultECoreNullMetadata",
    "CamxResultEInducedError",
    "CamxResultEFenceGroupError",
    "CamxResultECSLStreamOn"
};

// CamxResult max size to be used, for module specific errors in CamxResultExt
static const CamxResult CamxResultMax = 255;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Extended Result Codes
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// The result code type to be returned from different FAs but unique per module to mean specific error type
typedef CamxResult CamxResultExt;

// Base for all extended errors per module
static const CamxResultExt CamxResultExtBase                      = CamxResultMax + 1;

// Core extended error codes (Starts from 256)
static const CamxResultExt CamxResultExtCoreBase                  = CamxResultExtBase * 1;
static const CamxResultExt CamxResultExtCoreInvalidReqAccess      = CamxResultExtCoreBase + 0;
static const CamxResultExt CamxResultExtCoreSOFWatchDogTimeout    = CamxResultExtCoreBase + 1;
static const CamxResultExt CamxResultExtCoreResultTimedOut        = CamxResultExtCoreBase + 2;
static const CamxResultExt CamxResultExtCoreFlushResultTimedOut   = CamxResultExtCoreBase + 3;
static const CamxResultExt CamxResultExtCorePCRTimeout            = CamxResultExtCoreBase + 4;
static const CamxResultExt CamxResultExtCoreHWEnvInitFail         = CamxResultExtCoreBase + 5;
static const CamxResultExt CamxResultExtCoreReqSubmitTwice        = CamxResultExtCoreBase + 6;
static const CamxResultExt CamxResultExtCoreShutterError          = CamxResultExtCoreBase + 7;
static const CamxResultExt CamxResultExtCorePipelineFlushTimeOut  = CamxResultExtCoreBase + 8;
static const CamxResultExt CamxResultExtCoreSessionFlushTimeOut   = CamxResultExtCoreBase + 9;
static const CamxResultExt CamxResultExtCorePreemptTimeout        = CamxResultExtCoreBase + 10;

// Kernel extended error codes (Starts from 512)
static const CamxResultExt CamxResultExtKMDBase                   = CamxResultExtBase * 2;
static const CamxResultExt CamxResultExtKMDRecovery               = CamxResultExtKMDBase + 1;
static const CamxResultExt CamxResultExtKMDFullRecovery           = CamxResultExtKMDBase + 2;
static const CamxResultExt CamxResultExtKMDSOFFreeze              = CamxResultExtKMDBase + 3;
static const CamxResultExt CamxResultExtKMDMaxValue               = CamxResultExtKMDBase + 24;

/* Fence error reason types base */
static const CamxResultExt CamxResultExtFenceErrorBase            = CamxResultExtKMDMaxValue + 1;

/* Common Fence reason types */
static const UINT32 CamxResultExtCommonFenceStart      = CamxResultExtFenceErrorBase + 0;
static const UINT32 CamxResultExtCommonFenceUnused     = CamxResultExtCommonFenceStart + 0;
static const UINT32 CamxResultExtCommonFenceSuccess    = CamxResultExtCommonFenceStart + 1;
static const UINT32 CamxResultExtCommonFenceFlush      = CamxResultExtCommonFenceStart + 2;
static const UINT32 CamxResultExtCommonFenceStop       = CamxResultExtCommonFenceStart + 3;
static const UINT32 CamxResultExtCommonFenceSynx       = CamxResultExtCommonFenceStart + 4;
static const UINT32 CamxResultExtCommonFenceRegPayload = CamxResultExtCommonFenceStart + 5;
static const UINT32 CamxResultExtCommonFenceSyncSignal = CamxResultExtCommonFenceStart + 6;
static const UINT32 CamxResultExtCommonFenceRelease    = CamxResultExtCommonFenceStart + 7;
static const UINT32 CamxResultExtCommonFenceMaxValue   = CamxResultExtCommonFenceStart + 50;

/* Isp error reason types */
static const UINT32 CamxResultExtIspErrorStart          = (CamxResultExtCommonFenceMaxValue + 1);
static const UINT32 CamxResultExtIspErrorUnknown        = (CamxResultExtIspErrorStart + 0);
static const UINT32 CamxResultExtIspErrorBubble         = (CamxResultExtIspErrorStart + 1);
static const UINT32 CamxResultExtIspErrorOverflow       = (CamxResultExtIspErrorStart + 2);
static const UINT32 CamxResultExtIspErrorP2iError       = (CamxResultExtIspErrorStart + 3);
static const UINT32 CamxResultExtIspErrorViolation      = (CamxResultExtIspErrorStart + 4);
static const UINT32 CamxResultExtIspErrorBusifOverflow  = (CamxResultExtIspErrorStart + 5);
static const UINT32 CamxResultExtIspErrorFlush          = (CamxResultExtIspErrorStart + 6);
static const UINT32 CamxResultExtIspErrorHwStop         = (CamxResultExtIspErrorStart + 7);
static const UINT32 CamxResultExtIspErrorBadFrame       = (CamxResultExtIspErrorStart + 8);
static const UINT32 CamxResultExtIspErrorMaxValue       = (CamxResultExtIspErrorStart + 50);

/* Icp error reason types */
static const UINT32 CamxResultExtIcpErrorStart               = (CamxResultExtIspErrorMaxValue + 1);
static const UINT32 CamxResultExtIcpErrorUnknown             = (CamxResultExtIcpErrorStart + 0);
static const UINT32 CamxResultExtIcpErrorFrameProcessFailure = (CamxResultExtIcpErrorStart + 1);
static const UINT32 CamxResultExtIcpErrorConfigErr           = (CamxResultExtIcpErrorStart + 2);
static const UINT32 CamxResultExtIcpErrorMaxValue            = (CamxResultExtIcpErrorStart + 50);

/* Jpeg error reason types */
static const UINT32 CamxResultExtJpegErrorStart            = (CamxResultExtIcpErrorMaxValue + 1);
static const UINT32 CamxResultExtJpegErrorUnknown          = (CamxResultExtJpegErrorStart + 0);
static const UINT32 CamxResultExtJpegErrorInvldCmd         = (CamxResultExtJpegErrorStart + 1);
static const UINT32 CamxResultExtJpegErrorSetIrqCb         = (CamxResultExtJpegErrorStart + 2);
static const UINT32 CamxResultExtJpegErrorHwResetFailed    = (CamxResultExtJpegErrorStart + 3);
static const UINT32 CamxResultExtJpegErrorCdmChangeBaseErr = (CamxResultExtJpegErrorStart + 4);
static const UINT32 CamxResultExtJpegErrorCdmConfigErr     = (CamxResultExtJpegErrorStart + 5);
static const UINT32 CamxResultExtJpegErrorStartHwErr       = (CamxResultExtJpegErrorStart + 6);
static const UINT32 CamxResultExtJpegErrorMaxValue         = (CamxResultExtJpegErrorStart + 50);

/* Fd error reason types */
static const UINT32 CamxResultExtFdErrorStart        = (CamxResultExtJpegErrorMaxValue + 1);
static const UINT32 CamxResultExtFdErrorUnknown      = (CamxResultExtFdErrorStart + 0);
static const UINT32 CamxResultExtFdErrorIrqFrameDone = (CamxResultExtFdErrorStart + 1);
static const UINT32 CamxResultExtFdErrorIrqResetDone = (CamxResultExtFdErrorStart + 2);
static const UINT32 CamxResultExtFdErrorHalt         = (CamxResultExtFdErrorStart + 3);
static const UINT32 CamxResultExtFdErrorMaxValue     = (CamxResultExtFdErrorStart + 50);

/* Lrme error reason types */
static const UINT32 CamxResultExtLrmeErrorStart    = (CamxResultExtFdErrorMaxValue + 1);
static const UINT32 CamxResultExtLrmeErrorUnknown  = (CamxResultExtLrmeErrorStart + 0);
static const UINT32 CamxResultExtLrmeErrorCbError  = (CamxResultExtLrmeErrorStart + 1);
static const UINT32 CamxResultExtLrmeErrorMaxValue = (CamxResultExtLrmeErrorStart + 50);

/* Ope error reason types */
static const UINT32 CamxResultExtOpeErrorStart         = (CamxResultExtLrmeErrorMaxValue + 1);
static const UINT32 CamxResultExtOpeErrorUnknown       = (CamxResultExtOpeErrorStart + 0);
static const UINT32 CamxResultExtOpeErrorPageFault     = (CamxResultExtOpeErrorStart + 1);
static const UINT32 CamxResultExtOpeErrorHwHang        = (CamxResultExtOpeErrorStart + 2);
static const UINT32 CamxResultExtOpeErrorHalt          = (CamxResultExtOpeErrorStart + 3);
static const UINT32 CamxResultExtOpeErrorConfigErr     = (CamxResultExtOpeErrorStart + 4);
static const UINT32 CamxResultExtOpeErrorHwFlush       = (CamxResultExtOpeErrorStart + 5);
static const UINT32 CamxResultExtOpeErrorHwResubmit    = (CamxResultExtOpeErrorStart + 6);
static const UINT32 CamxResultExtOpeErrorHwResetDone   = (CamxResultExtOpeErrorStart + 7);
static const UINT32 CamxResultExtOpeErrorHwError       = (CamxResultExtOpeErrorStart + 8);
static const UINT32 CamxResultExtOpeErrorInvldCmd      = (CamxResultExtOpeErrorStart + 9);
static const UINT32 CamxResultExtOpeErrorHwResetFailed = (CamxResultExtOpeErrorStart + 10);
static const UINT32 CamxResultExtOpeErrorMaxValue      = (CamxResultExtOpeErrorStart + 50);


// IFE extended error codes (Starts from 1024)
static const CamxResultExt CamxResultExtIFEBase                                 = CamxResultExtBase * 4;
static const CamxResultExt CamxResultExtIFEUnsupportedHDRFormat                 = CamxResultExtIFEBase + 0;
static const CamxResultExt CamxResultExtIFEInvalidBufferDimension               = CamxResultExtIFEBase + 1;
static const CamxResultExt CamxResultExtIFEInvalidHALCrop                       = CamxResultExtIFEBase + 2;
static const CamxResultExt CamxResultExtIFEInvalidHDRBEStatsConfig              = CamxResultExtIFEBase + 3;
static const CamxResultExt CamxResultExtIFEInvalidAWBBGStatsConfig              = CamxResultExtIFEBase + 4;
static const CamxResultExt CamxResultExtIFEInvalidBFStatsConfig                 = CamxResultExtIFEBase + 5;
static const CamxResultExt CamxResultExtIFEInvalidTintlessBGStatsConfig         = CamxResultExtIFEBase + 6;
static const CamxResultExt CamxResultExtIFEInvalidBHistStatsConfig              = CamxResultExtIFEBase + 7;
static const CamxResultExt CamxResultExtIFEInvalidHDRBHistStatsConfig           = CamxResultExtIFEBase + 8;
static const CamxResultExt CamxResultExtIFEInvalidIHistStatsConfig              = CamxResultExtIFEBase + 9;
static const CamxResultExt CamxResultExtIFEInvalidMNDSInput                     = CamxResultExtIFEBase + 10;
static const CamxResultExt CamxResultExtIFEInvalidCropCodinates                 = CamxResultExtIFEBase + 11;
static const CamxResultExt CamxResultExtIFEGeoLibFailure                        = CamxResultExtIFEBase + 12;
static const CamxResultExt CamxResultExtIFENCLibFaliure                         = CamxResultExtIFEBase + 13;
static const CamxResultExt CamxResultExtIFEResubmitInitPacketFailure            = CamxResultExtIFEBase + 14;
static const CamxResultExt CamxResultExtIFEInvalidBufferDim                     = CamxResultExtIFEBase + 15;
static const CamxResultExt CamxResultExtIFEInvalidSensorConfig                  = CamxResultExtIFEBase + 16;
static const CamxResultExt CamxResultExtIFEAcquireResourceFailure               = CamxResultExtIFEBase + 17;
static const CamxResultExt CamxResultExtIFEInsufficientHWResource               = CamxResultExtIFEBase + 18;

static const CamxResultExt CamxResultExtIFEBaseMax = CamxResultExtIFEInsufficientHWResource;


// IPE extended error codes (Starts from 1280)
static const CamxResultExt CamxResultExtIPEBase                         = CamxResultExtBase * 5;
static const CamxResultExt CamxResultExtIPEInvalidBWVote                = CamxResultExtIPEBase + 0;
static const CamxResultExt CamxResultExtIPEInvalidDimension             = CamxResultExtIPEBase + 1;
static const CamxResultExt CamxResultExtIPEInvalidFormat                = CamxResultExtIPEBase + 2;
static const CamxResultExt CamxResultExtIPEIQModuleFail                 = CamxResultExtIPEBase + 3;
static const CamxResultExt CamxResultExtIPEInvalidTuningData            = CamxResultExtIPEBase + 4;
static const CamxResultExt CamxResultExtIPEInvalidCropRegion            = CamxResultExtIPEBase + 5;
static const CamxResultExt CamxResultExtIPEAcquireFailure               = CamxResultExtIPEBase + 6;
static const CamxResultExt CamxResultExtIPEMAPFailure                   = CamxResultExtIPEBase + 7;
static const CamxResultExt CamxResultExtIPEInputError                   = CamxResultExtIPEBase + 8;
static const CamxResultExt CamxResultExtIPEHWTimeOut                    = CamxResultExtIPEBase + 9;
static const CamxResultExt CamxResultExtIPEStripingFailure              = CamxResultExtIPEBase + 10;
static const CamxResultExt CamxResultExtIPEPassError                    = CamxResultExtIPEBase + 11;
static const CamxResultExt CamxResultExtIPEInvalidStats                 = CamxResultExtIPEBase + 12;
static const CamxResultExt CamxResultExtIPEBufferAllocFailure           = CamxResultExtIPEBase + 13;
static const CamxResultExt CamxResultExtIPEPatchingFailure              = CamxResultExtIPEBase + 14;
static const CamxResultExt CamxResultExtIPEInvalidInputMeta             = CamxResultExtIPEBase + 15;
static const CamxResultExt CamxResultExtIPEInvalidInputFences           = CamxResultExtIPEBase + 16;
static const CamxResultExt CamxResultExtIPEInvalidConfiguration         = CamxResultExtIPEBase + 17;
static const CamxResultExt CamxResultExtIPEGeoLibError                  = CamxResultExtIPEBase + 18;
static const CamxResultExt CamxResultExtIPENCLibError                   = CamxResultExtIPEBase + 19;
static const CamxResultExt CamxResultExtIPEPerModError                  = CamxResultExtIPEBase + 20;
static const CamxResultExt CamxResultExtIPECMDBufNoMemory               = CamxResultExtIPEBase + 21;
static const CamxResultExt CamxResultExtIPEInvalidCmdBuffer             = CamxResultExtIPEBase + 22;
static const CamxResultExt CamxResultExtIPEInvalidPortConfig            = CamxResultExtIPEBase + 23;
static const CamxResultExt CamxResultExtIPEInvalidImageBuffer           = CamxResultExtIPEBase + 24;
static const CamxResultExt CamxResultExtIPEInvalidIOConfig              = CamxResultExtIPEBase + 25;
static const CamxResultExt CamxResultExtIPEIQModuleCreateFailure        = CamxResultExtIPEBase + 26;
static const CamxResultExt CamxResultExtIPECmdBufCreateFailure          = CamxResultExtIPEBase + 27;
static const CamxResultExt CamxResultExtIPEUBWCDimensionRenegotiation   = CamxResultExtIPEBase + 28;

// BPS extended error codes (Starts from 1536)
static const CamxResultExt CamxResultExtBPSBase                          = CamxResultExtBase * 6;
static const CamxResultExt CamxResultExtBPSInvalidBWVote                 = CamxResultExtBPSBase + 0;
static const CamxResultExt CamxResultExtBPSIQModuleCreateFail            = CamxResultExtBPSBase + 1;
static const CamxResultExt CamxResultExtBPSCMDBufferManagerListInitFail  = CamxResultExtBPSBase + 2;
static const CamxResultExt CamxResultExtBPSCMDBufferManagerCreateFail    = CamxResultExtBPSBase + 3;
static const CamxResultExt CamxResultExtBPSMultiCMDBufferCreateFail      = CamxResultExtBPSBase + 4;
static const CamxResultExt CamxResultExtBPSStripingLibraryOpenFail       = CamxResultExtBPSBase + 5;
static const CamxResultExt CamxResultExtBPSDeviceAcquireFail             = CamxResultExtBPSBase + 6;
static const CamxResultExt CamxResultExtBPSStaticMetadataGetFail         = CamxResultExtBPSBase + 7;
static const CamxResultExt CamxResultExtBPSMergedBufferGetFail           = CamxResultExtBPSBase + 8;
static const CamxResultExt CamxResultExtBPSFWCMDRegionInfoSendFail       = CamxResultExtBPSBase + 9;
static const CamxResultExt CamxResultExtBPSVendorTagLocationGetFail      = CamxResultExtBPSBase + 10;
static const CamxResultExt CamxResultExtBPSVendorTagLocationQueryFail    = CamxResultExtBPSBase + 11;
static const CamxResultExt CamxResultExtBPSDataListGetFail               = CamxResultExtBPSBase + 12;
static const CamxResultExt CamxResultExtBPSCameraIDGetFail               = CamxResultExtBPSBase + 13;
static const CamxResultExt CamxResultExtBPSInvalidSensorModeData         = CamxResultExtBPSBase + 14;
static const CamxResultExt CamxResultExtBPSInvalidFrameProcessData       = CamxResultExtBPSBase + 15;
static const CamxResultExt CamxResultExtBPSInvalidImageFormat            = CamxResultExtBPSBase + 16;
static const CamxResultExt CamxResultExtBPSInvalidBatchCount             = CamxResultExtBPSBase + 17;
static const CamxResultExt CamxResultExtBPSMetadataTagGetFail            = CamxResultExtBPSBase + 18;
static const CamxResultExt CamxResultExtBPSFaceROIGetFail                = CamxResultExtBPSBase + 19;
static const CamxResultExt CamxResultExtBPSIQSettingFillFail             = CamxResultExtBPSBase + 20;
static const CamxResultExt CamxResultExtBPSScaleRatioSetFail             = CamxResultExtBPSBase + 21;
static const CamxResultExt CamxResultExtBPSIQConfigProgramFail           = CamxResultExtBPSBase + 22;
static const CamxResultExt CamxResultExtBPSInputFrameBufferDataFillFail  = CamxResultExtBPSBase + 23;
static const CamxResultExt CamxResultExtBPSInputIOConfigAddFail          = CamxResultExtBPSBase + 24;
static const CamxResultExt CamxResultExtBPSInvalidInputPortImage         = CamxResultExtBPSBase + 25;
static const CamxResultExt CamxResultExtBPSOutputFrameBufferDataFillFail = CamxResultExtBPSBase + 26;
static const CamxResultExt CamxResultExtBPSOutputIOConfigAddFail         = CamxResultExtBPSBase + 27;
static const CamxResultExt CamxResultExtBPSInvalidOutputPortImage        = CamxResultExtBPSBase + 28;

// CVP extended error codes (Starts from 1792)
static const CamxResultExt CamxResultExtCVPBase                   = CamxResultExtBase * 7;
static const CamxResultExt CamxResultExtCVPSSRError               = CamxResultExtCVPBase + 0;
static const CamxResultExt CamxResultExtCVPSesCreationFailed      = CamxResultExtCVPBase + 1;
static const CamxResultExt CamxResultExtCVPSesInitFailed          = CamxResultExtCVPBase + 2;
static const CamxResultExt CamxResultExtCVPSesStartFailed         = CamxResultExtCVPBase + 3;
static const CamxResultExt CamxResultExtCVPSesDestroyFailed       = CamxResultExtCVPBase + 4;
static const CamxResultExt CamxResultExtCVPSesDeinitFailed        = CamxResultExtCVPBase + 5;
static const CamxResultExt CamxResultExtCVPSesStopFailed          = CamxResultExtCVPBase + 6;
static const CamxResultExt CamxResultExtCVPDMEExecFailed          = CamxResultExtCVPBase + 7;
static const CamxResultExt CamxResultExtCVPOutputValdtnFailed     = CamxResultExtCVPBase + 8;
static const CamxResultExt CamxResultExtCVPOutputNCLIBFailed      = CamxResultExtCVPBase + 9;
static const CamxResultExt CamxResultExtCVPInvalidBufNegPtr       = CamxResultExtCVPBase + 10;
static const CamxResultExt CamxResultExtCVPBufAllocFailure        = CamxResultExtCVPBase + 11;
static const CamxResultExt CamxResultExtCVPChromatixFailure       = CamxResultExtCVPBase + 12;
static const CamxResultExt CamxResultExtCVPIQModuleCreateFailure  = CamxResultExtCVPBase + 13;
static const CamxResultExt CamxResultExtCVPInputBufUnavailable    = CamxResultExtCVPBase + 14;
static const CamxResultExt CamxResultExtCVPInputError             = CamxResultExtCVPBase + 15;
static const CamxResultExt CamxResultExtCVPInvalidImage           = CamxResultExtCVPBase + 16;
static const CamxResultExt CamxResultExtCVPSynxCreateFailed       = CamxResultExtCVPBase + 17;
static const CamxResultExt CamxResultExtCVPSynxBindFailed         = CamxResultExtCVPBase + 18;
static const CamxResultExt CamxResultExtCVPSynxExportFailed       = CamxResultExtCVPBase + 19;
static const CamxResultExt CamxResultExtCVPInputImageUnavailable  = CamxResultExtCVPBase + 20;
static const CamxResultExt CamxResultExtCVPBufferUnavailable      = CamxResultExtCVPBase + 21;
static const CamxResultExt CamxResultExtCVPGeoLibError            = CamxResultExtCVPBase + 22;
static const CamxResultExt CamxResultExtCVPMetaDataUnavailable    = CamxResultExtCVPBase + 23;
static const CamxResultExt CamxResultExtCVPInvalidTuningData      = CamxResultExtCVPBase + 24;
static const CamxResultExt CamxResultExtCVPInvalidConfiguration   = CamxResultExtCVPBase + 25;
static const CamxResultExt CamxResultExtCVPIQModuleFail           = CamxResultExtCVPBase + 26;
static const CamxResultExt CamxResultExtCVPConfigICASetFailed     = CamxResultExtCVPBase + 27;
static const CamxResultExt CamxResultExtCVPInitDMEFailed          = CamxResultExtCVPBase + 28;

// QSAT extended error codes (Starts from 2048)
static const CamxResultExt CamxResultExtQSATBase                  = CamxResultExtBase * 8;
static const CamxResultExt CamxResultExtQSATSSRError              = CamxResultExtQSATBase + 0;

// FD extended error codes (Starts from 2304)
static const CamxResultExt CamxResultExtFDBase                        = CamxResultExtBase * 9;
static const CamxResultExt CamxResultExtFDPubFrameSetFailed           = CamxResultExtFDBase + 0;
static const CamxResultExt CamxResultExtFDPubIntFrameSetFailed        = CamxResultExtFDBase + 1;
static const CamxResultExt CamxResultExtFDMSensorModeDataUnavailable  = CamxResultExtFDBase + 2;
static const CamxResultExt CamxResultExtFDPublishResultsFailed        = CamxResultExtFDBase + 3;
static const CamxResultExt CamxResultExtFDInvalidBufferFormat         = CamxResultExtFDBase + 4;
static const CamxResultExt CamxResultExtFDInvalidImageBuffer          = CamxResultExtFDBase + 5;
static const CamxResultExt CamxResultExtFDPreProcessingFailed         = CamxResultExtFDBase + 6;
static const CamxResultExt CamxResultExtFDInvalidBufNegPtr            = CamxResultExtFDBase + 7;
static const CamxResultExt CamxResultExtFDMInvalidAADimension         = CamxResultExtFDBase + 8;
static const CamxResultExt CamxResultExtFDInvalidBufReqmntPtr         = CamxResultExtFDBase + 9;
static const CamxResultExt CamxResultExtFDInvalidImageFormat          = CamxResultExtFDBase + 10;
static const CamxResultExt CamxResultExtFDInvalidInput                = CamxResultExtFDBase + 11;
static const CamxResultExt CamxResultExtFDCVPSynxCreateFailed         = CamxResultExtFDBase + 12;
static const CamxResultExt CamxResultExtFDCVPSynxGetStatusFailed      = CamxResultExtFDBase + 13;
static const CamxResultExt CamxResultExtFDCVPNullPortPointer          = CamxResultExtFDBase + 14;
static const CamxResultExt CamxResultExtFDCVPConstructFencesFailed    = CamxResultExtFDBase + 15;
static const CamxResultExt CamxResultExtFDCVPFDFenceFailed            = CamxResultExtFDBase + 16;
static const CamxResultExt CamxResultExtFDMutexCreateFailed           = CamxResultExtFDBase + 17;
static const CamxResultExt CamxResultExtFDGetCameraConfigFailed       = CamxResultExtFDBase + 18;
static const CamxResultExt CamxResultExtFDSetupFDEngineFailed         = CamxResultExtFDBase + 19;
static const CamxResultExt CamxResultExtFDCVPSynxInitFailed           = CamxResultExtFDBase + 20;
static const CamxResultExt CamxResultExtFDCVPGetFormatFailed          = CamxResultExtFDBase + 21;
static const CamxResultExt CamxResultExtFDCVPCreateSessionFailed      = CamxResultExtFDBase + 22;
static const CamxResultExt CamxResultExtFDCVPInitFDFailed             = CamxResultExtFDBase + 23;
static const CamxResultExt CamxResultExtFDMInvalidOutputPortPtr       = CamxResultExtFDBase + 24;
static const CamxResultExt CamxResultExtFDMInvalidDLFDDimension       = CamxResultExtFDBase + 25;
static const CamxResultExt CamxResultExtFDHWInvalidOutputImageBuffer  = CamxResultExtFDBase + 26;
static const CamxResultExt CamxResultExtFDHWInvalidInputImageFormat   = CamxResultExtFDBase + 27;
static const CamxResultExt CamxResultExtFDHWInvalidInputImageBuffer   = CamxResultExtFDBase + 28;
static const CamxResultExt CamxResultExtFDCVPInvalidImageFormatPtr    = CamxResultExtFDBase + 29;
static const CamxResultExt CamxResultExtFDCVPReqIDConflict            = CamxResultExtFDBase + 30;
static const CamxResultExt CamxResultExtFDHWMetaDataUnavailable       = CamxResultExtFDBase + 31;

// JPEG extended error codes (Starts from 2560)
static const CamxResultExt CamxResultExtJPEGBase                          = CamxResultExtBase * 10;
static const CamxResultExt CamxResultExtJPEGCMDBufferManagerListInitFail  = CamxResultExtJPEGBase + 1;
static const CamxResultExt CamxResultExtJPEGCMDBufferManagerCreateFail    = CamxResultExtJPEGBase + 2;
static const CamxResultExt CamxResultExtJPEGVendorTagLocationQueryFail    = CamxResultExtJPEGBase + 3;
static const CamxResultExt CamxResultExtJPEGDeviceAcquireFail             = CamxResultExtJPEGBase + 4;
static const CamxResultExt CamxResultExtJPEGInputIOConfigAddFail          = CamxResultExtJPEGBase + 5;
static const CamxResultExt CamxResultExtJPEGInvalidInputPortImage         = CamxResultExtJPEGBase + 6;
static const CamxResultExt CamxResultExtJPEGOutputIOConfigAddFail         = CamxResultExtJPEGBase + 7;
static const CamxResultExt CamxResultExtJPEGInvalidOutputPortImage        = CamxResultExtJPEGBase + 8;
static const CamxResultExt CamxResultExtJPEGCMDBufferFillFail             = CamxResultExtJPEGBase + 9;
static const CamxResultExt CamxResultExtJPEGInputNestedBufferAddFail      = CamxResultExtJPEGBase + 10;
static const CamxResultExt CamxResultExtJPEGOutputNestedBufferAddFail     = CamxResultExtJPEGBase + 11;
static const CamxResultExt CamxResultExtJPEGInvalidLibraryAPI             = CamxResultExtJPEGBase + 12;
static const CamxResultExt CamxResultExtJPEGLibraryNotFound               = CamxResultExtJPEGBase + 13;
static const CamxResultExt CamxResultExtJPEGBufferInitFail                = CamxResultExtJPEGBase + 14;
static const CamxResultExt CamxResultExtJPEGBuffersAndEnginesInitFail     = CamxResultExtJPEGBase + 15;
static const CamxResultExt CamxResultExtJPEGInvalidImageOrThumbnail       = CamxResultExtJPEGBase + 16;
static const CamxResultExt CamxResultExtJPEGInvalidNumberOfInputPort      = CamxResultExtJPEGBase + 17;
static const CamxResultExt CamxResultExtJPEGInvalidNumberOfOutputPort     = CamxResultExtJPEGBase + 18;
static const CamxResultExt CamxResultExtJPEGInvalidOutputBuffer           = CamxResultExtJPEGBase + 19;
static const CamxResultExt CamxResultExtJPEGOutputBufferResetFail         = CamxResultExtJPEGBase + 20;
static const CamxResultExt CamxResultExtJPEGOutputBufferExternalUseFail   = CamxResultExtJPEGBase + 21;
static const CamxResultExt CamxResultExtJPEGMainImageBufferFlushFail      = CamxResultExtJPEGBase + 22;
static const CamxResultExt CamxResultExtJPEGEncoderOutputPublishFail      = CamxResultExtJPEGBase + 23;
static const CamxResultExt CamxResultExtJPEGEncoderOutputTNPublishFail    = CamxResultExtJPEGBase + 24;
static const CamxResultExt CamxResultExtJPEGMainEncoderOutInfoGetFail     = CamxResultExtJPEGBase + 25;
static const CamxResultExt CamxResultExtJPEGInvalidEncodedMainBufferSize  = CamxResultExtJPEGBase + 26;
static const CamxResultExt CamxResultExtJPEGThumbEncoderOutInfoGetFail    = CamxResultExtJPEGBase + 27;
static const CamxResultExt CamxResultExtJPEGInvalidEncodedThumbBufferSize = CamxResultExtJPEGBase + 28;
static const CamxResultExt CamxResultExtJPEGGPURotatedDimensionGetFail    = CamxResultExtJPEGBase + 29;
static const CamxResultExt CamxResultExtJPEGFCVRotatedDimensionGetFail    = CamxResultExtJPEGBase + 30;
static const CamxResultExt CamxResultExtJPEGEXIFImageParamSetFail         = CamxResultExtJPEGBase + 31;
static const CamxResultExt CamxResultExtJPEGUnknownInputPort              = CamxResultExtJPEGBase + 32;
static const CamxResultExt CamxResultExtJPEGInvalidFormat                 = CamxResultExtJPEGBase + 33;
static const CamxResultExt CamxResultExtJPEGThumbnailFormatGetFail        = CamxResultExtJPEGBase + 34;

// StatsParser extended error codes (Starts from 2816)
static const CamxResultExt CamxResultExtStatsParseBase            = CamxResultExtBase * 11;

// Sensor extended error codes (Starts from 3072)
static const CamxResultExt CamxResultExtSensorBase                    = CamxResultExtBase * 12;
static const CamxResultExt CamxResultExtSensorPDAFConfigurationFailed = CamxResultExtSensorBase + 0;
static const CamxResultExt CamxResultExtSensorDeviceCSLReleaseFailed  = CamxResultExtSensorBase + 1;

// AEC extended error codes (Starts from 3328)
static const CamxResultExt CamxResultExtAECBase                     = CamxResultExtBase * 13;
static const CamxResultExt CamxResultExtAECEPRFailed                = CamxResultExtAECBase + 0;
static const CamxResultExt CamxResultExtAECHandleCommandFailed      = CamxResultExtAECBase + 1;
static const CamxResultExt CamxResultExtAECGetAlgoInputFailed       = CamxResultExtAECBase + 2;
static const CamxResultExt CamxResultExtAECPublishMetadataFailed    = CamxResultExtAECBase + 3;
static const CamxResultExt CamxResultExtAECInitializeFailed         = CamxResultExtAECBase + 4;
static const CamxResultExt CamxResultExtAECBaseEnd                  = CamxResultExtAECBase + 5;


// AWB extended error codes (Starts from 3584)
static const CamxResultExt CamxResultExtAWBBase                         = CamxResultExtBase * 14;
static const CamxResultExt CamxResultExtAWBInitializeFailed             = CamxResultExtAWBBase + 0;
static const CamxResultExt CamxResultExtAWBPostPipelineCreateFailed     = CamxResultExtAWBBase + 1;
static const CamxResultExt CamxResultExtAWBEPRFailed                    = CamxResultExtAWBBase + 2;
static const CamxResultExt CamxResultExtAWBBufferDependencyFailed       = CamxResultExtAWBBase + 3;
static const CamxResultExt CamxResultExtAWBPropertyDependencyFailed     = CamxResultExtAWBBase + 4;
static const CamxResultExt CamxResultExtAWBMultiStatsDependencyFailed   = CamxResultExtAWBBase + 5;
static const CamxResultExt CamxResultExtAWBAlgoProcessInputFailed       = CamxResultExtAWBBase + 6;
static const CamxResultExt CamxResultExtAWBGetParamFailed               = CamxResultExtAWBBase + 7;
static const CamxResultExt CamxResultExtAWBPublishMetadataFailed        = CamxResultExtAWBBase + 8;
static const CamxResultExt CamxResultExtAWBProcessFailed                = CamxResultExtAWBBase + 9;
static const CamxResultExt CamxResultExtAWBBaseEnd                      = CamxResultExtAWBBase + 10;

// AF extended error codes (Starts from 3840)
static const CamxResultExt CamxResultExtAFBase                           = CamxResultExtBase * 15;
static const CamxResultExt CamxResultExtAFInitIOUtilFailed               = CamxResultExtAFBase + 0;
static const CamxResultExt CamxResultExtAFPropertyDependencyFailed       = CamxResultExtAFBase + 1;
static const CamxResultExt CamxResultExtAFMultiStatsDependencyFailed     = CamxResultExtAFBase + 2;
static const CamxResultExt CamxResultExtAFBufferDependencyFailed         = CamxResultExtAFBase + 3;
static const CamxResultExt CamxResultExtAFEPRFailedInvalidPointerFailed  = CamxResultExtAFBase + 4;
static const CamxResultExt CamxResultExtAFSetSingleParamFailed           = CamxResultExtAFBase + 5;
static const CamxResultExt CamxResultExtAFSetParamFailed                 = CamxResultExtAFBase + 6;
static const CamxResultExt CamxResultExtAFPublishOutputFailed            = CamxResultExtAFBase + 7;
static const CamxResultExt CamxResultExtAFPublishFOVCFailed              = CamxResultExtAFBase + 8;
static const CamxResultExt CamxResultExtAFPublishSkippedFrameFailed      = CamxResultExtAFBase + 9;
static const CamxResultExt CamxResultExtAFSetDefaultConfigFailed         = CamxResultExtAFBase + 10;
static const CamxResultExt CamxResultExtAFAFProcessFailed                = CamxResultExtAFBase + 11;
static const CamxResultExt CamxResultExtAFParsePDFailed                  = CamxResultExtAFBase + 12;
static const CamxResultExt CamxResultExtAFParseISPFailed                 = CamxResultExtAFBase + 13;
static const CamxResultExt CamxResultExtAFProcessingNodeFinalizeFailed   = CamxResultExtAFBase + 14;
static const CamxResultExt CamxResultExtAFPostPipelineCreateFailed       = CamxResultExtAFBase + 15;
static const CamxResultExt CamxResultExtAFProcessingNodeInitializeFailed = CamxResultExtAFBase + 16;
static const CamxResultExt CamxResultExtAFEPRFailed                      = CamxResultExtAFBase + 17;
static const CamxResultExt CamxResultExtAFStatsProcessorEPRFailed        = CamxResultExtAFBase + 18;
static const CamxResultExt CamxResultExtAFBaseEnd                        = CamxResultExtAFBase + 19;

// ASD extended error codes (Starts from 4096)
static const CamxResultExt CamxResultExtASDBase                         = CamxResultExtBase * 16;
static const CamxResultExt CamxResultExtASDInitializeFailed             = CamxResultExtASDBase + 0;
static const CamxResultExt CamxResultExtASDGetAlgorithmInputFailed      = CamxResultExtASDBase + 1;
static const CamxResultExt CamxResultExtASDEPRFailed                    = CamxResultExtASDBase + 2;
static const CamxResultExt CamxResultExtASDProcessFailedSetParamsFailed = CamxResultExtASDBase + 3;
static const CamxResultExt CamxResultExtASDProcessFailed                = CamxResultExtASDBase + 4;
static const CamxResultExt CamxResultExtASDPublishMetadataFailed        = CamxResultExtASDBase + 5;
static const CamxResultExt CamxResultExtASDBaseEnd                      = CamxResultExtASDBase + 6;

// AFD extended error codes (Starts from 4352)
static const CamxResultExt CamxResultExtAFDBase                 = CamxResultExtBase * 17;
static const CamxResultExt CamxResultExtAFDInitializeFailed     = CamxResultExtAFDBase + 0;
static const CamxResultExt CamxResultExtAFDEPRFailed            = CamxResultExtAFDBase + 1;
static const CamxResultExt CamxResultExtAFDProcessFailed        = CamxResultExtAFDBase + 2;
static const CamxResultExt CamxResultExtAFDPublishOutputFailed  = CamxResultExtAFDBase + 3;
static const CamxResultExt CamxResultExtAFDBaseEnd              = CamxResultExtAFDBase + 4;

// StatsProcessing node extended error codes (Starts from 4608)
static const CamxResultExt CamxResultExtStatsProcessingBase                 = CamxResultExtBase * 18;
static const CamxResultExt CamxResultExtStatsProcessingNodeFinalizeFailed   = CamxResultExtStatsProcessingBase + 0;
static const CamxResultExt CamxResultExtStatsPostPipelineCreateFailed       = CamxResultExtStatsProcessingBase + 1;
static const CamxResultExt CamxResultExtStatsProcessingNodeInitializeFailed = CamxResultExtStatsProcessingBase + 2;
static const CamxResultExt CamxResultExtStatsBufferDependencyFailed         = CamxResultExtStatsProcessingBase + 3;
static const CamxResultExt CamxResultExtStatsPropertyDependencyFailed       = CamxResultExtStatsProcessingBase + 4;
static const CamxResultExt CamxResultExtStatsMultiStatsDependencyFailed     = CamxResultExtStatsProcessingBase + 5;
static const CamxResultExt CamxResultExtStatsEPRFailed                      = CamxResultExtStatsProcessingBase + 6;
static const CamxResultExt CamxResultExtStatsProcessingBaseEnd              = CamxResultExtStatsProcessingBase + 7;

// StatsParser node extended error codes (Starts from 4864)
static const CamxResultExt CamxResultExtStatsParserBase                           = CamxResultExtBase * 19;
static const CamxResultExt CamxResultExtStatsParserProcessingNodeFinalizeFailed   = CamxResultExtStatsParserBase + 0;
static const CamxResultExt CamxResultExtStatsParserProcessingNodeInitializeFailed = CamxResultExtStatsParserBase + 1;
static const CamxResultExt CamxResultExtStatsParserEPRFailed                      = CamxResultExtStatsParserBase + 2;
static const CamxResultExt CamxResultExtStatsParserProcessingBaseEnd              = CamxResultExtStatsParserBase + 3;

// StatsTracker node extended error codes (Starts from 5120)
static const CamxResultExt CamxResultExtStatsTrackerBase = CamxResultExtBase * 20;
static const CamxResultExt CamxResultExtStatsTrackerPostPipelineCreateFailed = CamxResultExtStatsTrackerBase + 0;
static const CamxResultExt CamxResultExtStatsTrackerBufferDependencyFailed   = CamxResultExtStatsTrackerBase + 1;
static const CamxResultExt CamxResultExtStatsTrackerEPRFailed                = CamxResultExtStatsTrackerBase + 2;
static const CamxResultExt CamxResultExtStatsTrackerProcessingBaseEnd        = CamxResultExtStatsTrackerBase + 3;

// StatsNN node extended error codes (Starts from 5376)
static const CamxResultExt CamxResultExtStatsNNBase                     = CamxResultExtBase * 21;
static const CamxResultExt CamxResultExtStatsNNPostPipelineCreateFailed = CamxResultExtStatsNNBase + 0;
static const CamxResultExt CamxResultExtStatsNNBufferDependencyFailed   = CamxResultExtStatsNNBase + 1;
static const CamxResultExt CamxResultExtStatsNNEPRFailed                = CamxResultExtStatsNNBase + 2;
static const CamxResultExt CamxResultExtStatsNNBaseEnd                  = CamxResultExtStatsNNBase + 4;

// EIS extended error codes (Starts from 5632)
static const CamxResultExt CamxResultExtEISBase                   = CamxResultExtBase * 22;
static const CamxResultExt CamxResultExtEISInitFailure            = CamxResultExtEISBase + 0;
static const CamxResultExt CamxResultExtEISNCSFailure             = CamxResultExtEISBase + 1;
static const CamxResultExt CamxResultExtEISDepFailure             = CamxResultExtEISBase + 2;
static const CamxResultExt CamxResultExtEISCropFailure            = CamxResultExtEISBase + 3;
static const CamxResultExt CamxResultExtEISAlgoFailure            = CamxResultExtEISBase + 4;
static const CamxResultExt CamxResultExtEISSampleWindow           = CamxResultExtEISBase + 5;
static const CamxResultExt CamxResultExtEISMarginFailure          = CamxResultExtEISBase + 6;

// IQModule extended error codes (Starts from 5888)
static const CamxResultExt CamxResultExtIQModBase                 = CamxResultExtBase * 23;
static const CamxResultExt CamxResultExtIQModInterpolationFailed  = CamxResultExtIQModBase + 0;
static const CamxResultExt CamxResultExtIQModCalcSettingFailed    = CamxResultExtIQModBase + 1;
static const CamxResultExt CamxResultExtIQModPackRegisterFailed   = CamxResultExtIQModBase + 2;
static const CamxResultExt CamxResultExtIQModChromatixFailure     = CamxResultExtIQModBase + 3;
static const CamxResultExt CamxResultExtIQModGetCmdBufferFailure  = CamxResultExtIQModBase + 4;

// Custom node extended error codes (Starts from 10240)
static const CamxResultExt CamxResultExtCustomBase                = CamxResultExtBase * 40;

#endif // CAMXRETURNTYPES_H
