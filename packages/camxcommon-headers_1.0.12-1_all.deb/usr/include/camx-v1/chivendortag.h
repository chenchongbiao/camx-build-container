////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2017-2021,2023 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @file chivendortag
/// @brief Define Qualcomm Technologies, Inc. Vendor tag information
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef CHIVENDORTAG_H
#define CHIVENDORTAG_H

#include "camxcdktypes.h"
#include "chicommontypes.h"
#include "chi.h"

#include <unordered_map>

#ifdef __cplusplus

extern "C"
{
#endif // __cplusplus

/// @brief Data structures that are exposed to OEM must be packed to have the expected layout.
#pragma pack(push, CDK_PACK_SIZE)

/// @brief Defines maximum number of nodes for FOVs
#define MAX_NODES_NUMBER              4

/// @brief Defines maximum number of streams for a camera
#define MAX_NUM_STREAMS               11

/// @brief Max number of faces detected
static const UINT8 FDMaxFaces        = 10;

/// @brief Defines maximum number of streams for a camera
static const UINT32 MaxLinkedCameras = 4;

/// @brief Defines maximum number of entries in array required in AllNodeCropInfo
static const UINT32 MaxCropInfoEntries = 30;

/// @brief Defines maximum number of ROIs in array required in streamROIInfo
static const UINT32 MaxSupportedROI = 3;

/// @brief Defines maximum number of related camera
static const UINT   MaxDevicePerLogicalCamera    = 8;

/// @brief Special value to determine the logical camera index
static const UINT32 LogicalCameraId = 0xFF;

/// @brief Invalid Index
static const UINT32 INVALID_MODE = 0xFFFFFFFF;

/// Defines the size of the SupportedFeature string buffer.
static const UINT ChiNodeSupportedFeatureBufferSize = 64;


/// @brief Map from chi stream pointer to the physical camera index
typedef std::unordered_map<CHISTREAM*, UINT> ChiStreamToCameraIdMap;

///@brief Enumeration describing sensor mode
typedef enum
{
    NoSync = 0,      ///< No Hardware Sync
    MasterMode,      ///< Master Mode
    SlaveMode,       ///< Slave Mode
} SensorSyncMode;

///@brief Enumeration describing sensor status
typedef enum
{
    SensorNoPerf = 0,///< No Perf Ctrl
    SensorActive,    ///< Sensor In Active Status
    SensorStandby,   ///< Sensor In Sleeping Status
} SensorPerfCtrl;

/// @brief EIS usecase mode
enum class ImageStabilizationMode
{
    NoEIS                    = 0, ///< no stabilization
    EIS2PreviewVideo         = 1, ///< EIS2  mode
    EIS2PreviewEIS3Video     = 2, ///< EIS2 preview and EIS3 video
    EIS2Preview4KEIS3Video   = 3, ///< EIS2 preview and 4K EIS3 video
    EISIoTMultiStream        = 4, ///< IOT EIS with Multi Stream EIS
    EISIoTSingleStream       = 5, ///< IOT EIS with Single Stream EIS
    IoTLDC                   = 6, ///< IOT LDC concurrency with EIS
    MaxImageStablizationMode = 7, ///< Max image stabilization mode
};


///@brief Enumeration describing Buffer input type
typedef enum
{
    BUFFER_FULL,                ///< Buffer is full sized - no downscaling
    BUFFER_DS4,                 ///< Buffer is downscaled by 4
    BUFFER_DS16,                ///< Buffer is downscaled by 16
    BUFFER_FD,                  ///< Buffer is fd - no downscaling
    MAX_BUFFER_INPUT_TYPES      ///< Max number of input types
} BufferInputType;

///@brief Enumeration describing Buffer usage type
enum class BufferUsageType
{
    PREVIEW,
    VIDEO,
    MAX_USAGE_TYPES
};

///@brief Structure describing sensor hardware sync mode configure
///Vendor tag section name:com.qti.chi.multicamerasensorconfig
///Vendor tag tag name:sensorsyncmodeconfig
typedef struct
{
    BOOL           isValid;        ///< flag to indicate if sync mode meta is valid
    SensorSyncMode sensorSyncMode; ///< sensor sync mode
} SensorSyncModeMetadata;

///@brief Enumeration describing seamless in-sensor control state
typedef enum
{
    None    = 0,
    InSensorHDR3ExpStart,
    InSensorHDR3ExpEnabled,
    InSensorHDR3ExpStop
}SeamlessInSensorState;

///@brief Enumeration describing seamless in-sensor Zoom State
typedef enum
{
    InSensorZoomNone  = 0,
    InSensorZoomBinning,
    InSensorZoomCrop,
}InSensorZoomState;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief Structure describing the image size
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct
{
    INT                   width;                        ///< Image size width value
    INT                   height;                       ///< Image size height value
} ImageSizeData;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief structure for refernce crop window size
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct
{
    INT32 width;       ///< width for reference crop window
    INT32 height;      ///< height for reference crop window
} RefCropWindowSize;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief Structure describing shift offset information
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct
{
    INT32                horizonalShift;               ///< x cordinate of the pixel
    INT32                verticalShift;                ///< y cordinate of the pixel
} ImageShiftData;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief Struct for a weighted region used for focusing/metering areas
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct
{
    INT32                xMin;                           ///< Top-left x-coordinate of the region
    INT32                yMin;                           ///< Top-left y-coordinate of the region
    INT32                xMax;                           ///< Width of the region
    INT32                yMax;                           ///< Height of the region
    INT32                weight;                         ///< Weight of the region
} WeightedRegion;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief Struct for a weighted region used for focusing/metering areas
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct
{
    UINT8                numFaces;                       ///< Number of faces detected
    UINT8                faceScore[FDMaxFaces];          ///< List of face confidence scores for detected faces
    CHIRECT              faceRect[FDMaxFaces];           ///< List of face rect information for detected faces
} FDMetadataResults;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief Structure describing Low Power mode
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct
{
    UINT32                cameraId;                     ///< Camera type of the chosen frame
    BOOL                  isEnabled;                    ///< Flag to check if Camera is active
} LowPowerModeData;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief Structure describing camera metadata needed by SAT node
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct
{
    BOOL                  isValid;                      ///< If this metadata is valid
    UINT32                cameraId;                     ///< Camera Id this metadata belongs to
    CHIRECT               pipelineCropRegion;           ///< Pipeline specific crop region
    CHIRECT               ifeLimitCropRegion;           ///< Max Crop that IFE can apply
    CHIRECT               fovRectIFE;                   ///< IFE FOV wrt to active sensor array
    CHIRECT               fovRectIPE;                   ///< IPE FOV wrt to active sensor array
    CHIRECT               ifeAppliedCrop;               ///< Crop applied by IFE
    CHIRECT               sensorIFEAppliedCrop;         ///< Crop applied by Sensor+IFE
    CHIRECT               ifeResidualCrop;              ///< Crop remaining after IFE processing
    WeightedRegion        afFocusROI;                   ///< AF focus ROI
    FLOAT                 lux;                          ///< LUX value
    INT32                 focusDistCm;                  ///< Focus distance in cm
    UINT32                afState;                      ///< AF state
    INT32                 isoSensitivity;               ///< ISO value
    INT64                 exposureTime;                 ///< Exposure time
    UINT64                sensorTimestamp;              ///< Sensor timestamp
    FDMetadataResults     fdMetadata;                   ///< Face detection metadata
} CameraMetadata;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief Enumeration for multi camera input port type
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
enum class MultiCameraPortType
{
    Full            = 0,  ///< Full port
    DS4             = 1,  ///< DS4 port
    DS16            = 2,  ///< DS16 port
    DisplayFull     = 3,  ///< Display full port
    DisplayDS4      = 4,  ///< Display DS4 port
    DisplayDS16     = 5,  ///< Display DS16 port
    FullLong        = 6,  ///< Full long port
    FullLongDS4     = 7,  ///< Full long DS4 port
    FullShort       = 8,  ///< Full short port
    FullShortDS4    = 9,  ///< Full short DS4 port
    DisplayLong     = 10, ///< Display long port
    DisplayLongDS4  = 11, ///< Display long DS4 port
    DisplayShort    = 12, ///< Display short port
    DisplayShortDS4 = 13, ///< Display short DS4
    FD              = 14, ///< FD port
    MaxPortType     = 15, ///< Max port type
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief Structure mapping physicalCameraId to a Node input port
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct
{
    CHILINKNODEDESCRIPTOR nodeDescriptor;
    UINT                  physicalCameraId;    ///< The physical cameraId associated with this nodeDescriptor
    BufferInputType       bufferDownscaleType; ///< The buffer input type
    BufferUsageType       bufferUsageType;     ///< The buffer usage(preview or video)
    MultiCameraPortType   portType;            ///< The port type
} PhysicalCameraInputConfiguration;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief Metadata structure containing a list of physicalCameraId to node input mappings
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct
{
    UINT                             numConfigurations;                     ///< The number of physical camera input configurations
    ImageStabilizationMode           imageStabilizationMode;                ///< Video image stabilization mode
    PhysicalCameraInputConfiguration configuration[MaxPhysicalCameraInput]; ///< Array of physicalCameraId to Node Input properties
} ChiMultiCameraConfig;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief Structure recording whether physical camera's parameter is different from logical camera's
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct
{
    UINT               cameraId;                                ///< physicalcamera Id
    BOOL               isDiff;                                  ///< Flag if the physical camera's parameter is
                                                                ///  different from logical camera's
} PhysicalLogicalDiffMap;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief Metadata structure containing a list of phsical-logical different dimension map
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct
{
    UINT                     numCam;                                     ///< number of cameras
    PhysicalLogicalDiffMap   fullDimensionDiffMap[MaxNumImageSensors];   ///< MCX realtime feature full output physical stream
                                                                         ///  compared to config logical full stream dimension
                                                                         ///  different map
} ChiMultiCamDimensionDiffMap;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief Structure describing Multi camera SAT input meta data structure
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct
{
    UINT32                frameId;                                       ///< Frame ID
    UINT8                 numInputs;                                     ///< Number of input metadata
    CameraMetadata        cameraMetadata[MaxDevicePerLogicalCamera];     ///< Camera metdata for SAT
    UINT32                masterCameraId;                                ///< Identifier of the master camera for input
#if (defined(CAMX_ANDROID_API) && (CAMX_ANDROID_API > 30)) // Greater than Android-Q
    FLOAT                 controlZoomRatio;                              ///< Logical control zoom ratio
#else
    CHIRECTINT            userCropRegion;                                ///< Logical overall user crop region
#endif // Greater than Android-Q
    FLOAT                 currentRealtimeZoomRatio;                      ///< Current realtime zoom ratio which is
                                                                         ///  not effected by offline frame delay
    BOOL                  fastTransitionFlag;                            ///< Flag whether the request needs fast transition
    BOOL                  isSnapshot;                                    ///< snapshot or preview meta
} InputMetadataOpticalZoom;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief Structure describing Multi camera SAT output meta data structure
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct
{
    UINT32                offlineSATMasterCameraId;                  ///< Current master camera id
    UINT32                recommendedMasterCameraId;                 ///< Recommended master camera id
    ImageShiftData        outputShiftPreview;                        ///< Preview frame shift due to spatial alignment
    ImageShiftData        outputShiftSnapshot;                       ///< Snapshot frame shift due to spatial alignment
    ImageSizeData         refResForOutputShift;                      ///< Reference resolution for the output shift
    CHIRECT               outputCrop;                                ///< Output Crop information
    ImageShiftData        outputShift[MaxDevicePerLogicalCamera];    ///< Frame shift due to spatial alignment
    UINT8                 numLinkedCameras;                          ///< Number of linked physical cameras
    LowPowerModeData      lowPowerMode[MaxDevicePerLogicalCamera];   ///< output lower power mode information
    FLOAT                 mappedViewRatio;                           ///< the real zoom ratio after mapped
} OutputMetadataOpticalZoom;


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief Structure describing physical camera configuration
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
struct CameraConfiguration
{
    UINT32              cameraId;                ///< Camera Id
    FLOAT               transitionZoomRatioLow;  ///< Min Transition Zoom ratio at which the camera will be active
    FLOAT               transitionZoomRatioHigh; ///< Max Transition Zoom ratio at which the camera will be active
    BOOL                enableSmoothTransition;  ///< Enable Smooth Transition for the camera during SAT
    CHISENSORCAPS       sensorCaps;              ///< Capabilities related to the device's imaging characteristics
    CHILENSCAPS         lensCaps;                ///< Capabilities related to the device's lens characteristics
    CHISENSORMODEINFO   sensorModeInfo;          ///< Sensor mode information
    BOOL                bIsMCXUsecase;           ///< Specifies If this is a MCX usecase
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief Structure describing set of physical configs
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
struct CameraConfigs
{
    UINT32              numPhysicalCameras;                         ///< Number of physical cameras
    CameraConfiguration cameraConfigs[MaxDevicePerLogicalCamera];   ///< Physical configuration of cameras
    UINT32              primaryCameraId;                            ///< Primary camera in the given Logical camera
    BOOL                enableSATFusion;                            ///< Flag to indicate if enable SAT fusion
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief Structure describing Multi camera RTB input meta data structure
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct
{
    UINT32                frameId;                                     ///< Frame ID
    UINT32                blurLevel;                                   ///< Blur intensity value to be applied to the Bokeh
    UINT32                blurMinValue;                                ///< Blur minimum value
    UINT32                blurMaxValue;                                ///< Blur maximum value
    UINT32                masterCameraId;                              ///< Master camera ID for input metadata.
    CameraMetadata        cameraMetadata[MaxDevicePerLogicalCamera];   ///< Camera metdata for RTB
    UINT8                 numLinkedCameras;                            ///< Number of linked physical cameras
#ifndef DOXYGEN_SHOULD_SKIP_THIS
#if (defined(CAMX_ANDROID_API) && (CAMX_ANDROID_API > 30)) // Greater than Android-Q
    FLOAT                 controlZoomRatio;                            ///< Logical control zoom ratio
#else
    CHIRECTINT            userCropRegion;                              ///< Overall user crop region
#endif // Greater than Android-Q
#endif /* DOXYGEN_SHOULD_SKIP_THIS */
    BOOL                  isSnapshot;                                  ///< snapshot or preview meta
} InputMetadataBokeh;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief Structure describing Multi camera RTB output meta data structure
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct
{
    UINT32                masterCameraId;                   ///< Current master camera id
    UINT32                activeMap;                        ///< Active map to indicate which pipeline is active
    UINT32                depthEffectInfo;                  ///< Depth Effect status information
} OutputMetadataBokeh;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief Structure for Dual camera role, Id
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct
{
    UINT32                currentCameraId;               ///< Current camera id
    UINT32                logicalCameraId;               ///< Logical camera id
    UINT32                masterCameraId;                ///< master camera id
} MultiCameraIds;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief Structure for Dual camera low power mode information
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct
{
    UINT32                isLPMEnabled;                               ///< Low power mode status
    UINT32                isSlaveOperational;                         ///< Is Slave operational when LPM is enabled
    LowPowerModeData      lowPowerMode[MaxDevicePerLogicalCamera];    ///< LPM info for all the real time pipelines
    UINT8                 numLinkedCameras;                           ///< Number of linked physical cameras
} LowPowerModeInfo;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief Structure for Dual camera sync mode information
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct
{
    BOOL                  isSyncModeEnabled;                    ///< Sync mode info to sync both the frames
} SyncModeInfo;


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief Structure for crop regions for capture request
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct
{
    CHIRECTINT            userCropRegion;                ///< Overall user crop region
    CHIRECT               dzWindowNoMargin;              ///< User crop region without SAT margin,for individual sensor
    CHIRECT               pipelineCropRegion;            ///< Pipeline specific crop region
    CHIRECT               ifeLimitCropRegion;            ///< Max Crop that IFE can apply
} CaptureRequestCropRegions;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief Structure for Feature2 input request information
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct
{
    UINT32                internalFrameNumber;           ///< internal frame number
} Feature2InputRequestInfo;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief Structure for Feature2 active cameras
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct
{
    UINT32      cameraId;                           ///< Camera Id
    BOOL        isActive;                           ///< Boolean indicating if the camera is active
} Feature2ActiveCameras;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief Structure for Feature2 active cameras
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct
{
    UINT32      cameraIdx     = INVALID_MODE;        ///< Camera Index
    UINT32      subSensorMode = INVALID_MODE;        ///< SubSensorMode
} CameraIdToSubSensorMode;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief Structure for Feature2 mcc result
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct
{
    BOOL                     isValid;                                    ///< Boolean indicating if the result is valid
    BOOL                     isSnapshotFusion;                           ///< Boolean indicating if the snapshot fusion is enabled
    UINT32                   masterCameraId;                             ///< Camera Id for the master camera
    Feature2ActiveCameras    activeCameras[MaxDevicePerLogicalCamera];   ///< Camera info indicating the LPM status
    UINT32                   numActiveCameras;                           ///< Number of active Cameras in the activeCameras array
    UINT32                   activeMap;                                  ///< Active map to indicate which pipeline is active
    ChiStreamToCameraIdMap   m_streamToPhyIdMap;                         ///< Updated Map from a stream pointer to the
                                                                         ///  LogicalCameraId for logical streams
    UINT32                   activeLogicalMap;                           ///< Active map to indicate which cameras are active
                                                                         ///  for the logical cameras
    UINT32                   activePhysicalMap;                          ///< Active map to indicate which cameras are active
                                                                         ///  for the physical cameras
    CameraIdToSubSensorMode  cameraIndexToSubSensorMode[MaxDevicePerLogicalCamera];  ///< Map from Camera Index to SubSensor Mode
} Feature2ControllerResult;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief Structure for Gamma information
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct
{
    BOOL    isGammaValid;              ///< Is Valid Gamma Entries
    UINT32  gammaG[65];                ///< Gamma Green Entries
} GAMMAINFO;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief Structure for NRM config data
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct
{
    INT    abf_mapping_en;
    INT    anr_mapping_en;
    INT    bpc_mapping_en;
    FLOAT  abf_edge_softness_offset;
    FLOAT  abf_strength_offset;
    FLOAT  anr_luma_threshold_scale[4];
    FLOAT  anr_chroma_threshold_scale[4];
    FLOAT  anr_luma_threshold_offset[4];
    FLOAT  anr_chroma_threshold_offset[4];
    FLOAT  anr_dcblend2_luma_strength_scale[4];
    FLOAT  anr_dcblend2_chroma_strength_scale[4];
    FLOAT  anr_dcblend2_luma_strength_offset[4];
    FLOAT  anr_dcblend2_chroma_strength_offset[4];
    FLOAT  bpc_fmax_offset;
    FLOAT  bpc_fmin_offset;
    FLOAT  abf_noise_std_lut_scale;
    FLOAT  anr_final_blender_luma_min_strength_high_freq_scale;
    FLOAT  anr_final_blender_chroma_min_strength_high_freq_scale;
} NRMConfigData;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief Structure for NRM Configurations
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct
{
    BOOL            nrmModuleEnable;
    BOOL            nrmDataChanged;
    NRMConfigData   nrmCfgData;
} NRMConfigs;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief Structure describing the OEM JPEG EXIF App header Data
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct
{
    SIZE_T  size;   ///< Size in bytes of the EXIF App header data buffer
    VOID*   pData;  ///< Pointer to the EXIF App header data buffer
} OEMJPEGEXIFAppData;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief Structure for Metadata Owner information
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct MetadataOwnerInfo
{
    UINT32                  cameraId;                    ///< Camera Id who owns this metadata
} METADATAOWNERINFO;

/// @brief struct containing the stream specific metadata for a particular stream
typedef struct
{
    VOID*              pSinkStreamPrivateInfo;        ///< Private information(ChiStream::pPrivateInfo) of the sink
                                                      ///  stream from which this stream buffer is generated
    INT                streamType;                    ///< Type of stream (optional)
    VOID*              pParentSinkStreamPrivateInfo;  ///< Private information(ChiStream::pPrivateInfo) of the
                                                      ///  Parent stream
    UINT               requestCropIndex;              ///< Index of crop entry in request crop info payload
    INT                index[MaxPerBufferMetadata];   ///  Index of the data entry corresponding to each buffer metadata
} StreamMapMetaEntry;

/// @brief struct containing the list of stream and thier index map
typedef struct
{
    UINT               streamMapEntryCount;                        ///< Number of valid streams
    StreamMapMetaEntry streamMapEntry[MaxOutputStreamsPerRequest]; ///< Mapping each stream to its index in the metadata
} StreamMapMeta;

/// @brief struct containing the current FOV and residual crop info for a stream
typedef struct
{
    CHIRectangle cropWRTActiveArray;    ///< Crop window w.r.t active pixel array
    CHIRectangle cropWRTSensor;         ///< Crop window w.r.t sensor output window(Also accounts for CSID crop)
    CHIRectangle cropWRTInput;          ///< Crop window of a node w.r.t to input frame dimension
    CHIRectangle cropWRTOutput;         ///< Crop window of a node w.r.t to output frame dimension for a particular port
    CHIDimension frameDimension;        ///< Frame dimension
} StreamCropInfo;

/// @brief struct containing the current FOV and residual crop info for a stream
typedef struct
{
    UINT   nodeType;                ///< Node that publishes the metadata
    UINT   portId;                  ///< Port id associated with the metadata
    UINT   instanceId;              ///< Instance Id of the node
    INT    previousEntry;           ///< Index of the previous entry
} StreamMetaPublisherInfo;

/// @brief struct containing the graph of stream crop information
typedef struct
{
    StreamCropInfo          streamCropInfo;         ///< Array containing port crop info per port per node
    StreamMetaPublisherInfo publisherInfo;          ///< Information regarding the publisher of this crop metadata
    CHIDimension            inputframeDimension;    ///< input frame dimension
    CHIDimension            outputframeDimension;   ///< Output frame dimension
} StreamCropLinkInfo;

/// @brief struct containing the stream crop information associated with each request
typedef struct
{
    UINT               streamCropCount;                       ///< Count of valid entries in the stream crop array
    StreamCropLinkInfo streamCropArray[MaxCropInfoEntries];   ///< Array containing port crop info per port per node
} RequestCropInfo;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief Enumeration describing the various callbacks modes for multicamera
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef enum : INT8
{
    McxCbModeDefault,            ///< Default behavior as CTS. Need to service every stream in the request
    McxCbModePrimaryOnly,        ///< Only streams from primary camera will be serviced in this mode
    McxCbModeMasterOnly,         ///< Only streams from master camera will be serviced in this mode
    McxCbModeAllActiveStreams,   ///< All streams from active camera will serviced in this mode
    McxCbModeLogicalMasterSlave, ///< In this mode one master and multiple slave logical streams will be
                                 ///  configured by the application.
} ChiMcxCbMode;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief Structure describing all the callback related information for multicamera
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct
{
    ChiMcxCbMode    mode;               ///< Callback modes
    BOOL            isRawZSLCbEnabled;  ///< Flag to enable Raw ZSL Callback
} ChiMcxCallbackInfo;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief CSID Binning modes
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
enum class CSIDBinningMode
{
    HorizontalBinning   = 0,    ///< Horizontal binning  (Bayer binning)
    QCFABinning         = 1,    ///< Quad CFA binning
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief structure for IFE CSID binning configuration
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct
{
    BOOL            isBinningEnabled;   ///< Flag to indeicate if CSID binning enabled
    CSIDBinningMode binningMode;        ///< binningMode: 0 H/V binning, 1 QuadraCFA binning
} CSIDBinningInfo;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief structure for Snapshot output dimension
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct
{
    UINT32  width;  ///< The width of snapshot output
    UINT32  height; ///< The height of snapshot output
} GeoLibStreamOutput;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief Structure for ISP ADRC parameters
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct
{
    BOOL  bIsADRCEnabled;                                      ///< Whether ADRC is enabled or not.
    FLOAT GTMPercentage;                                       ///< GTM percentage
    FLOAT DRCGain;                                             ///< DRC gain
    FLOAT DRCDarkGain;                                         ///< DRC dark gain
}ISPADRCParams;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief structure for vendor stream mapping.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
struct StreamMap
{
    UINT32     width;                    ///< width  of the tream
    UINT32     height;                   ///< height of the stream
    INT32      format;                   ///< format of the stream
    INT32      sequenceIndex;            ///< Configure stream order
    UINT32     streamIntent;             ///< Intent to describe if it is preview/snapshot
    UINT32     cameraIndex;              ///< Camera index 0/1/2
    INT32      isPhysicalStream;         ///< If stream needs from physicalcamera
    INT32      isThumbnailPostView;      ///< If this is snapshot postview stream
    INT32      reserved[8];              ///< Reserved
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief structure for dynamic fps  configuration.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
struct DynamicFpsConfig
{
    FLOAT   count;
    FLOAT   fps[4];
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief Array for DebugDumpConfig.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct
{
    CHAR dumpFileName[MaxNumImageSensors][128];
} DumpFileName;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief Structure for depth conversion library
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct
{
    CHAR*   libraryName;            /// Library name
    UINT32  depthOutputFormatCount; /// Depth output format count
    UINT32  depthOutputFormatID;    /// Depth output format ID
    VOID*   depthOutputFormat;      /// Pointer to depth output format list
} ChiDepthConversionLibInfo;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief Ideal Raw Information received on per request basis
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct
{
    BOOL        isIdealRaw;             ///< if ideal raw ouput is requested set to TRUE otherwise FALSE
    INT32       idealRawType;           ///< 0 -- MIPI Raw, 1 -- IFE IDEAL RAW, 2 -- BPS IDEAL RAW
} IdealRawInfo;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief Multicamera 3A synchronization type
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
enum MultiCamera3ASyncType
{
    MultiCamera3ASyncDisabled,      ///< 3A sync is disabled
    MultiCamera3ASyncQTI,           ///< QC 3A sync
    MultiCamera3ASyncSingleton,     ///< Singletone mode sync
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief Active Camera Information on per request basis
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct
{
    UINT   numActiveCameras;                            ///< Number of active Cameras
    UINT32 activeCameras[MaxDevicePerLogicalCamera];    ///< List of active Cameras with respect to framework ID
} ActiveCameraInfo;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief Smooth transition switch controller
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct
{
    BOOL         isFallback;  // Flag to indicate if do fallback
    UINT32       afDistance;  // AF distance
    CHIRECT      afROI;       // AF ROI
} SATSwitchController;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief SWMF Tuning parameters on per request basis
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
struct SWMFandAIDETuningParams
{
    bool   enableGyroRefinement;                 ///< Enable Gyro for image registration decision
    UINT32 imageRegDesc;                         ///< Image Registration Descriptor Selector; 0 -- BLOCK_DESCRIPTOR,
                                                 ///< 1 -- INVARIANT_DESCRIPTOR
    UINT32 imageRegMode;                         ///< Image Registration Accuracy Mode;0 -- FAST, 1 -- PRECISE
    float  deghostingStrength;                   ///< Controls amount of deghosting during temporal blending.
                                                 ///< Range: 0 ~ 1.(default = 0.5)
    float  localMotionSmoothingStrength;         ///< Controls amount of spatial smoothing on local motion areas.
                                                 ///< Range: 0 ~ 1.(default = 1.0)
    float  dtfSpatialYStrength;                  ///< Controls amount of dtf Y spatial smoothing Range: 0 ~ 0.5.(default = 0.0)
    float  dtfSpatialChromaStrength;             ///< Controls amount of dtf chroma spatial smoothing.
                                                 ///< Range: 0 ~ 0.5.(default = 0.0)
    float  spatioTemporalDenoiseBalanceStrength; ///< Controls spatio-temporal denoise balancing. Ranges from 0-1.
    float  sharpnessStrength;                    ///< Controls sharpening of blended frame. Ranges from 0-1.
    float  sharpnessScoreThreshold;              ///< Controls frame rejection threshold based on sharpest frame's score.
    float  denoiseStrength;                      ///< Denoising strength: 0.0-1.0 (default = 0.5)
};

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief HWMFNR Tuning parameters on per request basis
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
struct HWMFNRandAIDE2TuningParams
{
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// denoising_strength
///
/// Tuning Level: must_tune
/// Description: Control trade-off between noise reduction and detail preservation. Higher value results in less noise,
/// but also results in less texture/detail. Lower value results in the opposite.
/// Type: float
/// Default Value: 0.5
/// Range: [0,1.0]
/// Bit Depth: 0uQ0
/// Conversion: no conversion needed
/// Notes: none
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    float  denoiseStrength;                      ///< Denoising strength: 0.0-1.0 (default = 0.5)
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// color_saturation
///
/// Tuning Level: never_tune
/// Description: Control color saturation. Higher value means more saturation and lower value means less saturation(Not
/// used : Future usage)
/// Type: float
/// Default Value: 0
/// Range: [-0.5,0.5]
/// Bit Depth: 0uQ0
/// Conversion: no conversion needed
/// Notes: none
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    float color_saturation;

 ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// tone
///
/// Tuning Level: never_tune
/// Description: Control contrast enhancement. Higher value means more local contrast enhancement(Not used : Future usage)
/// Type: float
/// Default Value: 0
/// Range: [0,1]
/// Bit Depth: 0uQ0
/// Conversion: no conversion needed
/// Notes: none
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    float tone;

 ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// detail_enhancement
///
/// Tuning Level: never_tune
/// Description: Control detail enhancement. Higher value means more detail enhancement(Not used : Future usage)
/// Type: float
/// Default Value: 0
/// Range: [0,1]
/// Bit Depth: 0uQ0
/// Conversion: no conversion needed
/// Notes: none
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    float detail_enhancement;
};
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief Structure CVP Encoder Metadata
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct
{
    DOUBLE  fullResTransform[9];        ///< Intermediate 3x3 Transform generated by RANSAC
    DOUBLE  coarseTransform[9];         ///< Intermediate 3x3 Transform generated by RANSAC
    INT32   fullResTransformQ16[9];     ///< Final 3x3 Transform in Q16 format
    INT32   coarseTransformQ16[9];      ///< Final 3x3 Transform in Q16 format
    UINT32  fullResWidth;               ///< Full resoltion width
    UINT32  fullResHeight;              ///< FULL resolution height
    UINT32  processedWidth;             ///< Processed Width
    UINT32  processedHeight;            ///< Processed Height
    UINT32  nIsValid;                   ///< Flag to indicate validity
    UINT32  nFrameSumGradient;          ///< Frame-Level Sum Gradient
    UINT32  nFrameSumSquareGradient1;   ///< Frame-Level Sum Square Gradient1
    UINT32  nFrameSumSquareGradient2;   ///< Frame-Level Sum Square Gradient2
    UINT16  nLumaHist[8];               ///< Luma Histogram
    INT32   nMVxSum;                    ///< cumulative sum of MVx
    INT32   nMVySum;                    ///< cumulative sum of MVy
    UINT32  nNumMVs;                    ///< NumMVs
    UINT32  nVersionNum;                ///< Version number
    INT32   nTransformConfidence;       ///< Ransac Transform confidence
    UINT32  nCostSum;                   ///< Sum of all 8x8 blocks
    UINT32  reserved[184];              ///< Reserved
} CVPEncoderMetaData;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief  Enumerations referring to pipeline sync mode
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
enum PipelineSyncMode
{
    PipelineSyncDisabled,   ///< Pipeline sync is disabled
    PipelineSyncEnabled     ///< Pipeline sync is enabled
};

#pragma pack(pop)

#ifdef __cplusplus
}
#endif // __cplusplus

#endif // CHIVENDORTAG_H
