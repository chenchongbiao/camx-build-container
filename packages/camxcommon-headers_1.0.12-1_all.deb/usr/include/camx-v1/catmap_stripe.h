//-------------------------------------------------------------------------
// Copyright (c) 2020 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
/*------------------------------------------------------------------------
*       Include Files
* ----------------------------------------------------------------------- */

#ifndef _CATMAP_STRIPE_H
#define _CATMAP_STRIPE_H

#include "stripeNPSPPS.h"
#include "ipe_stripe_internal_structs.h"

void ConfigureCMUSGivenOutputCoordinates(
    const uint8_t cmus_mode,
    const int16_t out_start,
    const int16_t out_end,
    const int16_t catmap_frame_size,
    CMUSOutStruct *param_out);

void ConfigureSTMPGivenOutputCoordinates(
    const int16_t out_start,
    const int16_t out_end,
    const uint16_t catmap_frame_size,
    const BOOL LT,
    const BOOL RB,
    const uint16_t precision,
    const uint32_t step,
    const int32_t us_out_start_frame,
    STMPOutStruct *param_out);

void populateCMUSStripingOutput(IpeStripingLibraryOutputPerStripe* currStripe,
    const IpeStripeAllocationResultPerStripe* pAllocationResult_x,
    const IpeStripeAllocationResultPerStripe* pAllocationResult_y,
    const Ipe1dIntermediateModuleConfig* intermediate_config_x,
    const Ipe1dIntermediateModuleConfig* intermediate_config_y);

void populateSTMPStripingOutput(IpeStripingLibraryOutputPerStripe* currStripe,
    const Ipe1dIntermediateModuleConfig* intermediate_config_x,
    const Ipe1dIntermediateModuleConfig* intermediate_config_y);

void configureHiresCatmapFetchAndCMUS(
    BOOL is_horizontal,
    const IpeModuleConfig1dInput* pInput,
    const IpeStripeAllocationResultPerStripe* allocationResult,
    Ipe1dIntermediateModuleConfig* intermediate_config,
    Generic* pStripe);

void configureLoresCatmapFetchAndSTMP(
    BOOL is_horizontal,
    const IpeModuleConfig1dInput* pInput,
    const IpeStripeAllocationResultPerStripe* allocationResult,
    Ipe1dIntermediateModuleConfig* intermediate_config,
    Generic* pStripe);

#endif
