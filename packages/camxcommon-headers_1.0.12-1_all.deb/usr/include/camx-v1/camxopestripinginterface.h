//-------------------------------------------------------------------------
// Copyright (c) 2019-2021 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.

//------------------------------------------------------------------------
// @file  camxopestripinginterface.h
// @brief Declaration of all exposed structs & functions
//------------------------------------------------------------------------

#ifndef _CAMXOPESTRIPINGINTERFACE_H_
#define _CAMXOPESTRIPINGINTERFACE_H_

#include "camxdefs.h"

CAMX_NAMESPACE_BEGIN


static const UINT32 OPEMaxStripeCount = 64; ///< for 25MP max num of stripe is 32.

/// @brief Image range
enum OPEStripeImageRange
{
    CoordinateStart = 0,                                                       ///< Start coordinate
    CoordinateEnd,                                                             ///< End coordinate
    CoordinateCount                                                            ///< Coordinate count
};

/// @brief Pixel input count
enum OPEStripePixelInput
{
    OPEStripeMainIn = 0,                                                       ///< Main Input
    OPEStripePixelInputCount                                                   ///< Input count
};

/// @brief Pixel output
enum OPEStripePixelOutput
{
    OPEStripePixelOutputVideo = 0,                                             ///< Video output
    OPEStripePixelOutputDisp,                                                  ///< Display output
    OPEStripePixelOutputARGB,                                                  ///< ARGB output
    OPEStripePixelOutputFD,                                                    ///< FD output
    OPEStripePixelOutputDummy,                                                 ///< Dummy output
    OPEStripePixelOutputCount,                                                 ///< Max output count
    OPEStripePixelOutputLTMDC = OPEStripePixelOutputDummy,                     ///< LTMDC output
    OPEStripePixelOutputReference                                              ///< Reference output
};


/// @brief Stats output
enum OPEStripeStatsOutput
{
    OPEStripeStatsOutputIHIST = 0,                                             ///< IHIST stats output
    OPEStripeStatsOutputBG,                                                    ///< BG stats output
    OPEStripeStatsOutputLTMDC,                                                 ///< LTMDC stats output
    OPEStripeStatsOutputCount                                                  ///< Max stats output count
};

/// @brief WNR layers
enum OPEStripeWNRLayers{
    OPEStripeWNRLayer0        = 0,                                             ///< Layer 0
    OPEStripeWNRLayer1        = 1,                                             ///< Layer 1
    OPEStripeWNRLayer2        = 2,                                             ///< Layer 2
    OPEStripeWNRLayer3        = 3,                                             ///< Layer 3
    OPEStripeWNRLayerCountY   = 3,                                             ///< WNY Y max layer count
    OPEStripeWNRLayerCountC   = 4,                                             ///< WNR C max layer count
    OPEStripeWNRLayerMaxCount = 4                                              ///< Max layer count
};

/// @brief ROI struct
struct OPEStripeROIStruct {
    UINT16 x;                                                                  ///< x value
    UINT16 y;                                                                  ///< y value
    UINT16 width;                                                              ///< Width value
    UINT16 height;                                                             ///< Height value
};

/// @brief Zoom window struct
struct OPEStripeZoomWindow {
    BOOL               enable;                                                 ///< enable zoom
    OPEStripeROIStruct roi;                                                    ///< ROI
};

/// @brief Chroma Upsample 2.1 input params
struct OPEStripeChromaUpInputParams {
    BOOL enable;                                                               ///< enable Chroma Upsample
    BOOL cosited;                                                              ///< Cosited
    BOOL isOdd;                                                                ///< 0: even; 1: odd
};

/// @brief RNR output params
struct OPEStripeChromaUp1DOutputParams
{
    UINT16 enable;                                                             ///< Enable
    UINT16 outputl;                                                            ///< Output Length
    INT16  indexOffset;                                                        ///< Index offset
    INT16  roundingPattern;                                                    ///< Rounding pattern
    UINT32 initialPhase;                                                       ///< Initial phase
};

/// @brief Chroma Upsample output params
struct OPEStripeChromaUpsampleOutputParams
{
    OPEStripeChromaUp1DOutputParams *outX;                                     ///< Horizontal Upsample
    OPEStripeChromaUp1DOutputParams *outY;                                     ///< Vertical Upsample
};

/// @brief ABFBPC4.1 input params
struct OPEStripeABFBPCInputParams{
    BOOL  enable;                                                              ///< enable ABF BPC
    BOOL  BPCEnable;                                                           ///< BPC enable
    BOOL  ABFEnable;                                                           ///< ABF enable
    INT16 bayerPattern;                                                        ///< bayer pattern
};

/// @brief RNR output params
struct OPEStripeRnrOutputParams
{
    INT16 bx;                                                                  ///< bx value
    INT16 by;                                                                  ///< by value
    INT32 rSquareInit;                                                         ///< rsquare init
    INT16 rSquareShift;                                                        ///< rsquare shift
    INT16 rSquareScale;                                                        ///< rsquare scale
};

/// @brief ABFBPC output params
struct OPEStripeABFBPCOutputParams
{
  OPEStripeRnrOutputParams rnr;                                                ///< RNR value
  INT16                    bayerPattern;                                       ///< bayer pattern
};

/// @brief ASF input params
struct OPEStripeASFv30InputParams
{
    BOOL enable;                                                               ///< enable ASF
    BOOL edgeAlignmentEnable;                                                  ///< edge alignment enable
    BOOL contrastEnable;                                                       ///< contrast enable
    BOOL layer2ContrastEnable;                                                 ///< Layer 2 contrast enable
    BOOL layer1ContrastEnable;                                                 ///< Layer 1 contrast enable
    BOOL layer2Enable;                                                         ///< layer 2 enable
    BOOL layer1Enable;                                                         ///< layer 1 enable
};

/// @brief ASF output params
struct OPEStripeASFv30OutputParams
{
    INT16 faceHorizontalOffset;                                                ///< face Horizontal offset
    INT16 faceVerticalOffset;                                                  ///< face vertical offset
    INT16 rSquareShift;                                                        ///< rsquare shift
    INT16 rSquareScale;                                                        ///< rsquare scale
    INT32 initialRSquare;                                                      ///< initial rsquare
    INT16 initialOffsetMinusCenterHorizontal;                                  ///< initial offset minus center H
    INT16 initialOffsetMinusCenterVertical;                                    ///< initial offset minus center V
};

/// @brief Basic Module Input params
struct OPEStripeBasicModuleInput
{
    BOOL enable;                                                               ///< enable
};

/// @brief CRC 1D output params
struct OPEStripeCRCv101dOutputParams
{
    INT16 firstOut;                                                            ///< first out
    INT16 lastOut;                                                             ///< last out
    INT16 firstLineOut;                                                        ///< first Line out
    INT16 lastLineOut;                                                         ///< last Line out
};

/// @brief CRC striping output params
struct OPEStripeCRCv10StripingOutputParams
{
    BOOL enable;                                                               ///< enable CRC
    OPEStripeCRCv101dOutputParams *outX;                                       ///< X output
    OPEStripeCRCv101dOutputParams *outY;                                       ///< Y output
};

/// @brief iHIST input params
struct OPEStripeIHistv12InputParams
{
    INT32 enable;                                                              ///< iHIST enable
    INT32 histRgnHOffset;                                                      ///< Region H offset
    INT32 histRgnHNum;                                                         ///< Region H num
};

/// @brief iHIST output params
struct OPEStripeIHistv12OutputParams
{
    INT32 enable;                                                              ///< enable iHIST
    INT32 histRgnHOffset;                                                      ///< Region H offset
    INT32 histRgnHNum;                                                         ///< Region H num
};

/// @brief LTM input params
struct OPEStripeLTMv13InputParams
{
    BOOL enable;                                                               ///< enable LTM
    BOOL maskFilterEnable;                                                     ///< mask filter enable
    BOOL imgProcessEnable;                                                     ///< Image processing enable
    BOOL dataCollectEnable;                                                    ///< Data collection enable
    BOOL dataCollectionAtDC16Pass;                                             ///< Data collection at 16 pass enable
};

/// @brief LTM DC params
struct OPEStripeLTMV13DCParams
{
    UINT16 dataCollectEnable;                                                  ///< data collection enable
    UINT16 dsEnable;                                                           ///< Downscaler enable
    UINT16 dslIn;                                                              ///< DS1 input
    UINT16 dslout;                                                             ///< DS1 output
    UINT16 dsSkipCnt;                                                          ///< DS Skip count
    UINT16 dsStartCount;                                                       ///< DS Start count
    INT32  dsPhaseInit;                                                        ///< DS phase init
    UINT32 dsPhaseMulti;                                                       ///< DS Phase multi pass
    UINT16 dsQ2;                                                               ///< DS Q2
    UINT16 dsInputl;                                                           ///< DS input 1
    UINT16 dcInitCellnumX;                                                     ///< DC init cell X
    UINT16 dcInitdx;                                                           ///< DC init dx
    UINT16 dc3dSumClear;                                                       ///< DC 3D conv sum clear
    UINT16 dcConvStartCellX;                                                   ///< DC conv start cell X
    UINT16 dcConvEndCellX;                                                     ///< DC conv end cell X
    UINT16 dcXstart;                                                           ///< DC X start
    UINT16 dcXend;                                                             ///< DC X end
    UINT16 dropFirstOutput;                                                    ///< Drop First Output
    UINT16 dummyFieldForBytePadding;                                           ///< Dummy field for byte padding
};

/// @brief LTM IP 1D params
struct OPEStripeLTMV13IP1DParams
{
    UINT16 imageProcessEn;                                                     ///< Image Processing enable
    UINT16 ipCellSize;                                                         ///< IP cell size
    UINT16 ipInvCellSize;                                                      ///< IP Inv cell size
    UINT16 ipInitCellnum;                                                      ///< IP init cell num
    UINT16 ipInitD;                                                            ///< IP init D
    UINT16 ipInitP;                                                            ///< IP init P
    INT16  dummyFieldForBytePadding;                                           ///< Dummy field for byte padding
};

/// @brief LTM stripe output params
struct OPEStripeLTMv13StripingOutputParams
{
    OPEStripeLTMV13DCParams *dcOutX;                                           ///< DC Output X
    OPEStripeLTMV13DCParams *dcOutY;                                           ///< DC output Y
    OPEStripeLTMV13IP1DParams *ipOutX;                                         ///< IP Output X
    OPEStripeLTMV13IP1DParams *ipOutY;                                         ///< IP Ouput Y
    INT16 dsFac;                                                               ///< DS fac
    INT16 dummyFieldForBytePadding;                                            ///< Dummy field for byte padding
};

/// @brief MNDS input params
struct OPEStripeMNDSv20InputParams
{
    INT16 cScaleInCfgRoundingOptionH;                                          ///< Scale in cfg rounding option H
    INT16 cScaleInCfgRoundingOptionV;                                          ///< Scale in cfg rounding option V
    UINT16 overlapH;                                                           ///< v23 4uQ4 0:15
    UINT16 nnEN;                                                               ///< nearest neighbor mode
};

/// @brief MNDS input structure 1D
struct OPEStripeMNScaleDownInStructV201D
{
    INT32  phaseInit;                                                          ///< phase init
    UINT32 phaseStep;                                                          ///< phase step
    UINT16 enable;                                                             ///< enable MNDS
    UINT16 inputl;                                                             ///< input1
    UINT16 outputl;                                                            ///< output1
    UINT16 pixelOffset;                                                        ///< pixel offset
    UINT16 interpReso;                                                         ///< interpReso
    UINT16 roundingOptionV;                                                    ///< rounding option V
    UINT16 roundingOptionH;                                                    ///< rounding option H
    BOOL   dropFirstOutput;                                                    ///< drop first output
    UINT16 dummyFieldForBytePadding;                                           ///< Dummy field for byte padding
    UINT16 earlyTerminationH;                                                  ///< Early Termination
    UINT16 overlap;                                                            ///< Overlap
    // BOOL roundingBias;                                                      ///< add bias due to horizontal address offset
};

/// @brief MNDS output params
struct OPEStripeMNDSv20OutputParams
{
    OPEStripeMNScaleDownInStructV201D *outX;                                   ///< MNDS output X
    OPEStripeMNScaleDownInStructV201D *outY;                                   ///< MNDS output Y
};  // HW parameters

/// @brief RS Stats input params
struct OPEStripeRSInputParams
{
    BOOL    enable;                                                            ///< enable RS stats
    UINT16  rsRgnHOffset;                                                      ///< Region H offset
    UINT16  rsRgnVNum;                                                         ///< Region V num
    UINT16  rsRgnHNum;                                                         ///< region V num
    UINT16  rsRgnWidth;                                                        ///< Region width
};

/// @brief RS Stats output params
struct OPEStripeRSOutputParams
{
    BOOL    enable;                                                            ///< RS output enable
    UINT16  rsRgnHOffset;                                                      ///< Region H offset
    UINT16  rsRgnHNum;                                                         ///< region H num
    UINT16  firstHorRgnWidth;                                                  ///< first H region width
    UINT16  lastHorRgnWidth;                                                   ///< last H region width
};

/// @brief LSC34 input params (Spectra545)
struct OPERollOffv34InputParams
{
    BOOL   enable;
    UINT16 bWidthL;                     ///< Subgrid width, 9u, 2*Bwidth is the real width, n mean n+1
    UINT16 meshGridBwidthL;             ///< Meshgrid width, 9u, 2*MeshGridBwidth is the real width, n mean n+1
                                        ///< not used in rolloff implementation, only as HW counters
    UINT16 lXStartL;                    ///< Start block x index, 6u
    UINT16 bXStartL;                    ///< Start subgrid x index within start block, 3u
    UINT16 bXD1L;                       ///< x coordinate of top left pixel in start block/subgrid, 9u
    UINT16 numMeshGainH;                ///< Number of horizontal mesh gains, n mean n+2
    UINT16 IntpFactorL;                 ///< Bicubic interpolation factor (0:3)
};

/// @brief LSC34 Output params (Spectra545)
struct OPERollOffv34OutputParams
{
    UINT32 gridIndex;                    ///< Start block x index, 6u
    UINT32 subGridIndex;                 ///< Start subgrid x index within start block, 3u
    UINT32 pixelIndexWithinSubGrid;      ///< x coordinate of top left pixel in start block/subgrid, 9u
};

/// @brief Upscale v2.0 input params
struct OPEStripeUpscalarv20InputParams
{
    BOOL   enable;                                                             ///< enable Upscaler
    UINT32 yPhaseInitH;                                                        ///< Y phase init H value
    UINT32 yPhaseInitV;                                                        ///< Y phase init V value
    UINT16 yPreloadH;                                                          ///< Y preload H
    UINT16 yPreloadV;                                                          ///< Y preload H
    UINT16 yDitheringMode;                                                     ///< Y dithering mode
    UINT16 cDitheringMode;                                                     ///< C dithering mode
    UINT16 cRoundingOptionH;                                                   ///< C Rounding option H
    UINT16 cRoundingOptionV;                                                   ///< C Rounding option V
};

/// @brief Upscale v2.0 1D output params
struct OPEStripeUpscalev201dOutputParams
{
    UINT16 input1;                                                             ///< Upscaler input 1
    UINT16 outputl;                                                            ///< Upscaler output 1
    INT16  preload;                                                            ///< preload
    UINT16 ditheringModeY;                                                     ///< Y dithering mode
    UINT16 ditheringModeC;                                                     ///< C dithering mode
    UINT32 vRoundingMode;                                                      ///< V Rounding mode
    UINT32 hRoundingMode;                                                      ///< H Rounding mode
    INT16  dummyFieldForBytePadding;                                           ///< dummy field
    UINT32 phaseInit;                                                          ///< phase init
    UINT32 phaseStep;                                                          ///< phase step
};

/// @brief Upscale v2.0 output params
struct OPEStripeUpscalev20OutputParams
{
    BOOL opModeEnable;                                                         ///< Output mode enable
    OPEStripeUpscalev201dOutputParams *outX;                                   ///< Upscale output X
    OPEStripeUpscalev201dOutputParams *outY;                                   ///< Upscale output Y
};

/// @brief WNR input params
struct OPEStripeWNRInputParams
{
    BOOL   enable;                                                             ///< Enable WNR module
    BOOL   autoCropDisable;                                                    ///< disable auto-crop
    BOOL   layerEnable[OPEStripeWNRLayerMaxCount];                             ///< WNR layers enable
    UINT16 xCoordinate;                                                        ///< X coordinate
    UINT16 rSquare[OPEStripeWNRLayerMaxCount];                                 ///< rSquare
    UINT8  rSquareShift;                                                       ///< rsquare shift
};

/// @brief WNR output params
struct OPEStripeWNROutputParams
{
    INT16  initOffsetMinusCenterH;                                             ///< init offset minus Center H
    INT16  initOffsetMinusCenterV;                                             ///< init offset minus Center V
    UINT32 rSquareInit;                                                        ///< rSquare Init
    UINT8  rSquareScale;                                                       ///< rSquare Scale
    UINT8  rSquareShift;                                                       ///< rSquare Shift
};

/// @brief Frame write engine params
struct OPEStripeWriteEnginePassParam
{
    INT32 bufStride1;                                                          ///< buffer stride 1
    INT32 stripeHeight1;                                                       ///< Stripe 1 height
    INT32 bufStride2;                                                          ///< buffer stride 2
    INT32 stripeHeight2;                                                       ///< Stripe 2 height
};

/// @brief Stripe write wngine params
struct OPEStripeWriteEngineStripeParam
{
    INT32 enable1;                                                             ///< Enable 1
    INT32 hInit1;                                                              ///< H init1
    INT32 stripeWidth1;                                                        ///< Stripe width1
    INT32 enable2;                                                             ///< Enable 2
    INT32 hInit2;                                                              ///< H init2
    INT32 stripeWidth2;                                                        ///< Stripe width2
};

/// @brief OPE Striping Library Interface Input struct
struct OPEStripeInterfaceInput
{
    BOOL   stripingEnable;                                                     ///< 0: numStripes is 1; 1:regular striping
    BOOL   enableStripingDumps;                                                ///< enable_dump
    UINT16 chipID;                                                             ///< Indicate which chip
    UINT16 pixelInFormat[OPEStripePixelInputCount];                            ///< Pixel input format
    UINT16 pixelInWidth[OPEStripePixelInputCount];                             ///< Pixel input width
    UINT16 pixelInHeight[OPEStripePixelInputCount];                            ///< Pixel input height

    UINT16 pixelOutFormat[OPEStripePixelOutputCount];                          ///< Pixel output format
    UINT16 pixelOutWidth[OPEStripePixelOutputCount];                           ///< Pixel output width
    UINT16 pixelOutHeight[OPEStripePixelOutputCount];                          ///< Pixel output height
    OPEStripeZoomWindow pixelOutputZoomWindowUnion;                            ///< Pixel Out Zoom Window union
    OPEStripeZoomWindow pixelOutputZoomWindows[OPEStripePixelOutputCount];     ///< Pixel Out Zoom Windows
    UINT16 enableVideoOutMALalignment;                                         ///< Enable VideoOut MAL alignment
    UINT16 opeVideoOutMALalignmentGrid;                                        ///< VideoOut MAL alignment grid
    UINT16 muxRGBYUV444;                                                       ///< 0: RBG, 12b;   1: YUV444, 12b
    UINT16 muxYUV444YUV420;                                                    ///< 0: YUV444, 8b; 1: YUV420, 8b
    UINT16 overrideChromads2EN;                                                ///< 0: CDS disable, 1: CDS Enabled
    OPEStripeChromaUpInputParams    chromaUp;                                  ///< Chroma Upsample Input
    OPEStripeABFBPCInputParams      bpcabfInput;                               ///< BPCABF input
    OPEStripeBasicModuleInput       demosaicInput;                             ///< Demosaic input
    OPEStripeLTMv13InputParams      ltmInput;                                  ///< LTM input
    OPEStripeMNDSv20InputParams     chromaDS2Input;                            ///< Chroma DS2 input
    OPEStripeWNRInputParams         wnrYInput;                                 ///< WNR Y input
    OPEStripeWNRInputParams         wnrCInput;                                 ///< WNR C input
    OPEStripeASFv30InputParams      asfInput;                                  ///< ASF input
    OPEStripeUpscalarv20InputParams upscaleInput;                              ///< Upscaler input
    OPEStripeMNDSv20InputParams     mndsDispInput;                             ///< MNDS Display input
    OPEStripeMNDSv20InputParams     mndsFDInput;                               ///< MNDS FD input
    OPEStripeIHistv12InputParams    iHistInput;                                ///< iHIST input
    OPEStripeRSInputParams          rsInput;                                   ///< RS stats input
    OPERollOffv34InputParams        lscInput;                                  ///< Roll off input
    UINT32                          instance;                                  ///<.Instance ID
    UINT64                          requestID;                                 ///< Request ID
    UINT32                          hours;                                     ///< Time Stamp hours;
    UINT32                          minutes;                                   ///< Time Stamp minutes;
    UINT32                          seconds;                                   ///< Time Stamp seconds;
    BOOL                            isLTMDCOnlyOPE;                            ///< OPE LTM DC only

};

/// @brief Module 1D Output Storage
struct OPEStripeInterfaceModule1dOutputStorage {
  OPEStripeCRCv101dOutputParams crcPreChromaUpCropLumaOut;                     ///< CRC Pre-ChromaUp crop Y output
  OPEStripeCRCv101dOutputParams crcPreChromaUpCropChromaOut;                   ///< CRC Pre-ChromaUp C output
  OPEStripeCRCv101dOutputParams crcChromaDownscalerCropLumaOut;                ///< CRC DS crop Y output
  OPEStripeCRCv101dOutputParams crcChromaDownscalerCropChromaOut;              ///< CRC DS crop C output
  OPEStripeCRCv101dOutputParams crcPreUpscalarCropLumaOut;                     ///< CRC pre-upscaler crop Y output
  OPEStripeCRCv101dOutputParams crcPreUpscalarCropChromaOut;                   ///< CRC pre-upscaler crop C output
  OPEStripeCRCv101dOutputParams crcDispPreMndsCropLumaOut;                     ///< CRC Disp pre-MNDS Y output
  OPEStripeCRCv101dOutputParams crcDispPreMndsCropChromaOut;                   ///< CRC Disp pre-MNDS C output
  OPEStripeCRCv101dOutputParams crcDispPostCropLumaOut;                        ///< CRC Disp post-crop Y output
  OPEStripeCRCv101dOutputParams crcDispPostCropChromaOut;                      ///< CRC Disp post-crop C output
  OPEStripeCRCv101dOutputParams crcVideoPostCropLumaOut;                       ///< CRC Video post-crop Y output
  OPEStripeCRCv101dOutputParams crcVideoPostCropChromaOut;                     ///< CRC Video post-crop C output
  OPEStripeCRCv101dOutputParams crcPreRollOffCropOut;                          ///< CRC Pre Roll off Crop output (SPECTRA_545)

  OPEStripeChromaUp1DOutputParams chromaUpOut;                                 ///< Chroma Upsample output

  OPEStripeLTMV13DCParams dcOut;                                               ///< LTM DC output
  OPEStripeLTMV13IP1DParams ipOut;                                             ///< LTM IP output
  OPEStripeMNScaleDownInStructV201D chromaDS2Out;                              ///< Chroma DS2 output
  OPEStripeUpscalev201dOutputParams usYOut;                                    ///< Upscaler Y output
  OPEStripeUpscalev201dOutputParams usCOut;                                    ///< Upscaler C output
  OPEStripeMNScaleDownInStructV201D mndsDispYOut;                              ///< MNDS Disp Y ouput
  OPEStripeMNScaleDownInStructV201D mndsDispCOut;                              ///< MNDS Disp C output
};

/// @brief Striping Output per stripe
struct OPEStripeInterfaceOutputPerStripe
{
  INT16 pixelInHorizontalRange[OPEStripePixelInputCount][CoordinateCount];     ///< Input Port Info (Horizontal Dimension)
  INT16 pixelOutHorizontalRange[OPEStripePixelOutputCount][CoordinateCount];   ///< Output Port Info (Horizontal Dimension)
  OPEStripeInterfaceModule1dOutputStorage outputConfigStorage1d;               ///< StaticModule1DConfigData for Mem Mgmt
  OPEStripeWriteEngineStripeParam rsWriteEngineStripeParam;                    ///< RS write engine stripe params
  OPEStripeWriteEngineStripeParam ltmdcWriteEngineStripeParam;                 ///< LTM DC write engine stripe params
  // UINT16 statsOutHorizontalRange[OPEStripeStatsOutputCount][CoordinateCount];  ///< stats output coordinates
  // UINT16 statsOutHorizontalStride[OPEStripeStatsOutputCount];                  ///< stats output stride
  BOOL isLeftStripe;                                                           ///< Stripe Type (Horizontal Dimension)
  BOOL isRightStripe;                                                          ///< Stripe Type (Horizontal Dimension)
  OPEStripeCRCv10StripingOutputParams crcPreChromaUpCropLuma;                  ///< CRC DS crop Y
  OPEStripeCRCv10StripingOutputParams crcPreChromaUpCropChroma;                ///< CRC DS crop C
  OPEStripeCRCv10StripingOutputParams crcChromaDownscalerCropLuma;             ///< CRC DS crop Y
  OPEStripeCRCv10StripingOutputParams crcChromaDownscalerCropChroma;           ///< CRC DS crop C
  OPEStripeCRCv10StripingOutputParams crcPreUpscalarCropLuma;                  ///< CRC pre-upscaler crop Y
  OPEStripeCRCv10StripingOutputParams crcPreUpscalarCropChroma;                ///< CRC pre-upscaler crop C
  OPEStripeCRCv10StripingOutputParams crcDispPreMndsCropLuma;                  ///< CRC Disp pre-MNDS crop Y
  OPEStripeCRCv10StripingOutputParams crcDispPreMndsCropChroma;                ///< CRC Disp pre-MNDS crop C
  OPEStripeCRCv10StripingOutputParams crcDispPostCropLuma;                     ///< Disp post-crop Y
  OPEStripeCRCv10StripingOutputParams crcDispPostCropChroma;                   ///< Disp post-crop C
  OPEStripeCRCv10StripingOutputParams crcVideoPostCropLuma;                    ///< Video post-crop Y
  OPEStripeCRCv10StripingOutputParams crcVideoPostCropChroma;                  ///< Video post-crop C
  OPEStripeCRCv10StripingOutputParams crcPreRollOffCrop;                       ///< Pre Rolloff Crop (Spectra545)

  OPEStripeChromaUpsampleOutputParams chromaUpOutput;                          ///< Chroma Upsample output
  OPEStripeABFBPCOutputParams         bpcabfOutput;                            ///< BPCABF output
  OPEStripeLTMv13StripingOutputParams ltmOutput;                               ///< LTM output
  OPEStripeMNDSv20OutputParams        chromaDS2Output;                         ///< Chroma DS2 output
  OPEStripeWNROutputParams            wnrYOutput;                              ///< WNR Y output
  OPEStripeWNROutputParams            wnrCOutput;                              ///< WNR C output
  OPEStripeASFv30OutputParams         asfOutput;                               ///< ASF output
  OPEStripeUpscalev20OutputParams     upscaleYOutput;                          ///< Upscaler Y output
  OPEStripeUpscalev20OutputParams     upscaleCOutput;                          ///< Upscaler C output
  OPEStripeMNDSv20OutputParams        mndsDispYOutput;                         ///< MNDS Y output
  OPEStripeMNDSv20OutputParams        mndsDispCOutput;                         ///< MNDS C output
  OPEStripeIHistv12OutputParams       iHistOutput;                             ///< iHIST output
  OPEStripeRSOutputParams             rsOutput;                                ///< RS stats output
  OPERollOffv34OutputParams           lscOutput;                               ///< RollOff output
  UINT32                              qosOPECounter;                           ///< QOS OPE Counter
};

/// @brief Striping Output per frame
struct OPEStripeInterfaceOutputPerFrame
{
  INT16 pixelInVerticalRange[OPEStripePixelInputCount][CoordinateCount];       ///< Input Port Info (Vertical Dimension)
  INT16 pixelOutVerticalRange[OPEStripePixelOutputCount][CoordinateCount];     ///< Output Port Info (Vertical Dimension)
  OPEStripeInterfaceModule1dOutputStorage outputConfigStorage1d;               ///< StaticModule1DConfigData for Mem Mgmt
  OPEStripeWriteEnginePassParam rsWriteEngineFrameParam;                       ///< RS write engine frame params
  OPEStripeWriteEnginePassParam ltmdcWriteEngineFrameParam;                    ///< LTM DC write engine frame params
  UINT16                        numStripes;                                    ///< Num stripes
  OPEStripeInterfaceOutputPerStripe* stripeOut[OPEMaxStripeCount];             ///< Per stripe output config
};


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief Class that implements the opeStripingInterface
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
class OPEStripingInterface
{
public:
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// OpeStripingLibraryExecute
    ///
    /// @brief  OpeStripingLibraryExecute This API returns the Striping Output
    ///
    /// @param  pStripingInput           Striping Input
    /// @param  pStripingInputPerFrame   Striping Output
    ///
    /// @return UINT32
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    UINT32 OpeStripingLibraryExecute(
        OPEStripeInterfaceInput*           pStripingInput,
        OPEStripeInterfaceOutputPerFrame*  pStripingOutputPerFrame);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// OpeStripingLibraryReleaseStripeOutput
    ///
    /// @brief  Release Memory allocated
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    VOID OpeStripingLibraryReleaseStripeOutput();

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// OpeStripingLibraryExecute
    ///
    /// @brief  OpeStripingLibraryExecute This API returns the Striping Output
    ///
    /// @param  pStripeOut        Striping Output
    /// @param  isLTMDCOnlyOPE    LTM DC only OPE
    ///
    /// @return BOOL
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    BOOL OpeStripingLibraryCheckForDummyStripe(
        OPEStripeInterfaceOutputPerStripe* pStripeOut,
        BOOL                               isLTMDCOnlyOPE);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// ~OPEStripingInterface
    ///
    /// @brief  Destructor
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ~OPEStripingInterface();

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// OPEStripingInterface
    ///
    /// @brief  Constructor
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    OPEStripingInterface();

private:

    VOID*     s_pOPEStripeOut;                                                   ///< Struct for OPE Passout
    OPEStripingInterface(const OPEStripingInterface&) = delete;                  ///< Disallow the copy constructor
    OPEStripingInterface& operator=(const OPEStripingInterface&) = delete;       ///< Disallow assignment operator
};

#ifdef __cplusplus
extern "C" {
#endif    // end of _cplusplus

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// OpeStripingLibraryInitializeInterface
///
/// @brief  Initailize striping Interface
///
/// @return OPEStripingInterface
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
CAMX_VISIBILITY_PUBLIC VOID* OpeStripingLibraryInitializeInterface();

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// OpeStripingLibraryDeleteInterface
///
/// @brief  Delete striping Interface
///
/// @param  pObj   Object to Striping Interface
///
/// @return None
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
CAMX_VISIBILITY_PUBLIC VOID OpeStripingLibraryDeleteInterface(
    VOID* pObj);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// OpeStripingLibraryExecuteInterface
///
/// @brief  OpeStripingLibraryExecuteInterface This API returns the Striping Output
///
/// @param  pStripingInput           Striping Input
/// @param  pStripingInputPerFrame   Striping Output
/// @param  pNodeObj                 Striping Interface object
///
/// @return UINT32
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
CAMX_VISIBILITY_PUBLIC UINT32 OpeStripingLibraryExecuteInterface(
    OPEStripeInterfaceInput*           pStripingInput,
    OPEStripeInterfaceOutputPerFrame*  pStripingOutputPerFrame,
    VOID*                              pNodeObj);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// OpeStripingLibraryReleaseStripeOutputInterface
///
/// @brief  Release Memory allocated
///
/// @param  pNodeObj                 Striping Interface object
/// @return None
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
CAMX_VISIBILITY_PUBLIC VOID OpeStripingLibraryReleaseStripeOutputInterface(
    VOID*                  pNodeObj);


// function pointer definition for initializing striping interface.
typedef VOID*(*OpeStripingLibraryInitialize_t)();

// function pointer definition for releasing striping interface object
typedef VOID(*OpeStripingLibraryDelete_t)(
    VOID* pObj);

// function pointer definition for OPE striping library context execute
typedef uint32_t(*OpeStripingLibraryExecute_t)(OPEStripeInterfaceInput* pStripingInput,
                OPEStripeInterfaceOutputPerFrame* pStripingOutputPerFrame,
                VOID* pNodeObj);

// function pointer definition for releasing OPE striping library per stripe output
typedef VOID(*OpeStripingLibraryReleaseStripeOutput_t)(
    VOID* pNodeObj);

#ifdef __cplusplus
}
#endif    // end of _cplusplus

CAMX_NAMESPACE_END

#endif /* _CAMXOPESTRIPINGINTERFACE_H_ */
