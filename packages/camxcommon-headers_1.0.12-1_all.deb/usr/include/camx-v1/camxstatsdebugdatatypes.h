////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2017-2021 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @file  camxstatsdebugdatatypes.h
/// @brief Debug data types class declarations
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef CAMXSTATSDEBUGDATATYPES_H
#define CAMXSTATSDEBUGDATATYPES_H

#include "camxincs.h"

// Divide the 2-byte TypeID space into sectors, each allowing 256 types.
// This is merely a guideline; developers need not strictly adhere to this size.
#define TAGTYPE_SECTOR_SIZE         0x100
#define TAGTYPE_BASIC_MAX           0x40
#define TAGTYPE_AEC_MAX             (TAGTYPE_BASIC_MAX + (TAGTYPE_SECTOR_SIZE * 1))
#define TAGTYPE_AWB_MAX             (TAGTYPE_BASIC_MAX + (TAGTYPE_SECTOR_SIZE * 2))
#define TAGTYPE_AF_MAX              (TAGTYPE_BASIC_MAX + (TAGTYPE_SECTOR_SIZE * 3))
#define TAGTYPE_ASD_MAX             (TAGTYPE_BASIC_MAX + (TAGTYPE_SECTOR_SIZE * 4))
#define TAGTYPE_AFD_MAX             (TAGTYPE_BASIC_MAX + (TAGTYPE_SECTOR_SIZE * 5))
#define TAGTYPE_TUNING_MAX          (TAGTYPE_BASIC_MAX + (TAGTYPE_SECTOR_SIZE * 6))
#define TAGTYPE_CONCISE_AEC_MAX     (TAGTYPE_BASIC_MAX + (TAGTYPE_SECTOR_SIZE * 7))
#define TAGTYPE_CONCISE_AWB_MAX     (TAGTYPE_BASIC_MAX + (TAGTYPE_SECTOR_SIZE * 8))
#define TAGTYPE_CONCISE_AF_MAX      (TAGTYPE_BASIC_MAX + (TAGTYPE_SECTOR_SIZE * 9))
#define TAGTYPE_TFE_OPE_MAX         (TAGTYPE_BASIC_MAX + (TAGTYPE_SECTOR_SIZE * 10))
#define TAGTYPE_SWNODE_MAX          (TAGTYPE_BASIC_MAX + (TAGTYPE_SECTOR_SIZE * 11))
#define TAGTYPE_RESERVED_START      (TAGTYPE_SECTOR_SIZE * 254)
#define TAGTYPE_RESERVED_MAX        ((TAGTYPE_SECTOR_SIZE * 255) - 1)
#define TAGTYPE_OEM_START           (TAGTYPE_SECTOR_SIZE * 255)
#define TAGTYPE_OEM_MAX             (TAGTYPE_BASIC_MAX + (TAGTYPE_SECTOR_SIZE * 255)) // This is the limit for 2-bytes


// Divide the 2-byte TagID space into sectors, each allowing 512 tags.
// This should allow for a maximum of 128 sectors. Note that there is no requirement to strictly adhere to this guideline; so
// one could have TagID spaces much smaller or larger than this size defined here.
// Disclaimer: existing size definitions determine the start of the subsequent TagID space - and as such anything that is
// already released cannot be modified. Below sizes can therefore not change without adding necessary placeholders to ensure
// enum values stay constant across releases.
#define TAGID_SECTOR_SIZE           0x200
#define TAGID_BUILTIN_MAX           0x40
#define TAGID_AEC_MAX               (TAGID_BUILTIN_MAX + (TAGID_SECTOR_SIZE * 1))
#define TAGID_AWB_MAX               (TAGID_BUILTIN_MAX + (TAGID_SECTOR_SIZE * 2))
#define TAGID_AF_MAX                (TAGID_BUILTIN_MAX + (TAGID_SECTOR_SIZE * 3))
#define TAGID_ASD_MAX               (TAGID_BUILTIN_MAX + (TAGID_SECTOR_SIZE * 4))
#define TAGID_AFD_MAX               (TAGID_BUILTIN_MAX + (TAGID_SECTOR_SIZE * 5))
#define TAGID_TUNING_MAX            (TAGID_BUILTIN_MAX + (TAGID_SECTOR_SIZE * 6))
#define TAGID_CONCISE_AEC_MAX       (TAGID_BUILTIN_MAX + (TAGID_SECTOR_SIZE * 7))
#define TAGID_CONCISE_AWB_MAX       (TAGID_BUILTIN_MAX + (TAGID_SECTOR_SIZE * 8))
#define TAGID_CONCISE_AF_MAX        (TAGID_BUILTIN_MAX + (TAGID_SECTOR_SIZE * 9))
#define TAGID_TFE_OPE_MAX           (TAGID_BUILTIN_MAX + (TAGID_SECTOR_SIZE * 10))
#define TAGID_SWNODE_MAX            (TAGID_BUILTIN_MAX + (TAGID_SECTOR_SIZE * 11))
#define TAGID_OEM_START             (TAGID_SECTOR_SIZE * 127)
#define TAGID_OEM_MAX               (TAGID_BUILTIN_MAX + (TAGID_SECTOR_SIZE * 127))

CAMX_BEGIN_PACKED

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// NOTE: It must be enforced that new tags only get added to the bottom of this enum of each reserved section.
/// Aka add the new definition right above the "XXX  tag IDs - END". ID values which already exist must not change.
/// tag values should be hard coded and guaranteed to never change
//      so eliminate user error by hard coding values
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

///< @brief Defines the type of IDs for the debug data tag
///  NOTE: The values defined in this enum MUST NOT change! If an ID is being deprecated - developers can rename the ID to
///        to indicate that it is deprecated - but should not remove it.
enum class DebugDataTagID : UINT16
{
    UnusedSpace                         = 0,                            ///< Unused space in debug data buffer
    ReservedBasic                       = TAGID_BUILTIN_MAX,            ///< Reserved above can only be used as basic type definition

    // AEC tag IDs - START
    AECConfiguration,
    AECFrameHistory,
    AECModeHistory,
    AECMetering,
    AECConvergence,
    AECArbitration,
    AECExtension,
    AECStatsLumaRegion,
    AECExtremeColor,
    AECHistogram,
    AECLEDTable,
    AECFlash,
    AECBGProcResult,
    AECBHistProcResult,
    AECBayerStats,
    AECBayerHistogram,
    AECAlgorithmVersion,
    // AECX tag IDs - START
    AECXContext,
    AECXFrameHistory,
    AECXMetering,
    AECXConvergence,
    AECXArbitration,
    AECXExtension,
    AECXLEDTable,
    AECXFlash,
    AECXStats,
    AECXPrecisionFlah,
    AECXAlgorithmVersion,
    AECXNZSLMetering,
    AECXNZSLArbitration,
    AECTagIDMax                         = TAGID_AEC_MAX,
    // AEC tag IDs - END

    // AWB tag IDs - START
    AWBSetParam,                        ///< Deprecated
    AWBReferencePoints,
    AWBMWBGains,
    AWBCurFrameDecision,
    AWBPreFrameDecision,
    AWBPreValidDAPoint,
    AWBPreValidGA,
    AWBFrameIndex,
    AWBLuxIndex,
    AWBSubSampleData,
    AWBStatsScreenData,
    AWBIlluWeightVector,
    AWBDistWeightVector,
    AWBCustRefPoint,
    AWBMLCZData,
    AWBAGWData,
    AWBSAGen1InstanceCnt,
    AWBSAGen1Data,
    AWBSAFaceAssist,
    AWBDecisionAggregator,
    AWBTrigleGainAdjust,
    AWBTemporalConverg,
    AWBDSFData,
    AWBSensorCallibration,
    AWBHistoryInfo,
    AWBFlashData,
    AWBStatsInfo,
    AWBBestShotData,
    AWBLockAWBPoint,
    AWBLCDFlashData,
    AWBLEDTorchData,
    AWBBGStats,
    AWBSADualcamSync,
    AWBSCBasedConverge,
    AWBExternalInfo,
    AWBCustomizedSAInfo,
    AWBMLCZ2Data,
    AWBSAGen2InstanceCnt,
    AWBSAGen2Data,
    AWBGlobalEnvData,
    AWBGeneralWeightVector,
    AWBMLCZ3Data,
    AWBSpectralSensorAssistWeightVector,
    AWBAlgorithmVersion,
    AWBTagIDMax                         = TAGID_AWB_MAX,
    // AWB tag IDs - END

    // AF tag IDs - START
    AFFarEnd,
    AFNearEnd,
    AFFocalLength,
    AFFocalNumber,
    AFPixelSize,
    AFFocusDistance,
    AFActuatorSensitivity,
    AFCamifWidth,
    AFCamifHeight,
    AFActuator,
    AFConfigFrameId,
    AFGammaTableEnable,
    AFGammaTableLength,
    AFGammaTableContent,
    AFHorizontalKernel,
    AFVerticalKernel,
    AFSoftwareKernel,
    AFRoiInfo,
    AFRoiPattern,
    AFRoiGridSizeH,
    AFRoiGridSizeV,
    AFRoiGridGapH,
    AFRoiGridGapV,
    AFInputSel,
    AFGreenChannelSel,
    AFYChannelWeight,
    AFScaleEnable,
    AFScaleM,
    AFScaleN,
    AFCurrentMonitorIndex,
    AFMonitorHistorySize,
    AFActiveMonMask,
    AFMonitorCommonData,
    AFMonitorCAF,
    AFMonitorPDAF,
    AFMonitorTOF,
    AFCurrentConvergeIndex,
    AFConvergeHistorySize,
    AFActiveAlgoMask,
    AFConvergeCommonData,
    AFConvergeSingleAFData,
    AFConvergeCafFineScanData,
    AFConvergeTofData,
    AFConvergePDData,
    AFConvergeFollowerData,
    AFAlgorithmVersion,
    PDLibVersion,
    AFTagIDMax                          = TAGID_AF_MAX,
    // AF tag IDs - END

    // ASD tag IDs - START
    ASDTagIDMax                         = TAGID_ASD_MAX,
    // ASD tag IDs - END

    // AFD tag IDs - START
    AFDAlgorithmVersion,
    AFDSummaryData,
    AFDRowSumStatsData,
    AFDDataFromAECAF,
    AFDLegacyRollingData,
    AFDLegacyStaticData,
    AFDCorrelationRollingData,
    AFDCorrelationStaticData,
    AFDRowSumStatInfo,
    AFDDifferenceStatInfo,
    AFDStaticCorrelationStepInfo,
    AFDStaticEnergyRatio,
    AFDStaticAbsEnergy,
    AFDTagIDMax                         = TAGID_AFD_MAX,
    // AFD tag IDs - END

    // Tuning tag IDs - START
    TuningAECData,
    TuningAWBData,
    TuningSensorPixelFormat,
    TuningSensorNumPixelsPerLine,
    TuningSensorNumLinesPerFrame,
    TuningSensorMaxLineCount,
    TuningSensorResoultion,
    TuningSensorCropInfo,
    TuningBinningTypeH,
    TuningBinningTypeV,
    TuningIFEGamma16PackedLUT,
    TuningIFEGTM10PackedLUT,
    TuningIFELSC34PackedMesh,
    TuningBPSPedestalRegister,
    TuningBPSPedestalPackedLUT,
    TuningBPSLinearizationRegister,
    TuningBPSLinearizationPackedLUT,
    TuningBPSBPCPDPC20Register,
    TuningBPSBPCPDPC20PackedLUT,
    TuningBPSHDR22Register,
    TuningBPSGICRegister,
    TuningBPSGICPackedNoiseLUT,
    TuningBPSABFRegister,
    TuningBPSABFPackedLUT,
    TuningBPSLSC34Register,
    TuningBPSLSC34PackedMesh,
    TuningBPSWBRegister,
    TuningBPSDemosaicRegister,
    TuningBPSDemuxRegister,
    TuningBPSCCRegister,
    TuningBPSGTMPackedLUT,
    TuningBPSGammaLUT,
    TuningBPSCST12Register,
    TuningBPSHNR10Register,
    TuningBPSHNR10PackedLUT,
    TuningIPEGamma15PackedLUT,
    TuningBPSModulesConfigRegister,             ///< Deprecated
    TuningBPSTriggerModulesData,
    TuningBPSensorConfigData,
    TuningIPEGamma15PackedLUTOffline,
    TuningIPEModulesConfigRegister,             ///< Deprecated
    TuningIPEModulesConfigRegisterOffline,      ///< Deprecated
    TuningIPEICA10InputPackedLUT,
    TuningIPEICA10InputPackedLUTOffline,
    TuningIPEICA10ReferencePackedLUT,
    TuningIPEICA10ReferencePackedLUTOffline,
    TuningIPEANR10Register,
    TuningIPEANR10RegisterOffline,
    TuningIPETF10Register,
    TuningIPETF10RegisterOffline,
    TuningIPECAC2xRegister,
    TuningIPECAC2xRegisterOffline,
    TuningIPECST12Register,
    TuningIPECST12RegisterOffline,
    TuningIPELTM13PackedLUT,
    TuningIPELTM13PackedLUTOffline,
    TuningIPECC13Register,
    TuningIPECC13RegisterOffline,
    TuningIPE2DLUT10Register,
    TuningIPE2DLUT10RegisterOffline,
    TuningIPE2DLUT10PackedLUT,
    TuningIPE2DLUT10PackedLUTOffline,
    TuningIPEChromaEnhancement12Register,
    TuningIPEChromaEnhancement12RegisterOffline,
    TuningIPEChromasuppression20Register,
    TuningIPEChromasuppression20RegisterOffline,
    TuningIPESCE11Register,
    TuningIPESCE11RegisterOffline,
    TuningIPEASFRegister,                      ///< Deprecated
    TuningIPEASFRegisterOffline,               ///< Deprecated
    TuningIPEASF30PackedLUT,
    TuningIPEASF30PackedLUTOffline,
    TuningIPEUpscaler20PackedLUT,
    TuningIPEUpscaler20PackedLUTOffline,
    TuningIPEGrainAdder10PackedLUT,
    TuningIPEGrainAdder10PackedLUTOffline,
    TuningBPSHNRFace,
    TuningIPEASFFace,
    TuningIPEASFFaceOffline,
    TuningIPEANRFace,
    TuningIPEANRFaceOffline,
    TuningIPELTMExposureIndex,
    TuningIPELTMExposureIndexOffline,
    TuningBPSExposureGainRatio,
    TuningBPSNodeInfo,
    TuningIPENodeInfo,
    TuningIPENodeInfoOffline,
    TuningIPETuningMode,
    TuningIPETuningModeOffline,
    TuningIPEModulesConfigRegisterV1,          ///< Deprecated
    TuningIPEModulesConfigRegisterOfflineV1,   ///< Deprecated
    TuningIFEModuleEnableConfig,
    TuningIFETriggerModulesData,
    TuningIFEHDR2xRegister,
    TuningIFESensorConfigData,
    TuningBPSBPCPDPC30PackedLUT,
    TuningBPSBPCPDPC30Register,
    TuningBPSHDR30Register,
    TuningBPSLSC40Register,
    TuningBPSLSC40PackedMesh,
    TuningIPEHNR10RegisterOffline,
    TuningIPEHNR10PackedLUTOffline,
    TuningIPEHNRFaceOffline,
    TuningBPSFirmwareHeader,
    TuningBPSChipsetVersion,
    TuningIFELSC34Register,
    TuningIFELSC40Register,
    TuningIFELSC40PackedMesh,
    TuningIFEGamma16Register17x,
    TuningIFEGamma16Register480,
    TuningIFEGTM10Register17x,
    TuningIFEGTM10Register480,
    TuningIFEHDR30Register,
    TuningIPEHNR10Register,
    TuningIPEHNR10PackedLUT,
    TuningIPEHNRFace,
    TuningIPEICA30InputPackedLUT,
    TuningIPEICA30InputPackedLUTOffline,
    TuningIPEICA30ReferencePackedLUT,
    TuningIPEICA30ReferencePackedLUTOffline,
    TuningIPELENR10Register,
    TuningIPELENR10RegisterOffline,
    TuningIPELENRFace,
    TuningIPELENRFaceOffline,
    TuningIPELTM14PackedLUT,
    TuningIPELTM14PackedLUTOffline,
    TuningIPETF20Register,
    TuningIPETF20RegisterOffline,
    TuningIPEASF30Register,
    TuningIPEASF30RegisterOffline,
    TuningIPEFirmwareHeader,
    TuningIPEFirmwareHeaderOffline,
    TuningIPEChipsetVersion,
    TuningIPETriggerModulesData,
    TuningIPETriggerModulesDataOffline,
    TuningMultiFrameNumOfFrames,
    TuningIHDRSensor,
    TuningTMCTrigger,
    TuningDSX10Register,
    TuningDSX10RegisterOffline,
    TuningDSX10PackedLUT,
    TuningDSX10PackedLUTOffline,
    TuningMFHDRGamma16PackedLUT,
    TuningMFHDRGamma16PackedLUTOffline,
    TuningMFHDRCST0Register,
    TuningMFHDRCST0RegisterOffline,
    TuningMFHDRCST1Register,
    TuningMFHDRCST1RegisterOffline,
    TuningMFHDRCST2Register,
    TuningMFHDRCST2RegisterOffline,
    TuningMFHDRCST3Register,
    TuningMFHDRCST3RegisterOffline,
    TuningMFHDRMAC10Register,
    TuningMFHDRMAC10RegisterOffline,
    TuningMFHDRMAC10PackedLUT,
    TuningMFHDRMAC10PackedLUTOffline,
    TuningMFHDRGTM13PackedLUT,
    TuningMFHDRGTM13PackedLUTOffline,
    TuningMFHDRGTM13Register,
    TuningMFHDRGTM13RegisterOffline,
    TuningLTM16PackedLUT,
    TuningLTM16PackedLUTOffline,
    TuningMFHDRLTM16Register,
    TuningMFHDRLTM16RegisterOffline,
    TuningIFENodeInfo,
    TuningMFHDRTintlessBGShort,
    TuningMFHDRTintlessBGMedium,
    TuningMFHDRTintlessBGLong,
    TuningMFHDRBHistShort,
    TuningMFHDRBHistMedium,
    TuningMFHDRBHistLong,
    TuningSnapshotFrameExpType,
    TuningTagIDMax                      = TAGID_TUNING_MAX,
    // Tuning tag IDs - END

    // Concise AEC tag IDs - START
    ConciseAECTagIDMax                  = TAGID_CONCISE_AEC_MAX,
    // Concise AEC tag IDs - END

    // Concise AWB tag IDs - START
    ConciseAWBTagIDMax                  = TAGID_CONCISE_AWB_MAX,
    // Concise AWB tag IDs - END

    // Concise AF IDs - START
    ConciseAFTagIDMax                   = TAGID_CONCISE_AF_MAX,
    // Concise AF tag IDs - END

    // TFE/OPE tag IDs - START
    TuningTFEDemux14Register,
    TuningTFELSC35Register,
    TuningTFELSC35PackedMesh,
    TuningTFEWBBDS10Register,
    TuningOPEBPCABF41Register,
    TuningOPEBPCABF41RegisterOffline,
    TuningOPEBLS12Register,
    TuningOPEBLS12RegisterOffline,
    TuningOPEDemosaic36Register,
    TuningOPEDemosaic36RegisterOffline,
    TuningOPECC13Register,
    TuningOPECC13RegisterOffline,
    TuningOPEBPCABF41PackedLUT,
    TuningOPEBPCABF41PackedLUTOffline,
    TuningOPEGTM12PackedLUT,
    TuningOPEGTM12PackedLUTOffline,
    TuningOPELTM15PackedLUT,
    TuningOPELTM15PackedLUTOffline,
    TuningOPEGamma15PackedLUT,
    TuningOPEGamma15PackedLUTOffline,
    TuningOPEASF32PackedLUT,
    TuningOPEASF32PackedLUTOffline,
    TuningOPECSMCE11Register,
    TuningOPECSMCE11RegisterOffline,
    TuningOPEChromaEnhancement12Register,
    TuningOPEChromaEnhancement12RegisterOffline,
    TuningOPESCE11Register,
    TuningOPESCE11RegisterOffline,
    TuningOPEWNR24Register,
    TuningOPEWNR24RegisterOffline,
    TuningOPEASF32Register,
    TuningOPEASF32RegisterOffline,
    TuningOPEUpscaler13Register,
    TuningOPEUpscaler13RegisterOffline,
    TuningOPEWB14Register,
    TuningOPEWB14RegisterOffline,
    TuningOPEGTM12Register,
    TuningOPEGTM12RegisterOffline,
    TuningOPELTM15Register,
    TuningOPELTM15RegisterOffline,
    TuningGamma15Register,
    TuningGamma15RegisterOffline,
    TuningOPECST12Register,
    TuningOPECST12RegisterOffline,
    TuningTFETriggerModulesData,
    TuningTFESensorConfigData,
    TuningOPETuningMode,
    TuningOPETuningModeOffline,
    TuningOPETriggerModulesData,
    TuningOPETriggerModulesDataOffline,
    TuningOPEChipsetVersion,
    TuningOPEDEMUX14Register,
    TuningOPEDEMUX14RegisterOffline,
    TuningOPELSC35Register,
    TuningOPELSC35RegisterOffline,
    TuningOPELSC35PackedLUT,
    TuningOPELSC35PackedLUTOffline,

    TFEOPETagIDMax                      = TAGID_TFE_OPE_MAX,
    // TFE/OPE tag IDs - END

    // Chi Node tag Ids -Start
    TuningSWLSC35Data,
    TuningDemuxData,
    TuningSWFusionMFHDRConfigData,
    TuningSWFusionRunTimeParams,
    TuningSWECConfigData                = TAGID_SWNODE_MAX,

    TuningOEMStart                      = TAGID_OEM_START,
    TuningBPSOEMTuningData              = TuningOEMStart,
    TuningIFEOEMTuningData,
    TuningTFEOEMTuningData,
    TuningOEMTagIDMax                   = TAGID_OEM_MAX,
};

///< @brief Defines the type of the debug data tag
///  NOTE: The values defined in this enum MUST NOT change! If an ID is being deprecated - developers can rename the ID to
///        to indicate that it is deprecated - but should not remove it.
enum class DebugDataTagType : UINT16
{
    TypeDefinition                      = 1,                            ///< Payload: DebugDataTag + list of TypedefFieldInfo
    Char,
    Bool,
    UInt8,
    UInt16,
    UInt32,
    UInt64,
    UQNumber,                                                           ///< Payload: DebugDataUQNumber
    URational,                                                          ///< Payload: DebugDataURational
    Int8,
    Int16,
    Int32,
    Int64,
    QNumber,                                                            ///< Payload: DebugDataQNumber
    Rational,                                                           ///< Payload: DebugDataRational
    Float,
    Double,
    TwoDimArray,                                                        ///< Payload: DebugData2DArrayHeader + array data
    EndBasicTypes                       = TAGTYPE_BASIC_MAX,            ///< Reserve up to this number for basic types

    // Custom (non-basic) types - START
    CustomStart                         = EndBasicTypes,                ///< custom (non-basic) type
    // AEC Custom (non-basic) types - START
    AECTypeBegin,
    AECROIDim                           = AECTypeBegin,
    AECConfiguration,
    AECFrameHistory,
    AECModeHistory,
    AECMetering,
    AECConvergence,
    AECArbitration,
    AECExtension,
    AECStatsLumaRegion,
    AECExtremeColor,
    AECHistogram,
    AECLEDSetting,
    AECLEDTable,
    AECFlash,
    AECBGProcInfo,
    AECParsedBGRegionType,
    AECParsedLegacyYRegionType,
    AECBGProcResult,
    AECBHistProcInfo,
    AECBHistProcResult,                 ///< Deprecated
    AECBayerChannel,
    AECStatsRectangle,
    AECBayerStats,
    AECHistogramChannel,
    AECHistogramStats,
    AECBHistProcResultV1,
    AECAlgoVersion,
    // ------------------- AECX tags -------------------
    AECXTypeBegin = 0x81,
    AECXROIDim = AECXTypeBegin,
    AECXContext,
    AECXFrameHistory,
    AECXMetering,
    AECXConvergence,
    AECXArbitration,
    AECXExtension,
    AECXLEDSetting,
    AECXLEDTable,
    AECXFlash,
    AECXStatsROIInfo,
    AECXStatsResolution,
    AECXStatsChInfo,
    AECXStatsChList,
    AECXStats,
    AECXStatsRectangle,
    AECXOneArbitration,
    AECXConvHistory,
    AECXExpRngType,
    AECXROIInfo,
    AECXManualSetting,
    AECXAWBState,
    AECXOverrideSetting,
    AECXSensorInfo,
    AECXCameraInfo,
    AECXInputConfig,
    AECXGeneralSAType,
    AECXGeneralSCType,
    AECXSAComponentType,
    AECXSAArithOpType,
    AECXDataBankType,
    AECXStartEndType,
    AECXExposureSetType,
    AECXExposureInfoType,
    AECXFrameHistoryInfoType,
    AECX3HDRSnapShot,
    AECXPrecisionFlash,
    AECXAlgoVersion,
    AECXNZSLMetering,
    AECXNZSLArbitration,
    AECTypeEnd = AECXNZSLArbitration,
    AECTypeMax = TAGTYPE_AEC_MAX,
    // AEC Custom (non-basic) types - END

    // AWB Custom (non-basic) types - START
    AWBTypeBegin,
    AWBPoint                            = AWBTypeBegin,
    AWBZone,
    AWBZonePData,
    AWBDecisionPData,
    AWBModulePData,
    AWBGains,
    AWBTriggerPoint,
    AWBTriggerFloatData,
    AWBStatsRectangle,
    AWBTriggerNonLastLevelPData,
    AWBcustRefPt,
    AWBSATargetPData,
    AWBSAConfidencePData,
    AWBSFSubSmpPData,
    AWBSFStatsScrPData,
    AWBSFIlluWVPData,
    AWBSFDistWVPData,
    AWBSFCustRefPtPData,
    AWBSFMLCZPData,
    AWBSAAGWPData,
    AWBDASAData,
    AWBFaceAssistSAPData,
    AWBDAPData,
    AWBTriglGAPData,
    AWBTmpConvPData,
    AWBDSFPData,
    AWBSensorCalPData,
    AWBSAGen1PData,
    AWBHistPData,
    AWBFlashPData,
    AWBStatInfo,
    AWBStatPData,
    AWBBestShotPData,
    AWBSpecIlluPData,
    AWBLCDFlashPData,
    AWBLEDTorchPData,
    AWBStatsSensorInfo,                 ///< Deprecated
    AWBStatsWindowInfo,                 ///< Deprecated
    AWBIlluminatFactor,                 ///< Deprecated
    AWBIlluminantsCalibrationFactor,    ///< Deprecated
    AWBGeometricalDisparityCalibration, ///< Deprecated
    AWBStatsLEDCalibrationDataInput,    ///< Deprecated
    AWBManualConfiguration,             ///< Deprecated
    AWBStatsFaceData,                   ///< Deprecated
    AWBStatsFaceHistogram,              ///< Deprecated
    AWBStatsFaceInformation,            ///< Deprecated
    AWBProcessTrigGain,
    AWBFlashInformation,                ///< Deprecated
    AWBSetParamInfo,                    ///< Deprecated
    AWBSFDistWVPTrigger2D,
    AWBBGChannelData,
    AWBBGStatsData,
    AWBSADualcamSyncPData,
    AWBSCBasedConvergeData,
    AWBExternalInfo,
    AWBCustomizedSAInfo,
    AWBWeightedZone,
    AWBWeightedZonePData,
    AWBSFMLCZV2PData,
    AWBSAGen2PData,
    AWBGlobalEnvPData,
    AWBSFGenWVPTrigger2D,
    AWBSFGenWVPData,
    AWBWeightedZonePDataV2,
    AWBSFMLCZV3PData,
    AWBGenWVPData,
    AWBSFSpectralSensorAssistWVPData,
    AWBAlgoVersion,
    AWBFaceStatsCntData,
    AWBFaceStatsROI,
    AWBFaceStatInfo,
    AWBFaceStatFilterData,
    AWBFaceRefIlluCCT,
    AWBFaceRefIlluResults,
    AWBTypeEnd                          = AWBFaceRefIlluResults,
    AWBTypeMax                          = TAGTYPE_AWB_MAX,
    // AWB Custom (non-basic) types - END

    // AF Custom (non-basic) types - START
    AFTypeBegin,
    AFROIInfo                           = AFTypeBegin,
    AFCommonHistory,
    AFConvergeCommon,
    AFSingleAFHistory,
    AFSingleAFData,
    AFCAFFineScanHistory,
    AFCAFFineScanData,
    AFTOFHistory,
    AFTimeOfFlight,
    AFPDData,
    AFPDHistory,
    AFPhaseDifference,
    AFFollower,
    AFMonitorCommon,
    AFValueMonitorData,
    AFMonitorCAF,
    AFMonitorPDAF,
    AFMonitorTOF,
    AFGammaTable,
    AFFocusROI,
    AFFIRFilter,
    AFIIRFilter,
    AFCoringInfo,
    AFFilterKernel,
    AFSWKernel,
    AFAlgoVersion,
    PDLibMajorVersion,
    AFTypeEnd                           = PDLibMajorVersion,
    AFTypeMax                           = TAGTYPE_AF_MAX,
    // AF Custom (non-basic) types - END

    // ASD Custom (non-basic) types - START
    ASDTypeBegin,
    ASDTypeEnd,
    ASDTypeMax                          = TAGTYPE_ASD_MAX,
    // ASD Custom (non-basic) types - END

    // AFD Custom (non-basic) types - START
    AFDTypeBegin,
    AFDAlgoVersion                      = AFDTypeBegin,
    AFDSummary,
    AFDStatInfo,
    AFDDiffStatInfo,
    AFDRowSumStatsInfo,
    AFDAFLensPosInfoData,
    AFDAFLensMoveTypeData,
    AFDAFLogicalLensMoveInfoData,
    AFDACLensMoveInfoData,
    AFDAECAFData,
    AFDDefaultRollingData,
    AFDStaticEnergyRatio,
    AFDStaticAbsEnergy,
    AFDDefaultStaticData,
    AFDCorrelationRollingData,
    AFDStaticCorrStepInfo,
    AFDCorrelationStaticData,
    AFDTypeEnd                          = AFDCorrelationStaticData,
    AFDTypeMax                          = TAGTYPE_AFD_MAX,
    // AFD Custom (non-basic) types - END

    // Tuning metadata custom - START
    TuningTypeBegin,
    TuningAECExposureData               = TuningTypeBegin,
    TuningAECFrameControl,
    TuningAWBFrameControl,
    TuningSensorResolution,
    TuningSensorCropInfo,
    TuningLSC34MeshLUT,
    TuningGammaCurve,
    TuningGTMLUT,
    TuningPedestalLUT,
    TuningBPSBPCPDPC20Config,
    TuningBPSHDR22Config,
    TuningABFLUT,
    TuningHNR10LUT,
    TuningBPSTriggerData,
    TuningBPSSensorConfig,
    TuningICA10LUT,
    TuningANR10Config,
    TuningTF10Config,
    TuningLTM13LUT,
    Tuning2DLUT10LUT,
    TuningASF30LUT,
    TuningUpscaler20LUT,
    TuningGrainAdder10LUT,
    TuningFaceData,
    TuningIPEGamma15Curve,
    TuningIQNodeInfo,
    TuningModeInfo,
    TuningIFEEnableConfig,
    TuningIFETriggerData,
    TuningIFE2xHDR,
    TuningIFESensorConfig,
    TuningBPSBPCPDPC30LUT,
    TuningBPSBPCPDPC30Config,
    TuningLSC40MeshLUT,
    TuningBPSFirmwareHeader,
    TuningIFELSC40Config,
    TuningIFE30HDR,
    TuningICA30LUT,
    TuningLTM14LUT,
    TuningTF20Config,
    TuningIPEFirmwareHeader,
    TuningIPETriggerData,
    // Header version 1 - basic types
    DebugDataHeaderV1,                                                  ///< Payload: DebugDataHeaderV1 only
    H1Char,                                                             ///< Payload: DebugDataHeaderV1 + base type
    H1Bool,                                                             ///< Payload: DebugDataHeaderV1 + base type
    H1UInt8,                                                            ///< Payload: DebugDataHeaderV1 + base type
    H1UInt16,                                                           ///< Payload: DebugDataHeaderV1 + base type
    H1UInt32,                                                           ///< Payload: DebugDataHeaderV1 + base type
    H1UInt64,                                                           ///< Payload: DebugDataHeaderV1 + base type
    H1UQNumber,                                                         ///< Payload: DebugDataHeaderV1 + DebugDataUQNumber
    H1URational,                                                        ///< Payload: DebugDataHeaderV1 + DebugDataURational
    H1Int8,                                                             ///< Payload: DebugDataHeaderV1 + base type
    H1Int16,                                                            ///< Payload: DebugDataHeaderV1 + base type
    H1Int32,                                                            ///< Payload: DebugDataHeaderV1 + base type
    H1Int64,                                                            ///< Payload: DebugDataHeaderV1 + base type
    H1QNumber,                                                          ///< Payload: DebugDataHeaderV1 + DebugDataQNumber
    H1Rational,                                                         ///< Payload: DebugDataHeaderV1 + DebugDataRational
    H1Float,                                                            ///< Payload: DebugDataHeaderV1 + base type
    H1Double,                                                           ///< Payload: DebugDataHeaderV1 + base type
    // End-of-header version 1 basic types
    TuningTMCTriggerData,
    TuningDSX10LUT,
    TuningDSX10Data,
    TuningGamma16Curve,
    TuningMFHDRMACLUT,
    TuningMFHDRGTMLUT,
    TuningMFHDRGTMData,
    TuningLTM16LUT,
    TuningBHistConfig,
    TuningBHistStatsConfig,
    TuningRectangleCoordinate,
    TuningBGBEConfig,
    TuningBHistStatsOutput,
    TuningTintlessBGStatsConfig,
    TuningTintlessBGStatsOutput,
    TuningBHistStatsOutputHeader,
    TuningTintlessBGStatsOutputHeader,
    TuningHDRBEChannelData,
    TuningMFHDRCSTTuningMetadataHeader,
    TuningMFHDRMACTuningMetadataHeader,
    TuningDSX10LUTHeader,
    TuningTypeEnd                       = TuningDSX10LUTHeader,
    TuningTypeMax                       = TAGTYPE_TUNING_MAX,
    // Tuning metadata custom - END

    // Concise AEC Custom (non-basic) types for concise - Start
    ConciseAECTypeBegin,
    ConciseAECTypeEnd,
    ConciseAECTypeMax = TAGTYPE_CONCISE_AEC_MAX,
    // Concise AEC Custom (non-basic) types for concise - END

    // Concise AWB Custom (non-basic) types for concise - Start
    ConciseAWBTypeBegin,
    ConciseAWBTypeEnd,
    ConciseAWBTypeMax = TAGTYPE_CONCISE_AWB_MAX,
    // Concise AWB Custom (non-basic) types for concise - END

    // Concise AF Custom (non-basic) types for concise - Start
    ConciseAFTypeBegin,
    ConciseAFTypeEnd,
    ConciseAFTypeMax = TAGTYPE_CONCISE_AF_MAX,
    // Concise AF Custom (non-basic) types for concise - END

    // TFE/OPE metadata custom - START
    TuningTFEOPETypeBegin,
    TuningTFELSC35MeshLUT               = TuningTFEOPETypeBegin,
    TuningTFEDemux14Config,
    TuningTFEWBBDSDPC10Config,
    TuningTFELSC35Config,
    TuningOPEBPCABF41LUT,
    TuningOPEGTM12LUT,
    TuningOPELTM15LUT,
    TuningOPEGamma15Curve,
    TuningOPEASF32LUT,
    TuningOPEBPCABF41Config,
    TuningOPEBLS12Config,
    TuningOPEDemosaic36Config,
    TuningOPECC13Config,
    TuningOPECE12Config,
    TuningOPESCE11Config,
    TuningOPEWNR24Config,
    TuningOPEASF32Config,
    TuningOPEUpscaler13Config,
    TuningOPEWB14Config,
    TuningOPEGTM12Config,
    TuningOPELTM15Config,
    TuningOPEGamma15Config,
    TuningOPECST12Config,
    TuningTFETriggerData,
    TuningTFESensorConfig,
    TuningOPEModeInfo,
    TuningOPETriggerData,
    TuningOPEDemux14Config,
    TuningOPELSC35LUT,
    TuningOPELSC35Config,
    TuningTFEOPETypeEnd                 = TuningOPELSC35Config,
    TFEOPETypeMax                       = TAGTYPE_TFE_OPE_MAX,
    // Tuning metadata custom - END

    // Chi Node tag types -Start
    TuningChiNodeTypeBegin,
    TuningDemuxData                     = TuningChiNodeTypeBegin,
    TuningSWLSC35Data,
    TuningSWFusionMFHDRConfigData,
    TuningSWFusionRunTimeParams,
    TuningSWECConfigData,
    TuningChiNodeTypeEnd                = TuningSWECConfigData,
    TuningChiNodeMax                    = TAGTYPE_SWNODE_MAX,

    // Reserved EOM (non-basic) types - START
    ReservedTypeMin                     = TAGTYPE_RESERVED_START,
    ReservedTypeMax                     = TAGTYPE_RESERVED_MAX,
    OEMBegin                            = TAGTYPE_OEM_START,
    // Reserved OEM (non-basic) types - END
    OEMEnd                              = TAGTYPE_OEM_MAX,
    // All metadata custom - END
    CustomEnd                           = TAGTYPE_OEM_MAX

};

///< @brief List of deprecated debug data tag types as defined in DebugDataTagType enum.
///         All deprecated tags must be listed here but remain in the DebugDataTagType enum to keep the order of existing tags
static DebugDataTagType DebugDataTagTypeDeprecated[] =
{
    DebugDataTagType::AWBStatsSensorInfo,
    DebugDataTagType::AWBStatsWindowInfo,
    DebugDataTagType::AWBIlluminatFactor,
    DebugDataTagType::AWBIlluminantsCalibrationFactor,
    DebugDataTagType::AWBGeometricalDisparityCalibration,
    DebugDataTagType::AWBStatsLEDCalibrationDataInput,
    DebugDataTagType::AWBManualConfiguration,
    DebugDataTagType::AWBStatsFaceData,
    DebugDataTagType::AWBStatsFaceHistogram,
    DebugDataTagType::AWBStatsFaceInformation,
    DebugDataTagType::AWBFlashInformation,
    DebugDataTagType::AWBSetParamInfo,
    DebugDataTagType::AECBHistProcResult,
};

///< @brief List of deprecated debug data tag IDs as defined in DebugDataTagID enum.
///         All deprecated tags must be listed here but remain in the DebugDataTagID enum to keep the order of existing tags
static DebugDataTagID DebugDataTagIDDeprecated[] =
{
    DebugDataTagID::AWBSetParam,
    DebugDataTagID::TuningIPEModulesConfigRegister,
    DebugDataTagID::TuningIPEModulesConfigRegisterOffline,
    DebugDataTagID::TuningBPSModulesConfigRegister,
    DebugDataTagID::TuningIPEASFRegister,
    DebugDataTagID::TuningIPEASFRegisterOffline,
    DebugDataTagID::TuningIPEModulesConfigRegisterV1,
    DebugDataTagID::TuningIPEModulesConfigRegisterOfflineV1,
};

///< @brief Pipeline identification number. It should never be remove any of the enumeration values. External parser depends on it.
enum class DebugDataPipelineID : UINT16
{
    IFE = 1,
    IPE,
    BPS,
    TFE,
    OPE,
};

typedef UINT32  TagCount;           ///< Data type representing the Debug Data tag count
typedef UINT16  TypedefFieldLen;    ///< Data type representing the Debug Data type-definition field length
typedef UINT8   TypedefFieldID;     ///< Data type representing the Debug Data type-definition field ID

///< @brief Encapsulates a debug data tag header without any payloads
struct DebugDataTag
{
    /// Unique ID that identifies this tag
    DebugDataTagID    id;
    /// Type of the data associated with this tag
    DebugDataTagType  type;
    /// Number of times the data appears (more than 1 indicates array,
    /// while 0 indicates no data at all). Size in bytes of data is
    /// determined by sizeof(tagType) * Count
    ///
    /// Special case: when the type is DebugDataTagType::Typedef, the count determines
    /// the number of fields
    TagCount          count;
} CAMX_PACKED;

///< @brief Represents a single field within a type-definition tag
struct TypedefFieldInfo
{
    TypedefFieldID      fieldID;    ///< The field ID. Thsi should start at 1 for each type-definition
    DebugDataTagType    type;       ///< The data type of this field
    TypedefFieldLen     count;      ///< Number of occurances of this field. Set to 1 if a single field, otherwise set to
                                    ///  number of elements for an array field
} CAMX_PACKED;

///< @brief Debug data payload for DebugDataTagType::QNumber to represent a signed Q number
///         Float representation can be obtained by evaluating    value * pow(2, -1*qNumber)
struct DebugDataQNumber
{
    UINT8   qNumber;    ///< Exponent
    INT32   value;      ///< Value
} CAMX_PACKED;

///< @brief Debug data payload for DebugDataTagType::UQNumber to represent an unsigned Q number
///         Float representation can be obtained by evaluating    value * pow(2, -1*qNumber)
struct DebugDataUQNumber
{
    UINT8   qNumber;    ///< Exponent
    UINT32  value;      ///< Value
} CAMX_PACKED;

///< @brief Debug data payload for DebugDataTagType::Rational to represent a signed rational number
struct DebugDataRational
{
    INT32 numerator;    ///< Rational number's numerator
    INT32 denominator;  ///< Rational number's denominator
} CAMX_PACKED;

///< @brief Debug data payload for DebugDataTagType::URational to represent an unsigned rational number
struct DebugDataURational
{
    UINT32 numerator;   ///< Rational number's numerator
    UINT32 denominator; ///< Rational number's denominator
} CAMX_PACKED;

///< @brief Debug data header for 2D arrays to describe the array dimentions
struct DebugData2DArrayHeader
{
    DebugDataTagType    underlyingType; ///< Type of each element of the 2D array
    UINT16              dimension1;     ///< Array dimension 1 - or number of rows
    UINT16              dimension2;     ///< Array dimension 2 - or number of columns
} CAMX_PACKED;

///< @brief Header information for each data type version 1 (Version 0, means no header)
struct DebugDataHeaderV1
{
    DebugDataPipelineID pipelineID;     ///< Pipeline identification number
    UINT8               pathID;         ///< If multiple HW modules in same pipeline, but different path
    UINT8               orderID;        ///< If multiple HW modules in same path. ID number starting with 0 from input to output
    UINT16              reservedID[4];  ///< Reserved IDs for future use case
} CAMX_PACKED;

///< @brief Basic char type with header V1
struct DebugDataHeaderV1Char
{
    DebugDataHeaderV1   header;
    CHAR                value;
} CAMX_PACKED;

///< @brief Basic bool type with header V1
struct DebugDataHeaderV1Bool
{
    DebugDataHeaderV1   header;
    UINT8               value;
} CAMX_PACKED;

///< @brief Basic UINT8 type with header V1
struct DebugDataHeaderV1UINT8
{
    DebugDataHeaderV1   header;
    UINT8               value;
} CAMX_PACKED;

///< @brief Basic UINT16 type with header V1
struct DebugDataHeaderV1UINT16
{
    DebugDataHeaderV1   header;
    UINT16              value;
} CAMX_PACKED;

///< @brief Basic UINT32 type with header V1
struct DebugDataHeaderV1UINT32
{
    DebugDataHeaderV1   header;
    UINT32              value;
} CAMX_PACKED;

///< @brief Basic UINT64 type with header V1
struct DebugDataHeaderV1UINT64
{
    DebugDataHeaderV1   header;
    UINT64              value;
} CAMX_PACKED;

///< @brief Basic UQNumber type with header V1
struct DebugDataHeaderV1UQNumber
{
    DebugDataHeaderV1   header;
    DebugDataUQNumber   value;
} CAMX_PACKED;

///< @brief Basic URational type with header V1
struct DebugDataHeaderV1URational
{
    DebugDataHeaderV1   header;
    DebugDataURational  value;
} CAMX_PACKED;

///< @brief Basic INT8 type with header V1
struct DebugDataHeaderV1INT8
{
    DebugDataHeaderV1   header;
    INT8                value;
} CAMX_PACKED;

///< @brief Basic INT16 type with header V1
struct DebugDataHeaderV1INT16
{
    DebugDataHeaderV1   header;
    INT16               value;
} CAMX_PACKED;

///< @brief Basic INT32 type with header V1
struct DebugDataHeaderV1INT32
{
    DebugDataHeaderV1   header;
    INT32               value;
} CAMX_PACKED;

///< @brief Basic INT64 type with header V1
struct DebugDataHeaderV1INT64
{
    DebugDataHeaderV1   header;
    INT64               value;
} CAMX_PACKED;

///< @brief Basic QNumber type with header V1
struct DebugDataHeaderV1QNumber
{
    DebugDataHeaderV1   header;
    DebugDataQNumber    value;
} CAMX_PACKED;

///< @brief Basic Rational type with header V1
struct DebugDataHeaderV1Rational
{
    DebugDataHeaderV1   header;
    DebugDataRational   value;
} CAMX_PACKED;

///< @brief Basic float type with header V1
struct DebugDataHeaderV1Float
{
    DebugDataHeaderV1   header;
    FLOAT               value;
} CAMX_PACKED;

///< @brief Basic Double type with header V1
struct DebugDataHeaderV1Double
{
    DebugDataHeaderV1   header;
    double              value;
} CAMX_PACKED;

CAMX_END_PACKED

#endif // CAMXSTATSDEBUGDATATYPES_H
