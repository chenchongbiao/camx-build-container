// NOWHINE ENTIRE FILE
//----------------------------------------------------------------------------
// Copyright (c) 2018-2021 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
//---------------------------------------------------------------------------

#pragma once

#include "CommonDefs.h"

/// @brief Holds the necessary HW/chip version.
///        Needs to be set at start and then can be used by other SW components.
class NcLibChipInfo
{
public:

    enum TitanVersion
    {
        TITAN_180 = 0x00010800,
        TITAN_175 = 0x00010705,
        TITAN_170 = 0x00010700,
        TITAN_160 = 0x00010600,
        TITAN_150 = 0x00010500,
        TITAN_140 = 0x00010400,
        TITAN_120 = 0x00010200,
        TITAN_480 = 0x00040800,
        TITAN_580 = 0x00050800,
        TITAN_680 = 0x00060800,
        TITAN_570 = 0x00050700,
        TITAN_165 = 0x00010605,
        TITAN_497 = 0x00040907,
        TITAN_498 = 0x00040908,
    };

    // Derived information combining Titan Tiering version and HW version.
    // Not actually used in NcLib.
    enum ChipVersion
    {
        TITAN_VERSION_FIRST = 0,

        TITAN_170_V1 = 1,        // SDM845 (Napali)
        TITAN_160_V1 = 2,        // SDM840 (NapaliQ)
        TITAN_175_V1 = 3,        // SDM855 (Hana)
        TITAN_170_V2 = 4,        // SDM845 (Napali) v2
        TITAN_150_V1 = 5,        // SDM640 (Talos)
        TITAN_170_V2_ONEIPE = 6, // SDM670 (Warlock 1 core)
        TITAN_480_V1 = 7,        // SDM865 (Kona)
        SPECTRA_520 = 8,         //Mimas 2k(Kamorta, no icp)
        SPECTRA_560 = 9,         //Bitra
        TITAN_580_V1 = 10,       // SDM8XX (Lahaina)
        Reserved_0 = 11,         // Reserved for Spectra540,   Kamorta
        Reserved_1 = 12,         // Reserved for Spectra620,
        SPECTRA_550 = 13,        // Reserved for Spectra640,   Netrani
        Reserved_3 = 14,         // Reserved for Spectra660,
        SPECTRA_680 = 15,        // Waipio

        CEDROS = 0x20000000,
        BITRA = 0x20000000,
        SAIPAN = 0x1003000,

        CHIP_VERSION_NONE = 0x7FFFFFFF
    };

    struct Capabilities
    {
        uint32_t IfeDsx : 1;
        uint32_t        : 7;

        uint32_t IcaMajorVer                   : 3;
        uint32_t IcaGridExtrapolationCorners   : 1;
        uint32_t IcaGridExtrapolationPerimeter : 1;
        uint32_t IcaHighResGrid                : 1;
        uint32_t                               : 2;

        uint32_t TfMajorVer : 3;
        uint32_t LMC        : 1;
        uint32_t IpeDsx     : 1;
        uint32_t TfMinorVer : 2;
        uint32_t ALGM       : 1;

        uint32_t GeoLib         : 1;
        uint32_t HDR            : 1;
        uint32_t CvpIcaMajorVer : 3;
        uint32_t VBSE           : 1;
        uint32_t DmeMajorVer    : 2;
    };

    /// @brief  Required initializer
    /// @param  titanVersion The version of the camera platform
    /// @param  hwVersion    The version of the camera CPAS
    /// @return None
    static void Set(uint32_t titanVersion, uint32_t hwVersion);

    /// @brief  Camera platform version accessor
    /// @return The version of the camera platform
    static inline TitanVersion GetTitanVersion()
    {
        NCLIB_ASSERT_DEBUG(s_titanVersion != INVALID_TITAN_VERSION);
        return s_titanVersion;
    }

    /// @brief  Camera CPAS version accessor
    /// @return The version of the camera CPAS
    static inline uint32_t GetHwVersion()
    {
        NCLIB_ASSERT_DEBUG(s_hwVersion != INVALID_CHIP_VERSION);
        return s_hwVersion;
    }

    /// @brief  Tests whether running on Napali
    /// @return True if running on Napali
    static inline bool IsNapali() { return GetTitanVersion() == TITAN_170; }

    /// @brief  Tests whether running on Napali or Talos
    /// @return True if running on Napali or Talos
    static inline bool IsNapaliFamily() { return (GetTitanVersion() == TITAN_170) || (GetTitanVersion() == TITAN_150); }

    /// @brief  Tests whether running on Hana
    /// @return True if running on Hana
    static inline bool IsHana()   { return GetTitanVersion() == TITAN_175; }

    /// @brief  Tests whether running on Kodiak
    /// @return True if running on Kodiak
    static inline bool IsKodiak()   { return (GetTitanVersion() == TITAN_165) || (GetTitanVersion() == TITAN_497) || (GetTitanVersion() == TITAN_498); }

    /// @brief  Tests whether running on Kona
    /// @return True if running on Kona
    static inline bool IsKona()   { return GetTitanVersion() == TITAN_480; }

    /// @brief  Tests whether running on Lahaina
    /// @return True if running on Lahaina
    static inline bool IsLahaina() { return GetTitanVersion() == TITAN_580; }

    /// @brief  Tests whether running on Lahaina or Cedros
    /// @return True if running on Lahaina or Cedros
    static inline bool IsLahainaFamily() { return GetTitanVersion() == TITAN_580 || GetTitanVersion() == TITAN_570; }

    /// @brief  Tests whether running on Waipio
    /// @return True if running on Waipio
    static inline bool IsWaipio() { return GetTitanVersion() == TITAN_680; }

    /// @brief  Tests whether running on Talos
    /// @return True if running on Talos
    static inline bool IsTalos()  { return GetTitanVersion() == TITAN_150; }

    /// @brief  Tests whether running on Cedros
    /// @return True if running on Cedros
    static inline bool IsCedros() { return GetTitanVersion() == TITAN_570; }

    /// @brief  Current HW/SW capabilities accessor
    /// @return Current HW/SW capabilities structure
    static inline Capabilities GetCapabilities() { return s_capabilities; }

    /// @brief  Get NcLib Version
    /// @return none
    static void GetNcLibVersion(char* version, unsigned int size);

private:
    NcLibChipInfo() = delete;

private:
    static const TitanVersion INVALID_TITAN_VERSION = (TitanVersion)0;
    static const ChipVersion  INVALID_CHIP_VERSION = CHIP_VERSION_NONE;

    static TitanVersion s_titanVersion;
    static uint32_t s_hwVersion;
    static Capabilities s_capabilities;
};
