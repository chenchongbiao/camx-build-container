//-------------------------------------------------------------------------
// Copyright (c) 2020 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
//------------------------------------------------------------------------
// @file  mimas20.h
//------------------------------------------------------------------------

#ifndef __MIMAS_20__
#define __MIMAS_20__

#define MIMAS20_TFE_CHROMADS2_VERSION       (22u)
#define MIMAS20_OPE_CHROMA_UPSCALE_VERSION  (21u)
#define MIMAS20_OPE_MNDS_VERSION            (22u)
#define MIMAS20_OPE_CHROMADS2_VERSION       (22u)
#define MIMAS20_OPE_ASF_VERSION             (33u)
#define MIMAS20_OPE_YUV_DS_VERSION          (13u)
#define MIMAS20_OPE_CRC_VERSION             (12u)
#define MIMAS20_OPE_LTM_VERSION             (15u)
#define MIMAS20_OPE_ROWSUM_VERSION          (15u)
#define MIMAS20_OPE_IHIST_VERSION           (11u)
#define MIMAS20_OPE_ABFBPC_VERSION          (41u)
#define MIMAS20_OPE_DEMOSAIC_VERSION        (38u)
#define MIMAS20_OPE_ANR_VERSION             (13u)

#define MIMAS20_OPE_MAX_BUFFER_SIZE         (336u)

//BPS

#define MIMAS20_BPS_MAX_BUFFER_SIZE         (336u)

#define MIMAS20_BPS_MUX_NODE_OPTION_CHROMADS2   (0u)
#define MIMAS20_BPS_MUX_NODE_OPTION_ROOT        (1u)

#define MIMAS20_OPE_MUX_NODE_OPTION_BAYER   (0u)
#define MIMAS20_OPE_MUX_NODE_OPTION_YUV     (1u)

#include "striping_library.h"

uint16_t register_callbacks_mimas_20_pipeline(void* apData);
uint16_t init_mimas_20_instance(PipelineInfo* apPipelineInfo);
uint16_t deinit_mimas_20_instance(PipelineInfo* apPipelineInfo);
uint16_t create_mimas_20_tfe_pipeline(PipelineInfo* apPipelineInfo);
uint16_t create_mimas_20_ope_pipeline(PipelineInfo* apPipelineInfo);
uint16_t create_mimas_20_bps_pipeline(PipelineInfo* apPipelineInfo);
uint16_t destroy_mimas_20_tfe_pipeline(PipelineInfo* apPipelineInfo);
uint16_t destroy_mimas_20_ope_pipeline(PipelineInfo* apPipelineInfo);
uint16_t destroy_mimas_20_bps_pipeline(PipelineInfo* apPipelineInfo);

#endif //__MIMAS_20__
