////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2024 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @file  camxlrmetitan17x.h
/// @brief LRME register setting for Titan17x
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef CAMXLRMETITAN17X_H
#define CAMXLRMETITAN17X_H

#include "camxtitan17xdefs.h"
#include "camxisphwsetting.h"
#include "camxcmdbuffer.h"
#include "camxispiqmodule.h"

CAMX_NAMESPACE_BEGIN

enum lrmeCLCRegistersList
{
    lrmeCLCModuleConfig = 0,                  ///< module config register
    lrmeCLCModuleFormat,                      ///< module format register
    lrmeCLCModuleRangeStep,                   ///< range step register
    lrmeCLCModuleOffset,                      ///< module offset register
    lrmeCLCModuleMaxAllowedSad,               ///< max allowed sad register
    lrmeCLCModuleMinAllowedTarMad,            ///< tar mad register
    lrmeCLCModuleMeaningfulSaDDiff,           ///< Algo Specific register
    lrmeCLCModulMinSaDDiffDenom,              ///< Algo Specific register
    lrmeCLCModuleRobustnessMeasureDistMap0,   ///< Algo Specific register
    lrmeCLCModuleRobustnessMeasureDistMap1,   ///< Algo Specific register
    lrmeCLCModuleRobustnessMeasureDistMap2,   ///< Algo Specific register
    lrmeCLCModuleRobustnessMeasureDistMap3,   ///< Algo Specific register
    lrmeCLCModuleRobustnessMeasureDistMap4,   ///< Algo Specific register
    lrmeCLCModuleRobustnessMeasureDistMap5,   ///< Algo Specific register
    lrmeCLCModuleRobustnessMeasureDistMap6,   ///< Algo Specific register
    lrmeCLCModuleRobustnessMeasureDistMap7,   ///< Algo Specific register
    lrmeCLCModuleDsCropHorizontal,            ///< Crop of tar input
    lrmeCLCModuleDsCropVertical,              ///< Crop of tar input
    lrmeCLCModuleTarPdUnpacker,               ///< Crop of tar input
    lrmeCLCModuleRefPdUnpacker,               ///< Crop of tar input
    lrmeCLCModuleSwOverride,                  ///< Chicken bits
    lrmeCLCModuleTarHeight,                   ///< tar input height
    lrmeCLCModuleRefHeight,                   ///< ref input height
    lrmeRegisterListMax                       ///< Max registers count
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief LRME register setting for Titan17x
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
class LRMETitan17x final : public ISPHWSetting
{
public:
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// LRMETitan17x
    ///
    /// @brief  Constructor
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    LRMETitan17x();

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// CreateCmdList
    ///
    /// @brief  Generate the Command List
    ///
    /// @param  pInputData          Pointer to the Inputdata
    /// @param  pDMIBufferOffset    Pointer for DMI Buffer
    ///
    /// @return CamxResultSuccess if successful.
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual CamxResult CreateCmdList(
        VOID*       pInputData,
        UINT32*     pDMIBufferOffset);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// PackIQRegisterSetting
    ///
    /// @brief  Calculate register settings based on common library result
    ///
    /// @param  pInput       Pointer to the Input data to the IQ module for calculation
    /// @param  pOutput      Pointer to the Output data to the IQ module for DMI calculation
    ///
    /// @return Return CamxResult.
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual CamxResult PackIQRegisterSetting(
        VOID*  pInput,
        VOID*  pOutput);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// DumpRegConfig
    ///
    /// @brief  Print register configuration of Crop module for debug
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual VOID DumpRegConfig();

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// SetupInternalData
    ///
    /// @brief  Update module internal Data from register
    ///
    /// @param  pData Pointer to internal data to be updated
    ///
    /// @return Return CamxResult
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual CamxResult SetupInternalData(
        VOID* pData);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// InitializeRegisters
    ///
    /// @brief     This method sets up LRME register addresses and default values
    ///
    /// @return    None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    VOID InitializeRegisters();

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// ~LRMETitan17x
    ///
    /// @brief  Destructor
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual ~LRMETitan17x();

private:
    LRMETitan17x(const LRMETitan17x&)            = delete;          ///< Disallow the copy constructor
    LRMETitan17x& operator=(const LRMETitan17x&) = delete;          ///< Disallow assignment operator


    UINT32*               m_pLrmeRegistersValue;       ///< The lrme register values
    UINT32*               m_pLrmeRegistersAddress;     ///< The lrme register adressed
    UINT32                m_numRegisters;              ///< number of LRME registers
};

CAMX_NAMESPACE_END

#endif // CAMXLRMETITAN17X_H
