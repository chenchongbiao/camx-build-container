//-------------------------------------------------------------------------
// Copyright (c) 2015-2020 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
//------------------------------------------------------------------------

#ifndef IPE_STRIPE_INTERNAL_STRUCTS_H_
#define IPE_STRIPE_INTERNAL_STRUCTS_H_

#include "stripeNPSPPS.h"
#include "modules.h"
#include "stripe.h"
#include "blur_stripe.h"

#ifdef __cplusplus
extern "C"
{
#endif

typedef struct {
    CMUSStriping1dOutputParams clc;
    int16_t fetchFirst;
    int16_t fetchLast;
} CMUSOutStruct;

typedef struct {
    modStriping1dOutputParams clc;
    int16_t fetchFirst;
    int16_t fetchLast;
} STMPOutStruct;

typedef struct _TieringParam
{
    int16_t local_lineBufferSize;
    uint16_t datapath_align_step_x;
    uint16_t datapath_align_step_y;

    // kernels
    int16_t local_kernelABF;
    int16_t local_kernelLCAC;
    int16_t local_kernelWB;
    int16_t local_kernelBayerGTM;
    int16_t local_kernelBayerLTM;
    int16_t local_kernelDemosaic;
    int16_t local_kernelGIC;
    int16_t local_kernelHNR;

    //waipio.s2.50 for now these kernels are not used, because a config-dependent kernel is calculated in the initialization of pass avirables
    int16_t local_kernelBlur;
    int16_t local_kernelVSE;

    int16_t local_kernelCAC2;
    int16_t local_kernelASF;
    int16_t local_kernelChromaUp;
    int16_t local_kernelUpscale;

    int16_t local_kernelRNF;
    int16_t local_kernelCYLPF;
    int16_t local_kernelFilter2;
    //int16_t local_kernelTF_small_pass;
    //int16_t local_kernelTF_full_pass;
    int16_t local_kernelTF[4];
    int16_t local_kernelTFDilate;
    int16_t local_kernelTFErrode;
    int16_t local_kernelTFRefinement;           //this is hidden from the TF kernel but is needed to calculate some coordinate constraints
    int16_t local_kernelTFLMC;
    int16_t local_kernelLENR;
    int16_t local_kernel8TapDownscale;
    int16_t local_kernel_ltm_ip_mask_filter;
    int16_t local_kernel_ltmmp_mask_filter;
    int16_t constraint_min_ica_out;

    // BPS
    int16_t local_kernelBPCPDPC;
    int16_t local_kernelHDRRecon;
    int16_t local_kernelHDRMAC;
    int16_t local_kernelCADL;
    int16_t local_kernelSimplePDPC;
    int16_t local_kernelSimpleBPC;

    //int16_t local_kernelMfhdrPreMacLeft;
    int16_t local_kernelMfhdrMacLeft;
    int16_t local_kernelMfhdrMacRight;

    int16_t local_kernelMfhdrMacLeft_Mac1;
    int16_t local_kernelMfhdrMacRight_Mac1;
    //int16_t local_kernelMfhdrPostMacRight;
}
TieringParam;

typedef struct _PassVar1D
{
        // scale ratios - q_factor format
        int32_t ds4Ratio;
        BOOL    upscaleEnable;
        int32_t upscaleRatioSIMO;
        int32_t downscaleRatioVideo;
        int32_t downscaleRatioDisp;
        int32_t downscaleRatioApp;
        int32_t downscaleRatioVideo_c;
        int32_t downscaleRatioDisp_c;
        int32_t downscaleRatioApp_c;
        int32_t ltmdc_q2;
        int32_t downscaleRatioLTMDC;
        // main dimentions (before simo upscale)
        int16_t mainDimInSource;
        int16_t mainDimInSource_pps;
        int16_t mainDimInSource_SIMO;

        // scaled offsets (after simo upscale) - q_factor format
        int16_t scaledMainDimInSource;
        int16_t scaledVideoOffsetInSource;
        int16_t scaledDispOffsetInSource;
        int16_t scaledAppOffsetInSource;
        int16_t mainOffsetInSource;
        int16_t mainOffsetInSource_pps;
        int16_t mainOffsetInSource_SIMO;

        // scaled dimensions (after simo upscale)
        int16_t scaledVideoInDim;
        int16_t scaledDispInDim;
        int16_t scaledAppInDim;

        int16_t dummy_field_for_byte_padding; //?

        MNScaleDownInStruct_V20_1D downscaleVideoLumaFrame;
        MNScaleDownInStruct_V20_1D downscaleVideoChromaFrame;
        MNScaleDownInStruct_V20_1D downscaleDispLumaFrame;
        MNScaleDownInStruct_V20_1D downscaleDispChromaFrame;
        MNScaleDownInStruct_V20_1D downscaleAppLumaFrame;
        MNScaleDownInStruct_V20_1D downscaleAppChromaFrame;

        MNScaleDownInStruct_V20_1D downscaleLTMDCFrame;
        Upscalev20Striping1dOutputParams upscaleSIMOFrame;
        UpscaleInStruct_V11_1D chromaUpFrame_Y;
        UpscaleInStruct_V11_1D chromaUpFrame_C;

        // mux output format
        int16_t PDITFIOutFormat;

        // format constraints
        int16_t mainInConstraint;
        int16_t refInConstraint;
        int16_t mfhdrInConstraint;
        int16_t TFIndConstraint;
        int16_t AlgmInConstraint;    // TODO_NKP: Set/ Use this variable.
        int16_t ANRDCInConstraint;
        int16_t ltm_mask_in_constaint;
        int16_t ltm_maxmin_in_constaint;
        int16_t LENRDS4InConstraint;
        int16_t bokehdcinConstraint; // waipio.s5.50
        int16_t PDIOutConstraint;
        int16_t TFIOutConstraint;
        int16_t AlgmOutConstraint;   // TODO_NKP: Set thiws variable.
        int16_t TFOutConstraint;
        int16_t DS4OutConstraint;
        int16_t dispOutConstraint;
        int16_t videoOutConstraint;
        int16_t appOutConstraint;
        int16_t ltm_mask_out_constaint;
        int16_t ltm_maxmin_out_constaint;

        int16_t ltmOutConstraint;

        int16_t videoOutMinSize;
        int16_t dispOutMinSize;
        int16_t appOutMinSize;
        int16_t TFOutMinSize;
        int16_t DS4OutMinSize;
        int16_t PdiOutMinSize;

        // flags
        BOOL striping;      // enable striping for this dimention
        BOOL is_horizontal;

        //int16_t preallocatedStripeCount;
        int16_t fetchExtension_middle;
        int16_t fetchExtension_edge;
        int16_t fetchStep;
        int16_t mainOutputGrid;         //the type of main output grid (0=display, 1=video, 2=TF_DS4_OUT/TF_OUT 3 LTM DC)
        int16_t other_dimension_video_ds_out_y;
        int16_t other_dimension_video_ds_out_c;
        int16_t other_dimension_display_ds_out_y;
        int16_t other_dimension_display_ds_out_c;
        int16_t other_dimension_app_ds_out_y;
        int16_t other_dimension_app_ds_out_c;

        ////////////////
        // MFHDR
        UpscaleInStruct_V11_1D              mfhdr_chromaUp1Frame_C;
        UpscaleInStruct_V11_1D              mfhdr_chromaUp2Frame_C;
        UpscaleInStruct_V11_1D              mfhdr_chromaUp3Frame_C;
        MNScaleDownInStruct_V20_1D          mfhdr_chromadn;
}
PassVar1D;              //those that keeps constant during the coordinate calculation process of stripes

typedef struct _ipeStripeAllocationControl
{
        int16_t cumulativeTFrefineBlk;
        int16_t cummulativePDIOut;
        int16_t cummulativeTFIOut;
        int16_t cummulativeAlgmOut;
        int16_t cummulativeTFOut;
        int16_t cummulativeDS4Out;
        int16_t cummulativeLtmDcOut;
        int16_t cummulative_ltmmp_mask_out;
        int16_t cummulative_ltmmp_maxmin_out;
        int16_t cummulativeVideoOutLuma;
        int16_t cummulativeDispOutLuma;
        int16_t cummulativeAppOutLuma;
        int16_t cummulativeNPSout;
        // waipio.s2.50.01, this variable needs to be initialized and updated to track how many unfinished pixels there remain as we allocate stripes
        int16_t cumulativeBlurMapOut; // waipio.s2.50 ... need to track cumulativeBlurMapOut

        int16_t nonOverlappingVideoOutStart;
        int16_t nonOverlappingDispOutStart;
        int16_t nonOverlappingAppOutStart;

        int16_t nonOverlappingTfOutStart;

        int16_t upscalarGoalInRight;
        int16_t upscalarGoalInLeft;
        int16_t upscalar_out_right;             //the right bound of the upscalar output -- derived from the video out + display out requirement
        int16_t upscalar_out_left;              //the left bound of the upscalar output -- derived from the video out + display out left bounds

        int16_t ltmDcLeftBound;
        int16_t videoOutLeftBound;
        int16_t dispOutLeftBound;
        int16_t appOutLeftBound;

        int16_t tfOutLeftBound;
        int16_t ds4OutLeftBound;
        int16_t pdiOutLeftBound;
        int16_t tfiOutLeftBound;
        int16_t algmOutLeftBound;
        int16_t ltmmp_mask_out_leftBound;
        int16_t ltmmp_maxmin_out_leftBound;

        int16_t ltmDcRightTarget;
        int16_t videoOutRightTarget;
        int16_t dispOutRightTarget;
        int16_t appOutRightTarget;

        int16_t tfOutRightTarget;
        int16_t ds4OutRightTarget;
        int16_t tfiOutRightTarget;
        int16_t algmOutRightTarget;
        int16_t pdiOutRightTarget;
        int16_t ltmmp_mask_out_RightTarget;
        int16_t ltmmp_maxmin_out_RightTarget;

        int16_t preallocatedStripeCount;

        int16_t TF_ds4_full_out_target_at_MFHDR_OUT_SEL_mux;

}
ipeStripeAllocationControl;

// Similar pronunciation to _Generic, which is C resreved word, to avoids conflictduring compilation
typedef struct _Generique
{
        int16_t tfWorkWindowInStart;

        // fetch coordinates
        int16_t tfiFetchFirst;
        int16_t tfiFetchLast;
        int16_t mainFetchFirst;
        int16_t mainFetchLast;
        int16_t refFetchFirst;
        int16_t refFetchLast;
        int16_t pdiFetchFirst;
        int16_t pdiFetchLast;
        int16_t lmcFetchFirst;
        int16_t lmcFetchLast;
        int16_t LmcFetchFirst[ICA_LMC_CNT];
        int16_t LmcFetchLast[ICA_LMC_CNT];
        int16_t algmFetchFirst;
        int16_t algmFetchLast;
        int16_t mfhdrFetchFirst;
        int16_t mfhdrFetchLast;
        int16_t ltmMaskIn_FetchFirst;
        int16_t ltmMaskIn_FetchLast;
        int16_t ltmMaxMinIn_FetchFirst;
        int16_t ltmMaxMinIn_FetchLast;
        int16_t lenrDs4FetchFirst;
        int16_t lenrDs4FetchLast;
        int16_t blurMapBlurFetchFirst;
        int16_t blurMapBlurFetchLast;
        int16_t blurMapVSEFetchFirst;
        int16_t blurMapVSEFetchLast;
        int16_t blurDs4FetchFirst;
        int16_t blurDs4FetchLast;
        int16_t catmaphiresFetchFirst;
        int16_t catmaphiresFetchLast;
        int16_t catmaploresFetchFirst;
        int16_t catmaploresFetchLast;
        //Kailua
        int16_t HdrLm1FetchFirst;
        int16_t HdrLm1FetchLast;
        int16_t HdrLm2FetchFirst;
        int16_t HdrLm2FetchLast;



        // write coordinates
        int16_t PDIOutFirst;
        int16_t PDIOutLast;
        int16_t TFIOutFirst;
        int16_t TFIOutLast;
        int16_t algmOutFirst;
        int16_t algmOutLast;
        int16_t TFOutFirst;
        int16_t TFOutLast;
        int16_t LMCOutFirst;
        int16_t LMCOutLast;
        int16_t DS4OutFirst;
        int16_t DS4OutLast;
        int16_t ltmMaskDcOut_First;
        int16_t ltmMaskDcOut_Last;
        int16_t ltmMaxMinOut_First;
        int16_t ltmMaxMinOut_Last;
        int16_t videoOutLumaFirst;
        int16_t videoOutLumaLast;
        int16_t dispOutLumaFirst;
        int16_t dispOutLumaLast;
        int16_t appOutLumaFirst;
        int16_t appOutLumaLast;


        int16_t blurMapOutFirst;
        int16_t blurMapOutLast;
        //Kailua
        int16_t HdrLm1OutFirst;
        int16_t HdrLm1OutLast;
        int16_t HdrLm2OutFirst;
        int16_t HdrLm2OutLast;

        int16_t dummy_field_for_byte_padding;

        // flags
        BOOL edgeStripeLT;
        BOOL edgeStripeRB;
        BOOL edgeStripePDILT;
        BOOL edgeStripePDIRB;
        BOOL edgeStripeTFILT;
        BOOL edgeStripeTFIRB;
        BOOL useDS4forBlur;

    IpeStripingModule1dOutputStorage module1d;
}
Generic;

typedef struct _Ipe1dIntermediateModuleConfig
{
        crop_1D ANRDCUpscaler1InCrop;
        crop_1D ANRDCUpscaler1OutCrop;
        crop_1D PDINFOutCrop;
        StripeParamsANRLNR anrlnr;      // ANR LNR striping paramters
        int32_t ANR_CYLPF_dithering_seed;
        int32_t ANR_dcnf_dithering_seed;
        int16_t anrlnrStart;
        int16_t tfRefRangeInROI;
        BilinearUsOutStruct blur_ds4_us;
        JbuOutStruct blur_jpu;
        JbuOutStruct vse_jpu;
        BOOL useDS4forBlur;
        // kailua.s2.50
        CMUSOutStruct cmus;
        STMPOutStruct stmp;
        crop_1D catmaphiresCropForASF;
        SBLUROutStruct sblur;

        crop_1D TFimageInCrop;
        int16_t TFimageInCrop_en;
        crop_1D TFrefInCrop;
        int16_t TFrefInCrop_en;

        crop_1D TFIEInCrop;
        crop_1D TFIEOutCrop;
        crop_1D TFIDOutCrop;
        crop_1D TFIUSInCrop;
        crop_1D TFIUSOutCrop;
        crop_1D TFIOutCrop;
        crop_1D TFLMCCropAfterUpscale;
        crop_1D TFLMCOutCrop;

        crop_1D TFOutCrop_Y;
        crop_1D TFOutCrop_C;
        crop_1D DS4InCropLuma;
        crop_1D DS4InCropChroma;
        crop_1D DS4OutCrop_Y;
        crop_1D DS4OutCrop_C;
        BOOL    dsx_luma_en;
        BOOL    dsx_chroma_en;

        crop_1D lenr_post_us4_crop;
        crop_1D cropLumaBeforeChromaUpsample;       // Y crop module before chroma upsample in PPS pipeline
        crop_1D cropChromaBeforeChromaUpsample;     // cbcr crop module before chroma upsample in PPS pipeline
        crop_1D ltmMultiPass_PostUpscale_Crop_1D;
        crop_1D cropAfterASF;


        crop_1D SIMOUpscaleCrop;
        crop_1D videoFOVCrop_luma;
        crop_1D videoFOVCrop_chroma;
        crop_1D dispFOVCrop_luma;
        crop_1D dispFOVCrop_chroma;
        crop_1D appFOVCrop_luma;
        crop_1D appFOVCrop_chroma;


        crop_1D videoLumaCrop;
        crop_1D videoChromaCrop;
        crop_1D dispLumaCrop;
        crop_1D dispChromaCrop;
        crop_1D appLumaCrop;
        crop_1D appChromaCrop;

        int16_t asf_face_offset;
        int16_t lenr_min_fetch;
        int16_t lenr_ds4_out_start;
        int16_t lenr_ds4_out_end;
        uint16_t lenr_left_fetch_margin;
        int16_t hnr_face_offset;
        int32_t hnr_rnr_b;
        int32_t lenr_dn4_rnr_b;
        int32_t lenr_dn8_rnr_b;
        int32_t lenr_dn16_rnr_b;
        int32_t asf_rnr_b;
        int32_t tf_LnrStartIdx;
        BOOL    upscalar_en_1d;

        crop_1D mfhdr_chromaUp1_precrop_luma;
        crop_1D mfhdr_chromaUp2_precrop_luma;
        crop_1D mfhdr_chromaUp3_precrop_luma;
        crop_1D mfhdr_chromaUp1_precrop_chroma;
        crop_1D mfhdr_chromaUp2_precrop_chroma;
        crop_1D mfhdr_chromaUp3_precrop_chroma;
        crop_1D mfhdr_chromadn_precrop_luma;
        crop_1D mfhdr_chromadn_precrop_chroma;
        crop_1D mfhdr_mac_lm1_postcrop;
        crop_1D mfhdr_mac_lm2_postcrop;
}
Ipe1dIntermediateModuleConfig;

typedef struct _PassInput1D
{
    // tiering information
    int32_t chip;
    int16_t datapath_align_step;

    // buffer sizes
    int16_t lineBufferSize;
    int16_t min_ica_out_size;
    BOOL striping;
    int16_t passIdx;                //0: full, 1: 1:4, 2: 1:16, 3: 1:64
    int16_t enforceMinOutputConstraint;

    // mainIn
    int16_t mainInFormat;
    int16_t mainInDim;
    int16_t mainInStride;
    int16_t zoomOffsetInSource;
    int16_t zoomDimInSource;
    int16_t tf_ds4_out_address_start;

    // refIn
    int16_t refInFormat;
    int16_t refInOffset;

    // ANRDCIn
    int16_t ANRDCInFormat;
    int16_t ANRDCInDim;
    int16_t ANRDCInStride;

    //int16_t ANRDCInZoomOffset;   // only for 1:1 pass, when zoom,  ANR/PDI input needs to have zoom window defined
    int16_t ANRDCInZoomDim;

    // TFInd
    int16_t TFIndFormat;
    int16_t TFIndDim;
    int16_t TFIndZoomOffset;
    int16_t TFIndStride;

    //int16_t TFIndZoomOffset;   // only for 1:1 pass, when zoom,  ANR/PDI input needs to have zoom window defined
    int16_t TFIndZoomDim;

    // ALGM
    int16_t AlgmFormat;
    int16_t AlgmDim;

    // MFHDR
    int16_t mfhdrInFormat;
    int16_t mfhdrInDim;

    // LtmMaskIn
    int16_t LtmMaskIn_Format;
    int16_t LtmMaskIn_Dim;    // TODO_NKP: Strides required???

    // LtmMaxMinIn
    int16_t LtmMaxMinIn_Format;
    int16_t LtmMaxMinIn_Dim;  // TODO_NKP: Strides required???

    // LtmMaskDcOut
    int16_t LtmMaskDcOut_Format;
    int16_t LtmMaskDcOut_Dim;  // TODO_NKP: Strides required???

    // LtmMaxMinOut
    int16_t LtmMaxMinOut_Format;
    int16_t LtmMaxMinOut_Dim;  // TODO_NKP: Strides required???

    // LENRIn
    int16_t lenrDs4InFormat;
    int16_t lenrDs4InDim;

    // BLURIn
    int16_t blurDs4InDim;
    int16_t blurMapBlurInputFormat;  // waipio.s2.50
    int16_t blurMapBlurOutputFormat; // waipio.s2.50
    int16_t blurMapVSEInputFormat;
    int16_t bokehdcinFormat; // waipio.s5.50

    // kailua.s2.50
    StripingPort catmaphiresIn;
    StripingPort catmaploresIn;

    // dispOut
    int16_t dispOutFormat;
    int16_t dispOutDim;
    int16_t dispOutStride;
    int16_t dispOffsetInSource;
    int16_t dispDimInSource;

    // videoOut
    int16_t videoOutFormat;
    int16_t videoOutDim;
    int16_t videoOutStride;
    int16_t videoOffsetInSource;
    int16_t videoDimInSource;

    // 3rd YUC appOut
    int16_t appOutFormat;
    int16_t appOutDim;
    int16_t appOutStride;
    int16_t appOffsetInSource;
    int16_t appDimInSource;

    // blur map out
    int16_t blurMapOutDim;

    //ltmDcOut
    int16_t ltmDcDim;

    // TFANRTFIOut
    int16_t PDIOutFormat;
    int16_t TFIOutFormat;
    int16_t AlgmOutFormat;
    int16_t TFOutFormat;

    int16_t TFANRTFIOutDim;   // if ANR& TFI both are enabled,  they have same dimensions.   TF output, set to be the same as the main input zoomDimInSource.
    int16_t TFANRTFIOutStride;

    // DS4Out
    int16_t DS4OutFormat;
    int16_t DS4OutDim;
    int16_t DS4OutStride;

    // kernels
    int16_t kernelHNR;
    // waipio.s2.50
    int16_t kernelBlur;
    int16_t kernelVSE;

    int16_t kernelCAC;
    int16_t kernelChromaUpsample;   // even though the module is always on,  still need to distinguish vertical and horizontal.
    int16_t kernel_ltm_ip_mask_filter;
    int16_t LTMDCEnable;    // for DC collection
    int16_t LTMIPEnable;    // call IP code for striping parameters
    int16_t LTM_MP_Enable;
    int16_t kernel_LtmMp;
    int16_t kernelASF;
    int16_t kernelUpscale;   //  only to pass in the kernel size.  whether to enable or disable is determined by the algorithm
    int16_t chromaUpEnable;         //This affects the data format of a series of modules: there might not be this case in the real world

      int16_t kernelLENR;

    int16_t kernelRNF;
    int16_t kernelCYLPF;
    int16_t kernelFilter2;

    int16_t kernelTF;
    int16_t TFenable;

    int16_t kernelTFDilate;
    int16_t kernelTFErode;
    int16_t kernelTFrefinement;     //this is hidden by the TF kernel but is needed to calculate some coordinate constraints
    int16_t kernelTFLMC;
    int16_t kernelTfLmc[ICA_LMC_CNT];

    int16_t kernel_ds4_dsx_luma;
    int16_t kernel_ds4_dsx_chroma;
    int16_t ds4Enable;
    int16_t dsxEnable;

    //int16_t kernelMfhdrPreMacLeft;   // 2 if unaligned to grid of 4
    int16_t kernelMfhdrMacLeft;      // 12 per MAC (0, 12, or 24)
    int16_t kernelMfhdrMacRight;     // 16 per MAC (0, 16, or 32)
    //int16_t kernelMfhdrPostMacRight; // 2 if unaligned to grid of 4

    int16_t videoDownChromaRoundingOption_h;        //: rounding option
    int16_t videoDownChromaRoundingOption_v;        //: rounding option
    int16_t dispDownChromaRoundingOption_h;     //: rounding option
    int16_t dispDownChromaRoundingOption_v;     //: rounding option
    int16_t appDownChromaRoundingOption_h;        //: rounding option for 3rd APP YUV out
    int16_t appDownChromaRoundingOption_v;        //: rounding option for 3rd APP YUV out

    int32_t ANR_CYLPF_dithering_seed_frame;     //: initial random seed for dithering in CYLPF
    int32_t ANR_dcnf_dithering_seed_frame;      //: initial random seed for dithering in dcnf
    int32_t tf_prngSeed_frame;                  //frame level TF PRNG seed
    int16_t tf_dithering_en;
    int16_t tf_useImgAsMctfpInput;              //during tf blending, the original image is used as the ref in. we therefore doesn't need to configure ref fetch
    int32_t tf_LnrStartIdx_frame;
    int32_t tf_LnrScale;
    int16_t tf_lmenable_currpass;
    int16_t tf_lmenable_prevpass;
    int16_t tf_lmcEnable_currpass[ICA_LMC_CNT];
    int16_t tf_lmcEnable_prevpass[ICA_LMC_CNT];
    TFrefinementInputParams TFrefinementFrame;

    int16_t digitalZoomOverFetch_lt;
    int16_t digitalZoomOverFetch_rb;

    BOOL chromaUp_cosited;
    BOOL chromaUp_even;
    BOOL ANR_dcnf_dithering_y_en;
    BOOL ANR_dcnf_dithering_c_en;
    int16_t upscalarEnable;
    int16_t ltmDCtableOption;
    BOOL is_ltm_ip_enable;
    GRAv10stripingInputParams gra;
    uint16_t upscale_dithering_mode_y;
    uint16_t upscale_dithering_mode_c;
    upscale_v20stripingInputParams1D upscalarIn;
    BOOL forceEvenStripe;
    ICAv10InputParams ica1;
    ICAv10InputParams ica2;
    DsxStripingInput_1D dsx_luma;
    DsxStripingInput_1D dsx_chroma;

    ChromaUpv20StripingInputParams      mfhdr_chroma_up_T1L_MACin1_ICA2;
    ChromaUpv20StripingInputParams      mfhdr_chroma_up_T2M_MACin2_MFHDR_FE;
    ChromaUpv20StripingInputParams      mfhdr_chroma_up_T3S_MACin0_TF;
    MFHDRMACv10StripingInputParams      mfhdr_mac;
    LTMv13StripingInputParams           mfhdr_ltm;
    uint16_t    mfhdr_ltmdc_pass;
    MNDSv20StripingInputParams          mfhdr_chromadn;


    int16_t   npsImageZoomWindow_isZoomEnable;
    int16_t   npsImageZoomWindow_start;
    int16_t   npsImageZoomWindow_size;
    int16_t   npsRefZoomWindow_isZoomEnable;
    int16_t   npsRefZoomWindow_start;
    int16_t   npsRefZoomWindow_size;
    int16_t   npsPrevRefZoomWindow_isZoomEnable;
    int16_t   npsPrevRefZoomWindow_start;
    int16_t   npsPrevRefZoomWindow_size;

    // waipio.s2.50 this needs to get populated with the values in IpeStripingLibraryInput
    BLURv10StripingInputParams          blur;
    VSEv10StripingInputParams           vse;
    HDR10PLUSv10StripingInputParams     hdr10plus;

    //Mimas2.0
    int16_t chromaDsRoundingOption_h;        //: rounding option
    int16_t chromaDsRoundingOption_v;        //: rounding option

    //kailua.s2.50
    CMUSStripingInputParams             cmus;
    STMPStripingInputParams             stmp;
    IpeStripingLibraryInputMuxInfo      Mux;
    SBLURStripingInputParams            sblur;
}
PassInput1D;

typedef struct _NPSPPSPassInput
{
    int32_t smallerPassEnabled;
    int32_t chip;
    PassInput1D horizontalPassIn;
    PassInput1D verticalPassIn;

    ANRLNRInputParams anrlnr;
    //TFLNRInputParams tflnr;
    int16_t mctfFlow; //0: legacy, 1: mixed loop
}
NPSPPSPassInput;

#ifdef __cplusplus
}
#endif

#endif
