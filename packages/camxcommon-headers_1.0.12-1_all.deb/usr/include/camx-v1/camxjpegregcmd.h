////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2021-2022, 2024 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @file  camxjpegregcmd.h
/// @brief camxjpegregcmd struct declarations
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/// @todo (CAMX-1988) Code clean up apply NC001 coding standard on entire project
/// @todo (CAMX-1989) Code clean up apply GR030 coding standard on entire project

#ifndef CAMXJPEGREGCMD_H
#define CAMXJPEGREGCMD_H

#include "titan170_jpeg_encode.h"

CAMX_NAMESPACE_BEGIN

/// @brief This structure encapsulates all possible register values for jpeg encoder.
struct JPEGEncoderRegCmd
{
    JPEG_ENCODE_JPEG_0_RESET_CMD             jpegEncResetCmd; ///< jpeg register
    JPEG_ENCODE_JPEG_0_CORE_CFG              jpegEncCoreCfg;  ///< jpeg register
    JPEG_ENCODE_JPEG_0_IRQ_MASK              jpegEncIRQMask;  ///< jpeg register
    JPEG_ENCODE_JPEG_0_IRQ_CLEAR             jpegEncIRQClear; ///< jpeg register
    JPEG_ENCODE_JPEG_0_FE_CFG                jpegEncFECfg;    ///< jpeg register

    /// FE_BUF_CFG
    JPEG_ENCODE_JPEG_0_PLN0_RD_BUFFER_SIZE   jpegEncPLN0RDBUFFERSIZE;  ///< jpeg register
    JPEG_ENCODE_JPEG_0_PLN0_RD_STRIDE        jpegEncPLN0RDSTRIDE     ; ///< jpeg register
    JPEG_ENCODE_JPEG_0_PLN1_RD_BUFFER_SIZE   jpegEncPLN1RDBUFFERSIZE;  ///< jpeg register
    JPEG_ENCODE_JPEG_0_PLN1_RD_STRIDE        jpegEncPLN1RDSTRIDE     ; ///< jpeg register
    JPEG_ENCODE_JPEG_0_PLN2_RD_BUFFER_SIZE   jpegEncPLNRDBUFFERSIZE;   ///< jpeg register
    JPEG_ENCODE_JPEG_0_PLN2_RD_STRIDE        jpegEncPLN2RDSTRIDE     ; ///< jpeg register
    JPEG_ENCODE_JPEG_0_PLN0_RD_HINIT         jpegEncPLN0RDHINIT      ; ///< jpeg register
    JPEG_ENCODE_JPEG_0_PLN1_RD_HINIT         jpegEncPLN1RDHINIT      ; ///< jpeg register
    JPEG_ENCODE_JPEG_0_PLN2_RD_HINIT         jpegEncPLN2RDHINIT      ; ///< jpeg register
    JPEG_ENCODE_JPEG_0_PLN0_RD_VINIT         jpegEncPLN0RDVINIT      ; ///< jpeg register
    JPEG_ENCODE_JPEG_0_PLN1_RD_VINIT         jpegEncPLN1RDVINIT      ; ///< jpeg register
    JPEG_ENCODE_JPEG_0_PLN2_RD_VINIT         jpegEncPLN2RDVINIT      ; ///< jpeg register

    /// jpege_lib_hw_we_cfg
    JPEG_ENCODE_JPEG_0_WE_CFG                jpegEnc_WE_CFG;    ///< jpeg register

    /// we buffer cfg
    JPEG_ENCODE_JPEG_0_PLN0_WR_BUFFER_SIZE   jpegEnc_PLN0_WR_BUFFER_SIZE; ///< jpeg register
    JPEG_ENCODE_JPEG_0_PLN0_WR_STRIDE        jpegEnc_PLN0_WR_STRIDE     ; ///< jpeg register
    JPEG_ENCODE_JPEG_0_PLN0_WR_HINIT         jpegEnc_PLN0_WR_HINIT      ; ///< jpeg register
    JPEG_ENCODE_JPEG_0_PLN0_WR_VINIT         jpegEnc_PLN0_WR_VINIT      ; ///< jpeg register
    JPEG_ENCODE_JPEG_0_PLN0_WR_HSTEP         jpegEnc_PLN0_WR_HSTEP      ; ///< jpeg register
    JPEG_ENCODE_JPEG_0_PLN0_WR_VSTEP         jpegEnc_PLN0_WR_VSTEP      ; ///< jpeg register
    JPEG_ENCODE_JPEG_0_PLN0_WR_BLOCK_CFG     jpegEnc_PLN0_WR_BLOCK_CFG;   ///< jpeg register

    /// encode cfg
    JPEG_ENCODE_JPEG_0_ENCODE_CFG                 jpegEnc_ENCODE_CFG                ; ///< jpeg register
    JPEG_ENCODE_JPEG_0_ENCODE_IMAGE_SIZE          jpegEnc_ENCODE_IMAGE_SIZE         ; ///< jpeg register
    JPEG_ENCODE_JPEG_0_FE_VBPAD_CFG               jpegEnc_FE_VBPAD_CFG              ; ///< jpeg register
    JPEG_ENCODE_JPEG_0_ENCODE_FSC_REGION_SIZE     jpegEnc_ENCODE_FSC_REGION_SIZE    ; ///< jpeg register
    JPEG_ENCODE_JPEG_0_ENCODE_FSC_BUDGET_0        jpegEnc_ENCODE_FSC_BUDGET_0       ; ///< jpeg register
    JPEG_ENCODE_JPEG_0_ENCODE_FSC_BUDGET_1        jpegEnc_ENCODE_FSC_BUDGET_1       ; ///< jpeg register
    JPEG_ENCODE_JPEG_0_ENCODE_FSC_BUDGET_2        jpegEnc_ENCODE_FSC_BUDGET_2       ; ///< jpeg register
    JPEG_ENCODE_JPEG_0_ENCODE_FSC_BUDGET_3        jpegEnc_ENCODE_FSC_BUDGET_3       ; ///< jpeg register

    /// crop cfg
    JPEG_ENCODE_JPEG_0_PLN0_RD_HINIT_INT        jpegEnc_PLN0_RD_HINIT_INT; ///< jpeg register
    JPEG_ENCODE_JPEG_0_PLN1_RD_HINIT_INT        jpegEnc_PLN1_RD_HINIT_INT; ///< jpeg register
    JPEG_ENCODE_JPEG_0_PLN2_RD_HINIT_INT        jpegEnc_PLN2_RD_HINIT_INT; ///< jpeg register
    JPEG_ENCODE_JPEG_0_PLN0_RD_VINIT_INT        jpegEnc_PLN0_RD_VINIT_INT; ///< jpeg register
    JPEG_ENCODE_JPEG_0_PLN1_RD_VINIT_INT        jpegEnc_PLN1_RD_VINIT_INT; ///< jpeg register
    JPEG_ENCODE_JPEG_0_PLN2_RD_VINIT_INT        jpegEnc_PLN2_RD_VINIT_INT; ///< jpeg register

    /// for both scaling disabled and enabled.
    JPEG_ENCODE_JPEG_0_SCALE_PLN0_HSTEP        jpegEnc_SCALE_PLN0_HSTEP; ///< jpeg register
    JPEG_ENCODE_JPEG_0_SCALE_PLN1_HSTEP        jpegEnc_SCALE_PLN1_HSTEP; ///< jpeg register
    JPEG_ENCODE_JPEG_0_SCALE_PLN2_HSTEP        jpegEnc_SCALE_PLN2_HSTEP; ///< jpeg register
    JPEG_ENCODE_JPEG_0_SCALE_PLN0_VSTEP        jpegEnc_SCALE_PLN0_VSTEP; ///< jpeg register
    JPEG_ENCODE_JPEG_0_SCALE_PLN1_VSTEP        jpegEnc_SCALE_PLN1_VSTEP; ///< jpeg register
    JPEG_ENCODE_JPEG_0_SCALE_PLN2_VSTEP        jpegEnc_SCALE_PLN2_VSTEP; ///< jpeg register

    /// if scaling enabled.
    JPEG_ENCODE_JPEG_0_SCALE_CFG              jpegEncSCALE_CFG;             ///< jpeg register
    JPEG_ENCODE_JPEG_0_SCALE_PLN0_OUTPUT_CFG  jpegEncSCALE_PLN0_OUTPUT_CFG; ///< jpeg register
    JPEG_ENCODE_JPEG_0_SCALE_PLN1_OUTPUT_CFG  jpegEncSCALE_PLN1_OUTPUT_CFG; ///< jpeg register
    JPEG_ENCODE_JPEG_0_SCALE_PLN2_OUTPUT_CFG  jpegEncSCALE_PLN2_OUTPUT_CFG; ///< jpeg register

    /// encode state
    JPEG_ENCODE_JPEG_0_ENCODE_PREDICTION_Y_STATE        jpegEnc_ENCODE_PREDICTION_Y_STATE;      ///< jpeg register
    JPEG_ENCODE_JPEG_0_ENCODE_PREDICTION_C_STATE        jpegEnc_ENCODE_PREDICTION_C_STATE;      ///< jpeg register
    JPEG_ENCODE_JPEG_0_ENCODE_RSM_STATE                 jpegEnc_ENCODE_RSM_STATE;               ///< jpeg register
    JPEG_ENCODE_JPEG_0_ENCODE_PACKER_STATE              jpegEnc_ENCODE_PACKER_STATE;            ///< jpeg register
    JPEG_ENCODE_JPEG_0_ENCODE_BYTE_PACKER_WORD0_STATE   jpegEnc_ENCODE_BYTE_PACKER_WORD0_STATE; ///< jpeg register
    JPEG_ENCODE_JPEG_0_ENCODE_BYTE_PACKER_WORD1_STATE   jpegEnc_ENCODE_BYTE_PACKER_WORD1_STATE; ///< jpeg register
    JPEG_ENCODE_JPEG_0_ENCODE_BYTE_PACKER_WORD2_STATE   jpegEnc_ENCODE_BYTE_PACKER_WORD2_STATE; ///< jpeg register
    JPEG_ENCODE_JPEG_0_ENCODE_BYTE_PACKER_WORD3_STATE   jpegEnc_ENCODE_BYTE_PACKER_WORD3_STATE; ///< jpeg register

    /// qtables set
    JPEG_ENCODE_JPEG_0_DMI_ADDR     jpegEnc_DMI_ADDR;                           ///< jpeg register
    JPEG_ENCODE_JPEG_0_DMI_CFG      jpegEnc_DMI_CFG;                            ///< jpeg register
    JPEG_ENCODE_JPEG_0_DMI_CFG      jpegEnc_DMI_CFG2;                           ///< jpeg register
    JPEG_ENCODE_JPEG_0_DMI_DATA     jpegEnc_DMI_QUANTIZATION_LUMA_DATA[64];     ///< jpeg register
    JPEG_ENCODE_JPEG_0_DMI_DATA     jpegEnc_DMI_QUANTIZATION_CHROMA_DATA[64];   ///< jpeg register

    /// for enque input buffer. fe_buffer_update. fe_ping_update
    JPEG_ENCODE_JPEG_0_CMD              jpegEnc_CMD             ; ///< jpeg register
    JPEG_ENCODE_JPEG_0_PLN0_RD_OFFSET   jpegEnc_PLN0_RD_OFFSET  ; ///< jpeg register
    JPEG_ENCODE_JPEG_0_PLN0_RD_PNTR     jpegEnc_PLN0_RD_PNTR    ; ///< jpeg register
    JPEG_ENCODE_JPEG_0_PLN1_RD_OFFSET   jpegEnc_PLN1_RD_OFFSET  ; ///< jpeg register
    JPEG_ENCODE_JPEG_0_PLN1_RD_PNTR     jpegEnc_PLN1_RD_PNTR    ; ///< jpeg register
    JPEG_ENCODE_JPEG_0_PLN2_RD_OFFSET   jpegEnc_PLN2_RD_OFFSET  ; ///< jpeg register
    JPEG_ENCODE_JPEG_0_PLN2_RD_PNTR     jpegEnc_PLN2_RD_PNTR    ; ///< jpeg register

    /// enque output buffer
    JPEG_ENCODE_JPEG_0_PLN0_WR_PNTR     jpegEnc_PLN0_WR_PNTR;    ///< jpeg register
    JPEG_ENCODE_JPEG_0_PLN1_WR_PNTR     jpegEnc_PLN1_WR_PNTR;    ///< jpeg register
    JPEG_ENCODE_JPEG_0_PLN2_WR_PNTR     jpegEnc_PLN2_WR_PNTR;    ///< jpeg register

    /// only if MMU_Prefetch is enabled.
    JPEG_ENCODE_JPEG_0_S0_MMU_PF_ADDR_MIN   jpegEnc_S0_MMU_PF_ADDR_MIN; ///< jpeg register
    JPEG_ENCODE_JPEG_0_S0_MMU_PF_ADDR_MAX   jpegEnc_S0_MMU_PF_ADDR_MAX; ///< jpeg register
    JPEG_ENCODE_JPEG_0_S1_MMU_PF_ADDR_MIN   jpegEnc_S1_MMU_PF_ADDR_MIN; ///< jpeg register
    JPEG_ENCODE_JPEG_0_S1_MMU_PF_ADDR_MAX   jpegEnc_S1_MMU_PF_ADDR_MAX; ///< jpeg register
    JPEG_ENCODE_JPEG_0_S2_MMU_PF_ADDR_MIN   jpegEnc_S2_MMU_PF_ADDR_MIN; ///< jpeg register
    JPEG_ENCODE_JPEG_0_S2_MMU_PF_ADDR_MAX   jpegEnc_S2_MMU_PF_ADDR_MAX; ///< jpeg register
    JPEG_ENCODE_JPEG_0_S3_MMU_PF_ADDR_MIN   jpegEnc_S3_MMU_PF_ADDR_MIN; ///< jpeg register
    JPEG_ENCODE_JPEG_0_S3_MMU_PF_ADDR_MAX   jpegEnc_S3_MMU_PF_ADDR_MAX; ///< jpeg register

    /// starting offline jpeg encode
    JPEG_ENCODE_JPEG_0_CMD                  jpegEnc_CMD2; ///< jpeg register
};

CAMX_NAMESPACE_END

#endif // CAMXJPEGENCCONFIG_H
