////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright(c) 2008-2010, 2014-2015, 2019 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/*****************************************************************************



 Modified content from IJL sources
 *
 This file is part of the Independent JPEG Group's software.
 *
 The authors make NO WARRANTY or representation, either express or implied,
 with respect to this software, its quality, accuracy, merchantability, or
 fitness for a particular purpose. This software is provided "AS IS", and
 you, its user, assume the entire risk as to its quality and accuracy.
 *
 This software is copyright (C) 1991-1996, Thomas G. Lane.
 All Rights Reserved except as specified below.
 *
 Permission is hereby granted to use, copy, modify, and distribute this
 software (or portions thereof) for any purpose, without fee, subject to
 these conditions:
 (1) If any part of the source code for this software is distributed, then
 this README file must be included, with this copyright and no-warranty
 notice unaltered; and any additions, deletions, or changes to the original
 files must be clearly indicated in accompanying documentation.
 (2) If only executable code is distributed, then the accompanying
 documentation must state that "this software is based in part on the work
 of the Independent JPEG Group".
 (3) Permission for use of this software is granted only if the user accepts
 full responsibility for any undesirable consequences; the authors accept
 NO LIABILITY for damages of any kind.
 *
 These conditions apply to any software derived from or based on the IJG
 code, not just to the unmodified library. If you use our work, you ought
 to acknowledge us.
 *
 Permission is NOT granted for the use of any IJG author's name or company
 name in advertising or publicity relating to this software or products
 derived from it. This software may be referred to only as "the Independent
 JPEG Group's software".
 *
 We specifically permit and encourage the use of this software as the basis
 of commercial products, provided that all warranty or liability claims are
 assumed by the product vendor.
 *
 This file contains a slow-but-accurate integer implementation of the
 forward DCT (Discrete Cosine Transform).
 *
 A 2-D DCT can be done by 1-D DCT on each row followed by 1-D DCT
 on each column. Direct algorithms are also available, but they are
 much more complex and seem not to be any faster when reduced to code.
 *
 This implementation is based on an algorithm described in
 C. Loeffler, A. Ligtenberg and G. Moschytz, "Practical Fast 1-D DCT
 Algorithms with 11 Multiplications", Proc. Int'l. Conf. on Acoustics,
 Speech, and Signal Processing 1989 (ICASSP '89), pp. 988-991.
 The primary algorithm described there uses 11 multiplies and 29 adds.
 We use their alternate method with 12 multiplies and 32 adds.
 The advantage of this method is that no data path contains more than one
 multiplication; this allows a very simple and accurate implementation in
 scaled fixed-point arithmetic, with a minimal number of shifts.

*****************************************************************************/

/*========================================================================
                             Edit History

$Header:

when       who     what, where, why
--------   ---     -------------------------------------------------------
05/20/10   stacyew Added bitstream formats in jpeg color format and subsampling.
09/21/09   mingy   Defined jpeg_rectangle_t structure.
08/03/09   vma     Switched to use the os abstraction layer (os_*)
07/13/09   zhiminl Added new event for aborting.
04/23/09   vma     Added new event where encoded thumbnail is
                   too big and is dropped by the encoder.
03/13/09   leim    Added RGBa color format.
07/07/08   vma     Created file.

========================================================================== */

#ifndef _JPEG_COMMON_H
#define _JPEG_COMMON_H

#include <string.h>
#include "jpegerr.h"
#include <os_int.h>

#include <stdlib.h>

// LUMA BLOCKS
#define H1V1_NUM_LUMA_BLOCKS      1
#define H2V1_NUM_LUMA_BLOCKS      2
#define H1V2_NUM_LUMA_BLOCKS      2
#define H2V2_NUM_LUMA_BLOCKS      4
// Restart Marker
#define BASE_RESTART_MARKER       0xFFD0
#define MAX_RESTART_MARKER_COUNT  8

typedef uint32_t  jpeg_event_t;
// Events common to encoder and decoder
#define JPEG_EVENT_DONE      0
#define JPEG_EVENT_WARNING   1
#define JPEG_EVENT_ERROR     2
#define JPEG_EVENT_ABORTED   3
// Events specific to encoder
#define JPEG_EVENT_THUMBNAIL_DROPPED 4

#define MAX_OUTPUT_BUF 30

typedef uint16_t* jpeg_quant_table_t;
typedef struct
{
    uint8_t bits[17];
    uint8_t values[256];

} jpeg_huff_table_t;

// Holds N discontigous bitstream buffer's offsets, valid range size and total discontigous buffers
typedef struct
{
    uintptr_t bs_buff_offsets[MAX_OUTPUT_BUF];
    uint32_t  bs_buff_sizes[MAX_OUTPUT_BUF];
    uint32_t  n_bs_buff;
}jpeg_dest_buff_info;

#ifndef true
#define true  1
#endif
#ifndef false
#define false 0
#endif

// Color subsampling formats
// Ordering handcrafted for efficient coding, alter with care!
typedef enum
{
    JPEG_H2V2      = 0,
    JPEG_H2V1      = 1,
    JPEG_H1V2      = 2,
    JPEG_H1V1      = 3,
    JPEG_GRAYSCALE = 4,

    JPEG_BS_H2V2      = 6,
    JPEG_BS_H2V1      = 7,
    JPEG_BS_H1V2      = 8,
    JPEG_BS_H1V1      = 9,
    JPEG_YUY2         = 10,
    JPEG_UYVY         = 11,

} jpeg_subsampling_t;

// Possibly supported color formats
// Ordering handcrafted for efficient coding, alter with care!
typedef enum
{
    YCRCBLP_H2V2 = 0,
    YCBCRLP_H2V2 = 1,

    YCRCBLP_H2V1 = 2,
    YCBCRLP_H2V1 = 3,

    YCRCBLP_H1V2 = 4,
    YCBCRLP_H1V2 = 5,

    YCRCBLP_H1V1 = 6,
    YCBCRLP_H1V1 = 7,

    MONOCHROME = 8,

    RGB565 = 9,
    RGB888 = 10,
    RGBa   = 11,

    JPEG_BITSTREAM_H2V2 = 12,
    JPEG_BITSTREAM_H2V1 = 14,
    JPEG_BITSTREAM_H1V2 = 16,
    JPEG_BITSTREAM_H1V1 = 18,

    YUY2 = 20,
    UYVY_T = 22, // adding *_T to avoid conflict in CamX files. Acutal variable name = UYVY

    JPEG_COLOR_FORMAT_MAX,

} jpeg_color_format_t;

typedef enum
{
    NV12,
    NV21,
    IYUV,
    YUV12
} jpeg_memory_format_t;

typedef struct
{
    uint32_t           width;
    uint32_t           height;
    jpeg_subsampling_t subsampling;

} jpeg_frm_info_t;

typedef struct
{
    int32_t left;
    int32_t top;
    int32_t right;
    int32_t bottom;

} jpeg_rectangle_t;

#endif // #ifndef _JPEG_COMMON_H
