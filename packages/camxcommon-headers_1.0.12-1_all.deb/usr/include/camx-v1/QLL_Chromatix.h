// NOWHINE ENTIRE FILE
//-------------------------------------------------------------------------
// Copyright (c) 2020 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
//------------------------------------------------------------------------


#ifndef __QLL_CHROMATIX_H__
#define __QLL_CHROMATIX_H__

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct QLL_TOP_V10_TAG
{
    // QLL enable bit
    // format: 1u
    uint32_t enable;

} QLL_TOP_V10;

typedef struct QLL_CALIBRATION_V10_TAG
{
    // QLL mode is activated if above this lux index value
    // format: float
    float lux_index_for_mode_enable;

    // Lens focal length mm in 35mm eqv. 0 means calculate automatically from device (if exists)
    // format: float
    float lens_focal_length_eqv_mm;

    // Amount of maximum OIS compensation in degrees. 0 means no OIS
    // format: float
    float ois_compensation_range_deg;

    // Gyro's noise floor threshold in radians per second
    // format: float
    float gyro_noise_floor_thresh_rad_per_sec;

    // Maximum MFNR frame count
    // format: 7u
    uint32_t max_mfnr_frame_count;

    // Maximum ZSL frame count to use out of the ZSL buffer. 0 means no MFHDR, -1 means automatic from SW
    // format: 7s
    int32_t max_zsl_buffer_frame_count;

    // Reserved parameter 1
    // format: float
    float res_param_1;

    // Reserved parameter 2
    // format: float
    float res_param_2;

    // Reserved parameter LUT 1
    // format: float
    float res_lut_param_1[32];

    // Reserved parameter LUT 2
    // format: float
    float res_lut_param_2[32];

} QLL_CALIBRATION_V10;

typedef struct QLL_MOTION_AWARENESS_TUNING_V10_TAG
{
    // Maximum duration, in seconds, between 2 sequential QLL captures (shot to shot)
    // format: float
    float requested_max_shot_to_shot_duration_sec;

    // Maximum extra duration (on top of shot-to-shot), in seconds, for background image processing
    // format: float
    float requested_max_processing_duration_overhead_sec;

    // Maximum exposure duration, in seconds, for a single  image (depends on sensor driver)
    // format: float
    float requested_max_single_frame_exp_sec;

    // Utilizes only ZSL frames with sensitivity change factor smaller than this value
    // format: float
    float zsl_aec_change_factor_threshold;

    // The amount of accepted motion blur in the scene in the range from ZSL exposure to max exposure time. 1 means QLL automatic exposure time decision of long frame. 0 means same long exposure time as in ZSL (medium). Interpolation in between.
    // format: float
    float accepted_long_frame_motion_blur;

    // Local motion dominance in motion calculation. 0 means local motion is ignored
    // format: float
    float local_motion_weight;

    // Controls the amount of sensitivity to local motion area
    // format: float
    float local_motion_sensitivity;

    // If the exposure time ratio between ZSL medium and the decided PSL long smaller than this factor, expose long same as ZSL medium
    // format: float
    float expose_long_as_med_factor_threshold;

    // When tripod detected, the maximum duration, in seconds, between 2 sequential QLL captures (shot to shot)
    // format: float
    float tripod_detected_max_shot_to_shot_duration_sec;

    // When tripod detected, the maximum exposure duration, in seconds, for a single  image (depends on sensor driver)
    // format: float
    float tripod_detected_max_single_frame_exp_sec;

    // When tripod detected, the local motion dominance in motion calculation. 0 means local motion is ignored
    // format: float
    float tripod_detected_local_motion_weight;

    // Reserved parameter 3
    // format: float
    float res_param_3;

    // Reserved parameter 4
    // format: float
    float res_param_4;

    // Reserved parameter LUT 3
    // format: float
    float res_lut_param_3[32];

    // Reserved parameter LUT 4
    // format: float
    float res_lut_param_4[32];

} QLL_MOTION_AWARENESS_TUNING_V10;

typedef struct QLL_ML_ISP_TUNING_V10_TAG
{
    // Enable long MFNR post ML ISP noise reduction
    // format: 1u
    uint32_t ml_enable;

    // Controls the amount of noise reduction of the ML node according to temporal filtration amount. Higher value means more noise reduction. 0 means no ML ISP pass. LUT in-values correspond to [1,2,4,8,16,32] frames temporally blended.
    // format: float
    float ml_nr[6];

    // Controls the amount of high frequency retention according to temporal filtration amount. Higher means more retention. LUT in-values correspond to [1,2,4,8,16,32] frames temporally blended.
    // format: float
    float ml_hf[6];

    // Noise reduction factor according to radial distance from image center. 1 means no modification. Higher value is stronger noise reduction.
    // format: float
    float ml_rnr[17];

    // Selects ML weights by this identifier. The value maps to the model weights.
    // format: 8u
    uint32_t ml_model_sel;

    // Reserved parameter 6
    // format: float
    float res_param_5;

    // Reserved parameter 6
    // format: float
    float res_param_6;

    // Reserved parameter LUT 5
    // format: float
    float res_lut_param_5[32];

    // Reserved parameter LUT 6
    // format: float
    float res_lut_param_6[32];

} QLL_ML_ISP_TUNING_V10;

typedef struct QLL_Chromatix_TAG
{
    QLL_TOP_V10 top;
    QLL_CALIBRATION_V10 calibration;
    QLL_MOTION_AWARENESS_TUNING_V10 motion_awareness_tuning;
    QLL_ML_ISP_TUNING_V10 ml_isp_tuning;
} QLL_Chromatix;

// ############ Functions ############
int32_t Validate_QLL_Chromatix( QLL_Chromatix* regStruct );
void SetDefaultVal_QLL_Chromatix( QLL_Chromatix* regStruct );
// ###################################
#ifdef __cplusplus
}
#endif


#endif //__QLL_CHROMATIX_H__

