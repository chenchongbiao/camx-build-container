////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2020-2021, 2024 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @file  camxisppipeline.h
/// @brief ISP pipeline Base Class
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef CAMXISPPIPELINE_H
#define CAMXISPPIPELINE_H

// NOWHINE FILE CP006: used standard libraries
#include <list>
#include "camxcslispdefs.h"
#include "camxdefs.h"
#include "camxhwcontext.h"
#include "camxispiqmodule.h"
#include "camxispstatsmodule.h"
#include "camxcslifedefs.h"
#include "camxcslicpdefs.h"



CAMX_NAMESPACE_BEGIN

/// @todo (CAMX-1117) Update based on BPS IQ module size
const UINT MaxBPSIQModules = 30;                                  ///< Max Number of IQ Modules

static const UINT ICA_MODE_DISABLED  = 0;    ///< IPE ICA mode disabled
static const UINT ICA_MODE_ENABLED   = 1;    ///< IPE ICA mode enabled
static const UINT ICA_MODE_MAX       = 2;    ///< IPE ICA mode max

static const UINT UBWC_MODE_DISABLED = 0;    ///< IPE UBWC mode disabled
static const UINT UBWC_MODE_ENABLED  = 1;    ///< IPE UBWC mode enabled
static const UINT UBWC_MODE_MAX      = 2;    ///< IPE UBWC mode max

/// @brief BPS IQ Module Information
struct BPSIQModuleInfo
{
    ISPIQModuleType moduleType;                                   ///< IQ Module Type
    BOOL            isEnabled;                                    ///< Module Available or not
    CamxResult      (*IQCreate)(BPSModuleCreateData* pInputData); ///< Static create fuction of this IQ Module
    UINT32          moduleVersion;                                ///< Module version of the IQ module
};

/// @brief BPS Capability Information
struct BPSIQModuleList
{
    UINT             numBPSIQModules;                             ///< Number of BPS IQ Modules
    BPSIQModuleInfo* pBPSIQModule[MaxBPSIQModules];               ///< List of BPS IQ Module
};

/// @brief IFE IQ Module Information
struct IFEIQModuleInfo
{
    ISPIQModuleType   moduleType;                                      ///< IQ Module Type
    union
    {
        IFEPipelinePath IFEPath;                                       ///< IFE Path
        SFEPipelinePath SFEPath;                                       ///< SFE Path
    } PipelinePath;
    UINT8             installed;                                       ///< Module Available or not on particular chipset
    CamxResult        (*IQCreate)(IFEModuleCreateData* pInputData);    ///< Static create fuction of this IQ Module
};

/// @brief IFE Stats Module Information
struct IFEStatsModuleInfo
{
    ISPStatsModuleType moduleType;                                              ///< Stats Module Name
    union
    {
        IFEPipelinePath IFEPath;                                                ///< IFE Path
        SFEPipelinePath SFEPath;                                                ///< SFE Path
    } PipelinePath;
    UINT8              installed;                                               ///< Module Available or not on chipset
    CamxResult         (*StatsCreate)(IFEStatsModuleCreateData* pInputData);    ///< Static create fuction of this Stats Module
};

/// @brief IFE Capability Information
struct IFECapabilityInfo
{
    UINT                numIFEIQModule;              ///< Number of IQ Modules
    IFEIQModuleInfo*    pIFEIQModuleList;            ///< List of IQ Module
    UINT                numIFEStatsModule;           ///< Number of Stats Modules
    IFEStatsModuleInfo* pIFEStatsModuleList;         ///< List of Stats Module
    UINT                numRDILinkPerIFE;            ///< Number of RDI Link per IFE
    UINT                numIFE;                      ///< Number of IFE
    UINT32              UBWCSupportedVersionMask;    ///< UBWC supported version
    UBWCLossyMode       UBWCLossySupport;            ///< UBWC Lossy supported
    UINT32              lossy10bitWidth;             ///< Lossy 10 bit width
    UINT32              lossy10bitHeight;            ///< Lossy 10 bit height
    UINT32              lossy8bitWidth;              ///< Lossy 8 bit width
    UINT32              lossy8bitHeight;             ///< Lossy 8 bit height
    UINT32              ICAVersion;                  ///< ICA version;
    BOOL                LDCSupport;                  ///< LDC supported version
};

/// @brief BPS pass name capability information
struct BpsPassNameCapability
{
    BpsPassName       passName;                                   ///< BPS pass name
    BOOL              passSupported;                              ///< pass supported or not
};

/// @brief BPS Capability Information
struct BPSCapabilityInfo
{
    UINT32                  UBWCSupportedVersionMask;    ///< UBWC supported version
    UBWCLossyMode           UBWCLossySupport;            ///< UBWC lossy support
    UINT32                  ICAVersion;                  ///< ICA version;
    BOOL                    LDCSupport;                  ///< LDC supported version
    SWTMCVersion            tmcversion;                  ///< TMC version
    FLOAT                   frameCyclesMaxPerSecond;     ///< Max pixel throughput per second
    BOOL                    isSRSupprted;                       ///< if bps supports the SR
    BpsPassNameCapability*  pBpsPassNameCapability;      ///< List of capable BPS passes for this hw version
};

/// @brief IPE IQ Module Information
struct IPEIQModuleInfo
{
    ISPIQModuleType   moduleType;                                   ///< IQ Module Type
    IPEPath           path;                                         ///< IPE path indicating IQ module flow
    BOOL              installed;                                    ///< Module Available or not
    CamxResult        (*IQCreate)(IPEModuleCreateData* pInputData); ///< Static create fuction of this IQ Module
};

/// @brief IPE ICA transofrm info
struct IPEICATransformInfo
{
    BOOL             isEnable;                  ///< Transform enable flag
    CamxMetadataType metaDataType;              ///< Metadata type
    UINT             portSpecificMetaPortId;    ///< Input port id if metdata type is PSM
    UINT8            ICATagIndex;               ///< ICA tag index
};

/// @brief IPE ICA usecase info
struct IPEICAUsecaseInfo
{
    UINT32              usecaseMask;            ///< Usecase Mask
    IPEICATransformInfo inGrid;                 ///< Input grid transform info
    IPEICATransformInfo inPerspective;          ///< Input perspective transform info
    IPEICATransformInfo inGridStabilize;        ///< Input grid stabilization transform info
    IPEICATransformInfo inPerspectiveStabilize; ///< Input perspective stabilization transform info
    IPEICATransformInfo refGrid;                ///< Ref Grid transform info
    IPEICATransformInfo refPerspective;         ///< Ref perspective transform info
    IPEICATransformInfo referenceMCTFImage;     ///< Reference MCTF Image alignement
    IPEICATransformInfo referenceMCTFGyro;      ///< Reference MCTF gyro alignement
};

/// @brief IPE ICA usecase selection data
struct IPEICAUsecaseSelectionData
{
    BOOL    isLoopbackPortEnabled;              ///< Is Loop back port enalbe flag
    BOOL    isNonEISLDCGridEnabled;             ///< Is Non EIS LDC grid enabled flag
    BOOL    isStabilizationTypeSAT;             ///< Is stabilization type SAT
    BOOL    isStabilizationTypeEIS2;            ///< Is stabilization type EIS2
    BOOL    isStabilizationTypeEIS3;            ///< Is stabilization type EIS3
    BOOL    isBlendWithNPS;                     ///< Is MFSR/MFNR blending mode with NPS
    BOOL    isPostfilterWithNPS;                ///< Is MFSR/MFNR post filter with NPS
    BOOL    isRealtimeIPE;                      ///< Is realtime IPE
    UINT32  numMFHDRExposure;                   ///< Num exposures in MFHDR
    BOOL    isTFIOnlyPortEnabled;               ///< Is TFI Only IPE Port is enabled
    BOOL    isANROnlyPortEnabled;               ///< Is ANR Only IPE Port is enabled
    BOOL    isOEMICASettingEnabled;             ///< Is OEM ICA setting enabled
};

/// @brief IPE Capability Information
struct IPECapabilityInfo
{
    const IPEIQModuleInfo*  pIPEIQModuleList;                       ///< List of IQ Module
    UINT                    numIPEIQModules;                        ///< Number of IQ Modules
    const IPEIQModuleInfo*  pIPEExtraPassIQModuleList;              ///< List of IQ Module
    UINT                    numIPEExtraPassIQModules;               ///< Number of IQ Modules
    const IPEIQModuleInfo*  pIPEUpScaleExtraPassIQModuleList;       ///< List of IQ Module
    UINT                    numUpScaleIPEExtraPassIQModules;        ///< Number of IQ Modules
    UINT                    numIPE;                                 ///< Number of IPE
    UINT                    maxOutputPorts;                         ///< Max number of output ports supported
    UINT                    maxInputPorts;                          ///< Max number of input ports supported
    UINT                    maxInputWidth[ICA_MODE_MAX];            ///< Max IPE input  width
    UINT                    maxInputHeight[ICA_MODE_MAX];           ///< Max IPE input  height
    UINT                    maxOutputWidth;                         ///< Max IPE output width
    UINT                    maxOutputHeight;                        ///< Max IPE output height
    UINT                    minInputWidth;                          ///< Min IPE input  width
    UINT                    minInputHeight;                         ///< Min IPE input  height
    UINT                    minOutputWidth;                         ///< Min IPE output width
    UINT                    minOutputHeight;                        ///< Min IPE output width
    UINT                    minOutputWidthUBWC10bit;                ///< Min IPE output width for UBWC 10 bit format
    UINT                    minOutputHeightUBWC10bit;               ///< Min IPE output height for UBWC 10 bit format
    UINT                    minOutputWidthUBWC8bit;                 ///< Min IPE output width for UBWC 8 bit format
    UINT                    minOutputHeightUBWC8bit;                ///< Min IPE output height for UBWC 8 bit format
    UBWCLossyMode           UBWCLossySupport;                       ///< UBWC Lossy supported
    UINT32                  UBWCSupportedVersionMask;               ///< UBWC supported version
    UINT32                  lossy10bitWidth;                        ///< Lossy 10 bit width
    UINT32                  lossy10bitHeight;                       ///< Lossy 10 bit height
    UINT32                  lossy8bitWidth;                         ///< Lossy 8 bit width
    UINT32                  lossy8bitHeight;                        ///< Lossy 8 bit height
    UINT32                  ICAVersion;                             ///< ICA version;
    UINT32                  ICAGridGeometryRows;                    ///< Grid geometry rows
    UINT32                  ICAGridGeometryColumns;                 ///< Grid geometry columns
    BOOL                    disableLENRDS4Buffer;                   ///< LENR supported version
    BOOL                    LENRSupport;                            ///< LENR supported version
    BOOL                    referenceLookaheadTransformSupported;   ///< Ref Lookahead Transform support
    BOOL                    swStriping;                             ///< Striping done in UMD
    BOOL                    LDCSupport;                             ///< LDC supported version
    BOOL                    MFHDRSupport;                           ///< MFHDR supported platform
    BOOL                    isPostfilterWithBlend;                  ///< Flag to check if MFNR Postfilter has Blend stage
    BOOL                    IPEDSXSupport;                          ///< Flag to check if IPE has DSX in the plaform
    FLOAT                   maxUpscale[UBWC_MODE_MAX];              ///< Max upscale limit
    FLOAT                   maxDownscale[UBWC_MODE_MAX];            ///< Max downscale limit
    FLOAT                   realtimeClockEfficiencyNoOverhead;      ///< realtime clock Efficiency no overhead
    FLOAT                   nonrealtimeClockEfficiencyNoOverhead;   ///< non real time clock Efficiency no overhead
    FLOAT                   realtimeClockEfficiencyOverhead;        ///< realtime clock Efficiency overhead
    FLOAT                   nonrealtimeClockEfficiencyOverhead;     ///< non real time clock Efficiency Overhead
    BOOL                    hasMFlimit;                             ///< Flag to check MF processing resolution limit
    UINT                    numIPEICAUsecases;                      ///< Number of ICA usecase
    FLOAT                   maxDownScaleThreshold;                  ///< Max scaleratio below which downscale causes IQ issues
    FLOAT                   minUpscaleThreshold;                    ///< Min scaleratio above which upscale causes IQ issues
    IPEICAUsecaseInfo*      pIPEICAUsecaseList;                     ///< IPE ICA usecase list
    BOOL                    supportQLL;                             ///< whether support QLL library
    FLOAT                   nonrealtimeFrameCyclesMaxPerSecond;     ///< max pixel throughput per second
    UINT                    minLTMWidth;                            ///< min LTM Width
    UINT                    minLTMHeight;                           ///< min LTM Height
};

/// @brief TFE IQ Module Information
struct TFEIQModuleInfo
{
    ISPIQModuleType   moduleType;                                      ///< IQ Module Type
    TFEPipelinePath   TFEPath;                                         ///< TFE pipeline path
    UINT8             installed;                                       ///< Module Available or not on particular chipset
    CamxResult        (*IQCreate)(TFEModuleCreateData* pInputData);    ///< Static create fuction of this IQ Module
};

/// @brief TFE Stats Module Information
struct TFEStatsModuleInfo
{
    ISPStatsModuleType moduleType;                                              ///< Stats Module Name
    UINT8              installed;                                               ///< Module Available or not on chipset
    CamxResult         (*StatsCreate)(TFEStatsModuleCreateData* pInputData);    ///< Static create fuction of this Stats Module
};

/// @brief TFE Capability Information
struct TFECapabilityInfo
{
    UINT                numTFEIQModule;            ///< Number of IQ Modules
    TFEIQModuleInfo*    pTFEIQModuleList;          ///< List of IQ Module
    UINT                numTFEStatsModule;         ///< Number of Stats Modules
    TFEStatsModuleInfo* pTFEStatsModuleList;       ///< List of Stats Module
    UINT                numRDILinkPerTFE;          ///< Number of RDI Link per TFE
    UINT                numTFE;                    ///< Number of TFE
};

/// @brief IPE IQ Module Information
struct OPEIQModuleInfo
{
    ISPIQModuleType   moduleType;                                   ///< IQ Module Type
    OPEPipelinePath   path;                                         ///< OPE path indicating if it is input or reference
    BOOL              installed;                                    ///< Module Available or not
    CamxResult        (*IQCreate)(OPEModuleCreateData* pInputData); ///< Static create fuction of this IQ Module
};

/// @brief OPE Stats Module Information
struct OPEStatsModuleInfo
{
    ISPStatsModuleType moduleType;                                              ///< Stats Module Name
    UINT8              installed;                                               ///< Module Available or not on chipset
    CamxResult         (*StatsCreate)(OPEStatsModuleCreateData* pInputData);    ///< Static create fuction of this Stats Module
};

/// @brief OPE Capability Information
struct OPECapabilityInfo
{
    OPEIQModuleInfo*    pOPEIQModuleList;                            ///< List of IQ Module
    OPEStatsModuleInfo* pOPEStatsModuleList;                         ///< List of Stats Module
    UINT                numOPEIQModules;                             ///< Number of IQ Modules
    UINT                numOPEStatsModules;                          ///< Number of Stats Modules
    UINT                numOPE;                                      ///< Number of OPE
    UINT                maxInputWidth;                               ///< Max OPE input  width
    UINT                maxInputHeight;                              ///< Max OPE input  height
    UINT                maxOutputWidth;                              ///< Max OPE output width
    UINT                maxOutputHeight;                             ///< Max OPE output height
    UINT                minInputWidth;                               ///< Min OPE input  width
    UINT                minInputHeight;                              ///< Min OPE input  height
    UINT                minOutputWidth;                              ///< Min OPE output width
    UINT                minOutputHeight;                             ///< Min OPE output width
    FLOAT               maxUpscale;                                  ///< Max upscale limit
    FLOAT               maxDownscale;                                ///< Max downscale limit
    FLOAT               realtimeClockEfficiency;                     ///< realtime clock Efficiency
    FLOAT               nonrealtimeClockEfficiency;                  ///< non real time clock Efficiency
};

/// @brief CPAS TOP Register Information
struct CPASTopRegInfo
{
    UINT            generationShift;    ///< CPAS TOP register Generation shift
    UINT            tierShift;          ///< CPAS TOP register Tier shift
    UINT            titanStepShift;     ///< CPAS TOP register Titan step shift
    UINT            majorShift;         ///< CPAS TOP register major shift
    UINT            minorShift;         ///< CPAS TOP register minor shift
    UINT            hwStepShift;        ///< CPAS TOP register HW step shift
    UINT            capabilityIPE0Mask; ///< CPAS TOP register capability IPE_0 Mask
    UINT            capabilityIPE1Mask; ///< CPAS TOP register capability IPE_1 Mask
    UINT            opeMask;            ///< TOP register OPE Mask
    UINT            tfe0Mask;           ///< TOP register TFE_0 Mask
    UINT            tfe1Mask;           ///< TOP register TFE_1 Mask
    UINT            tfe2Mask;           ///< TOP register TFE_2 Mask
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief Base Class for all the ISP Pipeline setup
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
class ISPPipeline
{
public:
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetModuleList
    ///
    /// @brief  Function to be implemented to get the pipleine capability
    ///
    /// @param  pIQmoduleInfo structure into which capability info is filled
    ///
    /// @return CamxResult
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual CamxResult GetModuleList(
                BPSIQModuleList* pIQmoduleInfo)
    {
        CAMX_UNREFERENCED_PARAM(pIQmoduleInfo);

        return CamxResultSuccess;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetModuleListForMode
    ///
    /// @brief  Function to be implemented to get the pipleine capability in mode requested
    ///
    /// @param  pIQmoduleInfo structure into which capability info is filled
    /// @param  mode          returns the capability in this mode
    ///
    /// @return CamxResult
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual CamxResult GetModuleListForMode(
                BPSIQModuleList* pIQmoduleInfo,
                UINT32 mode);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// FetchPipelineCapability
    ///
    /// @brief  Update the ISP pipeline capability
    ///
    /// @return Poiter to the Capbility Structure
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    CAMX_INLINE VOID* FetchPipelineCapability()
    {
        return m_pCapability;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// SetPipelineCapability
    ///
    /// @brief  Helper method to set PipelineCapability
    ///
    /// @param  pCapability Pointer to the Capability Structure
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    CAMX_INLINE VOID SetPipelineCapability(
        VOID* pCapability)
    {
        m_pCapability = pCapability;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// ProgramIQModuleEnableConfig
    ///
    /// @brief  Reprogram the Module enable settings for the IQ Modules
    ///
    /// @param  pInputData          Pointer to the input data
    /// @param  pISPData            Pointer to the ISP internal data
    /// @param  pIFEOutputPathInfo  Pointer to the IFE output path data
    ///
    /// @return CamxResult True on successful execution else False on failure
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual CamxResult ProgramIQModuleEnableConfig(
        ISPInputData*       pInputData,
        ISPInternalData*    pISPData,
        IFEOutputPath*      pIFEOutputPathInfo)
    {
        CAMX_UNREFERENCED_PARAM(pInputData);
        CAMX_UNREFERENCED_PARAM(pISPData);
        CAMX_UNREFERENCED_PARAM(pIFEOutputPathInfo);
        return CamxResultSuccess;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetISPIQModulesOfType
    ///
    /// @brief  Get ISP IQ module
    ///
    /// @param  moduleType  Module type
    /// @param  pModuleInfo Pointer to the module info
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual VOID GetISPIQModulesOfType(
        ISPIQModuleType moduleType,
        VOID*           pModuleInfo)
    {
        CAMX_UNREFERENCED_PARAM(moduleType);
        CAMX_UNREFERENCED_PARAM(pModuleInfo);
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// DumpTuningMetadata
    ///
    /// @brief  Helper to publish tuning metadata
    ///
    /// @param  pInputData          Pointer to the input data
    /// @param  pDebugDataWriter    Pointer to tuning-data writer
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual VOID DumpTuningMetadata(
        ISPInputData*       pInputData,
        DebugDataWriter*    pDebugDataWriter)
    {
        CAMX_UNREFERENCED_PARAM(pInputData);
        CAMX_UNREFERENCED_PARAM(pDebugDataWriter);
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// FillFlushConfig
    ///
    /// @brief  Helper function to fill the Flush Config
    ///
    /// @param  pCmdBuffer Pointer to the command buffer
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual VOID FillFlushConfig(
        CmdBuffer*  pCmdBuffer)
    {
        CAMX_UNREFERENCED_PARAM(pCmdBuffer);
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetICPClockAndBandWidthConfigurationVersion
    ///
    /// @brief  Helper to Get BandWidth configuration
    ///
    /// @return ICPBWconfiguration
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual UINT32 GetICPClockAndBandWidthConfigurationVersion()
    {
        return CSLICPGenericBlobCmdBufferClkV2;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// SetupCoreConfig
    ///
    /// @brief  Helper function to setup Core Config
    ///
    /// @param  pCmdBuffer      Pointer to the command buffer
    /// @param  pStatsTapOut    Pointer to stats tap-out config
    /// @param  pCfg            Pointer to the Core Config Structure
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual CamxResult SetupCoreConfig(
        CmdBuffer*      pCmdBuffer,
        IFEStatsTapOut* pStatsTapOut,
        VOID*           pCfg)
    {
        CAMX_UNREFERENCED_PARAM(pCmdBuffer);
        CAMX_UNREFERENCED_PARAM(pStatsTapOut);
        CAMX_UNREFERENCED_PARAM(pCfg);

        return CamxResultSuccess;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// UpdateModuleConfig
    ///
    /// @brief  Helper function to update module Config data
    ///
    /// @param  pCmdBuffer      Pointer to the command buffer
    /// @param  portID          Port ID
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual CamxResult UpdateModuleConfig(
        CmdBuffer*      pCmdBuffer,
        UINT            portID)
    {
        CAMX_UNREFERENCED_PARAM(pCmdBuffer);
        CAMX_UNREFERENCED_PARAM(portID);

        return CamxResultSuccess;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// FillCGCConfig
    ///
    /// @brief  Helper function to fill the CGC Config
    ///
    /// @param  pCmdBuffer Pointer to the command buffer
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual VOID FillCGCConfig(
        CmdBuffer*  pCmdBuffer)
    {
        CAMX_UNREFERENCED_PARAM(pCmdBuffer);
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// UpdateWMConfig
    ///
    /// @brief  Helper function to Update WM Config
    ///
    /// @param  pCmdBuffer      Pointer to the command buffer
    /// @param  pCalculatedData Pointer to the ISPInetnalData Structure
    ///
    /// @return CamxResultSuccess if success
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual CamxResult UpdateWMConfig(
        CmdBuffer*       pCmdBuffer,
        ISPInternalData* pCalculatedData)
    {
        CAMX_UNREFERENCED_PARAM(pCmdBuffer);
        CAMX_UNREFERENCED_PARAM(pCalculatedData);

        return CamxResultSuccess;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetISPAcquireInputInfoVersion
    ///
    /// @brief  Helper Function to Get ISPAcquireInputVersion
    ///
    /// @return UINT32
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual CAMX_INLINE UINT32 GetISPAcquireInputInfoVersion()
    {
        return ISPAcquireInputVersion1;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetISPAcquireCommonInfoVersion
    ///
    /// @brief  Helper Function to Get ISPAcquireInputVersion
    ///
    /// @return UINT32
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual CAMX_INLINE UINT32 GetISPAcquireCommonInfoVersion()
    {
        return ISPAcquireCommonVersion1;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetAcquireHWStructVersion
    ///
    /// @brief  Helper Function to Get ISPAcquireInputVersion
    ///
    /// @return UINT32
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual CAMX_INLINE UINT32 GetAcquireHWStructVersion()
    {
        return CSLAcquiredDeviceVersion1;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetIFEDefaultConfig
    ///
    /// @brief  Helper to populate default IFE configuration for IFE modules
    ///
    /// @param  pDefaultData    Pointer to the data to be use as default for IFE modules that differ from version to version
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual VOID GetIFEDefaultConfig(
        IFEDefaultModuleConfig* pDefaultData)
    {
        CAMX_UNREFERENCED_PARAM(pDefaultData);
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetOPEDefaultConfig
    ///
    /// @brief  Helper to populate default OPE configuration for OPE modules
    ///
    /// @param  pDefaultData    Pointer to the data to be use as default for OPE modules that differ from version to version
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual VOID GetOPEDefaultConfig(
        OPEDefaultModuleConfig* pDefaultData)
    {
        CAMX_UNREFERENCED_PARAM(pDefaultData);
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetCPASTopRegInfo
    ///
    /// @brief  Helper to get CPAS Register Info
    ///
    /// @param  pTopRegInfo    Pointer to the Top register data
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    static VOID GetCPASTopRegInfo(
        VOID* pTopRegInfo);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetCapability
    ///
    /// @brief  virtual method to get the isp pipeline capability
    ///
    /// @param  pCapabilityInfo Pointer to the structure into which capability info is filled
    ///
    /// @return CamxResult
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual CamxResult GetCapability(
        VOID* pCapabilityInfo)
    {
        CAMX_UNREFERENCED_PARAM(pCapabilityInfo);

        return CamxResultSuccess;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetPDHWCapability
    ///
    /// @brief  virtual method to get the isp pipeline PDHW capability
    ///
    /// @param  pCapabilityInfo Pointer to the structure into which capability info is filled
    /// @param  profileID       IFE node profile
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual VOID GetPDHWCapability(
        PDHwAvailablity* pCapabilityInfo,
        IFEProfileId     profileID)
    {
        CAMX_UNREFERENCED_PARAM(profileID);

        if (NULL != pCapabilityInfo)
        {
            pCapabilityInfo->isDualPDHwAvailable    = FALSE;
            pCapabilityInfo->isLCRHwAvailable       = FALSE;
            pCapabilityInfo->isSparsePDHwAvailable  = FALSE;
        }
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// StopPathAtCSIDFrameBoundary
    ///
    /// @brief  virtual method to Stop CSID at Frame boundary
    ///
    /// @param  pathInfo       IFE Output Path
    /// @param  pCmdBuffer     Pointer to the command buffer
    ///
    /// @return CamxResult
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual CamxResult StopPathAtCSIDFrameBoundary(
        UINT       pathInfo,
        CmdBuffer* pCmdBuffer)
    {
        CAMX_UNREFERENCED_PARAM(pathInfo);
        CAMX_UNREFERENCED_PARAM(pCmdBuffer);

        return CamxResultSuccess;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// ResumePathAtCSIDFrameBoundary
    ///
    /// @brief  virtual method to Stop CSID at Frame boundary
    ///
    /// @param  pathInfo       IFE Output Path
    /// @param  pCmdBuffer     Pointer to the command buffer
    ///
    /// @return CamxResult
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual CamxResult ResumePathAtCSIDFrameBoundary(
        UINT       pathInfo,
        CmdBuffer* pCmdBuffer)
    {
        CAMX_UNREFERENCED_PARAM(pathInfo);
        CAMX_UNREFERENCED_PARAM(pCmdBuffer);

        return CamxResultSuccess;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// SetupFlushRegDump
    ///
    /// @brief  virtual method to setup ISP Register Dump structures
    ///
    /// @param  pFlushBuffer Pointer to the flush dump Buffer
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual VOID SetupFlushRegDump(
        VOID* pFlushBuffer)
    {
        CAMX_UNREFERENCED_PARAM(pFlushBuffer);
        return;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// ParseFlushRegDump
    ///
    /// @brief  virtual method to parse ISP Register Dump structures
    ///
    /// @param  pFlushBuffer Pointer to the flush dump Buffer
    /// @param  pBankUpdate  Pointer to the DMI Bank Update
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual VOID ParseFlushRegDump(
        VOID*             pFlushBuffer,
        VOID*             pBankUpdate)
    {
        CAMX_UNREFERENCED_PARAM(pFlushBuffer);
        CAMX_UNREFERENCED_PARAM(pBankUpdate);
        return;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// UpdateDMIBankSelectValue
    ///
    /// @brief  virtual method to update DMI bank select to a given value
    ///
    /// @param  pBankUpdate     Pointer to the DMI Bank Update
    /// @param  isBankValueZero True if the DMI bank to be updated to bank zero
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual VOID UpdateDMIBankSelectValue(
        VOID* pBankUpdate,
        BOOL  isBankValueZero)
    {
        CAMX_UNREFERENCED_PARAM(pBankUpdate);
        CAMX_UNREFERENCED_PARAM(isBankValueZero);
        return;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// SetupHangRegDump
    ///
    /// @brief  virtual method to setup ISP Register Dump structures
    ///
    /// @param  pHangBuffer     Pointer to the hang dump Buffer
    /// @param  p_mode          IFE/TFE mode
    /// @param  isPerFrameDump  indicator for per frame dump
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual VOID SetupHangRegDump(
        VOID*         pHangBuffer,
        VOID*         p_mode,
        BOOL          isPerFrameDump)
    {
        CAMX_UNREFERENCED_PARAM(pHangBuffer);
        CAMX_UNREFERENCED_PARAM(isPerFrameDump);
        CAMX_UNREFERENCED_PARAM(p_mode);
        return;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// ParseHangRegDump
    ///
    /// @brief  Helper method to parse ISP Register Dump structures
    ///
    /// @param  pHangBuffer Pointer to the flush dump Buffer
    /// @param  leftHangFd  file descriptor fd for left Stripe
    /// @param  rightHangFd file descriptor fd for right Stripe
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual VOID ParseHangRegDump(
        VOID* pHangBuffer,
        INT   leftHangFd,
        INT   rightHangFd)

    {
        CAMX_UNREFERENCED_PARAM(pHangBuffer);
        CAMX_UNREFERENCED_PARAM(leftHangFd);
        CAMX_UNREFERENCED_PARAM(rightHangFd);
        return;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetFlushDumpBufferSize
    ///
    /// @brief  Helper method to return size of the Flush Bump
    ///
    /// @return Size of the Dump buffer
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    UINT32 GetFlushDumpBufferSize()
    {
        return m_flushDumpBufferSizeBytes;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// SetFlushDumpBufferSize
    ///
    /// @brief  Helper method to set Flush Dump Buffer Size
    ///
    /// @param  sizeBytes size of the buffer in bytes
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    VOID SetFlushDumpBufferSize(
        UINT32 sizeBytes)
    {
        m_flushDumpBufferSizeBytes = sizeBytes;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetCGCNumRegs
    ///
    /// @brief  Helper method to get CGC Num Regs
    ///
    /// @return CGC reg
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    UINT GetCGCNumRegs();

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// IFEPartialTileInfo
    ///
    /// @brief  Helper method to set IFE Partial Tile Regs
    ///
    /// @param  rIFELeftPartialTileShift  holds the value of Left Partial Tile Shift
    /// @param  rIFELeftPartialTileMask   holds the value of Left Partial Tile Mask
    /// @param  rIFERightPartialTileShift holds the value of Right Partial Tile Shift
    /// @param  rIFERightPartialTileMask  holds the value of Right Partial Tile Mask
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    static VOID IFEPartialTileInfo(
        UINT& rIFELeftPartialTileShift,
        UINT& rIFELeftPartialTileMask,
        UINT& rIFERightPartialTileShift,
        UINT& rIFERightPartialTileMask);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetHangDumpBufferSize
    ///
    /// @brief  Helper method to return size of the Hang Dump
    ///
    /// @return Size of the Dump buffer
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    UINT32 GetHangDumpBufferSize()
    {
        return m_hangDumpBufferSizeBytes;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetIFEBUSWRVersion
    ///
    /// @brief  Helper method to return IFE BUS Version
    ///
    /// @return IFE BUS Write Master Version
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual IFEBusWriteHWVersion GetIFEBUSWRVersion()
    {
        // returning invalid for So that All IFE Pipelines will implement
        return IFEBusWriteHWInvalid;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetInSensorZoomPDSkipCount
    ///
    /// @brief  Helper Function to Get InSensorZoomPDSkipCount
    ///
    /// @return UINT32
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual UINT32 GetInSensorZoomPDSkipCount()
    {
        return 0;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// SetHangDumpBufferSize
    ///
    /// @brief  Sets the buffer size of the Hang Dump
    ///
    /// @param  sizeBytes size of the buffer in bytes
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    VOID SetHangDumpBufferSize(
        UINT sizeBytes)
    {
        m_hangDumpBufferSizeBytes = sizeBytes;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetRegDumpBufferSize
    ///
    /// @brief  Helper method to return size of the Per frame Reg Dump
    ///
    /// @return Size of the Dump bfer
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    UINT32 GetRegDumpBufferSize()
    {
        return m_regDumpBufferSizeBytes;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// SetRegDumpBufferSize
    ///
    /// @brief  Helper method to set size of the Per frame Reg Dump
    ///
    /// @param  sizeBytes size of the buffer in bytes
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    VOID SetRegDumpBufferSize(
        UINT32 sizeBytes)
    {
        CAMX_LOG_VERBOSE(CamxLogGroupISP, "Reg Dump  Size = %d", sizeBytes);
        m_regDumpBufferSizeBytes = sizeBytes;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetBFHWCapability
    ///
    /// @brief  virtual method to get the isp pipeline BF HW capability
    ///
    /// @param  pCapabilityInfo Pointer to the structure into which capability info is filled
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual VOID GetBFHWCapability(
        AFBAFHardwareCapability* pCapabilityInfo)
    {
        if (NULL != pCapabilityInfo)
        {
            pCapabilityInfo->windowType    = AFFloatingWindow;
        }
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetUBWCModeConfig
    ///
    /// @brief  Helper function to get UBWC mode Config
    ///
    /// @param  pImageFormat  Imageformat pointer
    /// @param  planeIndex    planeIndex of a format
    ///
    /// @return modeConfig value
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual UINT32 GetUBWCModeConfig(
        const ImageFormat* pImageFormat,
        UINT32 planeIndex)
    {
        return ImageFormatUtils::GetUBWCModeConfig(pImageFormat, planeIndex);
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetUBWCPackerConfig
    ///
    /// @brief  Helper function to get UBWC Packer Config
    ///
    /// @param  pImageFormat   Imageformat pointer
    /// @param  pPackerConfig  pPackerConfig pointer
    ///
    /// @return CamxResult
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual CamxResult GetUBWCPackerConfig(
        const ImageFormat* pImageFormat,
        UINT32* pPackerConfig)
    {
        CamxResult result = CamxResultSuccess;
        *pPackerConfig = 0;
        switch (pImageFormat->format)
        {
            case Format::UBWCTP10:
                *pPackerConfig = 0xb;
                break;
            case Format::UBWCNV124R:
                *pPackerConfig = 0xe;
                break;
            default:
                CAMX_LOG_ERROR(CamxLogGroupISP, "Invalid UBWC format: %d",
                    pImageFormat->format);
                result = CamxResultEFailed;
                break;
        }
        return result;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetIFEBandWidthConfigurationVersion
    ///
    /// @brief  Helper to Get BandWidth configuration
    ///
    /// @return IFEBWconfiguration
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual UINT32 GetIFEBandWidthConfigurationVersion()
    {
        return IFEGenericBlobTypeResourceBWConfigV2;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetBPSSWNRMModuleVersion
    ///
    /// @brief  Get BPS SW NRM version from module info
    ///
    /// @param  pModuleInfo     Pointer to BPS module info
    ///
    /// @return SW NRM version of the module in this pipeline
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual SWNRMVersion GetBPSSWNRMModuleVersion(
        BPSIQModuleInfo* pModuleInfo)
    {
        CAMX_UNREFERENCED_PARAM(pModuleInfo);

        // Return invalid by default. All BPS pipelines supporting a specific NRM version must override this virtual function.
        return SWNRMVersion::NRMInvalid;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetIFESWNRMModuleVersion
    ///
    /// @brief  Get IFE SW NRM version from module info
    ///
    /// @param  pModuleInfo     Pointer to IFE module info
    ///
    /// @return SW NRM version of the module in this pipeline
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual SWNRMVersion GetIFESWNRMModuleVersion(
        IFEIQModuleInfo* pModuleInfo)
    {
        CAMX_UNREFERENCED_PARAM(pModuleInfo);

        // Return invalid by default. All IFE pipelines supporting a specific NRM version must override this virtual function.
        return SWNRMVersion::NRMInvalid;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetBPSSWTMCModuleVersion
    ///
    /// @brief  Get BPS SW TMC version from module info
    ///
    /// @param  pModuleInfo     Pointer to BPS module info
    ///
    /// @return SW TMC version of the module in this pipeline
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual SWTMCVersion GetBPSSWTMCModuleVersion(
        BPSIQModuleInfo* pModuleInfo)
    {
        CAMX_UNREFERENCED_PARAM(pModuleInfo);

        // Return invalid by default. All BPS pipelines supporting a specific TMC version must override this virtual function.
        return SWTMCVersion::TMCInvalid;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetIFESWTMCModuleVersion
    ///
    /// @brief  Get IFE SW TMC version from module info
    ///
    /// @param  pModuleInfo     Pointer to IFE module info
    ///
    /// @return SW TMC version of the module in this pipeline
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual SWTMCVersion GetIFESWTMCModuleVersion(
        IFEIQModuleInfo* pModuleInfo)
    {
        CAMX_UNREFERENCED_PARAM(pModuleInfo);

        // Return invalid by default. All IFE pipelines supporting a specific TMC version must override this virtual function.
        return SWTMCVersion::TMCInvalid;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// UseGeoLib
    ///
    /// @brief  Decides GeoLib is needed for this pipeline
    ///
    /// @return BOOL
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual BOOL UseGeoLib()
    {
        return FALSE;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// SetTitanChipVersion
    ///
    /// @brief  Set Titan Chip set version
    ///
    /// @param  titanChipVersion  titan chip set version
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    VOID SetTitanChipVersion(
        CSLCameraTitanChipVersion titanChipVersion)
    {
        m_titanChipVersion = titanChipVersion;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetTitanChipVersion
    ///
    /// @brief  Helper to Get Titan Chip version
    ///
    /// @return CSLCameraTitanChipVersion
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    CSLCameraTitanChipVersion GetTitanChipVersion()
    {
        return m_titanChipVersion;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetRegCmdSize
    ///
    /// @brief  Helper to Get Rgeister Command size needed for this pipeline in DWRDS
    ///
    /// @return size of the Rgeister comd size in DWORDS
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    UINT32 GetRegCmdSize()
    {
        return m_regCmdSizeInDwords;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// SetRegCmdSize
    ///
    /// @brief  Helper to Set Rgeister Command size needed for this pipeline in DWRDS
    ///
    /// @param  sizeInDwords  Size of the Reg Cmd in DWORDS
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    VOID SetRegCmdSize(
        UINT32 sizeInDwords)
    {
        m_regCmdSizeInDwords = sizeInDwords;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// SetThrottlePattern
    ///
    /// @brief  Helper function to Set Throttle pattern
    ///
    /// @param  throughPut  ThroughtPut rate
    /// @param  pCmdBuffer  Pointer to the command buffer
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual VOID SetThrottlePattern(
        FLOAT      throughPut,
        CmdBuffer* pCmdBuffer)
    {
        CAMX_UNREFERENCED_PARAM(throughPut);
        CAMX_UNREFERENCED_PARAM(pCmdBuffer);
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// FillTFEIQModuleVersion
    ///
    /// @brief  Helper to Fill TFE IQ module Version
    ///
    /// @param  pModuleVersion Pointer to the module version
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual VOID FillTFEIQModuleVersion(
        TFEIQHWVersion*  pModuleVersion)
    {
        CAMX_UNREFERENCED_PARAM(pModuleVersion);
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// FillTFEStatsModuleVersion
    ///
    /// @brief  Helper to Fill TFE Stats module Version
    ///
    /// @param  pModuleVersion Pointer to the module version
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual VOID FillTFEStatsModuleVersion(
        TFEStatsHWVersion*  pModuleVersion)
    {
        CAMX_UNREFERENCED_PARAM(pModuleVersion);
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetIPESWTMCModuleVersion
    ///
    /// @brief  Helper to return the installed TMC version
    ///
    /// @return SW TMC version of the module in this pipeline
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual SWTMCVersion GetIPESWTMCModuleVersion()
    {
        // Return invalid by default. All IPE pipelines supporting a specific TMC version must override this virtual function.
        return SWTMCVersion::TMCInvalid;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// FillICAUsecaseDependencyInfo
    ///
    /// @brief  Helper to fill ICA usecase dependency info based on usecase
    ///
    /// @param  usecaseSeletionData usecase selection data
    /// @param  instanceID          instance ID
    ///
    /// @return IPEICAUsecaseInfo Uscase dependency info
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual IPEICAUsecaseInfo FillICAUsecaseDependencyInfo(
        IPEICAUsecaseSelectionData usecaseSeletionData,
        UINT                       instanceID)
    {
        IPEICAUsecaseInfo usecaseDependencyInfo;
        Utils::Memset(&usecaseDependencyInfo, 0, sizeof(IPEICAUsecaseInfo));
        CAMX_UNREFERENCED_PARAM(usecaseSeletionData);
        CAMX_UNREFERENCED_PARAM(instanceID);
        return usecaseDependencyInfo;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// UpdateAECGainForMFHDR
    ///
    /// @brief  function to update AEC Gain for MFHDR IPE pipeline
    ///
    /// @param  moduleType    IPE IQ module type
    /// @param  pInputData    Pointer to ISP Input data
    /// @param  gtmPercentage gtm percentage
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual VOID UpdateAECGainForMFHDR(
        ISPIQModuleType moduleType,
        ISPInputData*   pInputData,
        FLOAT           gtmPercentage)
    {
        CAMX_UNREFERENCED_PARAM(moduleType);
        CAMX_UNREFERENCED_PARAM(pInputData);
        CAMX_UNREFERENCED_PARAM(gtmPercentage);
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetActiveIQModulesList
    ///
    /// @brief  Helper to Get Active IQ Module List
    ///
    /// @return Returns the refrence  to active IQ Module List
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    CAMX_INLINE std::list<ISPIQModule*>& GetActiveIQModulesList()
    {
        return m_activeModuleList;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetActiveStatsModulesList
    ///
    /// @brief  Helper to Get Active Stats Module List
    ///
    /// @return Returns the reference  to active Stats Module List
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    CAMX_INLINE std::list<ISPStatsModule*>& GetActiveStatsModulesList()
    {
        return m_activeStatsModuleList;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// CanSkipIFEIQModule
    ///
    /// @brief  Helper to check if the IQ Module Can be skipped
    ///
    /// @param  module IQ Module Type
    ///
    /// @return TRUE if the module can be skipped
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual BOOL CanSkipIFEIQModule(
        ISPIQModuleType module)
    {
        CAMX_UNREFERENCED_PARAM(module);
        return FALSE;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// CanSkipIFEStatsModule
    ///
    /// @brief  Helper to check if the Stats Module Can be skipped
    ///
    /// @param  module stats Module Type
    ///
    /// @return TRUE if the module can be skipped
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual  BOOL CanSkipIFEStatsModule(
        ISPStatsModuleType module)
    {
        CAMX_UNREFERENCED_PARAM(module);
        return FALSE;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// ~ISPPipeline
    ///
    /// @brief  Destructor
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual ~ISPPipeline() = default;

protected:
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// ISPPipeline
    ///
    /// @brief  Constructor
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ISPPipeline() = default;

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetICAUsecaseInfoIndex
    ///
    /// @brief  Set ICA usecase info index
    ///
    /// @param  usecaseMask ICA usecase mask
    ///
    /// @return ICA usecase info index
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    CAMX_INLINE UINT32 GetICAUsecaseInfoIndex(
        UINT32              usecaseMask,
        UINT32              numIPEICAUsecases,
        IPEICAUsecaseInfo   usecaseList[])
    {
        UINT32 index = -1;
        for (UINT32 i = 0; i < numIPEICAUsecases; i++)
        {
            if (usecaseList[i].usecaseMask == usecaseMask)
            {
                index = i;
                break;
            }
        }
        return index;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// AddICAPerUsecaseDependencyInfo
    ///
    /// @brief  Add ICA per usecase dependency info to m_IPEICAUsecaseDependencyInfo
    ///
    /// @param  usecaseInfoToAdd        Usecase dependency info to add
    /// @param  pUsecaseInforToReturn   Pointer to usecase dependency info accumilated
    /// @param  instanceID              Instance id
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual VOID AddICAPerUsecaseDependencyInfo(
        IPEICAUsecaseInfo   usecaseInfoToAdd,
        IPEICAUsecaseInfo*  pUsecaseInforToReturn,
        UINT                instanceID)
    {
        CAMX_UNREFERENCED_PARAM(usecaseInfoToAdd);
        CAMX_UNREFERENCED_PARAM(pUsecaseInforToReturn);
        CAMX_UNREFERENCED_PARAM(instanceID);
    }

    VOID*                      m_pCapability;             ///< Pipeline Capability Info
    std::list<ISPIQModule*>    m_activeModuleList;        ///< Active IQ Moduele List
    std::list<ISPStatsModule*> m_activeStatsModuleList;   ///< Active Stats Module List

private:
    ISPPipeline(const ISPPipeline&)            = delete; ///< Disallow the copy constructor
    ISPPipeline& operator=(const ISPPipeline&) = delete; ///< Disallow assignment operator

    CSLCameraTitanChipVersion m_titanChipVersion;         ///< Titan Chip Version
    UINT32                    m_hangDumpBufferSizeBytes  = 0;  ///< Hang Dump Buffer Size Bytes
    UINT32                    m_flushDumpBufferSizeBytes = 0;  ///< Flush Dump Buffer Size Bytes
    UINT32                    m_regDumpBufferSizeBytes   = 0;  ///< Reg Dump Buffer Size Bytes
    UINT32                    m_regCmdSizeInDwords;            ///< Register Command size in DWORDS
};

CAMX_NAMESPACE_END

#endif // CAMXISPPIPELINE_H
