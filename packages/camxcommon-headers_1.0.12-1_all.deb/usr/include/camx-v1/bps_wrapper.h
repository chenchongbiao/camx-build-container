//------------------------------------------------------------------------
// Copyright (c) 2020 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
//------------------------------------------------------------------------
// @file  bps_wrapper.h
//------------------------------------------------------------------------

#ifndef __BPS_WRAPPER__
#define __BPS_WRAPPER__

int32_t ConfigureBpsStriping(const BpsStripingLibraryInput    *pFirmwareInput,
    BpsStripingLibraryOutputPerFrame *pFrameOut,
    userBPSArgs                      *pUserBPSArgs);

#endif //__BPS_WRAPPER__