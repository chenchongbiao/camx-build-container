// NOWHINE ENTIRE FILE
//-------------------------------------------------------------------------
// Copyright (c) 2017-2020 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
//------------------------------------------------------------------------


#ifndef __DS4TO1_REGISTERS_H__
#define __DS4TO1_REGISTERS_H__

#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif

typedef struct DS4to1_REG_TAG
{
    // 0 - Disabled
    // 1 - Enabled
    // When disabled all of the Y-DS logic is shut-down and the module (including in-crop) is bypassed (i.e. output = input)
    // format: 1u
    uint32_t ENABLE_Y;

    // Defines the height of the stripe. This parameter is used for Y channel only. Default value is 0
    // This parameter is used by the HW to identify we are starting the last line of the stripe, so FW must configure this register with a valid number representing the last line we need to process.
    // format: 15u
    uint32_t IN_HEIGHT_Y;

    // 0 - Disabled
    // 1 - Enabled
    // When disabled all of the CbCr-DS logic is shut-down and the module (including in-crop) is bypassed (i.e. output = input)
    // format: 1u
    uint32_t ENABLE_C;

    // Defines the stripe height of the Chroma channel. For regular operation it should be configured with a value of:
    // in_height_y  >>1.
    // Default value is 0
    // This parameter is used by the HW to identify we are starting the last line of the stripe, so FW must configure this register with a valid number representing the last line we need to process.
    // e.g. for value of StartLine=4 and EndLine=11, we start from line 4 and take 8 lines in total.
    // format: 14u
    uint32_t IN_HEIGHT_C;

    // 8-Tap coefficient for pixels at locations 0 and 7.
    // For both Horizontal and vertical filters.
    // Default value (for 8-Tap typical) = 125
    // Typical value for binning option = 0
    // Coefficients values must comply with:
    // coeff_xx <= 256  (xx can be 07, 16 or 25)
    // coeff_07+coeff_16+coeff_25 <= 512
    // coeff_07+coeff_16+coeff_25 >= 256
    // format: 9u
    uint32_t COEFF_07;

    // 8-Tap coefficient for pixels at locations 1 and 6. For both Horizontal and vertical filters.
    // Default value (for 8-Tap typical) = 91
    // Typical value for binning option = 0
    // Value must comply same rules as in coeff_07
    // format: 9u
    uint32_t COEFF_16;

    // 8-Tap coefficient for pixels at locations 2 and 5.
    // For both Horizontal and vertical filters.
    // Default value (for 8-Tap typical) = 144
    // Typical value for binning option = 256
    // Value must comply same rules as in coeff_07
    // format: 9u
    uint32_t COEFF_25;

} DS4to1_REG;

// ############ Functions ############
int32_t Validate_DS4to1_REG( DS4to1_REG* regStruct );
void SetDefaultVal_DS4to1_REG( DS4to1_REG* regStruct );
// ###################################
#ifdef __cplusplus
}
#endif


#endif //__DS4TO1_REGISTERS_H__

