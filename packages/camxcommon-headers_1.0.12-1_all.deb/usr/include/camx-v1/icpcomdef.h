//-------------------------------------------------------------------------
// Copyright (c) 2015-2017, 2019-2020 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
//------------------------------------------------------------------------

//------------------------------------------------------------------------
// @file  icpcomdef.h
// @brief Abstract data types
//------------------------------------------------------------------------

//------------------------------------------------------------------------
// @Edit History
// when              who           what,where,why
// -----             ---           -------------
//
// 02/17/2017        skr           Initial version
//------------------------------------------------------------------------

#ifndef _ICP_COMDEF_H_
#define _ICP_COMDEF_H_

#include <stdint.h>

#ifndef __cplusplus
#include <stdbool.h>
#endif // __cplusplus

typedef uint32_t UINTPTR32;

#ifndef CEILING
#define CEILING(x,y) (((x) + (y) - 1) / (y))
#endif

#endif // _ICP_COMDEF_H_
