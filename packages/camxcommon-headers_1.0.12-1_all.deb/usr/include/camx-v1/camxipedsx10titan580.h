////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2020-2021, 2024 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @file  camxipedsx10titan580.h
/// @brief IPE DSX10 register setting for Titan580
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef CAMXIPEDSX10TITAN580_H
#define CAMXIPEDSX10TITAN580_H

#include "camxtitan17xdefs.h"
#include "camxisphwsetting.h"
#include "camxcmdbuffer.h"
#include "camxispiqmodule.h"
#include "camxisphwsetting.h"

CAMX_NAMESPACE_BEGIN

static const UINT32 DSX_LUMA_KERNAL_WEIGHTS_HORIZ   = 96;
static const UINT32 DSX_LUMA_KERNAL_WEIGHTS_VERT    = 96;
static const UINT32 DSX_CHROMA_KERNAL_WEIGHTS_HORIZ = 48;
static const UINT32 DSX_CHROMA_KERNAL_WEIGHTS_VERT  = 48;

static const UINT32 IPEDSX10LumaVerDMISize   = DSX_LUMA_KERNAL_WEIGHTS_VERT * sizeof(UINT64);
static const UINT32 IPEDSX10LumaHorDMISize   = DSX_LUMA_KERNAL_WEIGHTS_HORIZ * sizeof(UINT64);
static const UINT32 IPEDSX10ChromaHorDMISize = DSX_CHROMA_KERNAL_WEIGHTS_HORIZ * sizeof(UINT64);
static const UINT32 IPEDSX10ChromaVerDMISize = DSX_CHROMA_KERNAL_WEIGHTS_VERT * sizeof(UINT64);

static const UINT32 IPEDSX10TotalDMISize = IPEDSX10LumaVerDMISize + IPEDSX10LumaHorDMISize +
                                           IPEDSX10ChromaHorDMISize + IPEDSX10ChromaVerDMISize;

static const UINT32 IPEDSX10LumaHorizDword = (IPEDSX10LumaHorDMISize) / sizeof(UINT64);
static const UINT32 IPEDSX10LumaVertDWord  = (IPEDSX10LumaVerDMISize) / sizeof(UINT64);


static const UINT32 IPEDSX10ChromaHorizDword = (IPEDSX10ChromaHorDMISize) / sizeof(UINT64);
static const UINT32 IPEDSX10ChromaVertDWord  = (IPEDSX10ChromaVerDMISize) / sizeof(UINT64);

static const UINT32 IPEDSX10DMITotalDWord = IPEDSX10LumaHorizDword + IPEDSX10LumaVertDWord +
                                            IPEDSX10ChromaHorizDword + IPEDSX10ChromaVertDWord;

static const UINT32 IPEDSXNumRegWriteCmds    = 6;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief IPE DSX10 register setting for Titan580
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
class IPEDSX10Titan580 final : public ISPHWSetting
{
public:
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// IPEDSX10Titan580
    ///
    /// @brief  Constructor
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    IPEDSX10Titan580();

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// CreateCmdList
    ///
    /// @brief  Generate the Command List
    ///
    /// @param  pInputData       Pointer to the Inputdata
    /// @param  pDMIBufferOffset Pointer for DMI Buffer
    ///
    /// @return CamxResultSuccess if successful.
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual CamxResult CreateCmdList(
        VOID*   pInputData,
        UINT32* pDMIBufferOffset);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// WriteLUTInDMI
    ///
    /// @brief  writes all 14 LUTs from DSX into cmd buffer
    ///
    /// @param  pInputData Pointer to IPE module input data
    ///
    /// @return CamxResult Indicates if LUTs are successfully written into DMI cdm header
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    CamxResult WriteLUTInDMI(
        ISPInputData* pInputData);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// PackIQRegisterSetting
    ///
    /// @brief  Calculate register settings based on common library result
    ///
    /// @param  pInput       Pointer to the Input data to the IQ module for calculation
    /// @param  pOutput      Pointer to the Output data to the IQ module for DMI calculation
    ///
    /// @return Return CamxResult.
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual CamxResult PackIQRegisterSetting(
        VOID*  pInput,
        VOID*  pOutput);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// DumpRegConfig
    ///
    /// @brief  Print register configuration of Crop module for debug
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual VOID DumpRegConfig();

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetRegSize
    ///
    /// @brief  Returns register size
    ///
    /// @return Number of bytes of register structure.
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual UINT GetRegSize();

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// UpdateTuningMetadata
    ///
    /// @brief  Update Tuning Metadata
    ///
    /// @param  pInputData      Pointer to the InputData
    ///
    /// @return CamxResultSuccess if successful.
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual CamxResult UpdateTuningMetadata(
        VOID*  pInputData);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// SetupInternalData
    ///
    /// @brief  Update module internal Data from register
    ///
    /// @param  pData Pointer to internal data to be updated
    ///
    /// @return Return CamxResult
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual CamxResult SetupInternalData(
        VOID* pData);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// ~IPEDSX10Titan580
    ///
    /// @brief  Destructor
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual ~IPEDSX10Titan580();

private:
    IPEDSX10Titan580(const IPEDSX10Titan580&)            = delete; ///< Disallow the copy constructor
    IPEDSX10Titan580& operator=(const IPEDSX10Titan580&) = delete; ///< Disallow assignment operator

    VOID*                m_pRegCmd;                                ///< Pointer to Register list for DSX module
    UINT32               m_lutBank;                                ///< Lut Bank Switch
    VOID*                m_pModuleConfig;                          ///< Pointer Module configuration for IPEDSX10
    CmdBuffer*           m_pLUTCmdBuffer;                          ///< Shadow copy of module LUT command buffer
    UINT*                m_pOffsetLUTCmdBuffer;                    ///< Pointer to array of offset of all tables
    UINT                 m_singlePassCmdLength;                    ///< The length of the Command List, in bytes
    UINT                 m_numPass;                                ///< Number of passes
};

CAMX_NAMESPACE_END

#endif // CAMXIPEDSX10TITAN580_H
