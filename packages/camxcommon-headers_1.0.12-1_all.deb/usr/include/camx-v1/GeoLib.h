// NOWHINE ENTIRE FILE
//-------------------------------------------------------------------------
// Copyright (c) 2019-2020 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
//------------------------------------------------------------------------
#ifndef __GEOLIB_H__
#define __GEOLIB_H__

//------------------------------------------------------------------------
// @file  GeoLib.h
// @brief GeoLib API functions
//------------------------------------------------------------------------

#include <stdint.h>
#include "NcLibWarp.h"

#define GEOLIB_MAX_NUM_OF_SENSORS           (6)
#define GEOLIB_MAX_NUM_OF_IPES_PER_PORT     (3)

/**< Video/Preview supported flows */
enum GeoLibVideoFlowMode
{
    GEOLIB_VIDEO_WITH_INLINE_EIS,           /**< Video with inline EIS, undistorted IPE output (V_IE_U)  */
    GEOLIB_VIDEO_EIS_POST_IPE_DISTORTED,    /**< Video with EIS/DIS post-IPE, distorted IPE output (V_EPI_D) */
    GEOLIB_VIDEO_EIS_POST_IPE_UNDISTORTED,  /**< Video with EIS/DIS post-IPE, undistorted IPE output (V_EPI_U) */
    GEOLIB_VIDEO_NO_EIS_IPE_DISTORTED,      /**< Video without EIS/DIS, distorted IPE output (V_WOE_D) */
    GEOLIB_VIDEO_NO_EIS_IPE_UNDISTORTED,    /**< Video without EIS/DIS, undistorted IPE output (V_WOE_U) */
    GEOLIB_STILL_PREVIEW_IPE_DISTORTED,     /**< Preview, distorted IPE output (P_D) */
    GEOLIB_STILL_PREVIEW_IPE_UNDISTORTED,   /**< Preview, undistorted IPE output (P_U) */

    GEOLIB_FLOW_NUM                         /**< only for SW purpose */
};

/**< Snapshot/MFNR/MFSR flows */
enum GeoLibStillFlowMode
{
    GEOLIB_STILL_SNAPSHOT,          /**< Snapshot */
    GEOLIB_STILL_MFNR,              /**< MFNR (MFSR is permanently disabled) */
    GEOLIB_STILL_MFSR,              /**< Enable MFSR when possible, if all necessary conditions are held, otherwise fall through to MFNR mode (e.g., when MFSR is not possible due to insufficient upscaling). Depends on Chromatix (MF:Max_SR_sensor_gain) */
    GEOLIB_STILL_FLOW_MODE_NUM      /**< only for SW purpose */
};

/**< Snapshot/MFNR/MFSR flows */
enum GeoLibMultiFrameMode
{
    GEOLIB_MF_ANCHOR,               /**< Multi-frame pre-filter   */
    GEOLIB_MF_BLEND,                /**< Multi-frame blend stage  */
    GEOLIB_MF_FINAL,                /**< Multi-frame post-filter  */
    GEOLIB_MF_MODE_NUM              /**< only for SW purpose */
};

/**< Video/still multi-frame HDR-enabled flows */
enum GeoLibHdrFlowMode
{
    GEOLIB_HDR_FLOW_DISABLED,       /**< Non-HDR video/still flow */
    GEOLIB_HDR_FLOW_ENABLED,        /**< HDR video/still flow */
    GEOLIB_HDR_FLOW_MODE_NUM        /**< only for SW purpose */
};

typedef NcLibFloat2 GeoLibFloat2;
typedef NcLibROI GeoLibROI;
typedef NcLibImageSize GeoLibImageSize;
typedef NcLibFloat2 GeoLibWindowSize;

/**< Crop and scale configuration for cropping fractional ROI on input image, then
  scaling it to a fractional ROI on the output. The exact scaling factor is determined
  by the ratio between the crop ROI in the input and ROI in the output.

  NOTE: Current implementation will always set the offset of the output ROI to zero,
  meaning that the top and left of the output image will always be aligned with the
  top and left (fractional) offset in the input ROI.

                  ___________________________
       Input     |  |xxxxxxxxxxxxxx|         |
       Image     |  |x   IN ROI   x|         |
                 |__|xxxxxxxxxxxxxx|_________|
                        |
                     ___V______
       Output       |xxxxxxx   |
       Image        |x ROI x   | <-- padding
                    |xxxxxxx___|
 */
struct GeoLibCropAndScale
{
    GeoLibROI                       inputImageRoi;          /**< Input crop ROI (fractional) relative to sensor dimensions */
    GeoLibImageSize                 inputImageSize;         /**< Input size in pixels */
    GeoLibROI                       outputImageRoi;         /**< Scaled and cropped fractional ROI relative to the output; it can be smaller than the output due to output buffer padding. */
    GeoLibImageSize                 outputImageSize;        /**< Output size in pixels, including optional padding according to output ROI */

};

/**< ICA logical mapping parameters (one-to-one correspondence to ICA O2V and V2I registers) */
struct GeoLibIcaMapping
{
    GeoLibROI                       inputImageRoi;          /**< Input image ROI (on distorted domain) */
    GeoLibImageSize                 inputImageSize;         /**< Input image size in pixels (can be padded) */
    GeoLibImageSize                 inputValidSize;         /**< Input valid size in pixels */
    GeoLibROI                       outputImageRoi;         /**< Output image ROI (on undistorted domain) */
    GeoLibImageSize                 outputImageSize;        /**< Output image size in pixels */
};

/**< Multi-pass ICA1/ICA2 mapping configuration */
struct GeoLibIcaPassMapping
{
    uint32_t                        numPasses;
    GeoLibIcaMapping                icaMappingFull;         /**< IPE 1:1 pass mapping */
    GeoLibIcaMapping                icaMappingDS4;          /**< IPE 1:4 pass mapping */
    GeoLibIcaMapping                icaMappingDS16;         /**< IPE 1:16 pass mapping */
    GeoLibIcaMapping                icaMappingDS64;         /**< IPE 1:64 pass (still only) */
    GeoLibROI                       dzFOV;                  /**< Cropped zoom FOV */
};

/**< Specifies if LDC grid resampling is needed and the input for NcLibResampleGrid() */
struct GeoLibGridRoi
{
    bool                            enabled;                /**< Disabled if resample is not needed */
    GeoLibROI                       cropRoi;                /**< ROI for grid resampling (NcLibResampleGrid) */
    GeoLibROI                       outRoi;                 /**< ROI for grid resampling (NcLibResampleGrid) */
};

/**< Sensor geometry, per sensor crop (sensor mode) */
struct GeoLibSensorData
{
    GeoLibImageSize                 sensorSize;             /**< Sensor crop out size (CSID), in pixels */
};

/**< Requested IPE output parameters, in SISO/SIMO modes (at least one IPE out port must be enabled) */
struct GeoLibIpeParams
{
    GeoLibImageSize                 mainOutSize;            /**< Size of IPE_MAIN_OUT port, in pixels. Can be zero if disabled */
    GeoLibImageSize                 dispOutSize;            /**< Size of IPE_DISP_OUT port, in pixels. Can be zero if disabled */
};

/**< EIS-related parameters, as defined in EIS Chromatix */
struct GeoLibEisParams
{
    GeoLibFloat2                    minMarginRatio;         /**< Minimal EIS total margin ratio. Defined in Chromatix (EIS:minimal_total_margin) */
    GeoLibFloat2                    reqMarginRatio;         /**< EIS requested total margin ratio. Defined in Chromatix (EIS:requested_total_margins) */
};

/**< Inputs to EIS algorithm */
struct GeoLibInternalEisConfig
{
    GeoLibROI                       preCropDistorted;       /**< Pre-EIS crop window on distorted sensor (full IFE input and FOV) */
    GeoLibROI                       preCropUndistorted;     /**< Pre-EIS crop window on undistorted sensor (after LDC) */
    GeoLibROI                       outCropFOV;             /**< Final EIS output FOV, relative to undistorted pre-EIS crop window */
};

/**< Inputs to SAT algorithm */
struct GeoLibInternalSatConfig
{
    GeoLibROI                       satROI;                 /**< SAT ROI including margins in IFE out domain */
    GeoLibROI                       outFOV;                 /**< SAT transform output FOV in IFE Out domain */
};

/**< Inputs to ERS algorithm */
struct GeoLibInternalErsConfig
{
    GeoLibROI                       preCropDistorted;       /**< Pre-ERS crop window on distorted sensor (full IFE input and FOV) */
    GeoLibROI                       preCropUndistorted;     /**< Pre-ERS crop window on undistorted sensor (after LDC) */
};

/**< Frame-level inputs to IPE striping library */
struct GeoLibIpeStripingConfig
{
    GeoLibImageSize                 mainInputSize;          /**< Full size of Main (NPS) input window */
    GeoLibROI                       tfCropWindow;           /**< TF crop ROI on mainInput, aligned to 8 px */
    GeoLibROI                       videoOutFOV;            /**< Fractional FOV of IPE video output on mainInput, sub-pixel */
    GeoLibROI                       videoOutCropWindow;     /**< Video output crop on mainInput, in pixel resolution */
    GeoLibROI                       displayOutFOV;          /**< Fractional FOV of IPE display output on mainInput, sub-pixel */
    GeoLibROI                       displayOutCropWindow;   /**< Display output crop on mainInput, in pixel resolution */
    GeoLibCropAndScale              dsx;                    /**< IPE DSX settings (if available) */
};

/**< Each IFE output port is configured separately. */
enum GeoLibVideoStreamIfePort
{
    GEOLIB_IFE_PORT_VIDEO_OUT,                              /**< Video out, supports VSR */
    GEOLIB_IFE_PORT_DISPLAY_OUT,                            /**< Display out, no VSR */
    GEOLIB_IFE_PORT_OUT_NUM                                 /**< only for SW purpose */
};


/**< GeoLib Video one-time outputs (init) per stream (either IFE video out port or IFE display out port) */
struct GeoLibVideoIfeStreamCfg
{
    /* IFE FRAME SIZES */

    GeoLibImageSize                 ifeOutFullSize;         /**< IFE_out_1:1 max size in pixels (IFE_VIDEO_FULL_OUT or IFE_DISP_FULL_OUT) */
    GeoLibImageSize                 ifeOutFullValidSize;    /**< IFE_out_1:1 actual frame size in pixels, smaller or equal to ifeOutFullSize */
    GeoLibImageSize                 ifeOutDS4Size;          /**< IFE_out_1:4 max size in pixels (DSX for IFE video port or DS4 for IFE display port) */
    GeoLibImageSize                 ifeOutDS4ValidSize;     /**< IFE_out_1:4 actual frame size in pixels, smaller or equal to ifeOutDS4Size */
    GeoLibImageSize                 ifeOutDS16Size;         /**< IFE_out_1:16 max size in pixels (IFE_VIDEO_DS16_OUT or IFE_DISP_DS16_OUT) */
    GeoLibImageSize                 ifeOutDS16ValidSize;    /**< IFE_out_1:16 actual frame size in pixels, smaller or equal to ifeOutDS16Size */

    /* OFF-CENTER SHIFT */
    GeoLibFloat2                    ifeInCenter;           /**< Off-center shift in sensor domain */

    /*
    * INTERNAL CONTEXT FOR PER-FRAME CALCULATIONS
    */
    enum { CTX_SIZE = 908 };
    uint8_t                         ctx[CTX_SIZE];
};

/**< GeoLib Video one-time outputs (init) per IPE */
struct GeoLibVideoIpeStreamCfg
{
    /* MCTF IPE FRAME SIZES */
    GeoLibImageSize                 tfOutFullSize;          /**< TF Ref out 1:1 max size in pixels.*/
    GeoLibImageSize                 tfOutDS4Size;           /**< TF Ref out 1:4 max size in pixels.*/
    GeoLibImageSize                 tfOutDS16Size;          /**< TF Ref out 1:16 max size in pixels.*/

    /* HDR IPE FRAME SIZES */
    GeoLibImageSize                 hdrOutFullSize;         /**< HDR combine IPE out 1:1 max size in pixels, 0 for non-HDR flow */
    GeoLibImageSize                 hdrOutDS4Size;          /**< HDR combine IPE out 1:4 max size in pixels, 0 for non-HDR flow */
    GeoLibImageSize                 hdrOutDS16Size;         /**< HDR combine IPE out 1:16 max size in pixels, 0 for non-HDR flow */

    /*
    * INTERNAL CONTEXT FOR PER-FRAME CALCULATIONS
    */
    enum { CTX_SIZE = 284 };
    uint8_t                         ctx[CTX_SIZE];
};

/**< GeoLib Video one-time outputs (init) per stream CVP */
struct GeoLibVideoCvpStreamCfg
{
    /* CVP FRAME SIZES */
    GeoLibImageSize                 cvpDsOutSize;           /**< Maximal CVP DS out size in pixels */
    GeoLibImageSize                 cvpIcaOutSize;          /**< CVP ICA out max size in pixels */

    /*
    * INTERNAL CONTEXT FOR PER-FRAME CALCULATIONS
    */
    enum { CTX_SIZE = 36 };
    uint8_t                         ctx[CTX_SIZE];
};

/**< GeoLib Video per-frame outputs per-stream (either IFE video out or IFE display out) */
struct GeoLibVideoIfeFrameCfg
{
    GeoLibCropAndScale              ifeFullCropAndScale;        /**< IFE pre-crop and M/N DS settings (IFE video full output or IFE display full output) */
    GeoLibCropAndScale              ifeDSXCropAndScale;         /**< IFE DSX settings (IFE video out) */
    GeoLibCropAndScale              ifeFdCropAndScale;          /**< IFE face detection output settings (FD_OUT) */
    GeoLibInternalSatConfig         satConfig;                  /**< SAT algorithm configuration */
    GeoLibGridRoi                   icaGridRoi;                 /**< ICA grid resampling. Should be used if applying LDC in the following modes:
                                                                for CVP - GEOLIB_STILL_PREVIEW_IPE_DISTORTED, GEOLIB_STILL_PREVIEW_IPE_UNDISTORTED
                                                                for ICA1 - GEOLIB_VIDEO_EIS_POST_IPE_UNDISTORTED, GEOLIB_VIDEO_NO_EIS_IPE_UNDISTORTED, GEOLIB_STILL_PREVIEW_IPE_UNDISTORTED
                                                                */
    uint64_t                        requestID;                  /**< Request ID for debugging purposes */

    /*
    * INTERNAL CONTEXT FOR PER-FRAME CALCULATIONS
    */
    enum { CTX_SIZE = 400 };
    uint8_t                         ctx[CTX_SIZE];
};

/**< GeoLib Video per-frame outputs for IPE */
struct GeoLibVideoIpeFrameCfg
{
    GeoLibIcaPassMapping            ica1Mapping;                /**< ICA1 mapping configuration */
    GeoLibIcaPassMapping            ica2Mapping;                /**< ICA2 mapping configuration */
    GeoLibIpeStripingConfig         ipeStripingInputs;          /**< Frame-level inputs to IPE striping library */
    uint64_t                        requestID;                  /**< Request ID for debugging purposes */
};

/**< GeoLib Video per-frame outputs per EIS/ERS algorithm instance */
struct GeoLibVideoEisFrameCfg
{
    GeoLibInternalEisConfig         eisConfig;                  /**< EIS algorithm configuration */
    GeoLibInternalErsConfig         ersConfig;                  /**< ERS algorithm configuration */
    uint64_t                        requestID;                  /**< Request ID for debugging purposes */
};

/**< GeoLib Video per-frame outputs for CVP */
struct GeoLibVideoCvpFrameCfg
{
    GeoLibImageSize                 cvpDsOutSize;               /**< CVP-DS output size, if 0 DS should be disabled */
    GeoLibIcaMapping                cvpIcaMapping;              /**< CVP-ICA mapping configuration */
    GeoLibFloat2                    coarse2fullScale;           /**< Scale factor from coarse (CVP DME) domain to full (IPE in) domain */
    GeoLibFloat2                    coarseCenter;               /**< Transform center in coarse (CVP DME) domain. */
    uint64_t                        requestID;                  /**< Request ID for debugging purposes */
};

/**< GeoLib feature override flags */
enum GeoLibOverrideFlags
{
    GEOLIB_OVERRIDE_DISABLE_IPE_DIGITAL_ZOOM        = (1 << 0), /**< Disable IPE digital zoom (independent from EIS virtual margin) */
    GEOLIB_OVERRIDE_DISABLE_S580_IPEDS_CONSTRAINTS  = (1 << 1), /**< Disable IPE-MNDS downscaling restrictions in S580 */
    GEOLIB_OVERRIDE_FLAG_RESERVED_2                 = (1 << 2), /**< Reserved */
    GEOLIB_OVERRIDE_FLAG_RESERVED_3                 = (1 << 3), /**< Reserved */
};

//-------------------------------------------------------------------------
// Kona Still section
//-------------------------------------------------------------------------

/**< GeoLib Still Configuration */
struct GeoLibStillFrameConfig
{
    GeoLibStillFlowMode             flowMode;                   /**< Flow mode */
    GeoLibMultiFrameMode            mfMode;                     /**< multi frame mode */

    GeoLibImageSize                 bpsOutSizeFull;             /**< BPS 1:1 out image size */
    GeoLibImageSize                 bpsOutSizeDS4;              /**< BPS 1:4 out image size */
    GeoLibImageSize                 bpsOutSizeDS16;             /**< BPS 1:16 out image size */
    GeoLibImageSize                 bpsOutSizeDS64;             /**< BPS 1:64 out image size */
    GeoLibCropAndScale              bpsOutFullCrop;             /**< BPS 1:1 crop-only (no scaling) */
    GeoLibCropAndScale              bpsRegCropAndScale;         /**< BPS reg out M/N DS configuration */
    float                           offCenterH;                 /**< Horizontal off-center shift in sensor domain */
    GeoLibIcaPassMapping            ica1Mapping;                /**< ICA1 mapping configuration */
    GeoLibIcaPassMapping            ica2Mapping;                /**< ICA2 mapping configuration */
    GeoLibIcaMapping                cvpIcaMapping;              /**< CVP-ICA mapping configuration */
    GeoLibIpeStripingConfig         ipeStripingInputs;          /**< Frame-level inputs to IPE striping library */

    GeoLibFloat2                    coarse2fullScale;           /**< Scale factor from coarse (CVP DME) domain to full (IPE in) domain */
    GeoLibFloat2                    coarseCenter;               /**< Transform center in coarse (CVP DME) domain. */
};

/**
* @brief Still flow calculation for Kona.
*
* @param [in]  flowMode         Use case description
* @param [in]  mfMode           Multi-frame mode (N/A for snapshot)
* @param [in]  sensorSize       Full sensor output size (RDI), distorted pixels in case of LD
* @param [in]  ldFullOutToIn    Output-to-input LDC grid transform for this sensor. Defined in Chromatix (ICA:ctc_grid_x/ctc_grid_y), needs to be resampled to actual sensor output size.
* @param [in]  ldFullInToOut    Input-to-output LDC grid transform for this sensor. Defined in Chromatix (ICA:ld_i2u_grid_x/ld_i2u_grid_y), needs to be resampled to actual sensor output size.
* @param [in]  ldFullOutSize    Undistorted LDC output size, in square pixels. Should be zero when LDC is disabled. Defined in Chromatix (ICA:ld_full_out_width/ld_full_out_height)
* @param [in]  stillOutSize     Main (still) output size in pixels
* @param [in]  dispOutSize      Display output size (in IPE SIMO mode) in pixels, or NULL if IPE display output is disabled
* @param [in]  regOutSize       Registration image size, should be NULL in case of still snapshot or multi-frame post-processing (GEOLIB_MF_FINAL). Defined in Chromatix (CVP:multi_frame_input_resolution).
* @param [in]  zoomWindow       Digital zoom window on undistorted LDC domain, normalized
* @param [out] stillConfig      Output configuration
*
* @return NC_LIB_SUCCESS or appropriate error code on failure.
*/
int32_t GeoLibStillCalcFrame(
    const GeoLibStillFlowMode       flowMode,
    const GeoLibMultiFrameMode      mfMode,
    const GeoLibImageSize*          sensorSize,
    const NcLibIcaGrid*             ldFullOutToIn,
    const NcLibIcaGrid*             ldFullInToOut,
    const GeoLibImageSize*          ldFullOutSize,
    const GeoLibImageSize*          stillOutSize,
    const GeoLibImageSize*          dispOutSize,
    const GeoLibImageSize*          regOutSize,
    const GeoLibROI*                zoomWindow,
    GeoLibStillFrameConfig*         stillConfig
);

/**
* @brief Still flow calculation for Kona v2.
*
* @param [in]  flowMode         Use case description
* @param [in]  mfMode           Multi-frame mode (N/A for snapshot)
* @param [in]  sensorSize       Full sensor output size (RDI), distorted pixels in case of LD
* @param [in]  ldFullOutToIn    Output-to-input LDC grid transform for this sensor. Defined in Chromatix (ICA:ctc_grid_x/ctc_grid_y), needs to be resampled to actual sensor output size.
* @param [in]  ldFullInToOut    Input-to-output LDC grid transform for this sensor. Defined in Chromatix (ICA:ld_i2u_grid_x/ld_i2u_grid_y), needs to be resampled to actual sensor output size.
* @param [in]  ldFullOutSize    Undistorted LDC output size, in square pixels. Should be zero when LDC is disabled. Defined in Chromatix (ICA:ld_full_out_width/ld_full_out_height)
* @param [in]  stillOutSize     Main (still) output size in pixels
* @param [in]  dispOutSize      Display output size (in IPE SIMO mode) in pixels, or NULL if IPE display output is disabled
* @param [in]  regOutSize       Registration image size, should be NULL in case of still snapshot or multi-frame post-processing (GEOLIB_MF_FINAL). Defined in Chromatix (CVP:multi_frame_input_resolution).
* @param [in]  zoomWindow       Digital zoom window on undistorted LDC domain, normalized
* @param [out] stillConfig      Output configuration
*
* @return NC_LIB_SUCCESS or appropriate error code on failure.
*/
int32_t GeoLibStillCalcFrame_v2(
    const GeoLibStillFlowMode       flowMode,
    const GeoLibMultiFrameMode      mfMode,
    const GeoLibImageSize*          sensorSize,
    const NcLibIcaGrid*             ldFullOutToIn,
    const NcLibIcaGrid*             ldFullInToOut,
    const GeoLibImageSize*          ldFullOutSize,
    const GeoLibImageSize*          stillOutSize,
    const GeoLibImageSize*          dispOutSize,
    const GeoLibImageSize*          regOutSize,
    const GeoLibROI*                zoomWindow,
    GeoLibStillFrameConfig*         stillConfig
);


//-------------------------------------------------------------------------
// Video section
//-------------------------------------------------------------------------

/**
* @brief One-time video flow initialization per stream (either IFE video output or IFE display output).
*
* @param [in]  flowMode           Use case description
* @param [in]  hdrMode            Either HDR or non-HDR flow mode. Must be GEOLIB_HDR_FLOW_DISABLED in Kona.
* @param [in]  sensorData         Array of sensor specific data for all the sensors in multi-camera use
*                                 cases, or a pointer to a sensor data in case of single-camera case.
* @param [in]  numSensors         Number of sensors in sensor data array. Must be 1 in single-camera case.
*                                 Cannot exceed GEOLIB_MAX_NUM_OF_SENSORS.
* @param [in]  curSensorIdx       Current stream's sensor index in sensor array. Must be 0 in single-camera case.
* @param [in]  ifeOutPort         Either video or display IFE out port selection
* @param [in]  ifeOutMinSize      Minimum IFE output size in pixels, or NULL to disable the restriction.
* @param [in]  fdOutSize          Face detection final output size or NULL if FD config is not needed
* @param [in]  ldFullOutToIn      Output-to-input LDC grid transform for this sensor for this mode. Defined in Chromatix
*                                 (ICA:ctc_grid_x/ctc_grid_y), needs to be resampled to actual sensor output size.
* @param [in]  ipeParams          Array of IPE output parameters for all IPEs connected to this IFE out port (see diagram below).
* @param [in]  ipeParamsLen       Number of elements in ipeParams array (number of IPEs connected to current IFE out port).
*                                 Cannot exceed GEOLIB_MAX_NUM_OF_IPES_PER_PORT.
*
*   SHARED IFE-OUT TO MULTIPLE LINKED IPE-IN (ONE-TO-MANY):
*                                        _____
*      _____     _______________        |     |
*     |     |   |               |---+---| IPE |
*     |     |---| IFE_VIDEO_OUT |   |   |_____|  _____   <-- ipeParams[] of length 2
*     |     |   |_______________|   |           |     |
*     | IFE |                       +-----------| IPE |
*     |     |    _______________        _____   |_____|
*     |     |   |               |      |     |
*     |_____|---| IFE_DISP_OUT  |------| IPE |           <-- ipeParams[] of length 1
*               |_______________|      |_____|
*
* @param [in]  maxVsrScaling      Max VSR upscale ratio, in range [1.0, 3.0]; 1.0 means no VSR.
* @param [in]  eisParameters      EIS-related parameters, as defined in EIS Chromatix
* @param [in]  fovcMarginRatio    FOVC margin ratio from camera out, 0 for no FOVC
* @param [in]  overrideFlags      Optional bitmask for overriding default behavior (zero by default), OR'ed GeoLibOverrideFlags.
* @param [in]  secIfeConfig       Output configuration for the other IFE port in case CVP should be shared for both IFE ports.
*                                 Should be NULL if CVP is not shared between two IFE ports (Kona-like).
*
*   SHARED VIDEO/DISP CVP CONFIG:                               DUAL CVP CONFIG (KONA-LIKE):
*      _____     _____     _____                                   _____     _____     _____
*     |     |   |     |   |     |                                 |     |   |     |   |     |
*     |     |---| CVP |---| IPE | <-- IFE_VIDEO (ifeConfig1,      |     |---| CVP |---| IPE | <-- IFE_VIDEO
*     |     |   |_____|   |_____|      secIfeConfig=ifeConfig0)   |     |   |_____|   |_____|   (secIfeConfig=NULL)
*     | IFE |      |                            +                 | IFE |
*     |     |      |       _____                |                 |     |    _____     _____
*     |     |      v      |     |               |                 |     |   |     |   |     |
*     |_____|-------------| IPE | <-- IFE_DISP (ifeConfig0,       |_____|---| CVP |---| IPE | <-- IFE_DISP
*                         |_____|      secIfeConfig=NULL)                   |_____|   |_____|   (secIfeConfig=NULL)
*
* @param [out] ifeConfig          Output stream configuration
*
* @return NC_LIB_SUCCESS or appropriate error code on failure.
*/
int32_t GeoLibVideoIfeStreamInit(
    const GeoLibVideoFlowMode       flowMode,
    const GeoLibHdrFlowMode         hdrMode,
    const GeoLibSensorData          sensorData[],
    const uint32_t                  numSensors,
    const uint32_t                  curSensorIdx,
    const GeoLibVideoStreamIfePort  ifeOutPort,
    const GeoLibImageSize*          ifeOutMinSize,
    const GeoLibImageSize*          fdOutSize,
    const NcLibIcaGrid*             ldFullOutToIn,
    const GeoLibIpeParams           ipeParams[],
    const uint32_t                  ipeParamsLen,
    const float                     maxVsrScaling,
    const GeoLibEisParams*          eisParameters,
    const float                     fovcMarginRatio,
    const uint32_t                  overrideFlags,
    const GeoLibVideoIfeStreamCfg*  secIfeConfig,
    GeoLibVideoIfeStreamCfg*        ifeConfig
);

/**
* @brief One-time video flow initialization for each IPE.
*
* @param [in]  ifeConfig          GeoLibVideoIfeStreamInit output for the stream connected to this IPE
* @param [in]  ipeParams          Requested IPE output parameters
* @param [out] ipeConfig          Output IPE configuration
*
* @return NC_LIB_SUCCESS or appropriate error code on failure.
*/
int32_t GeoLibVideoIpeStreamInit(
    const GeoLibVideoIfeStreamCfg*  ifeConfig,
    const GeoLibIpeParams*          ipeParams,
    GeoLibVideoIpeStreamCfg*        ipeConfig
);

/**
* @brief One-time video flow initialization for CVP.
*
* @param [in]  ifeConfig          GeoLibVideoIfeStreamInit output for the stream connected to this CVP
* @param [out] cvpConfig          Output CVP configuration
*
* @return NC_LIB_SUCCESS or appropriate error code on failure.
*/
int32_t GeoLibVideoCvpStreamInit(
    const GeoLibVideoIfeStreamCfg*  ifeConfig,
    GeoLibVideoCvpStreamCfg*        cvpConfig
);

/**
* @brief Per-frame video flow calculation for IFE.
*
* @param [in]  streamConfig     Initial stream configuration (from GeoLibVideoIfeStreamInit).
* @param [in]  zoomWindow       Digital zoom window on undistorted LDC domain, normalized.
* @param [in]  satWindowSize    Crop window for SAT on undistorted LDC domain, normalized and centered at zoom window. SAT
*                               window size must be bigger or equal to zoom window size, or NULL if SAT is not enabled.
* @param [in]  ldFullOutToIn    Output-to-input LDC grid transform for this sensor for this mode. Defined in Chromatix
*                               (ICA:ctc_grid_x/ctc_grid_y), needs to be resampled to actual sensor output size.
* @param [in]  ldFullInToOut    Input-to-output LDC grid transform for this sensor. Defined in Chromatix
*                               (ICA:ld_i2u_grid_x/ld_i2u_grid_y), needs to be resampled to actual sensor output size.
* @param [in]  eisVsVsrFactor   EIS vs VSR preference factor, in range [0, 1]; 0 means best stablization, 1 means best resolution.
* @param [in]  vsrLimit         Effective Max VSR upscale ratio for this frame, in range [1, 3]; 1 means no VSR.
*                               Defined in Chromatix (VIDEO:max_vsr).
* @param [in]  requestID        Request ID (frame number) for debugging purposes.
* @param [out] out              Output frame IFE configuration.
*
* @return NC_LIB_SUCCESS or appropriate error code on failure.
*/
int32_t GeoLibVideoIfeCalcFrame(
    const GeoLibVideoIfeStreamCfg*  streamConfig,
    const GeoLibROI*                zoomWindow,
    const GeoLibWindowSize*         satWindowSize,
    const NcLibIcaGrid*             ldFullOutToIn,
    const NcLibIcaGrid*             ldFullInToOut,
    const float                     eisVsVsrFactor,
    const float                     vsrLimit,
    const uint64_t                  requestID,
    GeoLibVideoIfeFrameCfg*         out
);

/**
* @brief Per-frame video flow calculation for EIS.
*
* @param [in]  ifeFrameCfg      IFE frame calculations output. Should be passed from GeoLibVideoIfeCalcFrame
* @param [in]  outSize          Matching IPE output size in pixels.
* @param [in]  ldFullOutToIn    Output-to-input LDC grid transform for this sensor for this mode. Defined in Chromatix
*                               (ICA:ctc_grid_x/ctc_grid_y), needs to be resampled to actual sensor output size.
* @param [in]  ldFullInToOut    Input-to-output LDC grid transform for this sensor. Defined in Chromatix
*                               (ICA:ld_i2u_grid_x/ld_i2u_grid_y), needs to be resampled to actual sensor output size.
* @param [in]  fovcRatio        FOVC crop factor from 3A, in range [0, fovcMarginRatio]; where 0 means biggest FOV.
*                               0 if no FOVC data is available, e.g. NFL EIS.
* @param [out] out              Output IPE configuration for current frame
*
* @return NC_LIB_SUCCESS or appropriate error code on failure.
*/
int32_t GeoLibVideoEisCalcFrame(
    const GeoLibVideoIfeFrameCfg*   ifeFrameCfg,
    const GeoLibImageSize*          outSize,
    const NcLibIcaGrid*             ldFullOutToIn,
    const NcLibIcaGrid*             ldFullInToOut,
    const float                     fovcRatio,
    GeoLibVideoEisFrameCfg*         out
);

/**
* @brief Per-frame video flow calculation for CVP.
*
* @param [in]  cvpConfig        Initial CVP configuration (from GeoLibVideoCvpInit)
* @param [in]  ifeFrameCfg      IFE frame calculations output. Should be passed from GeoLibVideoIfeCalcFrame
* @param [in]  cvpDsRatio       Extra downscaling in CVP-DS for VSR flows, in range [1.0, 6.0]; 1.0 means no downscaling is done
*                               before registration. Defined in Chromatix (CVP:video_registration_down_scale_ratio)
* @param [out] out              Output frame CVP configuration
*
* @return NC_LIB_SUCCESS or appropriate error code on failure.
*/
int32_t GeoLibVideoCvpCalcFrame(
    const GeoLibVideoCvpStreamCfg*  cvpConfig,
    const GeoLibVideoIfeFrameCfg*   ifeFrameCfg,
    const float                     cvpDsRatio,
    GeoLibVideoCvpFrameCfg*         out
);

/**
* @brief Per-frame video flow calculation for IPE activations of HDR Combine stage.
*
* @param [in]  ipeConfig        Initial IPE configuration (from GeoLibVideoIpeInit)
* @param [in]  ifeFrameCfg      IFE frame calculations output. Should be passed from GeoLibVideoIfeCalcFrame
* @param [out] mExpOut          Output IPE configuration for current frame for medium exposure IPE, full pass only.
*                               Should be NULL for 2-exposures HDR.
* @param [out] slExpOut         Output IPE configuration for current frame for short and long exposures, DC4 and full passes.
*
* @return NC_LIB_SUCCESS or appropriate error code on failure.
*/
int32_t GeoLibVideoIpeHdrCalcFrame(
    const GeoLibVideoIpeStreamCfg*  ipeConfig,
    const GeoLibVideoIfeFrameCfg*   ifeFrameCfg,
    GeoLibVideoIpeFrameCfg*         mExpOut,
    GeoLibVideoIpeFrameCfg*         slExpOut
);

/**
* @brief Per-frame video flow calculation for IPE.
*
* @param [in]  ipeConfig        Initial IPE configuration (from GeoLibVideoIpeInit)
* @param [in]  ifeFrameCfg      IFE frame calculations output. Should be passed from GeoLibVideoIfeCalcFrame
* @param [in]  fovcRatio        FOVC crop factor from 3A, in range [0, fovcMarginRatio]; where 0 means biggest FOV.
* @param [in]  prevFrameConfig  Previous frame configuration (NULL for first frame)
* @param [out] out              Output IPE configuration for current frame
*
* @return NC_LIB_SUCCESS or appropriate error code on failure.
*/
int32_t GeoLibVideoIpeCalcFrame(
    const GeoLibVideoIpeStreamCfg*  ipeConfig,
    const GeoLibVideoIfeFrameCfg*   ifeFrameCfg,
    const float                     fovcRatio,
    const GeoLibVideoIpeFrameCfg*   prevFrameConfig,
    GeoLibVideoIpeFrameCfg*         out
);

//-------------------------------------------------------------------------
// Lahaina Still section
//-------------------------------------------------------------------------

/**< GeoLib Still IPE Configuration for non-HDR, or for each HDR stage */
struct GeoLibStillIPEFrameConfig
{
    GeoLibIcaPassMapping            ica1Mapping;                /**< ICA1 mapping configuration */
    GeoLibIcaPassMapping            ica2Mapping;                /**< ICA2 mapping configuration */
    GeoLibIpeStripingConfig         ipeStripingInputs;          /**< Frame-level inputs to IPE striping library */
};

/**< GeoLib Still Configuration for non HDR, or for one HDR exposure */
struct GeoLibStillMFFrameConfig
{
    GeoLibImageSize                 bpsOutSizeFull;             /**< BPS 1:1 out image size */
    GeoLibImageSize                 bpsOutSizeDS4;              /**< BPS 1:4 out image size */
    GeoLibImageSize                 bpsOutSizeDS16;             /**< BPS 1:16 out image size */
    GeoLibImageSize                 bpsOutSizeDS64;             /**< BPS 1:64 out image size */
    GeoLibCropAndScale              bpsOutFullCrop;             /**< BPS 1:1 crop-only (no scaling) */
    GeoLibCropAndScale              bpsRegCropAndScale;         /**< BPS reg out M/N DS configuration */
    GeoLibGridRoi                   icaGridRoi;                 /**< ICA grid resampling. */

    GeoLibIcaMapping                cvpIcaMapping;              /**< CVP-ICA mapping configuration */
    GeoLibFloat2                    coarse2fullScale;           /**< Scale factor from coarse (CVP DME) domain to full (IPE in) domain */
    GeoLibFloat2                    coarseCenter;               /**< Transform center in coarse (CVP DME) domain. */

    GeoLibStillIPEFrameConfig       mfAnchor;                   /**< IPE configuration for MFxR Anchor frame. */
    GeoLibStillIPEFrameConfig       mfBlend;                    /**< IPE configuration for MFxR blend stage. */
    GeoLibStillIPEFrameConfig       mfFinal;                    /**< IPE configuration for single snapshot or for MFxR final stage. */
};

/**< GeoLib Still Configuration for HDR blend stage. */
struct GeoLibStillHDRBlendFrameConfig
{
    GeoLibImageSize                 ipeSizeFull;             /**< Combined IPE out 1:1 image size */
    GeoLibImageSize                 ipeSizeDS4;              /**< Combined IPE out 1:4 image size */

    GeoLibIcaPassMapping            exp1Mapping;                /**< ICA mapping configuration for the first exposure*/
    GeoLibIcaPassMapping            exp2Mapping;                /**< ICA mapping configuration for the second exposure*/
    GeoLibIcaPassMapping            exp3Mapping;                /**< ICA mapping configuration for the third exposure*/
    GeoLibIpeStripingConfig         ipeStripingInputs;          /**< Frame-level inputs to IPE striping library */

    GeoLibIcaMapping                cvpIcaMappingExp1;       /**< CVP-ICA mapping for the first exposure */
    GeoLibIcaMapping                cvpIcaMappingExp2;       /**< CVP-ICA mapping for the second exposure */
    GeoLibIcaMapping                cvpIcaMappingExp3;       /**< CVP-ICA mapping for the third exposure */
    GeoLibFloat2                    coarse2fullScale;        /**< Scale factor from coarse (CVP DME) domain to full (IPE in) domain */
    GeoLibFloat2                    coarseCenter;            /**< Transform center in coarse (CVP DME) domain. */
};

/**
* @brief Still flow calculation for Snapshot, MFNR (for each HDR exposure) or MFSR (non-HDR).
*
* NOTE: Multi-frame HDR cannot be enabled with MFSR, since MFSR cannot work in low-light (long exposure).
*
* @param [in]  flowMode         Use case description
* @param [in]  hdrMode          Either HDR or non-HDR flow mode. Must be GEOLIB_HDR_FLOW_DISABLED in Kona
* @param [in]  sensorData       A pointer to the sensor data (RDI), distorted pixels in case of LD
* @param [in]  ldFullOutToIn    Output-to-input LDC grid transform for this sensor. Defined in Chromatix (ICA:ctc_grid_x/ctc_grid_y), needs to be resampled to actual sensor output size.
* @param [in]  ldFullOutSize    Undistorted LDC output size, in square pixels. Should be zero when LDC is disabled. Defined in Chromatix (ICA:ld_full_out_width/ld_full_out_height)
* @param [in]  ipeParams        Requested IPE output parameters
* @param [in]  regOutSize       Registration image size for MFxR case. Should be NULL in case of still snapshot. Defined in Chromatix (CVP:multi_frame_input_resolution).
* @param [in]  zoomWindow       Digital zoom window on undistorted LDC domain, normalized
* @param [in]  fovcRatio        FOVC crop factor from 3A, in range [0, 1); where 0 means biggest FOV. 0 if no FOVC data is available.
* @param [in]  overrideFlags    Optional bitmask for overriding default behavior (zero by default), OR'ed GeoLibOverrideFlags.
* @param [out] stillConfig      Output configuration
*
* @return NC_LIB_SUCCESS or appropriate error code on failure.
*/
int32_t GeoLibStillCalcFrame(
    const GeoLibStillFlowMode       flowMode,
    const GeoLibHdrFlowMode         hdrMode,
    const GeoLibSensorData*         sensorData,
    const NcLibIcaGrid*             ldFullOutToIn,
    const GeoLibImageSize*          ldFullOutSize,
    const GeoLibIpeParams*          ipeParams,
    const GeoLibImageSize*          regOutSize,
    const GeoLibROI*                zoomWindow,
    const float                     fovcRatio,
    const uint32_t                  overrideFlags,
    GeoLibStillMFFrameConfig*       stillConfig
);

/**
* @brief Still flow calculation for HDR blend and last stages.
*
* @param [in]  sensorData       A pointer to the sensor data (RDI), distorted pixels in case of LD
* @param [in]  ldFullOutToIn    Output-to-input LDC grid transform for this sensor. Defined in Chromatix (ICA:ctc_grid_x/ctc_grid_y), needs to be resampled to actual sensor output size.
* @param [in]  ldFullOutSize    Undistorted LDC output size, in square pixels. Should be zero when LDC is disabled. Defined in Chromatix (ICA:ld_full_out_width/ld_full_out_height)
* @param [in]  regOutSizeExp1   Registration image size for HDR the first frame. Defined in Chromatix (CVP:multi_frame_input_resolution).
* @param [in]  regOutSizeExp2   Registration image size for HDR the second exposure. Defined in Chromatix (CVP:multi_frame_input_resolution).
* @param [in]  regOutSizeExp3   Registration image size for HDR the third exposure. Should be NULL for 2-exposure HDR. Defined in Chromatix (CVP:multi_frame_input_resolution).
* @param [in]  ipeParams        Requested IPE output parameters
* @param [in]  zoomWindow       Digital zoom window on undistorted LDC domain, normalized
* @param [in]  fovcRatio        FOVC crop factor from 3A, in range [0, 1); where 0 means biggest FOV. 0 if no FOVC data is available.
* @param [in]  overrideFlags    Optional bitmask for overriding default behavior (zero by default), OR'ed GeoLibOverrideFlags.
* @param [out] hdrBlend         Output configuration for blend stage
* @param [out] hdrLast          Output configuration for last (HDR final) stage
*
* @return NC_LIB_SUCCESS or appropriate error code on failure.
*/
int32_t GeoLibStillHdrCalcFrame(
    const GeoLibSensorData*         sensorData,
    const NcLibIcaGrid*             ldFullOutToIn,
    const GeoLibImageSize*          ldFullOutSize,
    const GeoLibImageSize*          regOutSizeExp1,
    const GeoLibImageSize*          regOutSizeExp2,
    const GeoLibImageSize*          regOutSizeExp3,
    const GeoLibIpeParams*          ipeParams,
    const GeoLibROI*                zoomWindow,
    const float                     fovcRatio,
    const uint32_t                  overrideFlags,
    GeoLibStillHDRBlendFrameConfig* hdrBlend,
    GeoLibStillIPEFrameConfig*      hdrLast
);


#endif // __GEOLIB_H__
