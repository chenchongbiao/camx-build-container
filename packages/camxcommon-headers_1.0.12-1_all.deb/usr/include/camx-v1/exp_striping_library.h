//------------------------------------------------------------------------
// Copyright (c) 2020 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
//------------------------------------------------------------------------
// @file  exp_striping_library.h
//------------------------------------------------------------------------

/*------------------------------------------------------------------------
*       Header file guard
* -----------------------------------------------------------------------*/
#ifndef __EXP_STRIPING_LIB__
#define __EXP_STRIPING_LIB__

/*------------------------------------------------------------------------
*       Include Files
* -----------------------------------------------------------------------*/
#include <stdio.h>
#include <stdint.h>
#include "tree.h"
#include "list.h"
#include "modules.h"
#include "stripe_common_define.h"

typedef enum
{
    CORE_ID_TFE = 0x0,
    CORE_ID_OPE,
    CORE_ID_BPS,
    CORE_ID_MAX
} CoreId;

typedef enum
{
    STRIPING_LIB_FATAL = 0x0,
    STRIPING_LIB_ERROR,
    STRIPING_LIB_WARNING,
    STRIPING_LIB_INFO,
    STRIPING_LIB_DEBUG,
    STRIPING_LIB_TRACE
} DebugVerbosity;

typedef enum
{
    STRIPE_DIRECTION_UNKNOWN = -1,
    STRIPE_DIRECTION_HORIZONTAL,
    STRIPE_DIRECTION_VERTICAL
} StripeDirection;

typedef enum
{
    STRIPE_POSITION_UNKNOWN = 0x0,
    STRIPE_POSITION_FIRST = 0x1,
    STRIPE_POSITION_MIDDLE = 0x2,
    STRIPE_POSITION_LAST = 0x4
} StripePosition;

typedef enum
{
    INVALID = 0x0,
    YUV444  = 0x1,
    BAYER   = 0x2,
    YUV420  = 0x3,
} PixelFormat;

typedef enum
{
    RET_SUCCESS = 0x0,
    RET_INVALID_INPUT,
    RET_INVALID_OPERATION,
    RET_MEMORY_ALLOC_FAILED,
    RET_MAX_STRIPE_LIMIT_REACHED
} ReturnCode;

extern const char* Module_ID[];

//Demosaic
typedef struct
{
    BOOL en;
} DemosaicInputParams;

typedef struct
{
    uint16_t enable;
    uint16_t firstOut;
    uint16_t lastOut;
} Crop;

//ChromaDS2
typedef struct {
    Crop y_cropper;
    MNScaleDownInStruct_V20_1D mnds_output;
} ChromaDS2OutputParams;

//LSC

typedef struct {
    Crop Lsc_pre_cropper;

    RollOffOutputParameters rolloffOutParams; //Legacy output struct
} LSCstripingOutputParameters;

// ANR
typedef struct
{
    BOOL     RNF_BYPASS__LUMA;
    BOOL     RNF_BYPASS__CHROMA;
    BOOL     CYLPF_Bypass;
    BOOL     CYLPF_Filter2_Bypass;
    BOOL     DCUS_DITHERING_Y_En;
    BOOL     DCUS_DITHERING_C_En;
    uint32_t CYLPF_DITHERING_seed;
    uint32_t DCUS_DITHERING_seed;
    uint32_t CYLPF_LG_Ystart;
    uint32_t CYLPF_LG_YExtStart;
    uint32_t CYLPF_LG_Xstart;
    uint32_t CYLPF_LG_YRelInc;
    uint32_t CYLPF_LG_YExtRelInc;
    uint32_t CYLPF_LG_XRelInc;
    uint16_t ANRDCinDim; //smaller passes dimention : one2fourwidth for full pass and likewise
    uint16_t ANRDCInConstraint;
    uint16_t ANRDCInFormat;
}
ANRStripingInputParams;

typedef struct {
    int32_t DCUS_DITHERING_seed;
    int32_t CYLPF_LG_YExtStart;
    int16_t PDI_Pack_StartPhase;
    int16_t PDI_Pack_Crop_HorizStart;
    int16_t PDI_Pack_Crop_HorizEnd;
    int16_t dummy_field_for_byte_padding;

    BOOL    pdi_fetch_en;
    int16_t pdiFetchFirst;
    int16_t pdiFetchLast;

    int16_t CNR_FD_Offset;
    int16_t DCUS_IN_CROP_START;
    int16_t DCUS_IN_CROP_END;
    int16_t DCUS_OUT_CROP_START;
    int16_t DCUS_OUT_CROP_END;
    int16_t lnrStart;
    int32_t CYLPF_LG_Xstart;
    int32_t CYLPF_LG_Ystart;
} ANRCylpfstripingOutputParams;

typedef struct {
    int32_t CYLPF_DITHERING_seed;
} ANRFilter2stripingOutputParams;


typedef struct
{
    BOOL en;
    BOOL lmEnableCurPass, lmEnablePrevPass;
    BOOL isLmcEnabledCurPass[ICA_LMC_CNT], isLmcEnabledPrevPass[ICA_LMC_CNT];         //likely redundant
    BOOL tf_dithering_en;
    BOOL useImgAsMctfpInput;                //during TF blending, the original image is used as the ref in. we therefore doesn't need to configure ref fetch
    BOOL morph_Dilate_En, morph_Erode_En;
    int16_t TfOut_CropOutHorizAssumeSize;   //    ASSUME_HORIZ_FILTER_SIZE_NONE = 0, ASSUME_HORIZ_FILTER_SIZE_5 = 1, ASSUME_HORIZ_FILTER_SIZE_13 = 2,
    int16_t trEnable;                       //0 for FULL pass
    int16_t trStartX;                       // range: 1...276
    int16_t trBlockNumX;                    // it can be 1...10 per image
    int16_t trBlockSizeX;
    int16_t dummy_field_for_byte_padding;
    int32_t prngSeed;
    int32_t tfLnrStartIdxFrame;
    int32_t tfLnrScale;
    uint16_t TFIInDim; //smaller passes dimention : one2fourwidth for full pass and likewise
    uint16_t TFIInFormat;
    uint16_t TFIInConstraint;
    uint16_t AlgmDim;
    uint16_t AlgmFormat;
    uint16_t AlgmOutFormat;
    uint16_t RefInFormat;
}
TFStripingInputParams;

typedef struct
{
    BOOL tfi_in_en;
    BOOL useIndications;
    int16_t trEnable;
    int16_t trStartX;
    int16_t trBlockNumX;
    int16_t trStartBlockIndex;              //to configure the write engine; to be removed once we set up write engine interfaces
    int32_t prngSeed;
    int32_t LnrStartIdx;

    CRCv10Striping1dOutputParams imgCropIn;
    CRCv10Striping1dOutputParams mctfpCropIn;
    CRCv10Striping1dOutputParams outIndicationsCropOut;

    BOOL    Morph_Erode_cropIn_Left;
    BOOL    Morph_Erode_cropIn_Right;
    int16_t indUpscale_cropOutLeft;
    int16_t indUpscale_cropOutRight;

    BOOL    indUpscale_cropIn_Left;
    BOOL    indUpscale_cropIn_Right;
    int16_t Morph_Erode_cropOut_start;
    int16_t Morph_Erode_cropOut_end;
    int16_t Morph_Dilate_cropOut_start;
    int16_t Morph_Dilate_cropOut_end;

    BOOL    tfRefRangeInROI;
    uint8_t lmCropAfterUpscale_left;    // v20 only
    uint8_t lmCropAfterUpscale_right;   // v20 only
    uint8_t lmCropAfterUpscale_top;     // v20 only
    uint8_t lmCropAfterUpscale_bottom;  // v20 only
    BOOL    lmCropOut_enable;           // v20 only
    uint16_t lmCropOut_horizStart;      // v20 only
    uint16_t lmCropOut_horizEnd;        // v20 only
    uint16_t lmCropOut_vertStart;       // v20 only
    uint16_t lmCropOut_vertEnd;         // v20 only

    BOOL    tfi_fetch_en;
    BOOL    leftStripeTFI;
    BOOL    rightStripeTFI;
    int16_t tfiFetchFirst;
    int16_t tfiFetchLast;

    int16_t refFetchFirst;
    int16_t refFetchLast;
}
TFStripingOutputParams;

//MNDS/Chroma DS2
typedef struct
{
    int16_t chroma_dn_ratio;
    uint16_t input_dimension;
    MNScaleDownInStruct_V20_1D frame_level_input; //Configured in init_scalar
    MNDSv20StripingInputParams mnds_input_param; //Legacy mnds input structure
} MNDSstripingInputParameters;

typedef struct
{
    uint16_t en;
    int32_t  phase_init;
    uint32_t phase_step;
    uint16_t input_l;
    uint16_t output_l;
    uint16_t pixel_offset;
    uint16_t interp_reso;
    uint16_t rounding_option_v;
    uint16_t rounding_option_h;
    uint32_t drop_first_output;
    uint16_t early_termination_h;
} MNDSstripingOutputParameters;

//LTMDC
typedef struct
{
    BOOL enable;                                //(ltm_enable && data_collect_en)
    BOOL data_collection_at_DC16_pass;          //1: use DC16 to do LTM data collection
    uint16_t ltmDCtableOption;
    MNScaleDownInStruct_V20_1D ltmdc_frame;
} LTMDCStripingInputParam;

typedef struct
{
    LTMV13StripeDCParams dc_out;
    int16_t ds_fac;
} LTMDCStripingOutputParam;

//LTMIP
typedef struct {
    BOOL enable;
    BOOL mask_filter_en;
    uint16_t input_length;
}LTMIPStripingInputParam;

typedef struct {
    BOOL enable;
    uint32_t y_phase_init;
    uint16_t y_preload;
    uint16_t y_dithering_mode;
    uint16_t c_dithering_mode;
    uint16_t c_rounding_option_h;
    Upscalev20Striping1dOutputParams frameConfig;  // Frame level parameter
}YUV_UpScaleStripingInputParam;

typedef struct {
    CRCv10Striping1dOutputParams    preCrop_y;
    CRCv10Striping1dOutputParams    preCrop_C;
    Upscalev20Striping1dOutputParams upscaleOut_y;
    Upscalev20Striping1dOutputParams upscaleOut_c;
}YUV_UpScaleStripingOutputParam;

typedef struct {
    int16_t c_scale_in_cfg_rounding_option_h;
    int16_t c_scale_in_cfg_rounding_option_v;
    uint16_t OVERLAP_H;                         // v23 4uQ4 0:15
    uint16_t NN_EN;                             // nearest neighbor mode for catmap downscaling beginning waipioplus
    MNScaleDownInStruct_V20_1D frameParam_y;
    MNScaleDownInStruct_V20_1D frameParam_c;
}YUV_MNDSStripingInputParam;

typedef struct {
    CRCv10Striping1dOutputParams    preCrop_y;
    CRCv10Striping1dOutputParams    preCrop_c;
    MNScaleDownInStruct_V20_1D      mnds_out_y;
    MNScaleDownInStruct_V20_1D      mnds_out_c;
}YUV_MNDSStripingOutputParam;

typedef struct {
    CRCv10Striping1dOutputParams        preCrop_y;
    CRCv10Striping1dOutputParams        preCrop_C;
    ChromaUpv201dStripingOutputParams   chromaup;
} ChromaUpOutputParam;

/*typedef struct {
    uint16_t inStart;
    uint16_t inEnd;
} IcaOutputParams;*/

#define MODULE_ID_MAX_SIZE  100

typedef struct
{
    uint16_t enable;
    uint16_t version;
    uint16_t max_buffer_size;
    uint8_t input_format;
    uint8_t output_format;
} ModuleConfig;

typedef struct {
    ModuleConfig moduleConfig; //Common module properties
    //char* pModuleId; //"Module_ID+Instance" identifier
    uint64_t nModuleId; //"Module_ID+Instance" identifier
    void* pInputModuleData; //Module specific input params
    ListHandle* pOutputModuleDataListHandle; //List of module specific output params for each stripe
    void* pStripingInternalData; //Internal to striping library
} NodeInfo;

typedef struct
{
    ListHandle hModuleList; //List of NodeInfo
} StripingParams;

typedef struct
{
    uint16_t start;
    uint16_t size;
} ROI;

typedef struct
{
    uint16_t stripe_start;
    uint16_t stripe_end;
    uint16_t stripe_position;
    uint16_t target_start;
    uint16_t target_end;
    uint16_t target_out;
} StripeRange;

typedef struct
{
    uint16_t    stripeDirection;
    uint16_t    inputDimension; // horizontal and vertical
    uint16_t    Width;
    uint16_t    Height;
    uint16_t    inputFormatConstraint;
    uint16_t    cropStart; // For format Alignment
    uint16_t    cropEnd;
    uint16_t    shrinkEnd; // Shrink size When calculated fetch is greater than line buffer size
    zoom_window fullFrameROI;
    ROI         fovRoiPerDimension;
} RootNodeParams;

typedef struct
{
    BOOL bypass;
    int16_t     remainingPixelsToAllocate; // Number of remaining pixels to be allocated, per output port
    uint16_t    outputDimension;
    uint16_t    outputFormatConstraint;
    int32_t     isLeftStripe;
    int32_t     isRightStripe;
    ROI         fovRoiPerDimension;
} LeafNodeParams;

typedef struct
{
    StripeRange stripeRange;
    Crop cropConfig;
} LeafNodeOutputConfig;

typedef struct
{
    uint16_t option;
} MuxNodeInputParams;

//void sl_log(int level, const char *fmt, ...);
#define LOG_LEVEL STRIPING_LIB_TRACE
#define GET_LOG(x) ( (x <= LOG_LEVEL) ? TRUE : FALSE )

#define SL_FATAL(...) DEBUG_INFO_IF(GET_LOG(STRIPING_LIB_FATAL), __VA_ARGS__)
#define SL_ERROR(...) DEBUG_INFO_IF(GET_LOG(STRIPING_LIB_ERROR), __VA_ARGS__)
#define SL_WARNING(...) DEBUG_INFO_IF(GET_LOG(STRIPING_LIB_WARNING), __VA_ARGS__)

#define SL_INFO(...)  DEBUG_INFO_IF(GET_LOG(STRIPING_LIB_INFO),  __VA_ARGS__)
#define SL_DEBUG(...) DEBUG_INFO_IF(GET_LOG(STRIPING_LIB_DEBUG), __VA_ARGS__)
#define SL_TRACE(...) DEBUG_INFO_IF(GET_LOG(STRIPING_LIB_TRACE), __VA_ARGS__)

extern FILE *sl_logFile;

#if (WITH_DEBUG_INFO == 1)
#define SL_LOG(...) do{ \
                        if(sl_logFile != NULL) \
                        { \
                            fprintf(sl_logFile, __VA_ARGS__); \
                        }\
                      }WHILE_0
#else
#define SL_LOG(...)
#endif

uint16_t init(int anTiering, CoreId anCoreId);

uint16_t configure_striping(StripingParams* apStripingParams, CoreId anCoreId);

uint16_t deinit(CoreId anCoreId);

//Helper functions
BOOL check_if_left_stripe(uint16_t anStripePosition);
BOOL check_if_right_stripe(uint16_t anStripePosition);

#endif //__EXP_STRIPING_LIB__

