////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2019, 2024 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @file  camxopebpcabf41titan5x.h
/// @brief OPE BPCABF41 register setting for Titan5x
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef CAMXOPEBPCABF41TITAN5X_H
#define CAMXOPEBPCABF41TITAN5X_H

#include "camxisphwsetting.h"
#include "bpcabf41setting.h"
#include "camxcmdbuffer.h"
#include "camxispiqmodule.h"
#include "camxtitan5xdefs.h"
#include "camxiqinterface.h"
#include "camxopebpcabf41.h"

CAMX_NAMESPACE_BEGIN

static const UINT32 OPEMaxABFLUT                       = 1;
static const UINT32 OPEBPCABF41NoiseLUTSizeDword       = 64;  // 64 entries in the DMI table
static const UINT32 OPEBPCABF41NoiseLUTSize            = (OPEBPCABF41NoiseLUTSizeDword * OPERegisterWidthInBytes);

static const UINT32 OPEBPCABFDMILUTInit[] =
{
    0x000071FF, 0x000131C7, 0x00006F2F, 0x000028F8, 0x000042E4, 0x00001AC3, 0x000016B6, 0x000026AB,
    0x00001098, 0x00000E90, 0x00000E89, 0x00000C82, 0x00000A7C, 0x00000A77, 0x00000072, 0x00000A72,
    0x0000086D, 0x00000869, 0x00000065, 0x00000665, 0x00000862, 0x0000065E, 0x0000005B, 0x0000065B,
    0x00000658, 0x00000055, 0x00000455, 0x00000053, 0x00000653, 0x00000450, 0x0000004E, 0x0000044E,
    0x0000004C, 0x0000044C, 0x0000004A, 0x0000044A, 0x00000448, 0x00000046, 0x00000446, 0x00000044,
    0x00000244, 0x00000043, 0x00000443, 0x00000041, 0x00000241, 0x00000040, 0x00000440, 0x0000003E,
    0x0000003E, 0x0000003E, 0x0000003E, 0x0000003E, 0x0000003E, 0x0000003E, 0x0000003E, 0x0000003E,
    0x0000003E, 0x0000003E, 0x0000003E, 0x0000003E, 0x0000003E, 0x0000003E, 0x0000003E, 0x0000003E
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief OPE BPCABF41 register setting for Titan5x
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
class OPEBPCABF41Titan5x final : public ISPHWSetting
{
public:
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// CreateCmdList
    ///
    /// @brief  Generate the Command List
    ///
    /// @param  pInputData                Pointer to the Inputdata
    /// @param  pBPCABFHwSettingParams    Pointer for DMI Buffer
    ///
    /// @return CamxResultSuccess if successful.
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual CamxResult CreateCmdList(
        VOID*   pInputData,
        UINT32* pBPCABFHwSettingParams);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// CreateSubCmdList
    ///
    /// @brief  Generate the Sub Command List
    ///
    /// @param  pInputData       Pointer to the Inputdata
    /// @param  pDMIBufferOffset Pointer for DMI Buffer
    /// @param  pInput           Pointer to the Input data to the module enablement
    ///
    /// @return CamxResultSuccess if successful.
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual CamxResult CreateSubCmdList(
        VOID*   pInputData,
        UINT32* pDMIBufferOffset,
        VOID*   pInput);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// UpdateTuningMetadata
    ///
    /// @brief  Update Tuning Metadata
    ///
    /// @param  pInputData      Pointer to the InputData
    ///
    /// @return CamxResultSuccess if successful.
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual CamxResult UpdateTuningMetadata(
        VOID*  pInputData);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// PackIQRegisterSetting
    ///
    /// @brief  Calculate register settings based on common library result
    ///
    /// @param  pInput       Pointer to the Input data to the module for calculation
    /// @param  pOutput      Pointer to the Output data to the module for DMI buffer
    ///
    /// @return Return CamxResult.
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual CamxResult PackIQRegisterSetting(
        VOID* pInput,
        VOID* pOutput);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// ~OPEBPCABF41Titan5x
    ///
    /// @brief  Destructor
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual ~OPEBPCABF41Titan5x();

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// OPEBPCABF41Titan5x
    ///
    /// @brief  Constructor
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    OPEBPCABF41Titan5x();

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// DumpRegConfig
    ///
    /// @brief  Print register configuration of Crop module for debug
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    VOID DumpRegConfig();

private:
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// CreateFrameCmdList
    ///
    /// @brief  Generate the Command List
    ///
    /// @param  pInputData                Pointer to the Inputdata
    /// @param  pBPCABFHwSettingParams    Pointer for DMI Buffer
    ///
    /// @return CamxResultSuccess if successful.
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    CamxResult CreateFrameCmdList(
        VOID*   pInputData,
        UINT32* pBPCABFHwSettingParams);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// CreateStripeCmdList
    ///
    /// @brief  Generate the Command List
    ///
    /// @param  pInputData       Pointer to the Inputdata
    ///
    /// @return CamxResultSuccess if successful.
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    CamxResult CreateStripeCmdList(
        VOID*   pInputData);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// PackFrameIQRegisterSetting
    ///
    /// @brief  Calculate register settings per frame based on common library result
    ///
    /// @param  pInput       Pointer to the Input data to the module for calculation
    /// @param  pOutput      Pointer to the Output data to the module for DMI buffer
    ///
    /// @return Return CamxResult.
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    CamxResult PackFrameIQRegisterSetting(
        VOID* pInput,
        VOID* pOutput);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// PackStripeIQRegisterSetting
    ///
    /// @brief  Calculate register settings per stripe based on common library result
    ///
    /// @param  pInput         Pointer to the Input data to the module for calculation
    /// @param  pOutput        Pointer to the Output data to the module.
    ///
    /// @return Return CamxResult.
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    CamxResult PackStripeIQRegisterSetting(
        VOID* pInput,
        VOID* pOutput);


    VOID*            m_pRegCmd;           ///< ABFBPC Register List
    UINT32*          m_pNoiseLUT;         ///< Tuning ABF, holder of LUTs
    OPEBPCABF41Titan5x(const OPEBPCABF41Titan5x&)              = delete; ///< Disallow the copy constructor
    OPEBPCABF41Titan5x& operator=(const OPEBPCABF41Titan5x&) = delete; ///< Disallow assignment operator
};

CAMX_NAMESPACE_END

#endif // CAMXOPEBPCABF41TITAN5X_H
