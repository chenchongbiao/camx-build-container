// NOWHINE ENTIRE FILE
//-------------------------------------------------------------------------
// Copyright (c) 2020 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
//------------------------------------------------------------------------

#ifndef __PROCESS_LCAC_H__
#define __PROCESS_LCAC_H__

#include "LCAC_Chromatix.h"
#include "LCAC_Registers.h"
#include "NcLibContext.h"

#define LCAC_IFE_MIN_WIDTH 38u
#define LCAC_BPS_MIN_WIDTH 18u

/**
*  @brief   Calculate LCAC registers which are set directly by Chromatix.
*
*  @param [in]      chromatixStruct             pointer to the Chromatix struct
*  @param [in]      context                     LCAC SW Context struct
*  @param [out]     regStruct                   pointer to the register struct
*
*  @return NC_LIB_SUCCESS in case of success, otherwise failed.
*/
int32_t LCAC_ProcessNcLib(const LCAC_Chromatix* chromatixStruct,
                          const NCLIB_CONTEXT_LCAC* context,
                          LCAC_REG* regStruct);

/**
*  @brief   Validate LCAC SW Context
*
*  @param [in]      context                    LCAC SW Context struct to validate
*
*  @return NC_LIB_SUCCESS in case of success, otherwise failed.
*/
int32_t Validate_LCAC_Context(NCLIB_CONTEXT_LCAC* context);

#endif //__PROCESS_LCAC_H__