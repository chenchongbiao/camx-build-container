#ifndef _MODULESOPE_H_
#define _MODULESOPE_H_

// TODO : move all deprecated structs to internal header files.

//-------------------------------------------------------------------------
// Copyright (c) 2020 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
//------------------------------------------------------------------------

//------------------------------------------------------------------------
// @file  modulesOPE.h
// @brief striping output for each OPE module
//------------------------------------------------------------------------

/*------------------------------------------------------------------------
*       Include Files
* ----------------------------------------------------------------------- */
#include "modules.h"

/*------------------------------------------------------------------------
*       Type Declarations
* ----------------------------------------------------------------------- */

#pragma pack(push)
#pragma pack(4)

// ABF_BPC_v4.1
/*
typedef struct {
  BOOL en;
  BOOL bpc_en;
  BOOL abf_en;
  int16_t bayer_pattern;
} ABFBPCInputParams;

typedef struct {
  RnrStripingOutputParams rnr;
  int16_t bayer_pattern;
} ABFBPCOutputParams;
*/ //Included in modules.h

typedef enum {
  WNR_LAYER_0 = 0,
  WNR_LAYER_1 = 1,
  WNR_LAYER_2 = 2,
  WNR_LAYER_3 = 3,
  WNR_LAYER_COUNT_Y = 3,
  WNR_LAYER_COUNT_C = 4,
  WNR_LAYER_MAXCOUNT = 4
} WNR_Layers;

// WNR_v2.4
typedef struct {
  BOOL enable;                            // 0x0: Disable luma denoise module. 0x1: Enable luma denoise module
  BOOL autocrop_disable;                  // 0x0: Enable auto crop in luma denoise. 0x1: Disable auto crop in luma denoise
  BOOL layer_enable[WNR_LAYER_MAXCOUNT];   // 0x0: Disable per layer luma denoise. 0x1: Enable per layer luma denoise
  uint16_t x_coordinate;      // 16u. Horizontal center of radial correction
  uint16_t r_square[WNR_LAYER_MAXCOUNT];  // 3 radial control points.
  uint8_t  r_square_shift;               // Range: 0-19
} WNRInputParams;

typedef struct {
  int16_t  init_offset_minus_center_h;
  int16_t  init_offset_minus_center_v;
  uint32_t r_square_init;
  uint8_t  r_square_scale;
  uint8_t  r_square_shift;
} WNROutputParams;

// RS_v1.5
/*
typedef struct {
  BOOL enable;
  uint16_t  rs_rgn_h_offset; //13, Programmable offset of the starting pixel for row sum
  uint16_t  rs_rgn_v_num;
  uint16_t  rs_rgn_h_num;    //4, umber of horizontal regions n means n+1
  uint16_t  rs_rgn_width;
} RSInputParams;

typedef struct {
  BOOL     en;
  uint16_t rs_rgn_h_offset;     //13, Programmable offset of the starting pixel for row sum
  uint16_t rs_rgn_h_num;        //4, umber of horizontal regions (c) ?1
  uint16_t first_hor_rgn_width; //13, "Width of first column of regions in pixels, (ROI width) n means n+1"
  uint16_t last_hor_rgn_width;  //13, "Width of last column of regions in pixels, (ROI width) n means n+1"
} RSOutputParams;
*/ // included in modules.h
#pragma pack(pop)

#endif /*_MODULESOPE_H_ */