////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
// All rights reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
//
// Not a Contribution.
// Copyright (C) 2012 The Android Open Source Project
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @file  camera3_metadata_tags.h
/// @brief Declarations of metadata tags
///
/// Original tag definitions are defined in system/media/camera/include/system/camera_metadata_tags.h
/// Additional documentation on Google defined metadata tags can be found at system/media/camera/docs/docs.html
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// NOWHINE FILE GR002: Little extra length == much greater readability

#include <cstdint>


/// @brief Camera Metadata section definitions
enum CameraMetadataSection
{
    MetadataSectionColorCorrection,
    MetadataSectionControl,
    MetadataSectionDemosaic,
    MetadataSectionEdge,
    MetadataSectionFlash,
    MetadataSectionFlashInfo,
    MetadataSectionHotPixel,
    MetadataSectionJPEG,
    MetadataSectionLens,
    MetadataSectionLensInfo,
    MetadataSectionNoiseReduction,
    MetadataSectionQuirks,
    MetadataSectionRequest,
    MetadataSectionScaler,
    MetadataSectionSensor,
    MetadataSectionSensorInfo,
    MetadataSectionShading,
    MetadataSectionStatistics,
    MetadataSectionStatisticsInfo,
    MetadataSectionTonemap,
    MetadataSectionLed,
    MetadataSectionInfo,
    MetadataSectionBlackLevel,
    MetadataSectionSync,
    MetadataSectionReprocess,
    MetadataSectionDepth,
    MetadataSectionLogicalMultiCamera,
    MetadataSectionDistortionCorrection,
    MetadataSectionHEIC,
    MetadataSectionHEICInfo,
    MetadataSectionSectionCount,
    MetadataSectionVendorSection = 0x8000
};

/// @brief Hierarchy positions in enum space. All vendor extension tags must be defined with tag >= VendorSectionStart
enum CameraMetadataSectionStart
{
    MetadataSectionColorCorrectionStart      = MetadataSectionColorCorrection      << 16,
    MetadataSectionControlStart              = MetadataSectionControl              << 16,
    MetadataSectionDemosaicStart             = MetadataSectionDemosaic             << 16,
    MetadataSectionEdgeStart                 = MetadataSectionEdge                 << 16,
    MetadataSectionFlashStart                = MetadataSectionFlash                << 16,
    MetadataSectionFlashInfoStart            = MetadataSectionFlashInfo            << 16,
    MetadataSectionHotPixelStart             = MetadataSectionHotPixel             << 16,
    MetadataSectionJPEGStart                 = MetadataSectionJPEG                 << 16,
    MetadataSectionLensStart                 = MetadataSectionLens                 << 16,
    MetadataSectionLensInfoStart             = MetadataSectionLensInfo             << 16,
    MetadataSectionNoiseReductionStart       = MetadataSectionNoiseReduction       << 16,
    MetadataSectionQuirksStart               = MetadataSectionQuirks               << 16,
    MetadataSectionRequestStart              = MetadataSectionRequest              << 16,
    MetadataSectionScalerStart               = MetadataSectionScaler               << 16,
    MetadataSectionSensorStart               = MetadataSectionSensor               << 16,
    MetadataSectionSensorInfoStart           = MetadataSectionSensorInfo           << 16,
    MetadataSectionShadingStart              = MetadataSectionShading              << 16,
    MetadataSectionStatisticsStart           = MetadataSectionStatistics           << 16,
    MetadataSectionStatisticsInfoStart       = MetadataSectionStatisticsInfo       << 16,
    MetadataSectionTonemapStart              = MetadataSectionTonemap              << 16,
    MetadataSectionLedStart                  = MetadataSectionLed                  << 16,
    MetadataSectionInfoStart                 = MetadataSectionInfo                 << 16,
    MetadataSectionBlackLevelStart           = MetadataSectionBlackLevel           << 16,
    MetadataSectionSyncStart                 = MetadataSectionSync                 << 16,
    MetadataSectionReprocessStart            = MetadataSectionReprocess            << 16,
    MetadataSectionDepthStart                = MetadataSectionDepth                << 16,
    MetadataSectionLogicalMultiCameraStart   = MetadataSectionLogicalMultiCamera   << 16,
    MetadataSectionDistortionCorrectionStart = MetadataSectionDistortionCorrection << 16,
    MetadataSectionHEICStart                 = MetadataSectionHEIC                 << 16,
    MetadataSectionHEICInfoStart             = MetadataSectionHEICInfo             << 16,
    MetadataSectionVendorSectionStart        = MetadataSectionVendorSection        << 16
};

/// @brief Main enum for defining camera metadata tags.
enum CameraMetadataTag : uint32_t
{
    ColorCorrectionMode                             = MetadataSectionColorCorrectionStart,
    ColorCorrectionTransform,
    ColorCorrectionGains,
    ColorCorrectionAberrationMode,
    ColorCorrectionAvailableAberrationModes,
    ColorCorrectionEnd,

    ControlAEAntibandingMode                        = MetadataSectionControlStart,
    ControlAEExposureCompensation,
    ControlAELock,
    ControlAEMode,
    ControlAERegions,
    ControlAETargetFpsRange,
    ControlAEPrecaptureTrigger,
    ControlAFMode,
    ControlAFRegions,
    ControlAFTrigger,
    ControlAWBLock,
    ControlAWBMode,
    ControlAWBRegions,
    ControlCaptureIntent,
    ControlEffectMode,
    ControlMode,
    ControlSceneMode,
    ControlVideoStabilizationMode,
    ControlAEAvailableAntibandingModes,
    ControlAEAvailableModes,
    ControlAEAvailableTargetFPSRanges,
    ControlAECompensationRange,
    ControlAECompensationStep,
    ControlAFAvailableModes,
    ControlAvailableEffects,
    ControlAvailableSceneModes,
    ControlAvailableVideoStabilizationModes,
    ControlAWBAvailableModes,
    ControlMaxRegions,
    ControlSceneModeOverrides,
    ControlAEPrecaptureId,
    ControlAEState,
    ControlAFState,
    ControlAFTriggerId,
    ControlAWBState,
    ControlAvailableHighSpeedVideoConfigurations,
    ControlAELockAvailable,
    ControlAWBLockAvailable,
    ControlAvailableModes,
    ControlPostRawSensitivityBoostRange,
    ControlPostRawSensitivityBoost,
    ControlZslEnable,
    ControlAFSceneChange,
    ControlAvailableExtendedSceneModeMaxSizes,
    ControlAvailableExtendedSceneModeZoomRatioRanges,
    ControlExtendedSceneMode,
    ControlZoomRatioRange,
    ControlZoomRatio,
    ControlEnd,

    DemosaicMode                                    = MetadataSectionDemosaicStart,
    DemosaicEnd,

    EdgeMode                                        = MetadataSectionEdgeStart,
    EdgeStrength,
    EdgeAvailableEdgeModes,
    EdgeEnd,

    FlashFiringPower                                = MetadataSectionFlashStart,
    FlashFiringTime,
    FlashMode,
    FlashColorTemperature,
    FlashMaxEnergy,
    FlashState,
    FlashEnd,

    FlashInfoAvailable                              = MetadataSectionFlashInfoStart,
    FlashInfoChargeDuration,
    FlashInfoEnd,

    HotPixelMode                                    = MetadataSectionHotPixelStart,
    HotPixelAvailableHotPixelModes,
    HotPixelEnd,

    JPEGGpsCoordinates                              = MetadataSectionJPEGStart,
    JPEGGpsProcessingMethod,
    JPEGGpsTimestamp,
    JPEGOrientation,
    JPEGQuality,
    JPEGThumbnailQuality,
    JPEGThumbnailSizeTag,
    JPEGAvailableThumbnailSizes,
    JPEGMaxSize,
    JPEGSize,
    JPEGEnd,

    LensAperture                                    = MetadataSectionLensStart,
    LensFilterDensity,
    LensFocalLength,
    LensFocusDistance,
    LensOpticalStabilizationMode,
    LensFacing,
    LensPoseRotation,
    LensPoseTranslation,
    LensFocusRange,
    LensState,
    LensIntrinsicCalibration,
    LensRadialDistortion,
    LensPoseReference,
    LensDistortion,
    LensEnd,

    LensInfoAvailableApertures                      = MetadataSectionLensInfoStart,
    LensInfoAvailableFilterDensities,
    LensInfoAvailableFocalLengths,
    LensInfoAvailableOpticalStabilization,
    LensInfoHyperfocalDistance,
    LensInfoMinimumFocusDistance,
    LensInfoShadingMapSize,
    LensInfoFocusDistanceCalibration,
    LensInfoEnd,

    NoiseReductionMode                              = MetadataSectionNoiseReductionStart,
    NoiseReductionStrength,
    NoiseReductionAvailableNoiseReductionModes,
    NoiseReductionEnd,

    QuirksMeteringCropRegion                        = MetadataSectionQuirksStart,
    QuirksTriggerAFWithAuto,
    QuirksUseZslFormat,
    QuirksUsePartialResult,
    QuirksPartialResult,
    QuirksEnd,

    RequestFrameCount                               = MetadataSectionRequestStart,
    RequestId,
    RequestInputStreams,
    RequestMetadataMode,
    RequestOutputStreams,
    RequestType,
    RequestMaxNumOutputStreams,
    RequestMaxNumReprocessStreams,
    RequestMaxNumInputStreams,
    RequestPipelineDepth,
    RequestPipelineMaxDepth,
    RequestPartialResultCount,
    RequestAvailableCapabilities,
    RequestAvailableRequestKeys,
    RequestAvailableResultKeys,
    RequestAvailableCharacteristicsKeys,
    RequestAvailableSessionKeys,
    RequestAvailablePhysicalCameraRequestKeys,
    RequestCharacteristicKeysNeedingPermission,
    RequestEnd,

    ScalerCropRegion                                = MetadataSectionScalerStart,
    ScalerAvailableFormats,
    ScalerAvailableJPEGMinDurations,
    ScalerAvailableJPEGSizes,
    ScalerAvailableMaxDigitalZoom,
    ScalerAvailableProcessedMinDurations,
    ScalerAvailableProcessedSizes,
    ScalerAvailableRawMinDurations,
    ScalerAvailableRawSizes,
    ScalerAvailableInputOutputFormatsMap,
    ScalerAvailableStreamConfigurations,
    ScalerAvailableMinFrameDurations,
    ScalerAvailableStallDurations,
    ScalerCroppingType,
    ScalerAvailableRecommendedStreamConfigurations,
    ScalerAvailableRecommendedInputOutputFormatsMap,
    ScalerEnd,

    SensorExposureTime                              = MetadataSectionSensorStart,
    SensorFrameDuration,
    SensorSensitivity,
    SensorReferenceIlluminant1,
    SensorReferenceIlluminant2,
    SensorCalibrationTransform1,
    SensorCalibrationTransform2,
    SensorColorTransform1,
    SensorColorTransform2,
    SensorForwardMatrix1,
    SensorForwardMatrix2,
    SensorBaseGainFactor,
    SensorBlackLevelPattern,
    SensorMaxAnalogSensitivity,
    SensorOrientation,
    SensorProfileHueSaturationMapDimensions,
    SensorTimestamp,
    SensorTemperature,
    SensorNeutralColorPoint,
    SensorNoiseProfile,
    SensorProfileHueSaturationMap,
    SensorProfileToneCurve,
    SensorGreenSplit,
    SensorTestPatternData,
    SensorTestPatternMode,
    SensorAvailableTestPatternModes,
    SensorRollingShutterSkew,
    SensorOpticalBlackRegions,
    SensorDynamicBlackLevel,
    SensorDynamicWhiteLevel,
    SensorOpaqueRawSize,
    SensorEnd,

    SensorInfoActiveArraySize                       = MetadataSectionSensorInfoStart,
    SensorInfoSensitivityRange,
    SensorInfoColorFilterArrangement,
    SensorInfoExposureTimeRange,
    SensorInfoMaxFrameDuration,
    SensorInfoPhysicalSize,
    SensorInfoPixelArraySize,
    SensorInfoWhiteLevel,
    SensorInfoTimestampSource,
    SensorInfoLensShadingApplied,
    SensorInfoPreCorrectionActiveArraySize,
    SensorInfoEnd,

    ShadingMode                                     = MetadataSectionShadingStart,
    ShadingStrength,
    ShadingAvailableModes,
    ShadingEnd,

    StatisticsFaceDetectMode                        = MetadataSectionStatisticsStart,
    StatisticsHistogramMode,
    StatisticsSharpnessMapMode,
    StatisticsHotPixelMapMode,
    StatisticsFaceIds,
    StatisticsFaceLandmarks,
    StatisticsFaceRectangles,
    StatisticsFaceScores,
    StatisticsHistogram,
    StatisticsSharpnessMap,
    StatisticsLensShadingCorrectionMap,
    StatisticsLensShadingMap,
    StatisticsPredictedColorGains,
    StatisticsPredictedColorTransform,
    StatisticsSceneFlicker,
    StatisticsHotPixelMap,
    StatisticsLensShadingMapMode,
    StatisticsOISDataMode,
    StatisticsOISTimestamps,
    StatisticsOISXShifts,
    StatisticsOISYShifts,
    StatisticsEnd,

    StatisticsInfoAvailableFaceDetectModes          = MetadataSectionStatisticsInfoStart,
    StatisticsInfoHistogramBucketCount,
    StatisticsInfoMaxFaceCount,
    StatisticsInfoMaxHistogramCount,
    StatisticsInfoMaxSharpnessMapValue,
    StatisticsInfoSharpnessMapSize,
    StatisticsInfoAvailableHotPixelMapModes,
    StatisticsInfoAvailableLensShadingMapModes,
    StatisticsInfoAvailableOISDataModes,
    StatisticsInfoEnd,

    TonemapCurveBlue                                = MetadataSectionTonemapStart,
    TonemapCurveGreen,
    TonemapCurveRed,
    TonemapMode,
    TonemapMaxCurvePoints,
    TonemapAvailableToneMapModes,
    TonemapGamma,
    TonemapPresetCurve,
    TonemapEnd,

    LedTransmit                                     = MetadataSectionLedStart,
    LedAvailableLeds,
    LedEnd,

    InfoSupportedHardwareLevel                      = MetadataSectionInfoStart,
    InfoVersion,
    InfoSupportedBufferManagementVersion,
    InfoEnd,

    BlackLevelLock                                  = MetadataSectionBlackLevelStart,
    BlackLevelEnd,

    SyncFrameNumber                                 = MetadataSectionSyncStart,
    SyncMaxLatency,
    SyncEnd,

    ReprocessEffectiveExposureFactor                = MetadataSectionReprocessStart,
    ReprocessMaxCaptureStall,
    ReprocessEnd,

    DepthMaxDepthSamples                            = MetadataSectionDepthStart,
    DepthAvailableDepthStreamConfigurations,
    DepthAvailableDepthMinFrameDurations,
    DepthAvailableDepthStallDurations,
    DepthDepthIsExclusive,
    DepthAvailableRecommendedDepthStreamConfigurations,
    DepthAvailableDynamicDepthStreamConfigurations,
    DepthAvailableDynamicDepthMinFrameDurations,
    DepthAvailableDynamicDepthStallDurations,
    DepthEnd,

    LogicalMultiCameraPhysicalIDs                     = MetadataSectionLogicalMultiCameraStart,
    LogicalMultiCameraSensorSyncType,
    LogicalMultiCameraActivePhysicalId,
    LogicalMultiCameraEnd,

    DistortionCorrectionMode                          = MetadataSectionDistortionCorrectionStart,
    DistortionCorrectionAvailableModes,
    DistortionCorrectionEnd,

    HEICAvailableHEICStreamConfigurations             = MetadataSectionHEICStart,
    HEICAvailableHEICMinFrameDurations,
    HEICAvailableHEICStallDurations,
    HEICEnd,

    HEICInfoSupported                                 = MetadataSectionHEICInfoStart,
    HEICInfoMaxJpegAppSegmentsCount,
    HEICInfoEnd
};

/// @brief ColorCorrectionMode
enum ColorCorrectionModeValues
{
    ColorCorrectionModeTransformMatrix,
    ColorCorrectionModeFast,
    ColorCorrectionModeHighQuality,
    ColorCorrectionModeEnd
};

/// @brief ColorCorrectionAberrationMode
enum ColorCorrectionAberrationModeValues
{
    ColorCorrectionAberrationModeOff,
    ColorCorrectionAberrationModeFast,
    ColorCorrectionAberrationModeHighQuality,
    ColorCorrectionAberrationModeEnd
};

/// @brief ControlAEAntibandingMode
enum ControlAEAntibandingModeValues
{
    ControlAEAntibandingModeOff,
    ControlAEAntibandingMode50Hz,
    ControlAEAntibandingMode60Hz,
    ControlAEAntibandingModeAuto,
    ControlAEAntibandingAuto_50HZ,
    ControlAEAntibandingAuto_60HZ,
    ControlAEAntibandingModeEnd
};

/// @brief ControlAELock
enum ControlAELockValues
{
    ControlAELockOff,
    ControlAELockOn,
    ControlAELockEnd
};

/// @brief ControlAEMode
enum ControlAEModeValues
{
    ControlAEModeOff,
    ControlAEModeOn,
    ControlAEModeOnAutoFlash,
    ControlAEModeOnAlwaysFlash,
    ControlAEModeOnAutoFlashRedeye,
    ControlAEModeOnExternalFlash,
    ControlAEModeEnd
};

/// @brief ControlAEPrecaptureTrigger
enum ControlAEPrecaptureTriggerValues
{
    ControlAEPrecaptureTriggerIdle,
    ControlAEPrecaptureTriggerStart,
    ControlAEPrecaptureTriggerCancel,
    ControlAEPrecaptureTriggerEnd
};

/// @brief ControlAFMode
enum ControlAFModeValues
{
    ControlAFModeOff,
    ControlAFModeAuto,
    ControlAFModeMacro,
    ControlAFModeContinuousVideo,
    ControlAFModeContinuousPicture,
    ControlAFModeEdof,
    ControlAFModeEnd
};

/// @brief ControlAFTrigger
enum ControlAFTriggerValues
{
    ControlAFTriggerIdle,
    ControlAFTriggerStart,
    ControlAFTriggerCancel,
    ControlAFTriggerEnd
};

/// @brief ControlAWBLock
enum ControlAWBLockValues
{
    ControlAWBLockOff,
    ControlAWBLockOn,
    ControlAWBLockEnd
};

/// @brief ControlAWBMode
enum ControlAWBModeValues
{
    ControlAWBModeOff,
    ControlAWBModeAuto,
    ControlAWBModeIncandescent,
    ControlAWBModeFluorescent,
    ControlAWBModeWarmFluorescent,
    ControlAWBModeDaylight,
    ControlAWBModeCloudyDaylight,
    ControlAWBModeTwilight,
    ControlAWBModeShade,
    ControlAWBModeEnd
};

/// @brief ControlCaptureIntent
enum ControlCaptureIntentValues
{
    ControlCaptureIntentCustom,
    ControlCaptureIntentPreview,
    ControlCaptureIntentStillCapture,
    ControlCaptureIntentVideoRecord,
    ControlCaptureIntentVideoSnapshot,
    ControlCaptureIntentZeroShutterLag,
    ControlCaptureIntentManual,
    ControlCaptureIntentMotionTracking,
    ControlCaptureIntentEnd
};

/// @brief ControlEffectMode
enum ControlEffectModeValues
{
    ControlEffectModeOff,
    ControlEffectModeMono,
    ControlEffectModeNegative,
    ControlEffectModeSolarize,
    ControlEffectModeSepia,
    ControlEffectModePosterize,
    ControlEffectModeWhiteboard,
    ControlEffectModeBlackboard,
    ControlEffectModeAqua,
    ControlEffectModeEnd
};

/// @brief ControlMode
enum ControlModeValues
{
    ControlModeOff,
    ControlModeAuto,
    ControlModeUseSceneMode,
    ControlModeOffKeepState,
    ControlModeEnd
};

/// @brief ControlSceneMode
enum ControlSceneModeValues
{
    ControlSceneModeDisabled                        = 0,
    ControlSceneModeFacePriority,
    ControlSceneModeAction,
    ControlSceneModePortrait,
    ControlSceneModeLandscape,
    ControlSceneModeNight,
    ControlSceneModeNightPortrait,
    ControlSceneModeTheatre,
    ControlSceneModeBeach,
    ControlSceneModeSnow,
    ControlSceneModeSunset,
    ControlSceneModeSteadyphoto,
    ControlSceneModeFireworks,
    ControlSceneModeSports,
    ControlSceneModeParty,
    ControlSceneModeCandlelight,
    ControlSceneModeBarcode,
    ControlSceneModeHighSpeedVideo,
    ControlSceneModeHdr,
    ControlSceneModeFacePriorityLowLight,
    ControlSceneModeEnd
};

/// @brief ControlVideoStabilizationMode
enum ControlVideoStabilizationModeValues
{
    ControlVideoStabilizationModeOff,
    ControlVideoStabilizationModeOn,
    ControlVideoStabilizationModeEnd
};

/// @brief ControlAEState
enum ControlAEStateValues
{
    ControlAEStateInactive,
    ControlAEStateSearching,
    ControlAEStateConverged,
    ControlAEStateLocked,
    ControlAEStateFlashRequired,
    ControlAEStatePrecapture,
    ControlAEStateEnd
};

/// @brief ControlAFState
enum ControlAFStateValues
{
    ControlAFStateInactive,
    ControlAFStatePassiveScan,
    ControlAFStatePassiveFocused,
    ControlAFStateActiveScan,
    ControlAFStateFocusedLocked,
    ControlAFStateNotFocusedLocked,
    ControlAFStatePassiveUnfocused,
    ControlAFStateEnd
};

/// @brief ControlAWBState
enum ControlAWBStateValues
{
    ControlAWBStateInactive,
    ControlAWBStateSearching,
    ControlAWBStateConverged,
    ControlAWBStateLocked,
    ControlAWBStateEnd
};

/// @brief ControlAELockAvailable
enum ControlAELockAvailableValues
{
    ControlAELockAvailableFalse,
    ControlAELockAvailableTrue,
    ControlAELockAvailableEnd
};

/// @brief ControlAWBLockAvailable
enum ControlAWBLockAvailableValues
{
    ControlAWBLockAvailableFalse,
    ControlAWBLockAvailableTrue,
    ControlAWBLockAvailableEnd
};

/// @brief ControlAfSceneChangeValues
enum ControlAFSceneChangeValues
{
    ControlAFSceneChangeNotDetected,
    ControlAFSceneChangeDetected,
    ControlAFSceneChangeEnd
};

/// @brief ControlExtendedSceneMode
enum ControlExtendedSceneMode
{
    ControlExtendedSceneModeOff,
    ControlExtendedSceneModeBokehStillCapture,
    ControlExtendedSceneModeBokehContinuous,
    ControlExtendedSceneModeEnd
};

/// @brief DemosaicMode
enum DemosaicModeValues
{
    DemosaicModeFast,
    DemosaicModeHighQuality,
    DemosaicModeEnd
};

/// @brief EdgeMode
enum EdgeModeValues
{
    EdgeModeOff,
    EdgeModeFast,
    EdgeModeHighQuality,
    EdgeModeZeroShutterLag,
    EdgeModeEnd
};

/// @brief FlashMode
enum FlashModeValues
{
    FlashModeOff,
    FlashModeSingle,
    FlashModeTorch,
    FlashModeEnd
};

/// @brief FlashState
enum FlashStateValues
{
    FlashStateUnavailable,
    FlashStateCharging,
    FlashStateReady,
    FlashStateFired,
    FlashStatePartial,
    FlashStateEnd
};

/// @brief FlashInfoAvailable
enum FlashInfoAvailableValues
{
    FlashInfoAvailableFalse,
    FlashInfoAvailableTrue,
    FlashInfoAvailableEnd
};

/// @brief HotPixelMode
enum HotPixelModeValues
{
    HotPixelModeOff,
    HotPixelModeFast,
    HotPixelModeHighQuality,
    HotPixelModeEnd
};

/// @brief LensOpticalStabilizationMode
enum LensOpticalStabilizationModeValues
{
    LensOpticalStabilizationModeOff,
    LensOpticalStabilizationModeOn,
    LensOpticalStabilizationModeEnd
};

/// @brief LensFacing
enum LensFacingValues
{
    LensFacingFront,
    LensFacingBack,
    LensFacingExternal,
    LensFacingInvalid
};

/// @brief LensState
enum LensStateValues
{
    LensStateStationary,
    LensStateMoving,
    LensStateEnd
};

/// @brief LensPoseReference
enum LensPoseReferenceValues
{
    LensPoseReferencePrimaryCamera,
    LensPoseReferenceGyroscope,
    LensPoseReferenceUndefined,
    LensPoseReferenceEnd
};

/// @brief LensInfoFocusDistanceCalibration
enum LensInfoFocusDistanceCalibrationValues
{
    LensInfoFocusDistanceCalibrationUncalibrated,
    LensInfoFocusDistanceCalibrationApproximate,
    LensInfoFocusDistanceCalibrationCalibrated,
    LensInfoFocusDistanceCalibrationEnd
};

/// @brief NoiseReductionMode
enum NoiseReductionModeValues
{
    NoiseReductionModeOff,
    NoiseReductionModeFast,
    NoiseReductionModeHighQuality,
    NoiseReductionModeMinimal,
    NoiseReductionModeZeroShutterLag,
    NoiseReductionModeEnd
};

/// @brief QuirksPartialResult
enum QuirksPartialResultValues
{
    QuirksPartialResultFinal,
    QuirksPartialResultPartial,
    QuirksPartialResultEnd
};

/// @brief RequestMetadataMode
enum RequestMetadataModeValues
{
    RequestMetadataModeNone,
    RequestMetadataModeFull,
    RequestMetadataModeEnd
};

/// @brief RequestType
enum RequestTypeValues
{
    RequestTypeCapture,
    RequestTypeReprocess,
    RequestTypeEnd
};

/// @brief RequestAvailableCapabilities
enum RequestAvailableCapabilitiesValues
{
    RequestAvailableCapabilitiesBackwardCompatible,
    RequestAvailableCapabilitiesManualSensor,
    RequestAvailableCapabilitiesManualPostProcessing,
    RequestAvailableCapabilitiesRaw,
    RequestAvailableCapabilitiesPrivateReprocessing,
    RequestAvailableCapabilitiesReadSensorSettings,
    RequestAvailableCapabilitiesBurstCapture,
    RequestAvailableCapabilitiesYuvReprocessing,
    RequestAvailableCapabilitiesDepthOutput,
    RequestAvailableCapabilitiesConstrainedHighSpeedVideo,
    RequestAvailableCapabilitiesMotionTracking,
    RequestAvailableCapabilitiesLogicalMultiCamera,
    RequestAvailableCapabilitiesMonochrome,
    RequestAvailableCapabilitiesSecureImageData,
    RequestAvailableCapabilitiesSystemCamera,
    RequestAvailableOfflineProcessing,
    RequestAvailableCapabilitiesEnd
};

/// @brief ScalerAvailableFormats. This enum redefines the unnamed enum defined in system/graphics.h. Additional
///        information can be found there.
enum ScalerAvailableFormatsValues
{
    ScalerAvailableFormatsRaw16                     = 0x20,
    ScalerAvailableFormatsRawOpaque                 = 0x24,
    ScalerAvailableFormatsYV12                      = 0x32315659,
    ScalerAvailableFormatsYCrCb420Sp                = 0x11,
    ScalerAvailableFormatsImplementationDefined     = 0x22,
    ScalerAvailableFormatsYCbCr420888               = 0x23,
    ScalerAvailableFormatsBlob                      = 0x21,
    ScalerAvailableFormatsRaw10                     = 0x25,
    ScalerAvailableFormatsRaw12                     = 0x26,
    ScalerAvailableFormatsY8                        = 0x20203859,
    ScalerAvailableFormatsYCbCr422I                 = 0x14,
    // Modify below MaxScalerFormats value is new format is added or deleted.
};

/// @brief ScalerAvailableStreamConfigurations
enum ScalerAvailableStreamConfigurationsValues
{
    ScalerAvailableStreamConfigurationsOutput,
    ScalerAvailableStreamConfigurationsInput,
    ScalerAvailableStreamConfigurationsEnd
};

/// @brief ScalerCroppingType
enum ScalerCroppingTypeValues
{
    ScalerCroppingTypeCenterOnly,
    ScalerCroppingTypeFreeform,
    ScalerCroppingTypeEnd
};

/// @brief ScalerAvailableRecommendedStreamConfigurations
enum ScalerAvailableRecommendedStreamConfigurations
{
    ScalerAvailableRecommendedStreamConfigurationsPreview            = 0x0,
    ScalerAvailableRecommendedStreamConfigurationsRecord             = 0x1,
    ScalerAvailableRecommendedStreamConfigurationsVideoSnapshot      = 0x2,
    ScalerAvailableRecommendedStreamConfigurationsSnapshot           = 0x3,
    ScalerAvailableRecommendedStreamConfigurationsZSL                = 0x4,
    ScalerAvailableRecommendedStreamConfigurationsRAW                = 0x5,
    ScalerAvailableRecommendedStreamConfigurationsLowLatencySnapshot = 0x6,
    ScalerAvailableRecommendedStreamConfigurationsPublicEnd          = 0x7,
    ScalerAvailableRecommendedStreamConfigurationsVendorStart        = 0x18
    // Modify below MaxScalerAvailableRecommendStreamConfigurations
    // value if new format is added or deleted.
};

/// @brief SensorReferenceIlluminant1, SensorReferenceIlluminant2
enum SensorReferenceIlluminantValues
{
    SensorReferenceIlluminant1Daylight              = 1,
    SensorReferenceIlluminant1Fluorescent           = 2,
    SensorReferenceIlluminant1Tungsten              = 3,
    SensorReferenceIlluminant1Flash                 = 4,
    SensorReferenceIlluminant1FineWeather           = 9,
    SensorReferenceIlluminant1CloudyWeather         = 10,
    SensorReferenceIlluminant1Shade                 = 11,
    SensorReferenceIlluminant1DaylightFluorescent   = 12,
    SensorReferenceIlluminant1DayWhiteFluorescent   = 13,
    SensorReferenceIlluminant1CoolWhiteFluorescent  = 14,
    SensorReferenceIlluminant1WhiteFluorescent      = 15,
    SensorReferenceIlluminant1StandardA             = 17,
    SensorReferenceIlluminant1StandardB             = 18,
    SensorReferenceIlluminant1StandardC             = 19,
    SensorReferenceIlluminant1D55                   = 20,
    SensorReferenceIlluminant1D65                   = 21,
    SensorReferenceIlluminant1D75                   = 22,
    SensorReferenceIlluminant1D50                   = 23,
    SensorReferenceIlluminant1IsoStudioTungsten     = 24,
};

/// @brief SensorTestPatternMode
enum SensorTestPatternModeValues
{
    SensorTestPatternModeOff,
    SensorTestPatternModeSolidColor,
    SensorTestPatternModeColorBars,
    SensorTestPatternModeColorBarsFadeToGray,
    SensorTestPatternModePn9,
    SensorTestPatternModeBlack,
    SensorTestPatternModeCustom1                    = 256,
};

/// @brief SensorInfoColorFilterArrangement
enum SensorInfoColorFilterArrangementValues
{
    SensorInfoColorFilterArrangementRggb,
    SensorInfoColorFilterArrangementGrbg,
    SensorInfoColorFilterArrangementGbrg,
    SensorInfoColorFilterArrangementBggr,
    SensorInfoColorFilterArrangementRgb,
    SensorInfoColorFilterArrangementY,
    SensorInfoColorFilterArrangementMono,
    SensorInfoColorFilterArrangementNIR,
    SensorInfoColorFilterArrangementEnd
};

/// @brief SensorInfoTimestampSource
enum SensorInfoTimestampSourceValues
{
    SensorInfoTimestampSourceUnknown,
    SensorInfoTimestampSourceRealtime,
    SensorInfoTimestampSourceEnd
};

/// @brief SensorInfoLensShadingApplied
enum SensorInfoLensShadingAppliedValues
{
    SensorInfoLensShadingAppliedFalse,
    SensorInfoLensShadingAppliedTrue,
    SensorInfoLensShadingAppliedEnd
};

/// @brief ShadingMode
enum ShadingModeValues
{
    ShadingModeOff,
    ShadingModeFast,
    ShadingModeHighQuality,
    ShadingModeEnd
};

/// @brief StatisticsFaceDetectMode
enum StatisticsFaceDetectModeValues
{
    StatisticsFaceDetectModeOff,
    StatisticsFaceDetectModeSimple,
    StatisticsFaceDetectModeFull,
    StatisticsFaceDetectModeEnd
};

/// @brief StatisticsHistogramMode
enum StatisticsHistogramModeValues
{
    StatisticsHistogramModeOff,
    StatisticsHistogramModeOn,
    StatisticsHistogramModeEnd
};

/// @brief StatisticsSharpnessMapMode
enum StatisticsSharpnessMapModeValues
{
    StatisticsSharpnessMapModeOff,
    StatisticsSharpnessMapModeOn,
    StatisticsSharpnessMapModeEnd
};

/// @brief StatisticsHotPixelMapMode
enum StatisticsHotPixelMapModeValues
{
    StatisticsHotPixelMapModeOff,
    StatisticsHotPixelMapModeOn,
    StatisticsHotPixelMapModeEnd
};

/// @brief StatisticsSceneFlicker
enum StatisticsSceneFlickerValues
{
    StatisticsSceneFlickerNone,
    StatisticsSceneFlicker50Hz,
    StatisticsSceneFlicker60Hz,
    StatisticsSceneFlickerEnd
};

/// @brief StatisticsLensShadingMapMode
enum StatisticsLensShadingMapModeValues
{
    StatisticsLensShadingMapModeOff,
    StatisticsLensShadingMapModeOn,
    StatisticsLensShadingMapModeEnd
};

/// @brief StatisticsOISDataMode
enum StatisticsOISDataModeValues
{
    StatisticsOISDataModeOff,
    StatisticsOISDataModeOn,
    StatisticsOISDataModeEnd
};

/// @brief TonemapMode
enum TonemapModeValues
{
    TonemapModeContrastCurve,
    TonemapModeFast,
    TonemapModeHighQuality,
    TonemapModeGammaValue,
    TonemapModePresetCurve,
    TonemapModeEnd
};

/// @brief TonemapPresetCurve
enum TonemapPresetCurveValues
{
    TonemapPresetCurveSrgb,
    TonemapPresetCurveRec709,
    TonemapPresetCurveEnd
};

/// @brief LedTransmit
enum LedTransmitValues
{
    LedTransmitOff,
    LedTransmitOn,
    LedTransmitEnd
};

/// @brief LedAvailableLeds
enum LedAvailableLedsValues
{
    LedAvailableLedsTransmit,
    LedAvailableLedsEnd
};

/// @brief InfoSupportedHardwareLevel
enum InfoSupportedHardwareLevelValues
{
    InfoSupportedHardwareLevelLimited,
    InfoSupportedHardwareLevelFull,
    InfoSupportedHardwareLevelLegacy,
    InfoSupportedHardwareLevel3,
    InfoSupportedHardwareLevelExternal,
    InfoSupportedHardwareLevelEnd
};

/// @brief InfoSupportedBufferManagementVersion
enum InfoSupportedBufferManagementVersion
{
    HIDL_Device_3_5,
};

/// @brief BlackLevelLock
enum BlackLevelLockValues
{
    BlackLevelLockOff,
    BlackLevelLockOn,
    BlackLevelLockEnd
};

/// @brief SyncFrameNumber
enum SyncFrameNumberValues
{
    SyncFrameNumberConverging                       = -1,
    SyncFrameNumberUnknown                          = -2,
};

/// @brief SyncMaxLatency
enum SyncMaxLatencyValues
{
    SyncMaxLatencyPerFrameControl                   = 0,
    SyncMaxLatencyUnknown                           = -1,
};

/// @brief DepthAvailableFormats.
enum DepthAvailableFormatsValues
{
    DepthAvailableFormatsRawDepth              = 0x20,
    DepthAvailableFormatsY16                   = 0x20363159,
    DepthAvailableFormatsBlob                  = 0x21,
};

/// @brief DepthAvailableDepthStreamConfigurations
enum DepthAvailableDepthStreamConfigurationsValues
{
    DepthAvailableDepthStreamConfigurationsOutput,
    DepthAvailableDepthStreamConfigurationsInput,
    DepthAvailableDepthStreamConfigurationsEnd
};

/// @brief DepthDepthIsExclusive
enum DepthDepthIsExclusiveValues
{
    DepthDepthIsExclusiveFalse,
    DepthDepthIsExclusiveTrue,
    DepthDepthIsExclusiveEnd
};

/// @brief DepthAvailableDynamicDepthStreamConfigurations
enum DepthAvailableDynamicDepthStreamConfigurationValues
{
    DepthAvailableDynamicDepthStreamConfigurationsOutput,
    DepthAvailableDynamicDepthStreamConfigurationsInput,
    DepthAvailableDynamicDepthStreamConfigurationsEnd
};

/// @brief LogicalMultiCameraSensorSyncType
enum LogicalMultiCameraSensorSyncTypeValues
{
    LogicalMultiCameraSensorSyncTypeApproximate,
    LogicalMultiCameraSensorSyncTypeCalibrated,
    LogicalMultiCameraSensorSyncTypeEnd
};

/// @brief DistortionCorrectionModes
enum DistortionCorrectionModeValues
{
    DistortionCorrectionModesOff    = 0,
    DistortionCorrectionModesFast,
    DistortionCorrectionModesHighQuality,
    DistortionCorrectionModesEnd
};

/// @brief HEICAvailableHEICStreamConfigurations
enum HEICAvailableHEICStreamConfigurationValues
{
    HEICAvailableHEICStreamConfigurationsOutput,
    HEICAvailableHEICStreamConfigurationsInput,
    HEICAvailableHEICStreamConfigurationsEnd
};

/// @brief HEICInfoSupported
enum HEICInfoSupportedValues
{
    HEICInfoSupportedFalse,
    HEICInfoSupportedTrue,
    HEICInfoSupportedEnd
};

/// @brief ExposureMeteringAvailMode
enum ExposureMeteringAvailableModes
{
    ExposureMeteringFrameAverage,
    ExposureMeteringCenterWeighted,
    ExposureMeteringSpotMetering,
    ExposureMeteringSmartMetering,
    ExposureMeteringUserMetering,
    ExposureMeteringSpotMeteringAdv,
    ExposureMeteringCenterWeightedAdv,
    ExposureMeteringCustom,
    ExposureMeteringEnd
};

/// @brief "Manual Exposure" priority mode settings
enum class ISOExposureTimePriorityMode
{
    DisablePriority = -1,       ///< Disable ISO/ExpTime Priority
    ISOPriority,                ///< ISO priority
    ExposureTimePriority,       ///< Exposure time Priority
    GainPriority                ///< Gain priority
};

/// @brief IsoAvailModes
enum ISOModes
{
    ISOModeAuto,
    ISOModeDeblur,
    ISOMode100,
    ISOMode200,
    ISOMode400,
    ISOMode800,
    ISOMode1600,
    ISOMode3200,
    ISOModeEnd
};

/// @brief InstantAecAvailableModes
enum InstantAecAvailableModes
{
    InstantAecNormalConvergence,
    InstantAecAggressiveConvergence,
    InstantAecFastConvergence,
    InstantAecEnd
};

/// @brief InstantVideoHDRModes
enum VideoHDRAvailableModes
{
    VideoHdrOff,
    VideoHdrOn,
    VideoHdrEnd
};
