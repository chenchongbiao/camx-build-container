////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2019, 2024 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @file  camxtfewbbdsdpc10titan5x.h
/// @brief TFE WB/BDS/DPC10 register setting for Titan5x
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef CAMXTFEWBBDSDPC10TITAN5X_H
#define CAMXTFEWBBDSDPC10TITAN5X_H

#include "camxisphwsetting.h"
#include "bds10setting.h"
#include "camxispiqmodule.h"
#include "camxtitan5xdefs.h"

CAMX_NAMESPACE_BEGIN

static const UINT32 BDS10ScaleRatioLimit    = 105;    ///< Scaling ratio limit beyond which artificats are seen
static const UINT32 BDS10InterpolationShift = 14;     ///< Interpolation shift value
static const UINT32 BDS10MaxScaleFactor     = 32;     ///< Max downscaling factor considering chroma needs to be
struct TFEBDS10phaseOutBDS
{
    INT32  phaseInit;             ///< Phase init value
    UINT16 earlyTermination;      ///< early termination
    UINT16 preCrop;               ///< Pre crop
};

static const uint32_t TFE_BDS10_SCALER_PHASE_ACCUM_Q_BITS_SW = 21;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief TFE WBBDSDPC10 register setting for Titan5x
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
class TFEWBBDSDPC10Titan5x final : public ISPHWSetting
{
public:
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// CreateCmdList
    ///
    /// @brief  Generate the Command List
    ///
    /// @param  pInputData       Pointer to the Inputdata
    /// @param  pDMIBufferOffset Pointer for DMI Buffer
    ///
    /// @return CamxResultSuccess if successful.
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual CamxResult CreateCmdList(
        VOID*   pInputData,
        UINT32* pDMIBufferOffset);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// CreateSubCmdList
    ///
    /// @brief  Generate the Sub Command List
    ///
    /// @param  pInputData       Pointer to the Inputdata
    /// @param  pDMIBufferOffset Pointer for DMI Buffer
    /// @param  pModuleEnable    Pointer to the enable data
    ///
    /// @return CamxResultSuccess if successful.
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual CamxResult CreateSubCmdList(
        VOID*   pInputData,
        UINT32* pDMIBufferOffset,
        VOID*   pModuleEnable);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// UpdateTuningMetadata
    ///
    /// @brief  Update Tuning Metadata
    ///
    /// @param  pTuningMetadata      Pointer to the Tuning Metadata
    ///
    /// @return CamxResultSuccess if successful.
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual CamxResult UpdateTuningMetadata(
        VOID*  pTuningMetadata);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// PackIQRegisterSetting
    ///
    /// @brief  Calculate register settings based on common library result
    ///
    /// @param  pInput       Pointer to the Input data to the module for calculation
    /// @param  pOutput      Pointer to the Output data to the module for DMI buffer
    ///
    /// @return Return CamxResult.
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual CamxResult PackIQRegisterSetting(
        VOID* pInput,
        VOID* pOutput);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// ~TFEWBBDSDPC10Titan5x
    ///
    /// @brief  Destructer
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual ~TFEWBBDSDPC10Titan5x();

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// TFEWBBDSDPC10Titan5x
    ///
    /// @brief  Constructor
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    TFEWBBDSDPC10Titan5x();

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// DumpRegConfig
    ///
    /// @brief  Print register configuration of Crop module for debug
    ///
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    VOID DumpRegConfig();

private:
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// ConfigurePreCrop
    ///
    /// @brief   Configure precrop of scaler
    ///
    ///
    /// @return  None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    void ConfigurePreCrop();

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// ConfigureBDSPScaler
    ///
    /// @brief  Configure BDS P Scaler
    ///
    /// @param  hRatio                  horizontal ratio
    /// @param  vRatio                  vertical ratio
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    void ConfigureBDSPScaler(
                                FLOAT                hRatio,
                                FLOAT                vRatio);


    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// ConfigureBDSHorizontalTLBLScaler
    ///
    /// @brief  Configure BDS horizontal TL BL Scaler
    ///
    /// @param  hRatio                  horizontal ratio
    /// @param  vRatio                  vertical ratio
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    void ConfigureBDSHorizontalTLBLScaler(
                                FLOAT                hRatio,
                                FLOAT                vRatio);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// ConfigureBDSHorizontalTRBRScaler
    ///
    /// @brief  Configure BDS horizontal TR BR Scaler
    ///
    /// @param  hRatio                  horizontal ratio
    /// @param  vRatio                  vertical ratio
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    void ConfigureBDSHorizontalTRBRScaler(
                                FLOAT                hRatio,
                                FLOAT                vRatio);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// ConfigureBDSVerticalBLBRScaler
    ///
    /// @brief  Configure BDS vertical BL BR Scaler
    ///
    /// @param  hRatio                  horizontal ratio
    /// @param  vRatio                  vertical ratio
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    void ConfigureBDSVerticalBLBRScaler(
                                FLOAT                hRatio,
                                FLOAT                vRatio);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// ConfigureBDSVerticalTLTRScaler
    ///
    /// @brief  Configure BDS vertical TL TR Scaler
    ///
    /// @param  hRatio                  horizontal ratio
    /// @param  vRatio                  vertical ratio
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    void ConfigureBDSVerticalTLTRScaler(
                                FLOAT                hRatio,
                                FLOAT                vRatio);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// CalculateInitialPhaseOut
    ///
    /// @brief  Calculate the init phase
    ///
    /// @param  phaseFloat              phase
    /// @param  phaseStep               step
    /// @param  inDim                   input dimension
    /// @param  outDim                  output dimension
    /// @param  hRatio                  horizontal ratio
    /// @param  vRatio                  vertical ratio
    /// @param  useHorizontal           use horizontal ratio
    /// @param  pBDSOut                 Pointer BDS output
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    void CalculateInitialPhaseOut(
                                FLOAT                phaseFloat,
                                UINT32               phaseStep,
                                UINT16               inDim,
                                UINT16               outDim,
                                FLOAT                hRatio,
                                FLOAT                vRatio,
                                UINT32               useHorizontal,
                                TFEBDS10phaseOutBDS* pBDSOut);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// CalculateQ2Factor
    ///
    /// @brief  Calculate q2 factor
    ///
    /// @param  ratio     horizontal ratio
    ///
    /// @return Q2ratio
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    UINT16 CalculateQ2Factor(
                                FLOAT   ratio);

    VOID*               m_pWBBDSDPCRegCmd;                                 ///< Register List of this module
    BDSState*           m_pState;                                          ///< State
    Format              m_pixelFormat;                                     ///< Output pixel format
    UINT32              m_output;                                          ///< TFE piepline output
    ISPInputData*       m_pInputData;                                      ///< Pointer to current input data
    ISPInternalData*    m_pFrameLevel;                                     ///< Pointer to frame level data

    TFEWBBDSDPC10Titan5x(const TFEWBBDSDPC10Titan5x&)            = delete; ///< Disallow the copy constructor
    TFEWBBDSDPC10Titan5x& operator=(const TFEWBBDSDPC10Titan5x&) = delete; ///< Disallow assignment operator
};

CAMX_NAMESPACE_END

#endif // CAMXTFEWBBDSDPC10TITAN5X_H
