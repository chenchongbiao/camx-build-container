//-------------------------------------------------------------------------
// Copyright (c) 2018-2020 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.

//------------------------------------------------------------------------

#ifndef BPS_STRIPE_API_TRANSLATION_H_
#define BPS_STRIPE_API_TRANSLATION_H_

#include "list.h"
#include "icpcomdef.h"
#include "stripe.h"
#include "stripeBPS.h"
#include "stripedebug.h"

#ifdef __cplusplus
extern "C" {
#endif

    typedef struct
    {
        // top level
        int16_t   tiering;

        // BPS
        int16_t BPSInputFormat;
        int16_t BPSInputWidth;
        int16_t BPSInputHeight;
        int16_t BPSInputStride;
        zoom_window zoomWindow;
        zoom_window formatAlignedZoomWindow;

        uint32_t  mnds_overlap_min_phase_step; // MNDSv23 overlap feature control

        int16_t fullDS4Format;
        int16_t fullDS4OutWidth;
        int16_t fullDS4OutHeight;
        int16_t fullDS4OutStride;

        int16_t ds4ds16outFormat;
        int16_t ds4ds16outWidth;
        int16_t ds4ds16outHeight;
        int16_t DS4DS16OutStride;

        int16_t regOutFormat;
        int16_t regOutWidth;
        int16_t regOutHeight;
        int16_t regOutStride;

        int16_t moduleEnablePedestal;
        int16_t moduleEnableBPCPDPC;
        int16_t moduleEnableLensRollOff;
        int16_t moduleEnableGIC;
        int16_t moduleEnableABF;
        int16_t moduleEnableDemosaic;
        int16_t moduleEnableHNR;

        //int16_t forceEvenStripeCount;         // Force the total number of stripes to be an even number

        uint16_t HDR_MUX_SEL;                   // 0: datapath with Channel Gain, Bayer PDPC_BPC, BinCorr;   1: datapath directly from BPS input (from SFE);
        BOOL     striping;                      //: for debugging purpose
        int32_t  chromaDownRoundingOption_h;    //: MNDS rounding mode can vary
        int32_t  chromaDownRoundingOption_v;    //: MNDS rounding mode can vary
        int32_t  regOutDownRoundingOption_h;    //: MNDS rounding mode can vary
        int32_t  regOutDownRoundingOption_v;    //: MNDS rounding mode can vary

        Pedestalv13InputParams              pedestalParam;
        RollOffv34InputParameters            rollOffParam;
        HDRv20v30stripingInputParams        hdrParam;
        PDPCv20v30stripingInputParams        pdpcParam;
        LCACv10stripingInputParams            lcacParam;
        WBv20StripingInputParams            wbParam;
        BayerGTMv10StripingInputParams      bayerGtmParam;
        LTMv13StripingInputParams           bayerLtmParam; // no mask filter, no DC in BayerLTM v1.0
        BayerHistInputParams                bayerHistParam;
        BayerGridInputParam                 bayerGridParam;
        HNRInputParam                       hnrParam;
        GICv30InputParams                   gicParam;
        CADLv10StripingInputParams          cadlParam;
        BayerHistv17InputParams             bayerHistv17Param;
        simplePdpcv15InputParams            simplePdpcParam;
    }
    BPSFirmwareInput;

    typedef struct
    {
        // fetch coordinates
        int16_t fetchFirstPixel;
        int16_t fetchLastPixel;

        // write coordinates
        int16_t ds4ds16outFirstPixel;
        int16_t ds4ds16outLastPixel;
        int16_t fullDS4OutFirstPixel;
        int16_t fullDS4OutLastPixel;
        int16_t regOutFirstPixel;
        int16_t regOutLastPixel;

        // crop amounts
        crop_1D preRollOffCrop;
        crop_1D CDSCropLuma;
        crop_1D CDSCropChroma;
        crop_1D DS4DS16InCropLuma;
        crop_1D DS4DS16InCropChroma;
        crop_1D DS4DS16OutCropLuma;
        crop_1D DS4DS16OutCropChroma;
        crop_1D fullDS4InCropLuma;
        crop_1D fullDS4InCropChroma;
        crop_1D fullDS4OutCropLuma;
        crop_1D fullDS4OutCropChroma;
        crop_1D regInCrop;
        crop_1D regInCrop_chroma;
        crop_1D regOutCrop;
        crop_1D regOutCrop_chroma;

#ifdef PERF
        int BPCPDPCInputWidth;
        int BPCPDPCOutputWidth;
        int HDRRecInputWidth;
        int HDRRecOutputWidth;
        int HDRMACInputWidth;
        int HDRMACOutputWidth;
        int GICInputWidth;
        int GICOutputWidth;
        int ABFInputWidth;
        int ABFOutputWidth;
        int DemosaicInputWidth;
        int DemosaicOutputWidth;
        int eightTapDS4DS16InputWidth;
        int eightTapDS4DS16OutputWidth;
        int eightTapfullDS4InputWidth;
        int eightTapfullDS4OutputWidth;
#endif // PERF

        // flags
        BOOL leftStripe;
        BOOL rightStripe;

        // scalers
        MNScaleDownInStruct_V20_1D regOutDownscaler;
        //MNScaleDownInStruct_V20_1D regOutDownscalerFrame;
        //: chroma parameters for regout MNDS
        MNScaleDownInStruct_V20_1D regOutDownscaler_chroma;
        //MNScaleDownInStruct_V20_1D regOutDownscalerFrame_chroma;

        RollOffOutputParameters rolloffOutStripe;
        PedestalOutputParameters pedestalOutStripe;

        //: to configure the initial values for r_square calculation
        int GIC_PNR_bx;
        int ABF_bx;
        int HNR_RNR_bx;
        int HNR_face_horizontal_offset;
        //: chroma down needs a separate set of configuration to generate the rounding option
        MNScaleDownInStruct_V20_1D chromaDownscaler;
        //MNScaleDownInStruct_V20_1D chromaDownscalerFrame;
        //BOOL HDRzigzag_patternShift;          //: shift of zigzag pattern when the striping boundary is not aligned with it
        BOOL hdr_zrec_first_rb_exp;         //: shift of zigzag pattern when the striping boundary is not aligned with it
        PDPCv20v30stripingOutputParams pdpcParam;
        BayerGridOutputParam bayerGridParam;
        //==== generic ends here ====

        //: to configure the initial values for r_square calculation
        int GIC_PNR_r_square_init;
        int HNR_RNR_r_square_init;
        int ABF_r_square_init;
        int qosBPScounter;
        BayerHistOutputParams bayerHistParam;
        //int ABF_r_square_init0;

        CADLv10StripingOutputParams     cadlParam;
        LCACv10stripingOutputParams        lcacParam;
        LTMV13StripeIPParams_1D         bayerLtmIp;
        LTMv13StripingOutputParams      bayerLtmParam; // don't use DC params in BPS
        WriteEngineStripeParam          bgStatsWriteEngineStripeParam;
        BayerHistv17OutputParams        bayerHistv17Param;
        simplePdpcv15OutputParams       simplePdpcParam;
    }
    BPSStripeOutput;

    typedef struct
    {
        /* pass-level parameters */
        // fetch coordinates
        int16_t fetchFirstLine;
        int16_t fetchLastLine;

        // write coordinates
        int16_t ds4ds16outFirstLine;
        int16_t ds4ds16outLastLine;
        int16_t fullDS4OutFirstLine;
        int16_t fullDS4OutLastLine;
        int16_t regOutFirstLine;
        int16_t regOutLastLine;

        // crop amounts
        crop_1D preRollOffCrop;
        crop_1D CDSCropLuma;
        crop_1D CDSCropChroma;
        crop_1D DS4DS16InCropLuma;
        crop_1D DS4DS16InCropChroma;
        crop_1D DS4DS16OutCropLuma;
        crop_1D DS4DS16OutCropChroma;
        crop_1D fullDS4InCropLuma;
        crop_1D fullDS4InCropChroma;
        crop_1D fullDS4OutCropLuma;
        crop_1D fullDS4OutCropChroma;
        crop_1D regInCrop;
        crop_1D regInCrop_chroma;
        crop_1D regOutCrop;
        crop_1D regOutCrop_chroma;

        LTMV13StripeIPParams_1D bayerLtmIp;

#ifdef PERF
        int BPCPDPCInputHeight;
        int BPCPDPCOutputHeight;
        int HDRRecInputHeight;
        int HDRRecOutputHeight;
        int HDRMACInputHeight;
        int HDRMACOutputHeight;
        int GICInputHeight;
        int GICOutputHeight;
        int ABFInputHeight;
        int ABFOutputHeight;
        int DemosaicInputHeight;
        int DemosaicOutputHeight;
        int eightTapDS4DS16InputHeight;
        int eightTapDS4DS16OutputHeight;
        int eightTapfullDS4InputHeight;
        int eightTapfullDS4OutputHeight;
#endif // PERF

        // flags
        BOOL topStripe;
        BOOL bottomStripe;

        // scalers
        MNScaleDownInStruct_V20_1D regOutDownscaler;
        MNScaleDownInStruct_V20_1D regOutDownscalerFrame;
        //: chroma parameters for regout MNDS
        MNScaleDownInStruct_V20_1D regOutDownscaler_chroma;
        MNScaleDownInStruct_V20_1D regOutDownscalerFrame_chroma;

        RollOffOutputParameters rolloffOutPass;
        PedestalOutputParameters pedestalOutPass;

        //: to configure the initial values for r_square calculation
        int GIC_PNR_by;
        int ABF_by;
        int HNR_RNR_by;
        int HNR_face_vertical_offset;
        //: chroma down needs a separate set of configuration to generate the rounding option
        MNScaleDownInStruct_V20_1D chromaDownscaler;
        MNScaleDownInStruct_V20_1D chromaDownscalerFrame;
        //BOOL HDRzigzag_patternShift;   //: shift of zigzag pattern when the striping boundary is not aligned with it
        BOOL hdr_zrec_first_rb_exp;      //: shift of zigzag pattern when the striping boundary is not aligned with it
        PDPCv20v30stripingOutputParams pdpcParam;   //not used
        BayerGridOutputParam bayerGridParam;        //not used
        //==== generic ends here

        int16_t fullds4OutImageLumaWidth;
        int16_t ds4ds16OutImageLumaWidth;
        int16_t regOutImageLumaWidth;

        /* stripes */
        int16_t numStripes;
        ListHandle hStripeList;

#ifdef calculate_BW
        int16_t inputFormat;
        int16_t ds4ds16outFormat;
        int16_t fullDS4OutFormat;
        int16_t regOutFormat;
#endif

        //: to configure the initial values for r_square calculation
        int GIC_PNR_r_square_scale;
        int GIC_PNR_r_square_shift;
        int ABF_r_square_scale;
        int ABF_r_square_shift;
        int HNR_RNR_r_square_scale;
        int HNR_RNR_r_square_shift;

        WriteEnginePassParam bgStatsWriteEnginePassParam;
    }
    BPSPassOutput;

    typedef struct
    {
        /* frame-level parameters */


        /* passes */
        int32_t numPasses;
        int32_t dummy_field_for_byte_padding;
        BPSPassOutput * passes;
    }
    BPSFrameOutput;


    int32_t parseBPSFirmwareInput(BPSFirmwareInput * pFirmwareInput, BPSFrameOutput * pFrameOut, userBPSArgs *pUserBPSArgs);

#ifdef __cplusplus
}
#endif

#endif // !BPS_STRIPE_API_TRANSLATION_H_
