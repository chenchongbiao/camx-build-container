////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2020-2021, 2024 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @file  camxtitan175ife.h
/// @brief Titan 175 IFE pipeline Class
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef CAMXTITAN175IFE_H
#define CAMXTITAN175IFE_H

CAMX_NAMESPACE_BEGIN


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief Base Class for all IFE Titan 175 Pipeline setup
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
class Titan175IFE final : public ISPPipeline
{
public:
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetIFESWNRMModuleVersion
    ///
    /// @brief  Get SW NRM version from module info
    ///
    /// @param  pModuleInfo     Pointer to IFE module info
    ///
    /// @return NRM version
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual SWNRMVersion GetIFESWNRMModuleVersion(
        IFEIQModuleInfo* pModuleInfo) override;

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetIFESWTMCModuleVersion
    ///
    /// @brief  Get SW TMC version from module info
    ///
    /// @param  pModuleInfo     Pointer to IFE module info
    ///
    /// @return TMC version
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual SWTMCVersion GetIFESWTMCModuleVersion(
            IFEIQModuleInfo* pModuleInfo) override;

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// ProgramIQModuleEnableConfig
    ///
    /// @brief  Reprogram the Module enable settings for the IQ Modules
    ///
    /// @param  pInputData          Pointer to the input data
    /// @param  pISPData            Pointer to the ISP internal data
    /// @param  pIFEOutputPathInfo  Pointer to the IFE output path data
    ///
    /// @return CamxResult True on successful execution else False on failure
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    CamxResult ProgramIQModuleEnableConfig(
        ISPInputData*       pInputData,
        ISPInternalData*    pISPData,
        IFEOutputPath*      pIFEOutputPathInfo);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetISPIQModulesOfType
    ///
    /// @brief  Get ISP IQ module
    ///
    /// @param  moduleType  Module type
    /// @param  pModuleInfo Pointer to the module info
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    VOID GetISPIQModulesOfType(
        ISPIQModuleType moduleType,
        VOID*           pModuleInfo);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// FillConfigTuningMetadata
    ///
    /// @brief  Helper to populate tuning data easily obtain at IFE node level
    ///
    /// @param  pInputData          Pointer to the data input and output stuctures are inside
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    VOID FillConfigTuningMetadata(
        ISPInputData*       pInputData);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// DumpTuningMetadata
    ///
    /// @brief  Helper to publish tuning metadata
    ///
    /// @param  pInputData          Pointer to the input data
    /// @param  pDebugDataWriter    Pointer to tuning-data writer
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    VOID DumpTuningMetadata(
        ISPInputData*       pInputData,
        DebugDataWriter*    pDebugDataWriter);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// FillFlushConfig
    ///
    /// @brief  Helper function to Setup the Flush Config
    ///
    /// @param  pCmdBuffer Pointer to the command buffer
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    VOID FillFlushConfig(
        CmdBuffer*  pCmdBuffer);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// FillCGCConfig
    ///
    /// @brief  Helper function to fill the CGC Config
    ///
    /// @param  pCmdBuffer Pointer to the command buffer
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    VOID FillCGCConfig(
        CmdBuffer*  pCmdBuffer);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetIFEDefaultConfig
    ///
    /// @brief  Helper to populate default IFE configuration for IFE modules
    ///
    /// @param  pDefaultData    Pointer to the data to be use as default for IFE modules that differ from version to version
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    VOID GetIFEDefaultConfig(
        IFEDefaultModuleConfig* pDefaultData);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetPDHWCapability
    ///
    /// @brief  virtual method to get the isp pipeline PDHW capability
    ///
    /// @param  pCapabilityInfo Pointer to the structure into which capability info is filled
    /// @param  profileID       IFE node profile
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    VOID GetPDHWCapability(
        PDHwAvailablity* pCapabilityInfo,
        IFEProfileId     profileID);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetIFEBandWidthConfigurationVersion
    ///
    /// @brief  Helper to Get BandWidth configuration
    ///
    /// @return IFEBWconfiguration
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    UINT32 GetIFEBandWidthConfigurationVersion()
    {
        UINT32 BWType = IFEGenericBlobTypeResourceBWConfigV2;

        switch ( GetTitanChipVersion())
        {
            case CSLCameraTitanChipVersion::CSLTitan175V100:
            case CSLCameraTitanChipVersion::CSLTitan175V101:
            case CSLCameraTitanChipVersion::CSLTitan175V120:
                BWType = IFEGenericBlobTypeResourceBWConfig;
                break;

            case CSLCameraTitanChipVersion::CSLTitan175V130:
            case CSLCameraTitanChipVersion::CSLTitan165V100:
            case CSLCameraTitanChipVersion::CSLTitan497V100:
            case CSLCameraTitanChipVersion::CSLTitan498V100:
                BWType = IFEGenericBlobTypeResourceBWConfigV2;
                break;

            default:
                BWType = IFEGenericBlobTypeResourceBWConfigV2;
                break;
        }

        return BWType;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetISPAcquireInputInfoVersion
    ///
    /// @brief  Helper Function to Get ISPAcquireInputVersion
    ///
    /// @return UINT32
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    CAMX_INLINE UINT32 GetISPAcquireInputInfoVersion()
    {
        return ISPAcquireInputVersion2;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetISPAcquireCommonInfoVersion
    ///
    /// @brief  Helper Function to Get ISPAcquireInputVersion
    ///
    /// @return UINT32
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    CAMX_INLINE UINT32 GetISPAcquireCommonInfoVersion()
    {
        return ISPAcquireCommonVersion2;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetAcquireHWStructVersion
    ///
    /// @brief  Helper Function to Get ISPAcquireInputVersion
    ///
    /// @return UINT32
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    CAMX_INLINE UINT32 GetAcquireHWStructVersion()
    {
        return CSLAcquiredDeviceVersion2;
    }


    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetIFEBUSWRVersion
    ///
    /// @brief  Helper method to return IFE WRrite Bus version
    ///
    /// @return Bus version
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    IFEBusWriteHWVersion GetIFEBUSWRVersion()
    {
        return IFEBusWriteHWV1;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// UpdateDMIBankSelectValue
    ///
    /// @brief  Helper method to set all double banked DMI to a given bank value
    ///
    /// @param  pBankUpdate     Pointer to the DMI Bank Update
    /// @param  isBankValueZero True to select bank 0, otherwise, select bank 1
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual VOID UpdateDMIBankSelectValue(
        VOID* pBankUpdate,
        BOOL  isBankValueZero);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Titan175IFE
    ///
    /// @brief  Constructor
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    Titan175IFE();

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// ~Titan175IFE
    ///
    /// @brief  Destructor
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual ~Titan175IFE();

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// SetupHangRegDump
    ///
    /// @brief  Helper method to setup ISP Register Dump structures
    ///
    /// @param  pHangBuffer     Pointer to the hang dump Buffer
    /// @param  p_IFEMode       IFE Mode
    /// @param  isPerFrameDump  indicator for Per Frame Dump
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual VOID SetupHangRegDump(
        VOID*         pHangBuffer,
        VOID*         p_IFEMode,
        BOOL          isPerFrameDump);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// ParseHangRegDump
    ///
    /// @brief  Helper method to parse ISP Register Dump structures
    ///
    /// @param  pHangBuffer Pointer to the flush dump Buffer
    /// @param  leftHangFd  file descriptor fd for left Stripe
    /// @param  rightHangFd file descriptor fd for right Stripe
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual VOID ParseHangRegDump(
        VOID* pHangBuffer,
        INT   leftHangFd,
        INT   rightHangFd);

private:

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// FillIFERegReadInfo
    ///
    /// @brief  Helper function to fill Reg Read Info
    ///
    /// @param  pRegReadInfo  Pointer to the Register Read Info to be filled
    /// @param  offset        Reg Offset
    /// @param  numberOfReads number of DMI Data reads
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    CAMX_INLINE VOID FillIFERegReadInfo(
        IFERegReadInfo*  pRegReadInfo,
        UINT32           offset,
        UINT32           numberOfReads)
    {
        if (NULL != pRegReadInfo)
        {
            pRegReadInfo->readType                                   = IFERegDumpReadTypeReg;
            pRegReadInfo->regDescriptor.regReadCmd.offset            = offset;
            pRegReadInfo->regDescriptor.regReadCmd.numberOfRegisters = numberOfReads;
        }
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// FillIFEDMIReadInfo
    ///
    /// @brief  Helper function to fill Reg Read Info
    ///
    /// @param  pDMIReadInfo  Pointer to the DMI Read Info to be filled
    /// @param  offset        DMI Reg Offset
    /// @param  bankOffset    DMI Bank Offset
    /// @param  numberOfReads number of DMI Data reads
    /// @param  bankSelect    bank Select
    /// @param  lutSelect     LUT Select
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    CAMX_INLINE VOID FillIFEDMIReadInfo(
        IFERegReadInfo*  pDMIReadInfo,
        UINT32           offset,
        UINT32           bankOffset,
        UINT32           numberOfReads,
        UINT32           bankSelect,
        UINT32           lutSelect)
    {
        if (NULL != pDMIReadInfo)
        {
            pDMIReadInfo->readType = IFERegDumpReadTypeDMI;
            pDMIReadInfo->regDescriptor.dmiReadCmd.regWriteCmd[0].offset = offset;
            pDMIReadInfo->regDescriptor.dmiReadCmd.regWriteCmd[0].value  = 0x100000;
            pDMIReadInfo->regDescriptor.dmiReadCmd.numberOfRegWrites++;
            pDMIReadInfo->regDescriptor.dmiReadCmd.regWriteCmd[1].offset = offset + 0x4;
            pDMIReadInfo->regDescriptor.dmiReadCmd.regWriteCmd[1].value  = lutSelect;
            pDMIReadInfo->regDescriptor.dmiReadCmd.numberOfRegWrites++;
            pDMIReadInfo->regDescriptor.dmiReadCmd.regWriteCmd[2].offset = bankOffset;
            pDMIReadInfo->regDescriptor.dmiReadCmd.regWriteCmd[2].value  = bankSelect;
            pDMIReadInfo->regDescriptor.dmiReadCmd.numberOfRegWrites++;
            pDMIReadInfo->regDescriptor.dmiReadCmd.regRangeCmd.numberOfRegisters = numberOfReads;
            pDMIReadInfo->regDescriptor.dmiReadCmd.regRangeCmd.offset = offset + 0x8;
            pDMIReadInfo->regDescriptor.dmiReadCmd.postregWriteCmd[1].offset = offset + 0x4;
            pDMIReadInfo->regDescriptor.dmiReadCmd.postregWriteCmd[1].value = 0;
            pDMIReadInfo->regDescriptor.dmiReadCmd.numberOfPostWrites++;
        }
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// CanSkipIFEIQModule
    ///
    /// @brief  Helper to check if the IQ Module Can be skipped
    ///
    /// @param  module IQ Module Type
    ///
    /// @return TRUE if the module can be skipped
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual BOOL CanSkipIFEIQModule(
        ISPIQModuleType module)
    {
        BOOL bCanSkip = FALSE;

        // In MFHDR case, since Master and Slave IFE instances re use the same IFE Hw, we will only update
        // Linearization , PDPC and ABF in Short Context and Calculate erverything else in Long Context
        // Also for MNDS, Crop modules are needed for calculating Per port meta data.
        if ((module != ISPIQModuleType::IFELinearization) &&
            (module != ISPIQModuleType::IFEDemux)         &&
            (module != ISPIQModuleType::IFEPDPC)          &&
            (module != ISPIQModuleType::IFEABF)           &&
            (module != ISPIQModuleType::IFEBLS)           &&
            (module != ISPIQModuleType::IFEMNDS)          &&
            (module != ISPIQModuleType::IFEGamma)         &&
            (module != ISPIQModuleType::IFECrop)          &&
            (module != ISPIQModuleType::IFERoundClamp)    &&
            (module != ISPIQModuleType::IFEDS4)           &&
            (module != ISPIQModuleType::SWNRM))
        {
            bCanSkip = TRUE;
        }
        CAMX_LOG_VERBOSE(CamxLogGroupISP, " module %d skip %d ",
                        module, bCanSkip);
        return bCanSkip;
    }


    Titan175IFE(const Titan175IFE&)            = delete; ///< Disallow the copy constructor
    Titan175IFE& operator=(const Titan175IFE&) = delete; ///< Disallow assignment operator

    VOID*                          m_pModuleConfig;          ///< module config smember
    IFECapabilityInfo              m_IFECapability;         ///< IFE Capbility Info
    UINT32 m_hangDumpOutputBufferSize           = 0;        ///< Hang Dump Buffer size in Bytes
    UINT32 m_perFrameDumpOutputBufferSize       = 0;        ///< Per Frame Dump Buffer size in Bytes
};

CAMX_NAMESPACE_END

#endif // CAMXTITAN175IFE_H
