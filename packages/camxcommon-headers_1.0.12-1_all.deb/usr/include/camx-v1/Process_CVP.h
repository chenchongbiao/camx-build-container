// NOWHINE ENTIRE FILE
//-------------------------------------------------------------------------
// Copyright (c) 2018-2020 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
//------------------------------------------------------------------------

#ifndef __PROCESS_CVP_H__
#define __PROCESS_CVP_H__

#include "ICA_Chromatix.h"
#include "ImageTransform.h"
#include "NcLibWarpCommonDef.h"
#include "NcLibContext.h"
#include "GeoLib.h"
#include "DSX_Chromatix.h"
#include "DS4to1_Chromatix.h"


// This file does not include CVP headers so CamX modules that cannot include CVP API still can include this file.
// Structs that defined (or should be defined) in CVP API or forward declaird here.
typedef struct _cvpDmeFrameConfigIca cvpDmeFrameConfigIca;
struct NcLib_cvpGceFrameConfig;
struct NcLibGceConfig;
typedef struct CVP_Chromatix_v20_TAG CVP_Chromatix_v20;

/**
*  @brief   Calculate ICA transform based on DME processing.
*
*  @param [in]   coarseCenterW        Image center X
*  @param [in]   coarseCenterH        Image center Y
*  @param [in]   upscaleFactorW       Transform upscale factor X
*  @param [in]   upscaleFactorH       Transform upscale factor Y
*  @param [in]   cvpResult            CVP DME results
*  @param [out]  transform            DME transform
*
*  @return NC_LIB_SUCCESS in case of success, otherwise failed.
*/
int32_t ProcessCvpMeResult(
    float coarseCenterW,
    float coarseCenterH,
    float upscaleFactorW,
    float upscaleFactorH,
    const float cvpResult[3][3],
    CPerspectiveTransform* transform);

/**
*  @brief   Configure DME 2.0 frame
*
*  @param [in]      chromatix          Chromatix configuration
*  @param [out]     out                Output CVP DME frame settings
*
*  @return NC_LIB_SUCCESS in case of success, otherwise failed.
*/
int32_t NcLibProcessCvpDme20(const CVP_Chromatix_v20* chromatix, cvpDmeFrameConfigIca* out);


#define NCLIB_PROCESS_CVP_ICA20_PROC_BUFFER_SIZE (ICA_V20_GRID_TRANSFORM_SIZE * 16)
#define NCLIB_PROCESS_GCE_PROC_BUFFER_SIZE (ICA_V30_GRID_TRANSFORM_HI_RES_SIZE * 16)

/**
*  @brief   Calculate CVP pre-DME ICA registers
*
*  @param [in]      grid               input grid. Geometry has to be either NcLibIcaGrid35x27 or NcLibIcaGrid67x51.
*  @param [in]      persp              input perspective transform matrices.
*  @param [in]      geo                input ICA geometrical mapping struct.
*  @param [in,out]  procBuffer         Pointer to intermediate buffer of at least NCLIB_PROCESS_CVP_ICA20_PROC_BUFFER_SIZE
*                                      bytes. The function will use this buffer for intermediate calculations.
*  @param [in]      chromatixStruct    Pointer to the pass Chromatix struct
*  @param [out]     cvpStruct          Output struct filled by the function.
*                                      nOpgInterpLUT<n> are copied from ICA chromatix if provided.
*                                      nCtcXTranslation and nCtcYTranslation are not populated.
*
*  @return NC_LIB_SUCCESS in case of success, otherwise failed.
*/
int32_t NcLibProcessCvpIca(
    const NcLibWarpGrid* grid,       // Identical to IPEICAGridTransform
    const NcLibWarpMatrices* persp,  // Identical to IPEICAPerspectiveTransform
    const GeoLibIcaMapping* geo,
    const ICA_Chromatix* chromatixStruct,
    void* procBuffer,
    cvpDmeFrameConfigIca* cvpStruct);

/**
*  @brief   Get size of cvpDmeFrameConfigIca struct for "blind" memory allocation
*
*  @return cvpDmeFrameConfigIca size
*/
size_t NcLbGetSize_cvpDmeFrameConfigIca();

/**
*  @brief   Get ICA version used by CPV for current chip
*
*  @return 20 for Kona and Lahaina, 40 for Waipio, undefined otherwise.
*/
uint32_t NcLibGetCvpIcaVersion();

/**
*  @brief   Calculate GCE configuration
*
*  @param [in]      grid               Transform grid  Geometry has to be either NcLibIcaGrid35x27 or NcLibIcaGrid67x51.
*  @param [in]      persp              Perspective transform matrices.
*  @param [in]      dsxChx             GCE DSX Chromatix.
*  @param [in]      ds4Chx             GCE DS4 Chromatix.
*  @param [in]      icaChx             GCE ICA Chromatix. If it's NULL OPG LUTs will not be populated in the output struct.
*  @param [in]      geo                Geometrical configurations.
*  @param [in,out]  procBuffer         Pointer to intermediate buffer of at least NCLIB_PROCESS_GCE_PROC_BUFFER_SIZE
*                                      bytes. The function will use this buffer for intermediate calculations.
*  @param [out]     out                Output struct filled by the function.
*
*  @return NC_LIB_SUCCESS on success, appropriate error code on failure.
*/
int32_t NcLibProcessGce(
    const NcLibWarpGrid* grid,
    const NcLibWarpMatrices* persp,
    const DSX_Chromatix* dsxChx,
    const DS4to1_Chromatix* ds4Chx,
    const ICA_Chromatix* icaChx,
    const NcLibGceConfig* geo,
    void* procBuffer,
    NcLib_cvpGceFrameConfig* out);

#endif // __PROCESS_CVP_H__
