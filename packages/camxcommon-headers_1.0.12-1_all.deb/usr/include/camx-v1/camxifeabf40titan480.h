////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2019, 2024 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @file  camxifeabf40titan480.h
/// @brief IFE ABF40 register setting for Titan480
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef CAMXIFEABF40TITAN480_H
#define CAMXIFEABF40TITAN480_H

#include "camxisphwsetting.h"
#include "abf40setting.h"

CAMX_NAMESPACE_BEGIN



static const UINT32 IFEMaxABFLUT                    = 4;
static const UINT32 IFEABF40NoiseLUTSizeDword       = 64;  // 64 entries in the DMI table
static const UINT32 IFEABF40NoiseLUTSize            = (IFEABF40NoiseLUTSizeDword * sizeof(UINT32));
static const UINT32 IFEABF40ActivityLUTSizeDword    = 32;  // 32 entries in the DMI table
static const UINT32 IFEABF40ActivityLUTSize         = (IFEABF40ActivityLUTSizeDword * sizeof(UINT32));
static const UINT32 IFEABF40DarkLUTSizeDword        = 42;  // 48 entries in the DMI table
static const UINT32 IFEABF40DarkLUTSize             = (IFEABF40DarkLUTSizeDword * sizeof(UINT32));
static const UINT32 IFEABFTotalDMILengthDword       = (IFEABF40NoiseLUTSizeDword    +
                                                       IFEABF40ActivityLUTSizeDword +
                                                       IFEABF40DarkLUTSizeDword);
static const UINT32 IFEABFTotalLUTBufferSize        = (IFEABFTotalDMILengthDword * sizeof(UINT32));



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief IFE ABF40 register setting for Titan480
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
class IFEABF40Titan480 final : public ISPHWSetting
{
public:
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// CreateCmdList
    ///
    /// @brief  Generate the Command List
    ///
    /// @param  pInputData       Pointer to the Inputdata
    /// @param  pDMIBufferOffset Pointer for DMI Buffer
    ///
    /// @return CamxResultSuccess if successful.
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual CamxResult CreateCmdList(
        VOID*   pInputData,
        UINT32* pDMIBufferOffset);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// CreateSubCmdList
    ///
    /// @brief  Generate the Sub Command List
    ///
    /// @param  pInputData       Pointer to the Inputdata
    /// @param  pDMIBufferOffset Pointer for DMI Buffer
    /// @param  pModuleEnable    Pointer to the enable data
    ///
    /// @return CamxResultSuccess if successful.
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual CamxResult CreateSubCmdList(
        VOID*   pInputData,
        UINT32* pDMIBufferOffset,
        VOID*   pModuleEnable);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// UpdateTuningMetadata
    ///
    /// @brief  Update Tuning Metadata
    ///
    /// @param  pTuningMetadata      Pointer to the Tuning Metadata
    ///
    /// @return CamxResultSuccess if successful.
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual CamxResult UpdateTuningMetadata(
        VOID*  pTuningMetadata);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// PackIQRegisterSetting
    ///
    /// @brief  Packing register setting based on calculation data
    ///
    /// @param  pInput       Pointer to the Input data to the module for calculation
    /// @param  pOutput      Pointer to the Output data to the module for DMI buffer
    ///
    /// @return Return CamxResult.
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual CamxResult PackIQRegisterSetting(
        VOID* pInput,
        VOID* pOutput);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// ~IFEABF40Titan480
    ///
    /// @brief  Constructor
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual ~IFEABF40Titan480();

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// IFEABF40Titan480
    ///
    /// @brief  Constructor
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    IFEABF40Titan480();

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// DumpRegConfig
    ///
    /// @brief  Print register configuration of Crop module for debug
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    VOID DumpRegConfig();

private:
    VOID*           m_pRegCmd1;          ///< Register Set 1 of this Module
    VOID*           m_pRegCmd2;          ///< Register Set 2 of this Module
    UINT32*         m_pNoiseLUT;         ///< ABF DMI Noise LUT pointer
    UINT32*         m_pActivityLUT;      ///< ABF DMI Activity LUT pointer
    UINT32*         m_pDarkLUT;          ///< ABF DMI Dark LUT pointer

    IFEABF40Titan480(const IFEABF40Titan480&)            = delete; ///< Disallow the copy constructor
    IFEABF40Titan480& operator=(const IFEABF40Titan480&) = delete; ///< Disallow assignment operator
};

CAMX_NAMESPACE_END

#endif // CAMXIFEABF40TITAN480_H
