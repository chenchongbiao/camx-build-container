// NOWHINE ENTIRE FILE
//-------------------------------------------------------------------------
// Copyright (c) 2020 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
//------------------------------------------------------------------------


#ifndef __CVP_CHROMATIX_V20_H__
#define __CVP_CHROMATIX_V20_H__

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct CVP_Chromatix_v20_TAG
{
    // Enable image based registration
    // format: 1u
    uint32_t image_based_alignment_enable;

    // Maximum allowed NCC If NCC exceeds this threshold the block will be marked invalid (probably ME problem due to occlusion, too fast motion, etc).
    // format: 11u
    uint32_t robustness_max_allowed_ncc;

    // Minimum allowed tar variance value. If below this value (non-informative block) - the block will be marked invalid.
    // format: 16u
    uint32_t robustness_min_allowed_tar_var;

    // Locations with NCC difference below this threshold are considered to have exactly the same similarity measure
    // format: 11u
    uint32_t robustness_meaningful_ncc_diff;

    // Provides a requirement on minimal normalized difference of SADs at distance 1-8 pixels (for big distances the expected differences should be big). Default values: 0, 128, 128, 128, 128, 128, 128, 128 (no penalty to single pixel distance; afterwards same penalty for all other distances)
    // format: 9u
    uint32_t robustness_measure_dist_map[8];

    // Enable 5x5 filtering before calculating descriptor
    // format: 1u
    uint32_t descriptor_lpf;

    // Control the senstivity of the harris detector to edge vs corner. Reasoble values [10 , 32].Lower value  recognize "less segnificant" corner.
    // format: 8u
    uint32_t fpx_kappa;

    // Corner with Harris measure value lower than this value will be ignored.
    // format: 32u
    uint32_t fpx_threshold;

    // Hamming distance between two descriptors below which the blocks are considered as match.
    // Camera SW Should force the number to be module 4.
    // format: 8u
    uint32_t desc_match_threshold;

    // Robustenss value above indicate valid Motion vector.
    // format: 4s
    int32_t robustness_threshold;

    // Enabling inlier tracking, Improve decistion's coherency between frames.
    // format: 1u
    uint32_t inlier_track_enable;

    // Whether to calculate and apply transform confidence (based on coverage of the frame by  calculated valid MVs). Frames with higher coverage get higher confidence.
    // format: 1u
    uint32_t enable_transform_confidence;

    // Defines mapping function from calculated transform confidence to actually used transform confidence. The calculated confidence is in the range 0:256 (8 bit fraction). The mapping is:  actual confidence =  transform_confidence_mapping_base when calculated confidence <= transform_confidence_mapping_c1; 256 when calculated confidence > transform_confidence_mapping_c2 and linear interpolation in-between. Not relevant for multi frame flows.
    // format: 8u
    uint32_t transform_confidence_mapping_base;

    // Defines mapping function from calculated transform confidence to actually used transform confidence. The calculated confidence is in the range 0:256 (8 bit fraction). The mapping is:  actual confidence =  transform_confidence_mapping_base when calculated confidence <= transform_confidence_mapping_c1; 256 when calculated confidence > transform_confidence_mapping_c2 and linear interpolation in-between. Not relevant for multi frame flows.
    // format: 8uQ7
    uint32_t transform_confidence_mapping_c1;

    // Defines mapping function from calculated transform confidence to actually used transform confidence. The calculated confidence is in the range 0:256 (8 bit fraction). The mapping is:  actual confidence =  transform_confidence_mapping_base when calculated confidence <= transform_confidence_mapping_c1; 256 when calculated confidence > transform_confidence_mapping_c2 and linear interpolation in-between. Not relevant for multi frame flows.
    // format: 8uQ7
    uint32_t transform_confidence_mapping_c2;

    // When calculated transform confidence (before mapping) is below this threshold, the transform is ignored and replaced by identity transform. Hysteresis is used on this parameter to avoid excessive switching
    // format: 8u
    uint32_t transform_confidence_thr_to_force_identity_transform;

    // Defines which transform model to use during transform estimation stage (0=projective, 1=affine, 2=rigid, 4-AutoDetect )
    // format: 2u
    uint32_t transform_model;

    // L2 distacne between model estimation and measured motion vector below which MV will be considered as inlier.
    // format: float
    float model_match_thr;

    // This Parameter is relevant form multi frame flows. The parameter defines the input resolution of the alignement process. 0:1440p, 1:1280p, 2:1080p, 3:960p, 4:720p, 5:540p 6:270p. Maximal image width supported is 1920. In case input image width > 1920. The biggest resolution in which width <=1920 will be chosen.
    // format: 4u
    uint32_t multi_frame_input_resolution;

    // This parameter is relevant to VSR video flow. In order to reduce the noise level, extra down scale is performed before registration. The parameter sets the controls the downscale ratio. In case value == 1 no downscaling is done before registration.
    // format: float
    float video_registration_down_scale_ratio;

    // Identity trasnform detectection mode: 0 - disabled, 1 : 4  predfine calibreation. 1- tend to avoid identity detection  , 4 - detect identity in more permissive way. 5- expert mode, I this mode identity dtection will use directly the  ..
    // format: 4u
    uint32_t auto_identity_detect_mode;

    // Enaling Identity detection - relevant only if auto_detect_Identity_mode == 5
    // format: 1u
    uint32_t identity_detect__enable;

    // consistency measure above which the motion is not  considered as identity  - relevant only if auto_detect_Identity_mode == 5
    // format: 7u
    uint32_t identity_detect_consistency_mesure_th;

    // relevant only if auto_detect_Identity_mode == 5.
    // format: float
    float identity_detection_mvs_avg_size_th;

    // Threshold percentage of big motion vector that was used to calculate the transform.  Above this percentage thershold  the motion is not considered as identity- relevant only if auto_detect_Identity_mode == 5.
    // format: 17u
    uint32_t identity_detect_big_mvs_percent_th;

    // Enforce temporal consistency - if identify less than "parameter" out 5 frames the transform is not considered as identity - relevant only if auto_detect_Identity_mode == 5
    // format: 7u
    uint32_t identity_detect_temporal_consistency;

    // Threshold over transform complexity( significant rotation/perspective), identity transform is considered only if complexity is less than threshold  - relevant only if auto_detect_Identity_mode == 5- relevant only if auto_detect_Identity_mode == 5
    // format: 10u
    uint32_t identity_detect_complexity_th;

    // Threshold over the number of Motion vector that are in use, identity transform is considered only if number of motion vector is less than threshold  - relevant only if auto_detect_Identity_mode == 5
    // format: 10u
    uint32_t identity_detect_max_num_mvs_th;

    // Confidence to be set in case identity transform was detected by "identity detection" algorithm
    // format: 9u
    uint32_t confidence_auto_identity_detect;

    // Enabeling  screening  obvious motion  outlier vector based on size
    // format: 1u
    uint32_t motion_vector_screen_enable;

    // Enabling motion vector screening only if motion vector std is larger than motion_vector_screen_min_std_th
    // format: float
    float motion_vector_screen_min_std_th;

    // Reject motion vector which are longer  than median by  motion_vector_screen_std_factor_th times std
    // format: float
    float motion_vector_screen_std_factor_th;

    // conf1
    // format: float
    float conf1;

    // conf2
    // format: float
    float conf2;

    // conf3
    // format: float
    float conf3;

    // conf4
    // format: float
    float conf4;

    // conf5
    // format: float
    float conf5;

    // gain factor to improve contrast
    // format: float
    float contrast_gain_factor;

    // reserved1
    // format: float
    float reserved1;

    // reserved2
    // format: float
    float reserved2;

    // reserved3
    // format: float
    float reserved3;

    // reserved4
    // format: float
    float reserved4;

    // reserved5
    // format: float
    float reserved5;

    // filtering setting in CVP ICA
    // format: float
    float ica_filtering;

} CVP_Chromatix_v20;

// ############ Functions ############
int32_t Validate_CVP_Chromatix_v20( CVP_Chromatix_v20* regStruct );
void SetDefaultVal_CVP_Chromatix_v20( CVP_Chromatix_v20* regStruct );
// ###################################
#ifdef __cplusplus
}
#endif


#endif //__CVP_CHROMATIX_V20_H__

