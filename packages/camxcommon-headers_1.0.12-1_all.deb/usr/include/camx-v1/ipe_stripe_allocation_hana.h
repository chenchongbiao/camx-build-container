//-------------------------------------------------------------------------
// Copyright (c) 2015-2017 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
//------------------------------------------------------------------------

#ifndef IPE_STRIPE_ALLOCATION_HANA_H_
#define IPE_STRIPE_ALLOCATION_HANA_H_

#include "ipe_stripe_internal_structs.h"
#include "stripeNPSPPS.h"

int decideMinStripeCount(const PassInput1D * pInput, const PassVar1D * pParams);
int allocateStripes_hana(const PassInput1D * pInput, const PassVar1D * pParams, ipeStripeAllocationControl *allocationCtrl,
                         ListHandle *pHStripeAllocationResultList);


#endif
