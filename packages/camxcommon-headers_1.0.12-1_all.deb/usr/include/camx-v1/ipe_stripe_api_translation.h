//-------------------------------------------------------------------------
// Copyright (c) 2018-2020 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.

//------------------------------------------------------------------------

#ifndef IPE_STRIPE_API_TRANSLATION_
#define IPE_STRIPE_API_TRANSLATION_

// TODO : document this file: copyright, functions, etc.

#include "list.h"
#include "icpcomdef.h"
#include "stripe.h"
#include "stripeNPSPPS.h"
#include "stripedebug.h"

#ifdef __cplusplus
extern "C" {
#endif

    typedef struct _FirmwareInput
    {
        // debug
        int16_t overrideMaxBufferSize;

        // top level
        int16_t   tiering;
        int16_t   mux_mode;
        int16_t   oneto4PassEnable;
        int16_t   oneto16PassEnable;
        int16_t   oneto64PassEnable;
        int16_t   passSkipThreshold_w;
        int16_t   passSkipThreshold_h;

        int16_t TFfullOutFormat_full;
        int16_t TFds4OutFormat_full;
        int16_t TFds4OutFormat_1to4;
        int16_t                             mctfFlow;

        // main input
        int16_t   mainInFormat;
        int16_t   mainRefInFormat;
        int16_t   mainInWidth;
        int16_t   mainInHeight;
        int16_t   zoomEnable;
        int16_t   zoomFirstPixelInSource;
        int16_t   zoomFirstLineInSource;
        int16_t   zoomInWidth;
        int16_t   zoomInHeight;
        int16_t   prevZoomEnable;
        int16_t   prevZoomFirstPixelInSource;
        int16_t   prevZoomFirstLineInSource;
        int16_t   prevZoomInWidth;
        int16_t   prevZoomInHeight;
        int16_t   mainInStride;

        // algm
        ImageFormat                         algmInFormat;
        int16_t                             algmInWidth;
        int16_t                             algmInHeight;

        // MFHDR Input
        int16_t                             mfhdrInFormat;
        int16_t                             mfhdrInWidth;
        int16_t                             mfhdrInHeight;
        int16_t                             mfhdrInFormat_1to4;
        int16_t                             mfhdrInWidth_1to4;
        int16_t                             mfhdrInHeight_1to4;

        // 1:4 input frame
        int16_t  oneToFourInputFormat;
        int16_t  oneToFourRefInFormat;
        int16_t   oneToFourInputWidth;
        int16_t   oneToFourInputHeight;
        int16_t   oneToFourInputStride;

        // 1:4 zoom region for PDI & TFI,  used in full pass when zoom
        int16_t zoom1to4PDITFInputFirstPixel;
        int16_t zoom1to4PDITFInputFirstLine;
        int16_t zoom1to4PDITFInputWidth;
        int16_t zoom1to4PDITFInputHeight;


        // 1:16 input frame
        int16_t   oneToSixteenInputFormat;
        int16_t   oneToSixteenRefInFormat;
        int16_t   oneToSixteenInputWidth;
        int16_t   oneToSixteenInputHeight;
        int16_t   oneToSixteenInputStride;


        // 1:64 input frame
        int16_t   oneTo64InputFormat;
        int16_t   oneTo64RefInFormat;
        int16_t   oneTo64InputWidth;
        int16_t   oneTo64InputHeight;
        int16_t   oneTo64InputStride;

        // IPE_LENR_DS4_IN
        int16_t   lenrDs4InputFormat;

        // IPE_BLUR_DS4_IN
        int16_t    bokehdcinFormat[IPE_PASS_COUNT];

        // IPE_BLUR_MAP_IN
        int16_t   blurMapBlurInputFormat;
        int16_t   blurMapVSEInputFormat;

        // ALGM Output
        ImageFormat     algmOutFormat;
        int16_t         algmOutWidth;
        int16_t         algmOutHeight;

        // display output
        int16_t   dispOutFormat;
        int16_t   dispOutWidth;
        int16_t   dispOutHeight;
        int16_t   dispOutFirstPixelInSource;
        int16_t   dispOutFirstLineInSource;
        int16_t   dispOutWidthInSource;
        int16_t   dispOutHeightInSource;
        int16_t   dispOutStride;
        int32_t   dispDSratio_h;
        int32_t   dispDSratio_v;
        int32_t   dispPrevFirstPixelInSource;
        int32_t   dispPrevFirstLineInSource;

        // video output
        int16_t   videoOutFormat;
        int16_t   videoOutWidth;
        int16_t   videoOutHeight;
        int16_t   videoOutFirstPixelInSource;
        int16_t   videoOutFirstLineInSource;
        int16_t   videoOutWidthInSource;
        int16_t   videoOutHeightInSource;
        int16_t   videoOutStride;
        int32_t   videoDSratio_h;
        int32_t   videoDSratio_v;
        int32_t   videoPrevFirstPixelInSource;
        int32_t   videoPrevFirstLineInSource;

        uint32_t  mnds_overlap_min_phase_step[IPE_PASS_COUNT]; // MNDSv23 overlap feature control

        // module PPS on/off
        int16_t   moduleEnableCAC2;    // chroma upsample should be on
        int16_t   moduleEnableChromaUp;     //this might change the format of the following modules
        int16_t   moduleEnableLTM;     // if LTM enabled,  assuming DC collection in 1:4 pass
        int16_t   moduleEnableASF;
        int16_t   moduleEnableTF[4];      // to tell whether TF path is on or not.
        int16_t   moduleEnableUpscalar;
        int16_t   moduleEnableRNF[4];   // ANR
        int16_t   moduleEnableCYLPF[4];  // ANR
        int16_t   moduleEnableFilter2[4]; //ANR
        int16_t   moduleEnableTFDilate[4];
        int16_t   moduleEnableTFErode[4];
        int16_t   moduleEnableTFLMC[4];
        int16_t   moduleEnableTFALGM[IPE_PASS_COUNT];
        int16_t   moduleEnableDS4[4];

        //: ASF adaptive kernel size
        BOOL ASF_edge_alignment_enable;
        BOOL ASF_contrast_enable;
        BOOL ASF_layer_2_contrast_enable;                   // v3.4
        BOOL ASF_layer_1_contrast_enable;                   // v3.4
        BOOL ASF_layer_2_enable;
        BOOL ASF_layer_1_enable;

        // waipio.s2.50
        // Blur
        BLURv10StripingInputParams          blur[IPE_PASS_COUNT];
        VSEv10StripingInputParams           vse[IPE_PASS_COUNT];

        // HDR10PLUS
        int16_t HDR10PLUS_enable;
        int16_t HDR10PLUS_hdr10_hist_rgn_h_offset;
        int16_t HDR10PLUS_hdr10_hist_rgn_h_num;

        // tuning parameters:
        ANRLNRInputParams anrlnr[4];
        TFrefinementInputParams TFrefinementIn[3];
        ICAv10InputParams ica1;
        ICAv10InputParams ica2;


        int32_t videoDownRoundingOption_c_h;        //: MNDS chroma rounding mode can vary
        int32_t videoDownRoundingOption_c_v;        //: MNDS chroma rounding mode can vary
        int32_t dispDownRoundingOption_c_h;     //: MNDS chroma rounding mode can vary
        int32_t dispDownRoundingOption_c_v;     //: MNDS chroma rounding mode can vary
        BOOL chromaUp_cosited;
        BOOL chromaUp_even;
        int32_t ltmDCtableOption;    // defines the size of LTM DC table   0: 288x216  1: 144x108  2: 72x54
        int16_t ltm_ip_mask_filter_en;
        int16_t ltm_img_process_en;
        BOOL    ltm_data_collect_en;
        int16_t ltm_performDCatDC16pass;                //1: use DC16 to do LTM data collection
        int16_t dummy_field_for_byte_padding;
        int32_t ANR_CYLPF_dithering_seed_frame[4];
        int32_t ANR_dcnf_dithering_seed_frame[4];
        int32_t tf_prngSeed_frame[4];
        int16_t tf_dithering_en[4];
        int16_t tf_useImgAsMctfpInput[4];               //during tf blending, the original image is used as the ref in. we therefore doesn't need to configure ref fetch
        int32_t tf_LnrStartIdxH_frame[4];
        int32_t tf_LnrScaleH[4];
        int32_t tf_LnrStartIdxV_frame[4];
        int32_t tf_LnrScaleV[4];
        BOOL ANR_dcnf_dithering_y_en[4];
        BOOL ANR_dcnf_dithering_c_en[4];
        BOOL TFlowpowerMode;
        GRAv10stripingInputParams gra;
        upscale_v20stripingInputParams_old upscalarIn;
        HNRInputParam                       hnr;
        TFv10v20StripingInputParams tf[4];

        // mfhdr
        ChromaUpv20StripingInputParams      mfhdr_chroma_up_T1L_MACin1_ICA2;
        ChromaUpv20StripingInputParams      mfhdr_chroma_up_T2M_MACin2_MFHDR_FE;
        ChromaUpv20StripingInputParams      mfhdr_chroma_up_T3S_MACin0_TF;
        MFHDRMACv10StripingInputParams      mfhdr_mac;
        LTMv13StripingInputParams           mfhdr_ltm;
        MNDSv20StripingInputParams          mfhdr_chromadn;
        DsxStripingInputParams              dsx[IPE_PASS_COUNT];

        BOOL forceEvenStripe;
        BOOL avoidNarrowStripe;
        BOOL enforceMinOutputConstraint;
    }
    NPSPPSFirmwareInput;


    typedef struct _NPSPPSStripeOutput
    {
        IpeStripingModule1dOutputStorage    module1d;
        // fetch coordinates
        int16_t TFIndFetchFirstPixel;
        int16_t TFIndFetchLastPixel;
        int16_t mainInFetchFirstPixel;
        int16_t mainInFetchLastPixel;
        int16_t refInFetchFirstPixel;
        int16_t refInFetchLastPixel;
        int16_t ANRDCInFetchFirstPixel;
        int16_t ANRDCInFetchLastPixel;
        int16_t DCNFfetchFirst;                 //: for setting up the write engine of DCNF
        int16_t DCNFfetchLast;
        int16_t LMCInFetchFirstByte;   // 2Bytes per 8x8 pixels
        int16_t LMCInFetchLastByte;
        int16_t lmcFetchFirstPixel[ICA_LMC_CNT];
        int16_t lmcFetchLastPixel[ICA_LMC_CNT];
        int16_t algmFetchFirstPixel;
        int16_t algmFetchLastPixel;
        int16_t mfhdrFetchFirstPixel;
        int16_t mfhdrFetchLastPixel;
        int16_t ltmMaskIn_FetchFirst;
        int16_t ltmMaskIn_FetchLast;
        int16_t ltmMaxMinIn_FetchFirst;
        int16_t ltmMaxMinIn_FetchLast;
        int16_t LENRDS4InFetchFirstPixel;
        int16_t LENRDS4InFetchLastPixel;
        int16_t BLURDS4InFetchFirstPixel;
        int16_t BLURDS4InFetchLastPixel;
        int16_t BLURMAPInFetchFirstPixel;
        int16_t BLURMAPInFetchLastPixel;
        int16_t BLURMAPVSEInFetchFirstPixel;
        int16_t BLURMAPVSEInFetchLastPixel;

        // write coordinates
        int16_t PdiOutFirstPixel;
        int16_t PdiOutLastPixel;
        int16_t TFIOutFirstPixel;
        int16_t TFIOutLastPixel;
        int16_t algmOutFirstPixel;
        int16_t algmOutLastPixel;
        int16_t TFOutFirstPixel;
        int16_t TFOutLastPixel;
        int16_t LMCOutFirstByte;
        int16_t LMCOutLastByte;
        int16_t DS4OutFirstPixel;
        int16_t DS4OutLastPixel;
        int16_t ltmMaskDcOut_First;
        int16_t ltmMaskDcOut_Last;
        int16_t ltmMaxMinOut_First;
        int16_t ltmMaxMinOut_Last;
        int16_t videoOutLumaFirstPixel;
        int16_t videoOutLumaLastPixel;
        int16_t dispOutLumaFirstPixel;
        int16_t dispOutLumaLastPixel;
        int16_t blurMapOutFirstPixel;
        int16_t blurMapOutLastPixel;

        // crop amounts
        //ANR PDI input path
        crop_1D ANRDCUpscaler1InCrop;
        crop_1D ANRDCUpscaler1OutCrop;
        crop_1D ANRDCUpscaler2OutCrop;

        // ANR PDI output path
        crop_1D PDINOOutCrop;
        crop_1D PDINFOutCrop;

        crop_1D TFimageInCrop;
        int16_t TFimageInCrop_en;

        // TFI input path
        crop_1D TFIEInCrop;     // E2E-CHANGE (comment):should be one bit from each side representing 1-nibble crop
        crop_1D TFIEOutCrop;    // No Use (TF does automatic cropping according to left/right indication)
        crop_1D TFIDOutCrop;    // No Use (TF does automatic cropping according to left/right indication)
        crop_1D TFIUSInCrop;    // should be one bit from each side representing 1-nibble crop
        crop_1D TFIUSOutCrop;   // should be 3-bits per side representing [0,2,4]

        // ALGM_IN input path   // TODO_NKP: Comments explanations for following three lines.
        crop_1D AlgmInCrop;      // E2E-CHANGE (comment):should be one bit from each side representing 1-nibble crop
        crop_1D AlgmUSInCrop;    // should be one bit from each side representing 1-nibble crop
        crop_1D AlgmUSOutCrop;   // should be 3-bits per side representing [0,2,4]

        // TFI output path
        crop_1D TFIOutCrop;

        // ALGM Output path
        crop_1D AlgmOutCrop;

        // TF output path
        crop_1D TFOutCrop_Y;
        crop_1D TFOutCrop_C;
        int16_t TFrefInCrop_en;
        crop_1D TFrefInCrop;

        // DS4 output path
        crop_1D DS4InCropLuma;
        crop_1D DS4InCropChroma;
        crop_1D DS4OutCrop_Y;
        crop_1D DS4OutCrop_C;

        crop_1D cropLumaBeforeChromaUpsample;       // Y crop module before chroma upsample in PPS pipeline
        crop_1D cropChromaBeforeChromaUpsample;     // cbcr crop module before chroma upsample in PPS pipeline
        crop_1D cropAfterASF;


        crop_1D SIMOUpscaleCrop;
        crop_1D videoFOVCrop_luma;
        crop_1D videoFOVCrop_chroma;
        crop_1D dispFOVCrop_luma;
        crop_1D dispFOVCrop_chroma;
        crop_1D videoLumaCrop;              // after the down scaler
        crop_1D videoChromaCrop;            // after the down scaler
        crop_1D dispLumaCrop;
        crop_1D dispChromaCrop;

        crop_1D mfhdr1preChromaupCropLuma_1D;
        crop_1D mfhdr1preChromaupCropChroma_1D;
        crop_1D mfhdr2preChromaupCropLuma_1D;
        crop_1D mfhdr2preChromaupCropChroma_1D;
        crop_1D mfhdr3preChromaupCropLuma_1D;
        crop_1D mfhdr3preChromaupCropChroma_1D;
        crop_1D mfhdrpreChromadnCropLuma_1D;
        crop_1D mfhdrpreChromadnCropChroma_1D;

#ifdef PERF
        int32_t ANRInputWidth;
        int32_t ANROutputWidth;
        int32_t TFInputWidth;
        int32_t TFOutputWidth;
        int32_t eightTapDSInputWidth;
        int32_t eightTapDSOutputWidth;

        int32_t CAC2InputWidth;
        int32_t CAC2OutputWidth;
        int32_t ASFInputWidth;
        int32_t ASFOutputWidth;
#endif // PERF

        // flags
        BOOL leftStripe;
        BOOL rightStripe;
        BOOL leftStripePDI;          // is there corner case where for main input it's at boundary, but not for PDI & TFI?
        BOOL rightStripePDI;
        BOOL leftStripeTFI;
        BOOL rightStripeTFI;
        BOOL useDS4forBlur;

        // scalers
        UpscaleInStruct_V11_1D DCUpscale1H;    //  ANR PDI input path
        UpscaleInStruct_V11_1D DCUpscale2H;    //  ANR PDI input path
        UpscaleInStruct_V11_1D TFIUpscaleH;    //  TFI input path

        MNScaleDownInStruct_V20_1D downscaleVideoLumaH;
        MNScaleDownInStruct_V20_1D downscaleVideoChromaH;
        MNScaleDownInStruct_V20_1D downscaleDispLumaH;
        MNScaleDownInStruct_V20_1D downscaleDispChromaH;
        MNScaleDownInStruct_V20_1D downscaleLTMDCH;
        UpscaleInStruct_V20_1D upscaleSIMOH;
        UpscaleInStruct_V11_1D chromaUpH_Y;
        UpscaleInStruct_V11_1D chromaUpH_C;

        UpscaleInStruct_V11_1D DCUpscale1HFrame;
        UpscaleInStruct_V11_1D DCUpscale2HFrame;
        UpscaleInStruct_V11_1D TFIUpscaleHFrame;
        MNScaleDownInStruct_V20_1D downscaleVideoLumaHFrame;
        MNScaleDownInStruct_V20_1D downscaleVideoChromaHFrame;
        MNScaleDownInStruct_V20_1D downscaleDispLumaHFrame;
        MNScaleDownInStruct_V20_1D downscaleDispChromaHFrame;
        MNScaleDownInStruct_V20_1D downscaleLTMDCHFrame;
        UpscaleInStruct_V20_1D upscaleSIMOHFrame;
        UpscaleInStruct_V11_1D chromaUpFrame_Y;
        UpscaleInStruct_V11_1D chromaUpFrame_C;

        // LTM
        int16_t ltmDCDSoutputStartPixel;
        int16_t ltmDCDSoutputEndPixel;
        int16_t ltmIPInputStartPixel;
        int16_t ltmIPInputEndPixel;

        // LTM
        LTMV13StripeDCParams      ltmDCparams;
        LTMV13StripeIPParams_1D   ltmIPparams;

        //LTMInStructIPE_V13 ltm;          // LTM parameters

        // ANR
        int16_t anrlnrFirstPixel;
        int16_t dummy_field_for_byte_padding;
        int32_t ANR_CYLPF_dithering_seed;
        int32_t ANR_dcnf_dithering_seed;
        int32_t ANR_CYLPF_LG_start;

        // TF
        int32_t tf_prngSeed;
        int32_t tf_LnrStartIdx;
        TFrefinementOutputParams tfRefineParam;

        //DSX
        DSXInStruct_V1D dsx;

        // GRA
        GRAv10stripingOutputParams gra;

        // intermediate per-stripe variables
        int16_t ppsInFirst;
        int16_t ppsInLast;
        int16_t tfRefRangeInROI;

        int16_t anr_CNR_FD_XOffset;
        int16_t asf_face_horizontal_offset;
        //===== generic ends here ======
        int16_t asf_initial_offset_minus_center_horizontal;
        int32_t asf_initial_r_square;
        BOOL    dsx_luma_en;
        BOOL    dsx_chroma_en;
        HNRv10StripingOutputParams          hnr;
        LENRv10StripingOutputParams         lenr;
        BLURv10StripingOutputParams        blur;
        VSEv10StripingOutputParams      vse;
        //BLURMapStripingOutputParams     blur_map;
        //VSEStripingOutputParams        vse_map;

        HDR10PLUSv10StripingOutputParams  hdr10plus;

        // ANR
        StripeParamsANRDCUS anrdcus;    // ANR DC US striping parameters
        StripeParamsANRLNR anrlnr;      // ANR LNR striping paramters

        // TF (LMC)
        uint8_t lmCropAfterUpscale_left;
        uint8_t lmCropAfterUpscale_right;
        uint8_t lmCropAfterUpscale_top;
        uint8_t lmCropAfterUpscale_bottom;
        BOOL    lmCropOut_enable;
        uint16_t lmCropOut_horizStart;
        uint16_t lmCropOut_horizEnd;
        uint16_t lmCropOut_vertStart;
        uint16_t lmCropOut_vertEnd;

        int32_t qosIPEcounter;

        // HNR
        int HNR_RNR_bx;
        int HNR_RNR_r_square_init;
        int HNR_face_horizontal_offset;


        CRCv10StripingOutputParams      mfhdr1preChromaupCropLuma;
        CRCv10StripingOutputParams      mfhdr1preChromaupCropChroma;
        CRCv10StripingOutputParams      mfhdr2preChromaupCropLuma;
        CRCv10StripingOutputParams      mfhdr2preChromaupCropChroma;
        CRCv10StripingOutputParams      mfhdr3preChromaupCropLuma;
        CRCv10StripingOutputParams      mfhdr3preChromaupCropChroma;
        CRCv10StripingOutputParams      mfhdrpreChromadnCropLuma;
        CRCv10StripingOutputParams      mfhdrpreChromadnCropChroma;

        ChromaUpv20StripingOutputParams     mfhdr_chromaup_T1L_MACin1_ICA2;
        ChromaUpv20StripingOutputParams     mfhdr_chromaup_T2M_MACin2_MFHDR_FE;
        ChromaUpv20StripingOutputParams     mfhdr_chromaup_T3S_MACin0_TF;
        MFHDRMACv10StripingOutputParams     mfhdr_mac;
        LTMv13StripingOutputParams          mfhdr_ltm;
        MNDSv20StripingOutputParams         mfhdr_chromadn;

    }
    NPSPPSStripeOutput;

    typedef struct _NPSPPSPassOutput
    {
      IpeStripingModule1dOutputStorage    module1d;
        /* pass-level parameters */
        // fetch coordinates
        int16_t TFIndFetchFirstLine;
        int16_t TFIndFetchLastLine;
        int16_t mainInFetchFirstLine;
        int16_t mainInFetchLastLine;
        int16_t refInFetchFirstLine;
        int16_t refInFetchLastLine;
        int16_t ANRDCInFetchFirstLine;
        int16_t ANRDCInFetchLastLine;
        int16_t DCNFfetchFirst;                 //: for setting up the write engine of DCNF
        int16_t DCNFfetchLast;
        int16_t LMCInFetchFirstLine;
        int16_t LMCInFetchLastLine;
        int16_t LmcFetchFirstLine[ICA_LMC_CNT];
        int16_t LmcFetchLastLine[ICA_LMC_CNT];
        int16_t algmFetchFirstLine;
        int16_t algmFetchLastLine;
        int16_t mfhdrFetchFirstLine;
        int16_t mfhdrFetchLastLine;
        int16_t ltmMaskIn_FetchFirst;
        int16_t ltmMaskIn_FetchLast;
        int16_t ltmMaxMinIn_FetchFirst;
        int16_t ltmMaxMinIn_FetchLast;
        int16_t LENRDS4InFetchFirstLine;
        int16_t LENRDS4InFetchLastLine;
        int16_t BLURDS4InFetchFirstLine;
        int16_t BLURDS4InFetchLastLine;
        int16_t BLURMAPInFetchFirstLine;
        int16_t BLURMAPInFetchLastLine;
        int16_t BLURMAPVSEInFetchFirstLine;
        int16_t BLURMAPVSEInFetchLastLine;

        // write coordinates
        int16_t PdiOutFirstLine;
        int16_t PdiOutLastLine;
        int16_t TFIOutFirstLine;
        int16_t TFIOutLastLine;
        int16_t AlgmOutFirstLine;
        int16_t AlgmOutLastLine;
        int16_t TFOutFirstLine;
        int16_t TFOutLastLine;
        int16_t LMCOutFirstLine;
        int16_t LMCOutLastLine;
        int16_t DS4OutFirstLine;
        int16_t DS4OutLastLine;
        int16_t ltmMaskDcOut_First;
        int16_t ltmMaskDcOut_Last;
        int16_t ltmMaxMinOut_First;
        int16_t ltmMaxMinOut_Last;
        int16_t videoOutLumaFirstLine;
        int16_t videoOutLumaLastLine;
        int16_t dispOutLumaFirstLine;
        int16_t dispOutLumaLastLine;
        int16_t blurMapOutFirstLine; // waipio.s2.50
        int16_t blurMapOutLastLine;

        // crop amounts
        crop_1D ANRDCUpscaler1InCrop;
        crop_1D ANRDCUpscaler1OutCrop;
        crop_1D ANRDCUpscaler2OutCrop;
        crop_1D PDINOOutCrop;
        crop_1D PDINFOutCrop;

        crop_1D TFimageInCrop;
        int16_t TFimageInCrop_en;
        crop_1D TFIEInCrop;     //E2E-CHANGE (comment): No Use
        crop_1D TFIEOutCrop;    //Ok
        crop_1D TFIDOutCrop;    //Ok
        crop_1D TFIUSInCrop;    //No Use (Only vertical 1-nibble)
        crop_1D TFIUSOutCrop;   //Ok
        crop_1D TFIOutCrop;     //Should be 3-bits per side representing [0,2,4]
        crop_1D AlgmOutCrop;    // TODO_NKP: Is really required?
        crop_1D TFOutCrop_Y;
        crop_1D TFOutCrop_C;
        int16_t TFrefInCrop_en;
        crop_1D TFrefInCrop;

        crop_1D DS4InCropLuma;
        crop_1D DS4InCropChroma;
        crop_1D DS4OutCrop_Y;
        crop_1D DS4OutCrop_C;

        crop_1D cropLumaBeforeChromaUpsample;       // Y crop module before chroma upsample in PPS pipeline
        crop_1D cropChromaBeforeChromaUpsample;     // cbcr crop module before chroma upsample in PPS pipeline
        crop_1D cropAfterASF;

        crop_1D SIMOUpscaleCrop;
        crop_1D videoFOVCrop_luma;
        crop_1D videoFOVCrop_chroma;
        crop_1D dispFOVCrop_luma;
        crop_1D dispFOVCrop_chroma;
        crop_1D videoLumaCrop;
        crop_1D videoChromaCrop;
        crop_1D dispLumaCrop;
        crop_1D dispChromaCrop;

        crop_1D mfhdr1preChromaupCropLuma_1D;
        crop_1D mfhdr1preChromaupCropChroma_1D;
        crop_1D mfhdr2preChromaupCropLuma_1D;
        crop_1D mfhdr2preChromaupCropChroma_1D;
        crop_1D mfhdr3preChromaupCropLuma_1D;
        crop_1D mfhdr3preChromaupCropChroma_1D;
        crop_1D mfhdrpreChromadnCropLuma_1D;
        crop_1D mfhdrpreChromadnCropChroma_1D;

#ifdef PERF
        int32_t ANRInputHeight;
        int32_t ANROutputHeight;
        int32_t TFInputHeight;
        int32_t TFOutputHeight;
        int32_t eightTapDSInputHeight;
        int32_t eightTapDSOutputHeight;

        int32_t CAC2InputHeight;
        int32_t CAC2OutputHeight;
        int32_t ASFInputHeight;
        int32_t ASFOutputHeight;
#endif // PERF

        // flags
        BOOL topPad;
        BOOL bottomPad;
        BOOL topStripePDI;
        BOOL bottomStripePDI;
        BOOL topStripeTFI;
        BOOL bottomStripeTFI;

        // scalers
        UpscaleInStruct_V11_1D DCUpscale1V;
        UpscaleInStruct_V11_1D DCUpscale2V;
        UpscaleInStruct_V11_1D TFIUpscaleV; //E2E-CHANGE (comment):NO Use

        MNScaleDownInStruct_V20_1D downscaleVideoLumaV;
        MNScaleDownInStruct_V20_1D downscaleVideoChromaV;
        MNScaleDownInStruct_V20_1D downscaleDispLumaV;
        MNScaleDownInStruct_V20_1D downscaleDispChromaV;
        MNScaleDownInStruct_V20_1D downscaleLTMDCV;
        UpscaleInStruct_V20_1D upscaleSIMOV;
        UpscaleInStruct_V11_1D chromaUpV_Y;
        UpscaleInStruct_V11_1D chromaUpV_C;

        UpscaleInStruct_V11_1D DCUpscale1VFrame;
        UpscaleInStruct_V11_1D DCUpscale2VFrame;
        UpscaleInStruct_V11_1D TFIUpscaleVFrame;    //E2E-CHANGE (comment):NO Use
        MNScaleDownInStruct_V20_1D downscaleVideoLumaVFrame;
        MNScaleDownInStruct_V20_1D downscaleVideoChromaVFrame;
        MNScaleDownInStruct_V20_1D downscaleDispLumaVFrame;
        MNScaleDownInStruct_V20_1D downscaleDispChromaVFrame;
        MNScaleDownInStruct_V20_1D downscaleLTMDCVFrame;
        UpscaleInStruct_V20_1D upscaleSIMOVFrame;
        UpscaleInStruct_V11_1D chromaUpFrame_Y;
        UpscaleInStruct_V11_1D chromaUpFrame_C;

        // LTM
        int16_t ltmDCDSoutputStartLine;
        int16_t ltmDCDSoutputEndLine;
        int16_t ltmIPInputStartLine;
        int16_t ltmIPInputEndLine;

        // LTM
        LTMV13StripeDCParams   ltmDCparams;
        LTMV13StripeIPParams_1D   ltmIPparams;

        int32_t dummy_field_for_byte_padding;

        /* stripes */
        ListHandle hStripeList;
        int16_t    numStripes;

        // ANR
        int16_t anrlnrFirstLine;
        int32_t ANR_CYLPF_dithering_seed;
        int32_t ANR_dcnf_dithering_seed;
        int32_t ANR_CYLPF_LG_start;

        // TF
        int32_t tf_prngSeed;
        int32_t tf_LnrStartIdx;
        TFrefinementOutputParams tfRefineParam;

        //DSX
        DSXInStruct_V1D dsx;

        // GRA
        GRAv10stripingOutputParams gra;

        // intermediate per-stripe variables
        int16_t ppsInFirst;
        int16_t ppsInLast;
        int16_t tfRefRangeInROI;

        int16_t anr_CNR_FD_YOffset;
        int16_t asf_face_vertical_offset;
        //===== generic ends here ======
        int16_t asf_r_square_shift;
        int16_t asf_r_square_scale;
        int16_t asf_initial_offset_minus_center_vertical;

        int16_t anr_dcin_en;
        int16_t tfi_in_en;

        // enables
        int16_t LTMDCEnable;
        int16_t LTMIPEnable;
        int16_t ltm_ds_fac;
        int16_t TFenable;

        // scale ratios - q_factor format
        int32_t ds4Ratio;
        int32_t upscaleRatioSIMO_;          // TODO : unused in FW code
        int32_t downscaleRatioVideo_;       // TODO : unused in FW code
        int32_t downscaleRatioDisp_;        // TODO : unused in FW code

        int16_t videoOutImageLumaWidth;
        int16_t dispOutImageLumaWidth;


        BOOL chromaUp_cosited;
        BOOL chromaUp_even;
        BOOL ANR_dcnf_dithering_y_en;
        BOOL ANR_dcnf_dithering_c_en;
        int32_t ANR_CYLPF_LG_YExtStart;

        int16_t   ROI_start_x_TFI;
        int16_t   ROI_start_y_TFI;
        int16_t   refInOffset_x;
        int16_t   refInOffset_y;
        int16_t   ref1frameWidth;
        int16_t   ref1frameHeight;
        int16_t   ref4frameWidth;
        int16_t   ref4frameHeight;
        int16_t   npsImageZoomWindow_isZoomEnable;
        int16_t   npsImageZoomWindow_startX;
        int16_t   npsImageZoomWindow_startY;
        int16_t   npsImageZoomWindow_sizeX;
        int16_t   npsImageZoomWindow_sizeY;
        int16_t   npsRefZoomWindow_isZoomEnable;
        int16_t   npsRefZoomWindow_startX;
        int16_t   npsRefZoomWindow_startY;
        int16_t   npsRefZoomWindow_sizeX;
        int16_t   npsRefZoomWindow_sizeY;
        int16_t   npsPrevRefZoomWindow_isZoomEnable;
        int16_t   npsPrevRefZoomWindow_startX;
        int16_t   npsPrevRefZoomWindow_startY;
        int16_t   npsPrevRefZoomWindow_sizeX;
        int16_t   npsPrevRefZoomWindow_sizeY;

#ifdef calculate_BW
        // TODO : remove if there is no negative impact (struct size change)
        int16_t mainInFormat_;
        int16_t refInFormat_;
        int16_t ANRDCInFormat_;
        int16_t TFIndFormat_;
        int16_t AlgmInFormat_;  // TODO_NKP: Check. Is really required?

        int16_t dispOutFormat;   // TODO : remove when possible
        int16_t videoOutFormat;  // TODO : remove when possible
        int16_t PDIOutFormat_;
        int16_t TFIOutFormat_;
        int16_t AlgmOutFormat_;  // TODO_NKP: Check. Is really required?
        int16_t TFOutFormat_;
        int16_t DS4OutFormat_;
        int16_t dummy_field_for_byte_padding_0;
        int32_t dummy_field_for_byte_padding_1;
#endif

        // HNR
        int HNR_RNR_by;
        int HNR_RNR_r_square_scale;
        int HNR_RNR_r_square_shift;
}
    NPSPPSPassOutput;

    typedef struct
    {
        /* frame-level parameters */


        /* passes */
        int32_t numPasses;
        int32_t dummy_field_for_byte_padding;
        NPSPPSPassOutput * passes;
    }
    NPSPPSFrameOutput;


    int32_t parseNPSPPSFirmwareInput(NPSPPSFirmwareInput * pFirmwareInput, NPSPPSFrameOutput * pFrameOut, const BOOL striping, userIPEArgs *pUserIPEArgs);
    void IpeStripingInputTranslation(const NPSPPSFirmwareInput * pFirmwareInput, IpeStripingLibraryInput *pStripingInput );
    void IpeStripingOutputPerFrameTranslation(IpeStripingLibraryOutputPerFrame * pNewFormatIn, NPSPPSFrameOutput *pOldFormatOut, const IpeStripingLibraryInput *pStripingInput);
    void ReleaseIpeFrameResult(IpeStripingLibraryOutputPerFrame *ipe_frame_output);
#ifdef __cplusplus
}
#endif

#endif
