//-------------------------------------------------------------------------
// Copyright (c) 2020 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
//------------------------------------------------------------------------

//------------------------------------------------------------------------
// @file  iqsettings_v3.h
// @brief SPECTRA_640 data type definitions
//------------------------------------------------------------------------

#ifndef _IQSETTINGS_V3_H_
#define _IQSETTINGS_V3_H_

#include "ipdefs.h"

//------------------------------------------------------------------------
// Constant Definitions
//------------------------------------------------------------------------

//------------------------------------------------------------------------
// Type Declarations
//------------------------------------------------------------------------

// SPECTRA_640  BPS Additions

typedef struct _BayerDs4Parameters
{
    uint32_t SCALE_SELECT; /*8:8*/
    uint32_t MONO_EN; /*9:9*/
}BayerDs4Parameters;

// SPECTRA_640  OPE Additions
typedef struct _DEMOSAIC_MODULE_CFG_v38
{
    uint32_t  EN; /* 0:0 */
    uint32_t  COSITED_RGB_EN; /* 10:10 */
    uint32_t  DIR_G_INTERP_DIS; /* 12:12 */
    uint32_t  DIR_RB_INTERP_DIS; /* 13:13 */
    uint32_t  DYN_G_CLAMP_EN; /* 14:14 */
    uint32_t  DYN_RB_CLAMP_EN; /* 15:15 */
    uint32_t  GREY_EN; /* 17:17 */
    uint32_t  GREEN_BILATERAL_EN; /* 17:17 */
} DEMOSAIC_MODULE_CFG_v38;

typedef struct _DemosaicParameters_v38
{
    DEMOSAIC_MODULE_CFG_v38 moduleCfg;
} DemosaicParameters_v38;

typedef struct _BLS_MODULE_CFG
{
    uint32_t  EN; /* 0:0 */
} BLS_MODULE_CFG;

typedef struct _BlsParameters
{
    BLS_MODULE_CFG moduleCfg;
} BlsParameters;

typedef struct _MCE_MODULE_CFG
{
    uint32_t  EN; /* 0:0 */
} MCE_MODULE_CFG;

typedef struct _MceParameters
{
    MCE_MODULE_CFG moduleCfg;
} MceParameters;

typedef struct _STATS_IHIST_MODULE_CFG
{
    uint32_t  EN; /* 0:0 */
    uint32_t  IHIST_CHAN_SEL; /* 10:8 */
    uint32_t  SHIFT_BITS; /* 15:12 */
} STATS_IHIST_MODULE_CFG;

typedef struct _IHistogramParameters_v11
{
    STATS_IHIST_MODULE_CFG moduleCfg;
    int32_t  ihistRoiHOffset;
    int32_t  ihistRoiVOffset;
    int32_t  ihistRgnHNum;
    int32_t  ihistRgnVNum;
    uint32_t ihistSrcSel; //0: LTM output as source 1: GLUT output as source
} IHistogramParameters_v11;

typedef struct _ChromaDS2Parameters_v2
{
    ScalerParameters                scalerParameters;
    RoundAndClampParameters         roundAndClampParameters; // Need not be filled
} ChromaDS2Parameters_v2;

#endif // _IQSETTINGS_V3_H_
