//------------------------------------------------------------------------
// Copyright (c) 2020 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
//------------------------------------------------------------------------
// @file  ope_wrapper.h
//------------------------------------------------------------------------

#pragma once

#include "stripetop.h"

int32_t ConfigureOpeStriping(const IpeStripingLibraryInput* pFirmwareInput,
                             IpeStripingLibraryOutputPerFrame* pFrameOut,
                             const userIPEArgs* pUserIPEArgs);

