//-------------------------------------------------------------------------
// Copyright (c) 2020 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.

//------------------------------------------------------------------------
// @file  stripeOPE.h
// @brief Declaration of all exposed structs & functions
//------------------------------------------------------------------------

#ifndef _STRIPEOPE_H_
#define _STRIPEOPE_H_


/*------------------------------------------------------------------------
*       Include Files
* ----------------------------------------------------------------------- */
#include <stdlib.h>
#include "chipinforeaderdefs.h"
#include "list.h"
#include "icpcomdef.h"
#include "modules.h"
#include "modulesOPE.h"
#include "scalers.h"
#include "stripe.h"
#include "dsv20stripe.h"
#include "usv12stripe.h"
#include "usv20stripe.h"
#include "stripe_common_define.h"

#ifdef __cplusplus
extern "C" {
#endif

////////////////////////////////////////////////////////////////////////////////
// enum definitions
typedef enum _STRIPING_OPE_IMAGE_RANGE
{
  COORDINATE_START = 0,
  COORDINATE_END,
  COORDINATE_COUNT
}
STRIPING_OPE_IMAGE_RANGE;

typedef enum _STRIPING_OPE_PIXEL_INPUT
{
  STRIPING_OPE_MAIN_IN = 0,
  STRIPING_OPE_PIXEL_INPUT_COUNT
}
STRIPING_OPE_PIXEL_INPUT;

typedef enum _STRIPING_OPE_PIXEL_OUTPUT
{
  STRIPING_OPE_VIDEO_OUT = 0,
  STRIPING_OPE_DISP_OUT,
  STRIPING_OPE_ARGB_OUT,
  STRIPING_OPE_FD_OUT,
  STRIPING_OPE_DUMMY,
  STRIPING_OPE_PIXEL_OUTPUT_COUNT,
  // NOT PART OF API
  STRIPING_OPE_LTMDC_PIXEL_OUT = STRIPING_OPE_DUMMY,
  STRIPING_OPE_REFERENCE_OUT
}
STRIPING_OPE_PIXEL_OUTPUT;

typedef enum _STRIPING_OPE_STATS_OUTPUT
{
  STRIPING_OPE_IHIST_OUT = 0,
  STRIPING_OPE_BG_OUT,
  STRIPING_OPE_LTMDC_STATS_OUT,
  STRIPING_OPE_STATS_OUTPUT_COUNT
}
STRIPING_OPE_STATS_OUTPUT;

//#pragma pack(push)
//#pragma pack(4)

////////////////////////////////////////////////////////////////////////////////
// Low level structs

////////////////////////////////////////////////////////////////////////////////
// OPE Striping Library API Input struct
typedef struct _OpeStripingLibraryInput
{
  BOOL striping_enable; // 0: # of stripes forced to 1; 1: regular striping
  BOOL striping_dump_enable; // runtime switch to enable striping dump

  uint16_t chipID; // Indicate which chip

  //////////
  // Image Port Info
  uint16_t pixelInFormat[STRIPING_OPE_PIXEL_INPUT_COUNT];
  uint16_t pixelInWidth[STRIPING_OPE_PIXEL_INPUT_COUNT];
  uint16_t pixelInHeight[STRIPING_OPE_PIXEL_INPUT_COUNT];

  uint16_t pixelOutFormat[STRIPING_OPE_PIXEL_OUTPUT_COUNT];
  uint16_t pixelOutWidth[STRIPING_OPE_PIXEL_OUTPUT_COUNT];
  uint16_t pixelOutHeight[STRIPING_OPE_PIXEL_OUTPUT_COUNT];

  //zoom window
  zoom_window pixelOutputZoomWindowUnion;
  zoom_window pixelOutputZoomWindows[STRIPING_OPE_PIXEL_OUTPUT_COUNT];

  uint16_t enableVideoOutMALalignment;
  uint16_t OPE_VideoOutMALalignmentGrid;

  //////////
  // Frame-Level Module Config
  //////////
  uint16_t mux_rgb_yuv444;    // 0: RBG, 12b;   1: YUV444, 12b
  uint16_t mux_yuv444_yuv420; // 0: YUV444, 8b; 1: YUV420, 8b
  uint16_t override_chromads2_en;      // new flow : OPECDSInputSelect/mux_yuv444_yuv420 = 1 and (override ?)chromads2_en = 1

  ChromaUpv20StripingInputParams chroma_up;
  ABFBPCInputParams              abfbpc;
  BasicModuleInput               demosaic;
  LTMv13StripingInputParams      ltm;
  MNDSv20StripingInputParams     chromads2;
  WNRInputParams                 wnr_y;
  WNRInputParams                 wnr_c;
  ASFv30StripingInputParams      asf;
  Upscalarv20StripingInputParams upscale;
  MNDSv20StripingInputParams     mnds_disp;
  MNDSv20StripingInputParams     mnds_Fd;
  iHistv12InputParam             ihist;
  RSInputParams                  rs;
  RollOffv34InputParameters      rollOff;   // chipID == SPECTRA_545
} OpeStripingLibraryInput;

////////////////////////////////////////////////////////////////////////////////
//
typedef struct _OpeStripingModule1dOutputStorage {
  CRCv10Striping1dOutputParams crc_preChromaUpCropLuma_out;
  CRCv10Striping1dOutputParams crc_preChromaUpCropChroma_out;
  CRCv10Striping1dOutputParams crc_chromaDownscalerCropLuma_out;
  CRCv10Striping1dOutputParams crc_chromaDownscalerCropChroma_out;
  CRCv10Striping1dOutputParams crc_preUpscalarCropLuma_out;
  CRCv10Striping1dOutputParams crc_preUpscalarCropChroma_out;
  CRCv10Striping1dOutputParams crc_dispPreMndsCropLuma_out;
  CRCv10Striping1dOutputParams crc_dispPreMndsCropChroma_out;
  CRCv10Striping1dOutputParams crc_dispPostCropLuma_out;
  CRCv10Striping1dOutputParams crc_dispPostCropChroma_out;
  CRCv10Striping1dOutputParams crc_videoPostCropLuma_out;
  CRCv10Striping1dOutputParams crc_videoPostCropChroma_out;
  CRCv10Striping1dOutputParams crc_preRollOffCrop_out; // chipID == SPECTRA_545

  ChromaUpv201dStripingOutputParams chromaup_out;
  LTMV13StripeDCParams dc_out;
  LTMV13StripeIPParams_1D ip_out;
  MNScaleDownInStruct_V20_1D chromads2_out;
  Upscalev20Striping1dOutputParams us_y_out;
  Upscalev20Striping1dOutputParams us_c_out;
  MNScaleDownInStruct_V20_1D mnds_disp_y_out;
  MNScaleDownInStruct_V20_1D mnds_disp_c_out;
} OpeStripingModule1dOutputStorage;

////////////////////////////////////////////////////////////////////////////////
// OPE Striping Library API Output structs
typedef struct _OpeStripingLibraryOutputPerStripe
{
  //////////
  // Image Port Info (Horizontal Dimension)
  int16_t pixelInHorizontalRange[STRIPING_OPE_PIXEL_INPUT_COUNT][COORDINATE_COUNT];
  int16_t pixelOutHorizontalRange[STRIPING_OPE_PIXEL_OUTPUT_COUNT][COORDINATE_COUNT];

  //////////
  // Static Module 1D Config Data for Memory Management Purpose
  OpeStripingModule1dOutputStorage outputConfigStorage1d;

  WriteEngineStripeParam rsWriteEngineStripeParam;
  WriteEngineStripeParam ltmdcWriteEngineStripeParam;

  // stats output coordinates & stride
  // ltm dc coordinates (part of stats)
  //uint16_t statsOutHorizontalRange[STRIPING_OPE_STATS_OUTPUT_COUNT][COORDINATE_COUNT];
  //uint16_t statsOutHorizontalStride[STRIPING_OPE_STATS_OUTPUT_COUNT];

  //////////
  // Stripe Type (Horizontal Dimension)
  BOOL isLeftStripe;
  BOOL isRightStripe;

  //////////
  // Module Config
  CRCv10StripingOutputParams crc_preChromaUpCropLuma;
  CRCv10StripingOutputParams crc_preChromaUpCropChroma;
  CRCv10StripingOutputParams crc_chromaDownscalerCropLuma;
  CRCv10StripingOutputParams crc_chromaDownscalerCropChroma;
  CRCv10StripingOutputParams crc_preUpscalarCropLuma;
  CRCv10StripingOutputParams crc_preUpscalarCropChroma;
  CRCv10StripingOutputParams crc_dispPreMndsCropLuma;
  CRCv10StripingOutputParams crc_dispPreMndsCropChroma;
  CRCv10StripingOutputParams crc_dispPostCropLuma;
  CRCv10StripingOutputParams crc_dispPostCropChroma;
  CRCv10StripingOutputParams crc_videoPostCropLuma;
  CRCv10StripingOutputParams crc_videoPostCropChroma;
  CRCv10StripingOutputParams crc_preRollOffCrop; // chipID == SPECTRA_545


  ChromaUpv20StripingOutputParams                chroma_up;
  ABFBPCOutputParams                            abfbpc;
  LTMv13StripingOutputParams                    ltm;
  MNDSv20StripingOutputParams                    chromads2;
  WNROutputParams                                wnr_y;
  WNROutputParams                                wnr_c;
  ASFv30StripingOutputParams                    asf;
  Upscalev20StripingOutputParams                upscale_y;
  Upscalev20StripingOutputParams                upscale_c;
  MNDSv20StripingOutputParams                    mnds_disp_y;
  MNDSv20StripingOutputParams                    mnds_disp_c;
  iHistv12OutputParam                            ihist;
  RSOutputParams                                rs;
  RollOffOutputParameters                        rollOff; // chipID == SPECTRA_545


  //////////
  // Miscellaneous
  uint32_t                          qos_ope_counter;
} OpeStripingLibraryOutputPerStripe;

typedef struct _OpeStripingLibraryOutputPerFrame
{
  //////////
  // Image Port Info (Vertical Dimension)
  int16_t pixelInVerticalRange[STRIPING_OPE_PIXEL_INPUT_COUNT][COORDINATE_COUNT];
  int16_t pixelOutVerticalRange[STRIPING_OPE_PIXEL_OUTPUT_COUNT][COORDINATE_COUNT];

  //////////
  // Static Module 1D Config Data for Memory Management Purpose
  OpeStripingModule1dOutputStorage outputConfigStorage1d;

  WriteEnginePassParam rsWriteEngineFrameParam;
  WriteEnginePassParam ltmdcWriteEngineFrameParam;

  // No need for stripe type in vertical dimension

  //////////
  // Per-Stripe Info
  uint16_t   numStripes;
  ListHandle hStripeList;
} OpeStripingLibraryOutputPerFrame;

////////////////////////////////////////////////////////////////////////////////
// OPE Striping Library API Main Striping function
uint32_t OpeStriping(
  const OpeStripingLibraryInput    *in,
  OpeStripingLibraryOutputPerFrame *out
  );

static void handle_ope_striping_input_info(FILE* fp, OpeStripingLibraryInput * in);
int32_t dbg_scanOpeInput(OpeStripingLibraryInput * pStripingInput, char* fileName);

//#pragma pack(pop)

#ifdef __cplusplus
}
#endif

#endif /* _STRIPEOPE_H_ */
