////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2019, 2024 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @file  camxifemnds16titan17x.h
/// @brief IFE MNDS16 register setting for Titan17x
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef CAMXIFEMNDS16TITAN17X_H
#define CAMXIFEMNDS16TITAN17X_H

#include "camxdefs.h"
#include "camxisphwsetting.h"
#include "camxispiqmodule.h"

CAMX_NAMESPACE_BEGIN

static const UINT32 MNDS16InterpolationShift = 14;     ///< Interpolation shift value
static const UINT32 MNDS16ScalingLimit       = 128;    ///< Downscaling limit of MNDS 16 version
static const UINT32 MNDS16MaxScaleFactor     = 64;     ///< Max downscaling factor considering chroma needs to be
                                                       /// downscaled twice as much as luma channel

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief IFE MNDS16 register setting for Titan17x
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
class IFEMNDS16Titan17x final : public ISPHWSetting
{
public:
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// CreateCmdList
    ///
    /// @brief  Generate the Command List
    ///
    /// @param  pInputData       Pointer to the Inputdata
    /// @param  pDMIBufferOffset Pointer for DMI Buffer
    ///
    /// @return CamxResultSuccess if successful.
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual CamxResult CreateCmdList(
        VOID*   pInputData,
        UINT32* pDMIBufferOffset);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// PackIQRegisterSetting
    ///
    /// @brief  Calculate register settings based on common library result
    ///
    /// @param  pInput       Pointer to the Input data to the module for calculation
    /// @param  pOutput      Pointer to the Output data to the module for DMI buffer
    ///
    /// @return Return CamxResult.
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual CamxResult PackIQRegisterSetting(
        VOID* pInput,
        VOID* pOutput);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// ~IFEMNDS16Titan17x
    ///
    /// @brief  Constructor
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual ~IFEMNDS16Titan17x();

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// IFEMNDS16Titan17x
    ///
    /// @brief  Constructor
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    IFEMNDS16Titan17x();

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// DumpRegConfig
    ///
    /// @brief  Print register configuration of Crop module for debug
    ///
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    VOID DumpRegConfig();

private:
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// ConfigureFDLumaRegisters
    ///
    /// @brief  Configure scaler FD Luma output path registers
    ///
    /// @param  horizontalInterpolationResolution horizontal interpolation resolution
    /// @param  verticalInterpolationResolution   vertical interpolation resolution
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    VOID ConfigureFDLumaRegisters(
        UINT32 horizontalInterpolationResolution,
        UINT32 verticalInterpolationResolution);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// ConfigureFullLumaRegisters
    ///
    /// @brief  Configure scaler Full Luma output path registers
    ///
    /// @param  horizontalInterpolationResolution horizontal interpolation resolution
    /// @param  verticalInterpolationResolution   vertical interpolation resolution
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    VOID ConfigureFullLumaRegisters(
        UINT32 horizontalInterpolationResolution,
        UINT32 verticalInterpolationResolution);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// ConfigureDisplayLumaRegisters
    ///
    /// @brief  Configure scaler Display Luma output path registers
    ///
    /// @param  horizontalInterpolationResolution horizontal interpolation resolution
    /// @param  verticalInterpolationResolution   vertical interpolation resolution
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    VOID ConfigureDisplayLumaRegisters(
        UINT32 horizontalInterpolationResolution,
        UINT32 verticalInterpolationResolution);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// ConfigureFDChromaRegisters
    ///
    /// @brief  Configure scaler FD Chroma output path registers
    ///
    /// @param  horizontalInterpolationResolution horizontal interpolation resolution
    /// @param  verticalInterpolationResolution   vertical interpolation resolution
    /// @param  horizontalSubSampleFactor         horizontal subsampling factor
    /// @param  verticalSubsampleFactor           vertical subsampling factor
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    VOID ConfigureFDChromaRegisters(
       UINT32 horizontalInterpolationResolution,
       UINT32 verticalInterpolationResolution,
       FLOAT  horizontalSubSampleFactor,
       FLOAT  verticalSubsampleFactor);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// ConfigureFullChromaRegisters
    ///
    /// @brief  Configure scaler Full Chroma output path registers
    ///
    /// @param  horizontalInterpolationResolution horizontal interpolation resolution
    /// @param  verticalInterpolationResolution   vertical interpolation resolution
    /// @param  horizontalSubSampleFactor         horizontal subsampling factor
    /// @param  verticalSubsampleFactor           vertical subsampling factor
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    VOID ConfigureFullChromaRegisters(
        UINT32 horizontalInterpolationResolution,
        UINT32 verticalInterpolationResolution,
        FLOAT  horizontalSubSampleFactor,
        FLOAT  verticalSubsampleFactor);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// ConfigureDisplayChromaRegisters
    ///
    /// @brief  Configure scaler Display Chroma output path registers
    ///
    /// @param  horizontalInterpolationResolution horizontal interpolation resolution
    /// @param  verticalInterpolationResolution   vertical interpolation resolution
    /// @param  horizontalSubSampleFactor         horizontal subsampling factor
    /// @param  verticalSubsampleFactor           vertical subsampling factor
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    VOID ConfigureDisplayChromaRegisters(
        UINT32 horizontalInterpolationResolution,
        UINT32 verticalInterpolationResolution,
        FLOAT  horizontalSubSampleFactor,
        FLOAT  verticalSubsampleFactor);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// CalculateInterpolationResolution
    ///
    /// @brief  Calculate the interpolation resolution for scaling
    ///
    /// @param  scaleFactorHorizontal              horizontal scale factor
    /// @param  scaleFactorVertical                vertical scale factor
    /// @param  pHorizontalInterpolationResolution Pointer to horizontal interpolation resolution
    /// @param  pVerticalInterpolationResolution   Pointer to vertical interpolation resolution
    ///
    /// @return CamxResult Invalid input Error code for invalid scaling or format, else success
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    CamxResult CalculateInterpolationResolution(
        UINT32  scaleFactorHorizontal,
        UINT32  scaleFactorVertical,
        UINT32* pHorizontalInterpolationResolution,
        UINT32* pVerticalInterpolationResolution);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetChromaSubsampleFactor
    ///
    /// @brief  Get the subsample factor based on the pixel format
    ///
    /// @param  pHorizontalSubSampleFactor Pointer to horizontal chroma subsample factor
    /// @param  pVerticalSubsampleFactor   Pointer to Vertical chroma subsample factor
    ///
    /// @return CamxResult success if the format is handled
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    CamxResult GetChromaSubsampleFactor(
        FLOAT* pHorizontalSubSampleFactor,
        FLOAT* pVerticalSubsampleFactor);

    VOID*              m_pRegCmd;       ///< Register List of this Module
    MNDSState*         m_pState;        ///< State
    Format             m_pixelFormat;   ///< Output pixel format
    UINT32             m_output;        ///< IPE piepline output
    ISPInputData*      m_pInputData;    ///< Pointer to current input data

    IFEMNDS16Titan17x(const IFEMNDS16Titan17x&)            = delete; ///< Disallow the copy constructor
    IFEMNDS16Titan17x& operator=(const IFEMNDS16Titan17x&) = delete; ///< Disallow assignment operator
};

CAMX_NAMESPACE_END

#endif // CAMXIFEMNDS16TITAN17X_H
