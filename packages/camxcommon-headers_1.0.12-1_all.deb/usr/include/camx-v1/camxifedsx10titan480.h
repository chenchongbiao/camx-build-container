////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2019, 2024 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @file  camxifedsx10titan480.h
/// @brief IFE DSX10 register setting for Titan480
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef CAMXIFEDSX10TITAN480_H
#define CAMXIFEDSX10TITAN480_H


#include "camxdefs.h"
#include "camxisphwsetting.h"
#include "camxispiqmodule.h"

CAMX_NAMESPACE_BEGIN

static const UINT32 DSX_LUMA_KERNAL_WEIGHTS_HORIZ   = 96;
static const UINT32 DSX_LUMA_KERNAL_WEIGHTS_VERT    = 96;
static const UINT32 DSX_CHROMA_KERNAL_WEIGHTS_HORIZ = 48;
static const UINT32 DSX_CHROMA_KERNAL_WEIGHTS_VERT  = 48;

static const UINT32 IFEDSX10LumaHorDMISize   = DSX_LUMA_KERNAL_WEIGHTS_HORIZ * sizeof(UINT64);
static const UINT32 IFEDSX10LumaVerDMISize   = DSX_LUMA_KERNAL_WEIGHTS_VERT * sizeof(UINT64);
static const UINT32 IFEDSX10ChromaHorDMISize = DSX_CHROMA_KERNAL_WEIGHTS_HORIZ * sizeof(UINT64);
static const UINT32 IFEDSX10ChromaVerDMISize = DSX_CHROMA_KERNAL_WEIGHTS_VERT * sizeof(UINT64);


static const UINT32 IFEDSX10LumaHorizDword  =
                    (IFEDSX10LumaHorDMISize) / sizeof(UINT32);
static const UINT32 IFEDSX10LumaVertDWord =
                    (IFEDSX10LumaVerDMISize) / sizeof(UINT32);


static const UINT32 IFEDSX10ChromaHorizDword =
                    (IFEDSX10ChromaHorDMISize) / sizeof(UINT32);
static const UINT32 IFEDSX10ChromaVertDWord =
                    (IFEDSX10ChromaVerDMISize) / sizeof(UINT32);

static const UINT32 IFEDSX10DMITotalDWord = IFEDSX10LumaHorizDword +
                                            IFEDSX10LumaVertDWord +
                                            IFEDSX10ChromaHorizDword +
                                            IFEDSX10ChromaVertDWord;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief IFE DS411 register setting for Titan480
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
class IFEDSX10Titan480 final : public ISPHWSetting
{
public:
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// CreateCmdList
    ///
    /// @brief  Generate the Command List
    ///
    /// @param  pInputData       Pointer to the Inputdata
    /// @param  pDMIBufferOffset Pointer for DMI Buffer
    ///
    /// @return CamxResultSuccess if successful.
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual CamxResult CreateCmdList(
        VOID*   pInputData,
        UINT32* pDMIBufferOffset);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// PackIQRegisterSetting
    ///
    /// @brief  Calculate register settings based on CAMX Input
    ///
    /// @param  pInput       Pointer to the Input data to the module for calculation
    /// @param  pOutput      Pointer to the Output data to the module for DMI buffer
    ///
    /// @return Return CamxResult.
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual CamxResult PackIQRegisterSetting(
        VOID* pInput,
        VOID* pOutput);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// ~IFEDSX10Titan480
    ///
    /// @brief  Constructor
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual ~IFEDSX10Titan480();

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// IFEDSX10Titan480
    ///
    /// @brief  Constructor
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    IFEDSX10Titan480();

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// DumpRegConfig
    ///
    /// @brief  Print register configuration of DSX module for debug
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    VOID DumpRegConfig();

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// DumpDMIData
    ///
    /// @brief  Print DMI configuration of DSX module for debug
    ///
    /// @param  pData  Pointer to the Output Data
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    VOID DumpDMIData(
        VOID* pData);

private:
    VOID*             m_pRegCmd;    ///< Register List of this Module
    UINT32            m_lutBank;    ///< Lut Bank Switch

    IFEDSX10Titan480(const IFEDSX10Titan480&)            = delete; ///< Disallow the copy constructor
    IFEDSX10Titan480& operator=(const IFEDSX10Titan480&) = delete; ///< Disallow assignment operator
};

CAMX_NAMESPACE_END

#endif // CAMXIFEDSX10TITAN480_H
