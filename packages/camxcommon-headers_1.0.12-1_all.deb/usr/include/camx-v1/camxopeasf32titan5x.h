////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2019, 2024 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @file  camxopeasf32titan5x.h
/// @brief OPE ASF32 register setting for Titan5x
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef CAMXOPEASF32TITAN5X_H
#define CAMXOPEASF32TITAN5X_H

#include "camxtitan5xdefs.h"
#include "camxisphwsetting.h"
#include "camxcmdbuffer.h"
#include "camxispiqmodule.h"
#include "camxiqinterface.h"

CAMX_NAMESPACE_BEGIN

static const UINT  OPE_PP_CLC_ASF_DMI_LUT_CFG_LUT_SEL_NO_LUT_SELECTED  = 0x0;
static const UINT  OPE_PP_CLC_ASF_DMI_LUT_CFG_LUT_SEL_LAYER1_LUT  = 0x1;
static const UINT  OPE_PP_CLC_ASF_DMI_LUT_CFG_LUT_SEL_LAYER1_WT_LUT  = 0x2;

/// @brief: Enumerator to map optimized Look Up Tables indices with DMI LUT_SEL in ASF module HPG/SWI
enum OPEASFDMILUTConfigLUTSelIndex
{
    OPEASFNoLUTSelected        = OPE_PP_CLC_ASF_DMI_LUT_CFG_LUT_SEL_NO_LUT_SELECTED,    ///< No LUT
    OPEASFLayer1LUT            = OPE_PP_CLC_ASF_DMI_LUT_CFG_LUT_SEL_LAYER1_LUT,         ///< L1 LUTs
    OPEASFLayer1WeightLUT      = OPE_PP_CLC_ASF_DMI_LUT_CFG_LUT_SEL_LAYER1_WT_LUT,      ///< L1 LUT-Weight
    OPEASFMaxLUT               = 0x3,    ///< MAX LUT
};

/// @brief: This structure has information of number of entries for each LUT.
static const UINT OPEASFLUTNumEntries[OPEASFMaxLUT] =
{
    0,          ///< No LUT

    256,        ///< Layer1LUT consists of 6 internal LUTs each of size 256:
                ///< CONTRAST_NEGTIVE_LUT
                ///< CONTRAST_POSITIVE_LUT
                ///< LAYER_1_ACTIVITY_NORMALIZATION_LUT
                ///< LAYER_1_SOFT_THRESHOLD_LUT
                ///< LAYER_1_GAIN_NEGATIVE_LUT
                ///< LAYER_1_GAIN_POSITIVE_LUT

    256,        ///< Layer1WeightLUT consists of 2 internal LUTs each of size 256:
                ///< LAYER_1_SOFT_THRESHOLD_WEIGHT_LUT
                ///< LAYER_1_GAIN_WEIGHT_LUT
};

static const UINT OPEMaxASF30LUTNumEntries     = (OPEASFLUTNumEntries[OPEASFLayer1LUT] * 2) +
                                                  OPEASFLUTNumEntries[OPEASFLayer1WeightLUT];

// For OPEASFLayer1LUT, 6 internal LUTs(each of 8 bits and 256 entries) are combined, however the DMI buffer is 32 bit only.
// So, (OPEASFLUTNumEntries[OPEASFLayer1LUT] * sizeof(UINT32)) is multiplied by 2 where first 48 bits(32 + 16) bits are valid
// and next 16 bits are invalid.
static const UINT32 OPEASFLUTBufferSize        = 256 * OPERegisterWidthInBytes * 2 +
                                                 256 * OPERegisterWidthInBytes;
static const UINT32 OPEASFLUTBufferSizeInDWord = OPEMaxASF30LUTNumEntries;

static const UINT32 OPEASFDMILUTInit[] =
{
    // @todo (CAMX-4909) Add values here when provided by System team.
};


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief OPE ASF32 register setting for Titan5x
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
class OPEASF32Titan5x final : public ISPHWSetting
{
public:
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// CreateFrameCmdList
    ///
    /// @brief  Generate the Frame Command List
    ///
    /// @param  pInputData          Pointer to the Inputdata
    /// @param  pASFHwSettingParams Pointer for DMI Buffer
    ///
    /// @return CamxResultSuccess if successful.
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    CamxResult CreateFrameCmdList(
        VOID*   pInputData,
        UINT32* pASFHwSettingParams);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// CreateStripeCmdList
    ///
    /// @brief  Generate the Stripe Command List
    ///
    /// @param  pInputData       Pointer to the Inputdata
    ///
    /// @return CamxResultSuccess if successful.
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    CamxResult CreateStripeCmdList(
        VOID*   pInputData);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// CreateCmdList
    ///
    /// @brief  Generate the Command List
    ///
    /// @param  pInputData          Pointer to the Inputdata
    /// @param  pASFHwSettingParams Pointer for DMI Buffer
    ///
    /// @return CamxResultSuccess if successful.
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual CamxResult CreateCmdList(
        VOID*   pInputData,
        UINT32* pASFHwSettingParams);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// CreateSubCmdList
    ///
    /// @brief  Generate the Sub Command List
    ///
    /// @param  pInputData       Pointer to the Inputdata
    /// @param  pDMIBufferOffset Pointer for DMI Buffer
    /// @param  pModuleEnable    Pointer to the enable data
    ///
    /// @return CamxResultSuccess if successful.
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual CamxResult CreateSubCmdList(
        VOID*   pInputData,
        UINT32* pDMIBufferOffset,
        VOID*   pModuleEnable);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// UpdateTuningMetadata
    ///
    /// @brief  Update Tuning Metadata
    ///
    /// @param  pInputData      Pointer to the InputData
    ///
    /// @return CamxResultSuccess if successful.
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual CamxResult UpdateTuningMetadata(
        VOID*  pInputData);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// PackFrameIQRegisterSetting
    ///
    /// @brief  Calculate register Frame level settings based on common library result
    ///
    /// @param  pInput       Pointer to the Input data to the IQ module for calculation
    /// @param  pOutputVal   Pointer to the Output data to the IQ module for DMI calculation
    ///
    /// @return Return CamxResult.
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    CamxResult PackFrameIQRegisterSetting(
        VOID*  pInput,
        VOID*  pOutputVal);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// PackStripeIQRegisterSetting
    ///
    /// @brief  Calculate Stripe Level register settings based on common library result
    ///
    /// @param  pInput         Pointer to the Input data to the module for calculation
    ///
    /// @return Return CamxResult.
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    CamxResult PackStripeIQRegisterSetting(
        VOID* pInput);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// PackIQRegisterSetting
    ///
    /// @brief  Calculate register settings based on common library result
    ///
    /// @param  pInput       Pointer to the Input data to the IQ module for calculation
    /// @param  pOutputVal   Pointer to the Output data to the IQ module for DMI calculation
    ///
    /// @return Return CamxResult.
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual CamxResult PackIQRegisterSetting(
        VOID*  pInput,
        VOID*  pOutputVal);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// DumpRegConfig
    ///
    /// @brief  Print register configuration of Crop module for debug
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual VOID DumpRegConfig();

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// DumpDMILUTs
    ///
    /// @brief  Print DMI LUTs
    ///
    /// @param  pDMIDataPtr  Pointer to DMI buffer
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    VOID DumpDMILUTs(
        UINT32* pDMIDataPtr);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// GetRegSize
    ///
    /// @brief  Returns register size in bytes
    ///
    ///
    /// @return Number of bytes of register structure.
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual UINT GetRegSize();

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// FillDMITable
    ///
    /// @brief  FillDMITable ASF32 based on common library output
    ///
    /// @param  pData   Pointer to the Common Library Calculation Result
    /// @param  pOutput Pointer to the ASF32 output data (register set, DMI data pointer, etc.)
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    VOID FillDMITable(
        ASF32UnpackedField*     pData,
        ASF32OutputData*        pOutput);


    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// OPEASF32Titan5x
    ///
    /// @brief  Constructor
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    OPEASF32Titan5x();

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// ~OPEASF32Titan5x
    ///
    /// @brief  Destructor
    ///
    /// @return None
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    virtual ~OPEASF32Titan5x();

private:
    VOID*         m_pRegCmd;                                       ///< ASF32 Register list
    CmdBuffer*    m_pLUTDMICmdBuffer;                              ///< Shadow copy of module LUT DMI Command buffer
    UINT32*       m_pLUTs;                                         ///< Holder of LUTs

    OPEASF32Titan5x(const OPEASF32Titan5x&)            = delete;   ///< Disallow the copy constructor
    OPEASF32Titan5x& operator=(const OPEASF32Titan5x&) = delete; ///< Disallow assignment operator
};

CAMX_NAMESPACE_END

#endif // CAMXOPEASF32TITAN5X_H
