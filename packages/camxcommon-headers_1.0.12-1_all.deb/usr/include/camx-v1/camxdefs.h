////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2016-2020 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @file camxdefs.h
///
/// @brief CamX common definitions
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef CAMXDEFS_H
#define CAMXDEFS_H

#include "camxtypes.h"

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Constants
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
const UINT64 NanoSecondsPerSecond = 1000000000ULL;

const UINT64 MicroSecondsPerSecond = 1000000ULL;

const UINT64 MilliSecondsPerSecond = 1000ULL;

const UINT64 NanoSecondsPerMicroSecond = 1000ULL;

const UINT64 MicroSecondsPerMilliSecond = 1000ULL;

const UINT64 NanoSecondsPerMilliSecond = 1000000ULL;

const UINT TimeoutMilliseconds = 1000;

/// @brief Define invalid requestId
static const UINT CamxInvalidRequestId = 0;

/// @brief Define invalid stream Id
static const UINT CamxInvalidStreamId = 0xBEEFCAFE;

/// @brief Used to detect region/buffer overruns
static const UINT CamxCanary = 0x43216789;

/// @brief Maximum device index count
static const UINT CamxMaxDeviceIndex = 16;

/// @brief Maximum number of different node types
const UINT MaxNodeType = 16;

/// @brief Max pipelines per session
static const UINT32 MaxPipelinesPerSession  = 16;

/// @brief 64 character string length
static const UINT32 MaxStringLength64 = 64;

/// @brief 128 character string length
static const UINT32 MaxStringLength128 = 128;

/// @brief 256 character string length
static const UINT32 MaxStringLength256 = 256;

/// @brief 256 character string length
static const UINT32 MaxStringLength4092 = 4092;

/// @brief Invalid camera id
static const UINT32 InvalidCameraId = 0xFFFFFFFF;

/// @brief HAL buffer manager mode disabled
static const UINT32 HALBufferMgrModeDisabled            = 0;

/// @brief HAL buffer manager mode backward compatible
static const UINT32 HALbufferMgrModeBackwardCompatible  = 1;

/// @brief HAL buffer manager mode cached
static const UINT32 HALBufferMgrModeCached              = 2;

const UINT ChiExternalNode              = 255;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Macros
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/// @brief Helper for CamX namespace
// NOWHINE CP011: We're defining the macro
#define CAMX_NAMESPACE_BEGIN namespace CamX {

/// @brief Helper for CamX namespace
#define CAMX_NAMESPACE_END }

/// @brief A hint to the compiler that inlining is desired.
#define CAMX_INLINE __inline

/// @brief Ensures a function is inlined where supported. Use with care.
#if defined(__GNUC__)
#define CAMX_INLINE_FORCE __attribute__((always_inline))
#else
#define CAMX_INLINE_FORCE
#endif // __GNUC__

/// @brief Data structures that are directly accessed by HW must be packed to have the expected layout expected. Use a
///        platform-independent macro for this purpose.
#if defined(__GNUC__)
#define CAMX_PACKED                  __attribute__((__packed__))
#define CAMX_BEGIN_PACKED
#define CAMX_PACKED_ALIGN_N(N)       __attribute__((packed, aligned(N)))
#define CAMX_BEGIN_PACKED_ALIGN_N(N)
#define CAMX_END_PACKED
#else
#define CAMX_PACKED
#define CAMX_BEGIN_PACKED   \
    __pragma(pack(push, 1))
#define CAMX_BEGIN_PACKED_ALIGN_N(N)    \
    __pragma(pack(push, N))
#define CAMX_END_PACKED     \
    __pragma(pack(pop))
#define CAMX_PACKED_ALIGN_N(N)
#endif // defined(__GNUC__)

#if defined(__GNUC__)
#define CAMX_VISIBILITY_PUBLIC __attribute__ ((visibility ("default")))
#define CAMX_VISIBILITY_LOCAL  __attribute__ ((visibility ("hidden")))
#else
#define CAMX_VISIBILITY_PUBLIC __declspec(dllexport)
#define CAMX_VISIBILITY_LOCAL
#endif // defined(__GNUC__)

#if defined(__clang__) && defined(__has_cpp_attribute)
#   if __has_cpp_attribute(clang::fallthrough)
#       define CAMX_FALLTHROUGH_INTENDED [[clang::fallthrough]]
#   endif // __has_cpp_attribute(clang::fallthrough)
#else
#   if defined(__GNUC__) && defined(__has_cpp_attribute)
#       if __has_cpp_attribute(gnu::fallthrough)
#           define CAMX_FALLTHROUGH_INTENDED [[gnu::fallthrough]]
#       endif // __has_cpp_attribute(gnu::fallthrough)
#   endif // defined(__GNUC__) && defined(__has_cpp_attribute)
#endif // defined(__clang__) && defined(__has_cpp_attribute)

#if !defined(CAMX_FALLTHROUGH_INTENDED)
#define CAMX_FALLTHROUGH_INTENDED
#endif // !defined(CAMX_FALLTHROUGH_INTENDED)

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// CAMX_ARRAY_SIZE
///
/// @brief  Calculates the number of elements in an array
///
/// @param  arr The array to count the elements of
///
/// @return The number of elements in the array
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#define CAMX_ARRAY_SIZE(arr) (sizeof((arr)) / sizeof((arr)[0]))

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// CAMX_ARRAY_COLS
///
/// @brief  Calculates the number of columns in a 2D array
///
/// @param  arr The 2D array to count the number of columns of
///
/// @return The number of columns in the 2D array
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#define CAMX_ARRAY_COLS(arr) (sizeof((arr)[0]) / sizeof((arr)[0][0]))

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// CAMX_ARRAY_ROWS
///
/// @brief  Calculates the number of rows in a 2D array
///
/// @param  arr The 2D array to count the number of rows of
///
/// @return The number of rows in the 2D array
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#define CAMX_ARRAY_ROWS(arr) CAMX_ARRAY_SIZE(arr)

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// CAMX_STRINGIZE
///
/// @brief Stringize helper
///
/// @param arg Argument to stringize
///
/// @return Stringized arg
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#define CAMX_STRINGIZE(arg) #arg

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// CAMX_STRINGIZE_MACRO
///
/// @brief Macro stringize helper
///
/// @param arg Argument to macro expand and stringize
///
/// @return Stringized expansion of arg
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#define CAMX_STRINGIZE_MACRO(arg) CAMX_STRINGIZE(arg)

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// CAMX_UNREFERENCED_PARAM
///
/// @brief Unreferenced macro helper
///
/// @param param The unreferenced parameter.
///
/// @return void
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#define CAMX_UNREFERENCED_PARAM(param) (void)param

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// CAMX_ALIGN_TO
///
/// @brief Align the value to alignment
///
/// @param value        Value to be aligned to
/// @param alignment    alignment. Must be a multiple of two
///
/// @return Aligned value
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#define CAMX_ALIGN_TO(value, alignment) (((value) + ((alignment) - 1)) & ~((alignment) - 1))

#endif // CAMXDEFS_H
