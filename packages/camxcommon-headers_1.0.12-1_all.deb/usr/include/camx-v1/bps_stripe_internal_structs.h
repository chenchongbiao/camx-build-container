//-------------------------------------------------------------------------
// Copyright (c) 2015-2020 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
//------------------------------------------------------------------------

#ifndef BPS_STRIPE_INTERNAL_STRUCTS_H_
#define BPS_STRIPE_INTERNAL_STRUCTS_H_

// TODO : document this file: copyright, functions, etc.

#include "stripeBPS.h"
#include "stripedebug.h"


#ifdef __cplusplus
extern "C"
{
#endif
typedef struct _PassInputBPS1D
{
    // buffer sizes
    int16_t lineBufferSize;
    int16_t full_ds4_max_dim;

    // input
    int16_t inputFormat;
    int16_t frameDim;       //frame dimension w/o zoom
    int16_t inputDim;
    int16_t frame_fetch_start;
    int16_t rolloff_roi_start;
    int16_t output_roi_start;     //the output roi: coordinate defined in the input full-frame domain
    int16_t output_roi_end;
    int16_t aligned_roi_start;
    int16_t aligned_roi_end;
    BOOL aligned_roi_enable;

    // output
    int16_t ds4ds16outFormat;
    int16_t DS4DS16OutDim;

    int16_t fullDS4OutFormat;
    int16_t fullDS4OutDim;

    int16_t regOutFormat;
    int16_t regOutDim;

    uint32_t    mnds_overlap_min_phase_step; // MNDSv23 overlap feature control

    // these two modules impacts striping
    int16_t moduleEnablePedestal;      // this is enable flag
    int16_t moduleEnableLensRollOff;   // enable flag, both roll off and pedestal

    // kernels
    int16_t kernelBPCPDPC;
    int16_t kernelHDRRecon;            // depend on the option, set the kernel size accordingly
    int16_t kernelHDRMAC;
    int16_t kernelGIC;
    int16_t kernelABF;
    int16_t kernelLCAC;
    int16_t kernelWB;
    int16_t kernelBayerGTM;
    int16_t kernelBayerLTM;
    int16_t kernelDemosaic;
    int16_t kernelHNR;
    int16_t kernel8TapDownscale;       //9 (8-tap).
    int16_t kernelBayerHistv17;
    int16_t kernelSimplePDPC;
    int16_t kernelSimpleBPC;

    int16_t chromaDownRoundingOption_v;     //: rounding option
    int16_t regOutDownChromaRoundingOption_v;       //: rounding option
    int16_t chromaDownRoundingOption_h;     //: rounding option
    int16_t regOutDownChromaRoundingOption_h;       //: rounding option: 1-D striping affects both vertical and horizontal rounding options
    int16_t chroma_dn_ratio;
    int16_t isInputBayer;
    int16_t isInputYUV422;
    int16_t isInputYUV420;
    int16_t ds16OutputSelect;           //0: YUV, 1: Bayer, 2: RGB
    BOOL hdr_zrec_first_rb_exp;         //: shift of zigzag pattern when the striping boundary is not aligned with it
    Pedestalv13InputParams pedestalParam;
    RollOffv34InputParameters rollOffParam;
    PDPCv20v30stripingInputParams pdpcParam;
    BayerHistInputParams bayerHistParam;
    BayerGridInputParam  bayerGridParam;
    LCACv10stripingInputParams lcacParam;
    LTMv13StripingInputParams bayerLtmParam;
    CADLv10StripingInputParams cadlParam;
    BayerHistv17InputParams bayerHistv17Param;
    simplePdpcv15InputParams simplePdpcParam;
}
PassInputBPS1D;

typedef struct _BPSPassInput
{
    PassInputBPS1D horizontalPassIn;
    PassInputBPS1D verticalPassIn;
    int32_t chip;
}
BPSPassInput;

typedef struct
{
    // amount striped
    int16_t cummulativeDS4DS16Out;
    int16_t cummulativeFullDS4Out;
    int16_t cummulativeRegOutLuma;

    // output BPSStripeOutput max dimentions
    int16_t DS4DS16OutMaxDim;
    int16_t fullDS4OutMaxDim;
    int16_t regOutMaxDim;

    // scale ratios - q_factor format
    int32_t DS4DS16Ratio;
    int32_t fullDS4Ratio;
    int32_t regOutRatio;
    //int32_t regOutRatio_c;

    // flags
    BOOL striping;      // enable striping for this dimention
    BOOL redo;          // first stripe needs to be redone
    BOOL reallocatedStripe;
    BOOL firstStripe;   // current stripe is first stripe
    BOOL statOnly;

    // format constraints
    int16_t inputConstraint;
    int16_t DS4DS16OutConstraint;
    int16_t fullDS4OutConstraint;
    int16_t regOutConstraint;
    int16_t narrowStripeThreshold_fullDS4;
    int16_t narrowStripeThreshold_DS4DS16;
    int16_t narrowStripeThreshold_reg;
    int16_t minUBWCOutputSize;
    int16_t bHistStartPosQueue[PIXEL_RANGE_MAX];          //0: current start position, 1: previous start position
    int16_t bHistEndPosQueue[PIXEL_RANGE_MAX];            //0: current start position, 1: previous start position
    int16_t lcacInputRange[PIXEL_RANGE_MAX];
    int16_t cadlInputRange[PIXEL_RANGE_MAX];
    uint16_t sPdpcBpcInputRange[PIXEL_RANGE_MAX];
    int32_t qosBPScounter_1d;
    MNScaleDownInStruct_V20_1D regOutDownscalerFrame;
    MNScaleDownInStruct_V20_1D regOutDownscalerFrame_chroma;
    MNScaleDownInStruct_V20_1D chromaDownscalerFrame;

    crop_1D preRollOffCrop;
    crop_1D CDSCropLuma;
    crop_1D CDSCropChroma;
    crop_1D DS4DS16InCropLuma;
    crop_1D DS4DS16InCropChroma;
    crop_1D DS4DS16OutCropLuma;
    crop_1D DS4DS16OutCropChroma;
    crop_1D fullDS4InCropLuma;
    crop_1D fullDS4InCropChroma;
    crop_1D fullDS4OutCropLuma;
    crop_1D fullDS4OutCropChroma;
    crop_1D regInCrop;
    crop_1D regInCrop_chroma;
    crop_1D regOutCrop;
    crop_1D regOutCrop_chroma;
    int32_t GIC_PNR_b;
    int32_t ABF_b;
    int32_t HNR_RNR_b;
    int32_t HNR_face_offset;
    RollOffOutputParameters rolloffOut;
    PedestalOutputParameters pedestalOut;
    int32_t GIC_PNR_r_square_scale;
    int32_t GIC_PNR_r_square_shift;
    int32_t ABF_r_square_scale;
    int32_t ABF_r_square_shift;
    int32_t HNR_RNR_r_square_scale;
    int32_t HNR_RNR_r_square_shift;
    BOOL hdr_zrec_first_rb_exp;         //: shift of zigzag pattern when the striping boundary is not aligned with it
    PDPCv20v30stripingOutputParams pdpcParam;
    BayerGridOutputParam bayerGridParam;
}
PassVarBPS1D;

typedef struct
{
    // fetch coordinates
    int16_t fetchFirst;
    int16_t fetchLast;

    // write coordinates
    int16_t DS4DS16OutFirst;
    int16_t DS4DS16OutLast;
    int16_t fullDS4OutFirst;
    int16_t fullDS4OutLast;
    int16_t regOutFirst;
    int16_t regOutLast;
    int16_t DS16DS4OutFirst;
    int16_t DS16DS4OutLast;

    // flags
    BOOL edgeStripeLT;
    BOOL edgeStripeRB;

    BpsStripingModule1dOutputStorage module1d;
}
GenericBPS;

typedef struct
{
    crop_1D preRollOffCrop;
    crop_1D CDSCropLuma;
    crop_1D CDSCropChroma;
    crop_1D DS4DS16InCropLuma;
    crop_1D DS4DS16InCropChroma;
    crop_1D DS4DS16OutCropLuma;
    crop_1D DS4DS16OutCropChroma;
    crop_1D fullDS4InCropLuma;
    crop_1D fullDS4InCropChroma;
    crop_1D fullDS4OutCropLuma;
    crop_1D fullDS4OutCropChroma;
    crop_1D regInCrop;
    crop_1D regInCrop_chroma;
    crop_1D regOutCrop;
    crop_1D regOutCrop_chroma;
    int32_t GIC_PNR_b;
    int32_t ABF_b;
    int32_t HNR_RNR_b;
    int32_t HNR_face_offset;
    RollOffOutputParameters rolloffOutStripe;
    PedestalOutputParameters pedestalOutStripe;
}
Bps1dIntermediateModuleConfig;


//------------------------------------------------------------------------
//  configBPSPassOutput
//
//  @brief
//     Finds fetch parameters and sets stripe-dependent pipeline parameters
//      for each stripe
//
//  @params
//     pInput - input pass parameters
//     pOutput - output pass
//
//  @return
//     AEE_SUCCESS(0) if no error, otherwise
//     returns the appropriate AEE_xx error code
//------------------------------------------------------------------------
int32_t configBPSPassOutput(const BPSPassInput *pInput, BpsStripingLibraryOutputPerPass *pOutput,
                            userBPSArgs *pUserBPSArgs);


#ifdef __cplusplus
}
#endif
#endif // !BPS_STRIPE_INTERNAL_STRUCTS_H_
