//-------------------------------------------------------------------------
// Copyright (c) 2015-2017, 2019-2020 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
//------------------------------------------------------------------------

/*========================================================================
GLOBAL_TYPEDEF . H

*//** @file global_typedef.h
Global type & macro defintions


*//*====================================================================== */

/*========================================================================
Edit History

when       who     what, where, why
--------   ---     -------------------------------------------------------
12/01/07   ab     Initial revision

========================================================================== */

#ifndef __GLOBAL_TYPEDEF_H__
#define __GLOBAL_TYPEDEF_H__
#ifdef __cplusplus
extern "C" {
#endif


    /*------------------------------------------------------------------------
     *       Include Files
     * ----------------------------------------------------------------------- */
#include <string.h>
#include <stdio.h>
#include <stdint.h>

#if defined (_WIN32)

#include <assert.h>

#if !defined (VENUS_TEST_FRAMEWORK)
#define DIAG_USE_HFI
#else
#define DIAG_USE_SEMI_HOSTING
#endif

#endif

#define A_VENUS_BASE_ARM    0xE0000000
//#define VENUS_CMD_REG_LOG
//#define VELOCE_SINGLE_INPUT
//#define VELOCE_VPE_EN
 /*------------------------------------------------------------------------
 *       Definitions and Constants
 * ----------------------------------------------------------------------- */
#ifndef STRIPE_ABS
#define STRIPE_ABS(x)         ((x) >= 0 ? (x) : -(x))
#endif

#define CLIP1(x)       (!((x) & 0x100) ? (x) : (x) < 0 ? 0 : 255)
#define CLIP3(a, b, x) ((x) < (a) ? (a) : (x) > (b) ? (b) : (x))

#define CLAMP(X, Y) (X >= 0)? ((X <= Y)? X : Y) : 0

#define mmax(a, b)     ((a) > (b) ? (a) : (b))
#define mmin(a, b)     ((a) < (b) ? (a) : (b))
#ifndef NULL
#define NULL 0
#endif

#ifndef FALSE
#define FALSE 0
#endif  //FALSE

#ifndef TRUE
#define TRUE  1
#endif //TRUE

#ifndef FAIL
#define FAIL 0
#endif //FAIL

#ifndef SUCCESS
#define SUCCESS 1
#endif //SUCCESS

#define ALIGNMENT_8 8
#define ALIGNMENT_16 16
#define ALIGNMENT_32 32
#define ALIGNMENT_128 128
//#ifndef ASSERT
//#define ASSERT(x) assert(x)
//#endif

#ifndef STRIPE_MIN
        #define  STRIPE_MIN( x, y ) ( ((x) < (y)) ? (x) : (y) )
#endif

#ifndef STRIPE_MAX
        #define  STRIPE_MAX( x, y ) ( ((x) > (y)) ? (x) : (y) )
#endif

#ifndef LENGTH
        #define  LENGTH( start, end ) (end-start+1)
#endif

#ifndef CLZ
         #define CLZ(reg, val) { reg = 0; while( reg < 32 && ((val & (1 << (31 - reg))) == 0) ) reg ++;  }
#endif

#define ISPOWER2(x) (0 == ((x) & ((x)-1)))

#ifndef UINT32_MAX
//#define UINT32_MAX 0xFFFFFFFF
#endif

#ifndef SHRT_MAX
#define SHRT_MAX      32767         /* maximum (signed) short value */
#endif

/*------------------------------------------------------------------------
 *       Type Declarations
 * ----------------------------------------------------------------------- */
typedef void * (AllocatorFuncPtr) (int32_t size);
typedef void   (DeallocatorFuncPtr) (void *pMem);

/// Structure for holding memory allocator, deallocator information
typedef struct {
    AllocatorFuncPtr   *pfAlloc;        ///< Allocator func ptr
    void               *pAllocArg;      ///< Allocator func arg
    DeallocatorFuncPtr *pfDealloc;      ///< Deallocator func ptr
    void               *pDeallocArg;    ///< Deallocator func arg
} vHeap;

/*------------------------------------------------------------------------
 *       External Variables
 * ----------------------------------------------------------------------- */
/*------------------------------------------------------------------------
 *       Function Declarations
 * ----------------------------------------------------------------------- */
// Declaration of assert
#if !defined(_WIN32)
#undef assert  //disable ARM compiler defination

#define assert_loop(condition, ln, fn) \
do                                                                     \
{                                                                      \
    if (!condition)                                                    \
    {                                                                  \
        printf("assrt_loop line %d %s\n", ln, fn);                     \
        while(1) {};                                                   \
    }                                                                  \
} while(0);

#define assert(x) assert_loop((uint32_t)(x), __LINE__, __FILE__)
//incompatible redefinition of macro "assert" (declared at line 66 of "C:\Apps\ARMCT5.01\43\include\assert.h")
void sfr_init(void);

#endif

#ifdef __cplusplus
}
#endif
#endif // __GLOBAL_TYPEDEF_H__
