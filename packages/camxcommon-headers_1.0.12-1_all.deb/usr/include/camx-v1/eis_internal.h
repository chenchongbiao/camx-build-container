////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2021 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#pragma once

#include <stdint.h>
#include "is_interface.h"


#ifdef __cplusplus
extern "C" {
#endif

int32_t eis_internal_init(
    void** _context,
    const is_init_data_common* init_common,
    const is_init_data_sensor *init_sensors,
    uint32_t num_sensors);

int32_t eis_internal_destroy(void** _context);

int32_t eis_internal_process(void* eis3_handle, const is_input_t* eis3_input, is_output_t* is_output);

int32_t eis_internal_get_gyro_samples_time_interval(
    void* eis3_handle,
    const frame_times_t* frame_time_input,
    uint32_t active_sensor_idx,
    gyro_times_t* gyro_req_interval);

int32_t eis_internal_get_gyro_ois_samples_time_interval(
    void* eis3_handle,
    const frame_times_t* frame_time_input,
    uint32_t active_sensor_idx,
    gyro_times_t* gyro_req_interval,
    ois_times_t* ois_req_interval);

int32_t eis_internal_get_time_intervals(
    void* eis3_handle,
    const frame_times_t* frame_time_input,
    uint32_t active_sensor_idx,
    is_time_intervals* required_time_intervals);

int32_t eis_internal_get_stabilization_margin(
    void *eis3_handle,
    uint32_t active_sensor_idx,
    ImageDimensions* stabilizationMargins);

int32_t eis_internal_process_distortion_correction(
    void*                                       eis3_handle,
    const is_input_distortion_correction_t*     eis3_input,
    is_output_distortion_correction_t*          distortion_correction);

int32_t eis_internal_process_stabilize(
    void*                           eis3_handle,
    const is_input_stabilize_t*     eis3_input,
    is_output_stabilize_t*          is_output);

/** IS input data structure for eis_internal_utility_calc_alignment_matrix() */
typedef struct is_input_device_rotation_s
{
    eis_roi_windows     src_window_regions;     /**< Source Input and Output ROI's */
    uint64_t            src_mof_gyro_time;
    uint32_t            src_sensor_index;       /**< Source active sensor index */

    eis_roi_windows     dst_window_regions;     /**< Destination Input and Output ROI's */
    uint64_t            dst_mof_gyro_time;
    uint32_t            dst_sensor_index;       /**< Destination active sensor index */
} is_input_device_rotation_t;

int32_t eis_internal_utility_calc_alignment_matrix(
    void*                                   eis3_handle,
    const is_input_device_rotation_t*       inputs,
    NcLibWarpMatrices*                      alignment_matrix_out2in);


#ifdef __cplusplus
}
#endif

