//-------------------------------------------------------------------------
// Copyright (c) 2020 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
//------------------------------------------------------------------------

//------------------------------------------------------------------------
// @file  iqsettings_v4.h
// @brief BPS(Bayer Processing Segment) & IPE (Image Processing Engine) data types
//------------------------------------------------------------------------

//------------------------------------------------------------------------
// @Edit History
// when              who           what,where,why
// -----             ---           -------------
//
// 08/28/2020        mdoshi        Initial version
//------------------------------------------------------------------------
#ifndef _IQSETTINGS_V4_H_
#define _IQSETTINGS_V4_H_

#include "ipdefs.h"
#include "fwdefs.h"

#define BHIST_ROI_RGN_NUM    4

typedef enum
{
    STMP_AI_MOD_LTM = 0,
    STMP_AI_MOD_LTM_LCE = 1,
    STMP_AI_MOD_CCM = 2,
    STMP_AI_MOD_2DLUT = 3,

    STMP_AI_MOD_MAX,
} StmpAIModCfg;

typedef struct _LTM_MODULE_CFG_V2
{
    uint32_t EN;           /* 0:0  */
    uint32_t GAMMA_EN;     /* 8:8  */
    uint32_t RGAMMA_EN;    /* 9:9  */
    uint32_t LA_EN;        /* 12:12*/
    uint32_t NONLINEAR_IN; /* 20:20*/
    uint32_t TABLE_SEL;    /* 23:21*/
} LTM_MODULE_CFG_V2;

typedef struct _LtmParameters_v2
{
    LTM_MODULE_CFG_V2    moduleCfg;

    uint32_t             ltmImgProcessEn;

    uint32_t             ltmFaceControlEn;

    uint32_t             ltmEdgeAdaptiveMergeEn;

    uint32_t             dcMultipassMaskEn[PASS_NAME_MAX];
} LtmParameters_v2;

typedef struct SBLUR_MODULE_CFG
{
    uint32_t      EN;              /* 0:0 */
    uint32_t      MAP_BOOST_EN;    /* 1:1 */
    uint32_t      WEIGHT_BOOST_EN; /* 2:2 */
    uint32_t      MAP_LUT_EN;      /* 3:3 */
    uint32_t      SRI_EN;          /* 4:4 */
} SBLUR_MODULE_CFG;

typedef struct _SblurPassParameters
{
    SBLUR_MODULE_CFG    moduleCfg;
} SblurPassParameters;

typedef struct _SblurParameters //Sblur is a multi-pass CLC
{
    SblurPassParameters   parameters[PASS_NAME_MAX];
} SblurParameters;

typedef struct _COLOR_CORRECT_MODULE_CFG_V14
{
    uint32_t  EN; /* 0:0 */
    uint32_t  EN_1; /* 2:2 */
} COLOR_CORRECT_MODULE_CFG_V14;

typedef struct _ColorCorrectParameters_v14
{
    COLOR_CORRECT_MODULE_CFG_V14 moduleCfg;
} ColorCorrectParameters_v14;

typedef struct _CMUS_MODULE_CFG
{
    uint32_t  EN; /* 0:0 */
    uint32_t  CMUS_UP_MODE; /* 1:1 */
    uint32_t  FILTER_SIZE_DECISION_EN; /* 15:15 */
    uint32_t  FILTER_SIZE_DECISION_4X4; /* 16:16 */
} CMUS_MODULE_CFG;

typedef struct _CmusPassParameters
{
    CMUS_MODULE_CFG moduleCfg;
} CmusPassParameters;

typedef struct _CmusParameters
{
    CmusPassParameters   parameters[PASS_NAME_MAX];
} CmusParameters;

typedef struct _STMP_MODULE_CFG
{
    uint32_t  EN; /* 0:0 */
    uint32_t  PRE_CROP_EN; /* 8:8 */
} STMP_MODULE_CFG;

typedef struct _CatMapModCfg
{
    uint32_t  EN; /* 0:0 */
    uint32_t  UPSCALE_EN; /* 8:8 */
    uint32_t  POSTCROP_EN; /* 9:9 */
    uint32_t  NOP; /* 17:10 */
} CatMapModCfg;

typedef struct _CatMapModParameters
{
    CatMapModCfg modCfg;

    uint32_t  US_OUT_START_X;
    uint32_t  US_OUT_START_Y;
    uint32_t  US_STEP_X;
    uint32_t  US_STEP_Y;
} CatMapModParameters;

typedef struct _StmpPassParameters
{
    STMP_MODULE_CFG     moduleCfg;
    CatMapModParameters modCfgParams[STMP_AI_MOD_MAX];
} StmpPassParameters;

typedef struct _StmpParameters
{
    StmpPassParameters   parameters[PASS_NAME_MAX];
} StmpParameters;

typedef struct _STATS_HDR_BHIST_MODULE_CFG_v17
{
    uint32_t  EN;                        /*  0:0  */
    uint32_t  HDR_BHIST_ACTIVE_ROI_EN;   /*  7:5  */
    uint32_t  HDR_BHIST_CHAN_SEL;        /* 18:16 */
} STATS_HDR_BHIST_MODULE_CFG_v17;

typedef struct _BayerHistogramParameters_v17
{
    STATS_HDR_BHIST_MODULE_CFG_v17 moduleCfg;
    int32_t    bihistRoiHOffset[BHIST_ROI_RGN_NUM];
    int32_t    bihistRoiVOffset[BHIST_ROI_RGN_NUM];
    int32_t    bihistRgnHNum[BHIST_ROI_RGN_NUM];
} BayerHistogramParameters_v17;

typedef struct _PDPC_BPC_1D_MODULE_CFG
{
    uint32_t  EN;                  /* 0:0 */
    uint32_t  PDPC_EN;             /* 2:2 */
    uint32_t  BPC_EN;              /* 3:3 */
} PDPC_BPC_1D_MODULE_CFG;

typedef struct _PDPC1DParameters
{
    PDPC_BPC_1D_MODULE_CFG moduleCfg;
    int32_t    pdGlobalOffsetX;
    int32_t    pdTableOffsetX;
    int32_t    pdGlobalOffsetY;
    int32_t    pdTableOffsetY;
    int32_t    pdXEnd;
    int32_t    pdYEnd;
} PDPC1DParameters;

typedef struct _LENS_ROLLOFF_MODULE_CFG_v42
{
    uint32_t  EN;                   /*  0:0  */
    uint32_t  ALSC_EN;              /*  1:1  */
    uint32_t  GAIN_1D_EN;           /*  4:4  */
    uint32_t  CORRECTION_MODE_1D;   /*  5:5  */
    uint32_t  NUM_SUBBLOCKS;        /* 13:12 */
} LENS_ROLLOFF_MODULE_CFG_v42;

typedef struct _LensRollOffParameters_v42
{
    LENS_ROLLOFF_MODULE_CFG_v42 moduleCfg;
    uint32_t    subgridWidth;
    uint32_t    meshGridBwidth;
    uint32_t    startBlockIndex;
    uint32_t    startSubgridIndex;
    uint32_t    topLeftCoordinate;
    uint32_t    numHorizontalMeshGains;
    uint32_t    interpolationFactor;
    uint32_t    horizontalOffset;
    uint32_t    verticalOffset;
    uint32_t    rSquareBx;
    uint32_t    rSquareBy;

    uint32_t    initBlockY;
    uint32_t    initSubblockY;
    uint32_t    initPixelY;
} LensRollOffParameters_v42;

#endif // _IQSETTINGS_V4_H_
