////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2020-2021 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef _CVP_MV_STATS_HEADER_
#define _CVP_MV_STATS_HEADER_

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>

#define CVP_MV_MAGIC_SUFFIX                 (0x000CE555)
#define CVP_MV_MAGIC_VER_MAJOR(_major)      ((uint32_t)(_major) * (0x10000000))
#define CVP_MV_MAGIC_VER_MINOR(_minor)      ((uint32_t)(_minor) * (0x01000000))
#define CVP_MV_MAGIC_VER_STEP(_step)        ((uint32_t)(_step)  * (0x00100000))

#define CVP_MV_MAGIC_GEN(_major, _minor, _step)     (CVP_MV_MAGIC_SUFFIX | \
                                                     CVP_MV_MAGIC_VER_MAJOR(_major) | \
                                                     CVP_MV_MAGIC_VER_MINOR(_minor) | \
                                                     CVP_MV_MAGIC_VER_STEP(_step))
#define HFI_DME_MAX_FPX             (768)

#define CONVERT_SCORE_TO_INT(_score)                    (int32_t)(((_score) & 0x1000) ? ((~(0U)) & (~0x1FFF)) | (_score) : (_score))

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                          Lahaina Data structures
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#define CVP_MV_MAGIC_V100                       CVP_MV_MAGIC_GEN(1u, 0u, 0u)

// part of hfi_cvp.h EIS will also declare on the same data structures

/**< Meta data for each motion vector */
typedef union HFI_CVP_MV_STATS_V2_INFO_U
{
    uint32_t raw[1];        /**< note, actual size of this field, to force uint32_t alignment */

    struct DATA
    {
        uint32_t        score           : 13;   /**< Values in [-4095, +4096] */
        uint32_t        robustness      : 4;    /**< NCC score. Values in [-3,4] */
        uint32_t        isInlier        : 1;    /**< 0 == false, 1 == true */
        uint32_t        subPelValid     : 1;    /**< is sub-pixel valid: 0 == false, 1 == true */
    } data;
} HFI_CVP_MV_STATS_V2_INFO;

/**< Motion vector data structure */
typedef struct HFI_CVP_MV_STATS_V2_S
{
    float                       refCenterX; /**< Destination x-axis coordinate, values are in CVP input image domain */
    float                       refCenterY; /**< Destination y-axis coordinate, values are in CVP input image domain */

    uint16_t                    tarCenterX;  /**< Source x-axis coordinate, values are in CVP input image domain */
    uint16_t                    tarCenterY;  /**< Source y-axis coordinate, values are in CVP input image domain */

    HFI_CVP_MV_STATS_V2_INFO    meta;       /**< Additional meta data per motion vector */
}HFI_CVP_MV_STATS_V2;

typedef struct HFI_CVP_VIDEO_STATS_V2_S
{
    uint32_t                magic;          /**< 0x100CE555  -  magic number first 3 numbers (major, minor, step) are version number, rest of numbers are predefined */
    uint32_t                modelType;      /**< 0 perspective, 1 rigid, 2 affine. */
    uint32_t                nNumMv;         /**< Number of valid MVs*/
    HFI_CVP_MV_STATS_V2     sdisInfo[1];
}HFI_CVP_VIDEO_STATS_V2;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                          Waipio
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#define CVP_MV_MAGIC_V101                       CVP_MV_MAGIC_GEN(1u, 0u, 1u)

/**< Meta data for each motion vector */
typedef union HFI_CVP_MV_STATS_V2_1_INFO_U
{
    uint32_t raw[1];        /**< note, actual size of this field, to force uint32_t alignment */

    struct DATA
    {
        uint32_t        score                   : 13;   /**< Values in [-4095, +4096] */
        uint32_t        robustness              : 4;    /**< NCC score. Values in [-3,4] */
        uint32_t        isInlier                : 1;    /**< 0 == false, 1 == true */
        uint32_t        subPelValid             : 1;    /**< is sub-pixel valid: 0 == false, 1 == true */
        uint32_t        isPredictInlier         : 1;    /**< 0 == false, 1 == true */
    } data;
} HFI_CVP_MV_STATS_V2_1_INFO;

/**< Motion vector data structure */
typedef struct HFI_CVP_MV_STATS_V2_1_S
{
    float                       refCenterX; /**< Destination x-axis coordinate, values are in CVP input image domain */
    float                       refCenterY; /**< Destination y-axis coordinate, values are in CVP input image domain */

    uint16_t                    tarCenterX;  /**< Source x-axis coordinate, values are in CVP input image domain */
    uint16_t                    tarCenterY;  /**< Source y-axis coordinate, values are in CVP input image domain */

    HFI_CVP_MV_STATS_V2_1_INFO  meta;       /**< Additional meta data per motion vector */
}HFI_CVP_MV_STATS_V2_1;

typedef struct HFI_CVP_VIDEO_STATS_V2_1_S
{
    uint32_t                magic;          /**< 0x101CE555  -  magic number first 3 numbers (major, minor, step) are version number, rest of numbers are predefined */
    uint32_t                modelType;      /**< 0 perspective, 1 rigid, 2 affine. */
    uint32_t                nNumMv;         /**< Number of valid MVs*/
    uint32_t                frame_id;       /**< frame Id for this frame */
    HFI_CVP_MV_STATS_V2_1   sdisInfo[1];
}HFI_CVP_VIDEO_STATS_V2_1;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                          Helper defines
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#define HFI_CVP_VIDEO_STATS_GET_MAGIC(_ptr)         (((const uint32_t *)(_ptr))[0])

#define HFI_CVP_VIDEO_STATS_GET_MODEL_TYPE(_ptr)    (((const uint32_t *)(_ptr))[1])

#define HFI_CVP_VIDEO_STATS_GET_NUM_MV(_ptr)        (((const uint32_t *)(_ptr))[2])

/** packet data size */
#define HFI_CVP_MV_STATS_SIZEOF(_magic_id)      ((CVP_MV_MAGIC_V100 == _magic_id) ?                         \
                                                    sizeof(HFI_CVP_MV_STATS_V2) :                           \
                                                    (                                                       \
                                                            (CVP_MV_MAGIC_V101 == _magic_id) ?              \
                                                            sizeof(HFI_CVP_MV_STATS_V2_1) : 0x1)            \
                                                     )

IS_COMPILE_TIME_ASSERT(sizeof(HFI_CVP_VIDEO_STATS_V2) > sizeof(HFI_CVP_MV_STATS_V2));
IS_COMPILE_TIME_ASSERT(sizeof(HFI_CVP_VIDEO_STATS_V2_1) > sizeof(HFI_CVP_MV_STATS_V2_1));

/** packet header size */
#define HFI_CVP_VIDEO_STATS_SIZEOF(_magic_id)      ((CVP_MV_MAGIC_V100 == _magic_id) ?                                                  \
                                                    (sizeof(HFI_CVP_VIDEO_STATS_V2) - sizeof(HFI_CVP_MV_STATS_V2)):                     \
                                                    (                                                                                   \
                                                            (CVP_MV_MAGIC_V101 == _magic_id) ?                                          \
                                                            (sizeof(HFI_CVP_VIDEO_STATS_V2_1) - sizeof(HFI_CVP_MV_STATS_V2_1)) : 0x1)   \
                                                     )

IS_COMPILE_TIME_ASSERT(HFI_CVP_VIDEO_STATS_SIZEOF(CVP_MV_MAGIC_V100) == (sizeof(uint32_t) * 3));
IS_COMPILE_TIME_ASSERT(HFI_CVP_VIDEO_STATS_SIZEOF(CVP_MV_MAGIC_V101) == (sizeof(uint32_t) * 4));

// backwards compatibility due to bug in CVP v100
#define CONVERT_ROBUSTNESS_TO_INT(_robustness)  (int32_t)(((_robustness) & 0x8) ? ((~(0U)) & (~0xF)) | (_robustness) : (_robustness))


#ifdef __cplusplus
}
#endif

#endif /* _CVP_MV_STATS_HEADER_ */
