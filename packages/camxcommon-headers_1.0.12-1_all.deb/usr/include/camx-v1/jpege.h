////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright(c) 2008-2011, 2014-2015, 2019 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/*========================================================================
                             Edit History

$Header:

when       who     what, where, why
--------   ---     -------------------------------------------------------
22/02/19  semarose Added buffers to hold DC coefficients of main image
10/16/14   vgaur   Added multi-threaded fastCV flag and fastCV buffer pointer.
03/25/14  revathys Added stride support.
06/18/10   staceyw Changed jpege_upsample_cfg_t to jpege_scale_cfg_t, which
                   can be used both by upscale and downscale config.
06/14/10   leim    Added return type to output handler callback.
04/16/10   staceyw Added last output buffer flag in jpege_output_handler_t.
02/26/10   staceyw Changed to multiple piece-wise output buffers,
                   and added support for enqueue output buffer(s) back to
                   buffer(s) pool.
02/19/10   leim    Remove jpege_obj_t parameter in function call
                   jpege_get_default_config(), so this function is static,
                   and can be called any time.
02/08/10   staceyw Added input bitstream buffer in image fragment definition
                   for in-line jpeg mode.
10/13/09   vma     Changed to pass back user-prepared data in event
                   handlers and output produced handlers instead of the
                   encoder object itself.
06/02/09   vma     Added don't care preference.
04/23/09   vma     Added reporting of the event where thumbnail is
                   too big and is dropped.
09/12/08   vma     Added upsampler support.
07/07/08   vma     Created file.

========================================================================== */

#ifndef _JPEGE_H
#define _JPEGE_H

#include "jpeg_common.h"
#include "jpeg_buffer.h"

/* -----------------------------------------------------------------------
** Constant / Define Declarations
** ----------------------------------------------------------------------- */
#define MAX_FRAGMENTS  8

/* -----------------------------------------------------------------------
** Type Declarations
** ----------------------------------------------------------------------- */

/* Jpeg Encoder Preference */
typedef enum
{
    JPEG_ENCODER_PREF_HW_ACCELERATED_PREFERRED = 0,
    JPEG_ENCODER_PREF_HW_ACCELERATED_ONLY,
    JPEG_ENCODER_PREF_SOFTWARE_PREFERRED,
    JPEG_ENCODER_PREF_SOFTWARE_ONLY,
    JPEG_ENCODER_PREF_DONT_CARE,

    JPEG_ENCODER_PREF_MAX,

} jpege_preference_t;

/* The structure defining an image fragment. It contains both
 * the width and height of the fragment as well as the pointer
 * to the actual pixel data. The union inside the structure
 * contains YUV, RGB and bitstream fields. They should be used
 * accordingly depending on the color format of the pixel data. */
typedef struct
{
    union
    {
        struct
        {
            jpeg_buffer_t luma_buf;    // Buffer to hold the luma data (Y)
            jpeg_buffer_t chroma_buf;  // Buffer to hold the chroma data (CrCb or CbCr interlaced)
        } yuv;

        struct
        {
            jpeg_buffer_t rgb_buf;     // Buffer to hold the RGB data
        } rgb;

        struct
        {
            jpeg_buffer_t bitstream_buf;
                                       // Buffer to hold the bitstream
        } bitstream;

    } color;

    uint32_t   width;           // Width of the fragment
    uint32_t   height;          // Height of the fragment
    uint16_t   num_of_planes;

} jpege_img_frag_t;

/* The structure defining the information about the possible image input
 * to the Jpeg Encoder. Note that the image width and height in this structure
 * tells the encoder the real dimension of the image excluding the padded data
 * in case padding was pre-applied. The padded width and height would be captured
 * in the fragment width and height rather. */
typedef struct
{
    jpeg_color_format_t color_format;               // Color format of the image data (e.g. YCrCbLpH2V2)
    uint32_t            width;                      // Width of the image to be encoded
    uint32_t            height;                     // Height of the image to be encoded
    uint32_t            fragment_cnt;               // The number of fragments (max is 8)
    jpege_img_frag_t    p_fragments[MAX_FRAGMENTS]; // Array of the image fragments composing the image
                                                    // When set source, first fragment must be available.
                                                    // One fragment at each time to be delivered.
                                                    // It targets with hardware encoding only.
} jpege_img_data_t;

/* The structure defining the scale configuration */
typedef struct
{
    /*
     Scale is supported by certain hardware chipsets.
     Scale can used to crop the input image and encode it a different resolution.
     The cropped image can be cropped and upscaled by a factor of 1x - 8x
     or downscaled by a factor of 1x - 1/8x.
     An upscale is enabled automaticcally when at least one of the output image
     dimensions is greater than the corresponding input image dimension.
     An downScale is enabled automaticcally when at least one of the output image
     dimensions is less than the corresponding input image dimension.

            |-----------------------------------------------------|  /\
            |                /\                                   |   |
            |                 |                                   |   |
            |             v_offset                                |   |
            |                 |                                   |   |
            |                \/                                   |   |
            |              |-------------------|      /\          |   |
            |              |    scale          |       |          |   |
            |              |<-  input_width  ->|    scale         |   | input
            |              |                   |   input_height   |   | height
            |<- h_offset ->|                   |       |          |   |
            |              |                   |       |          |   |
            |              |-------------------|      \/          |   |
            |                                                     |   |
            |                                                     |   |
            |                                                     |   |
            |<--------------- input_width ----------------------->|   |
            |                                                     |   |
            |                                                     |   |
            |-----------------------------------------------------|  \/
    */

    uint32_t    input_width;   // input width
    uint32_t    input_height;  // input height
    uint32_t    h_offset;      // h_offset
    uint32_t    v_offset;      // v_offset
    uint32_t    output_width;  // output width
    uint32_t    output_height; // output height
    uint8_t     enable;        // enable flag

} jpege_scale_cfg_t;

///
///
///     <---input_luma_stride--->
///     <---width----->
///      _ _ _ _ _ _ _ _ _ _ _ _
///     |             |         |        W - Stride
///     |             |         |        w - Actual luma or chroma data width
///     |             |         |        Stride can be different for input and output buffers
///     |_ _ _ _ _ _ _|         |        as well as luma and chroma buffers.
///     |                       |
///     |_ _ _ _ _ _ _ _ _ _ _ _|
///
///
typedef struct
{
    uint8_t  enable;              //stride enable flag
    uint32_t input_luma_stride;   //Input luma stride
    uint32_t input_chroma_stride; //Input chroma stride
    uint32_t output_luma_stride;  //Output luma stride
    uint32_t output_chroma_stride;//Output chroma stride

} jpege_stride_cfg_t;

/* The structure defining the configuration to the Jpeg Encoder specific
 * specific to the image. */
typedef struct
{
    // Rotation in degree (clockwise). Valid values are: 0, 90, 180, 270.
    uint32_t              rotation_degree_clk;
    // The luma quantization table.
    jpeg_quant_table_t    luma_quant_tbl;
    // The chroma quantization table.
    jpeg_quant_table_t    chroma_quant_tbl;
    // The luma Huffman table for DC components.
    jpeg_huff_table_t     luma_dc_huff_tbl;
    // The chroma Huffman table for DC components.
    jpeg_huff_table_t     chroma_dc_huff_tbl;
    // The luma Huffman table for AC components.
    jpeg_huff_table_t     luma_ac_huff_tbl;
    // The chroma Huffman table for AC components.
    jpeg_huff_table_t     chroma_ac_huff_tbl;
    // Encode restart marker interval - how often restart markers are
    // inserted into the bitstream_t for error recovery.
    uint32_t              restart_interval;
    // Scale configuration
    jpege_scale_cfg_t     scale_cfg;
    // Stride configuration
    jpege_stride_cfg_t    stride_cfg;

    uint8_t                *fastCV_buffer;
    uint8_t                fastCV_flag;
    int                    fd_fastcv_buff;
    uint32_t               fastCV_buff_size;

    // DS8 Buffers
    int                  fd_ds8;
    uint32_t             ds8_buffer_size;
    uint8_t             *p_mainImage_ds8_luma_buffer;
    uint8_t             *p_mainImage_ds8_chroma_buffer;
} jpege_img_cfg_t;

/* =======================================================================
**                          Macro Definitions
** ======================================================================= */

/* =======================================================================
**                          Function Declarations
** ======================================================================= */

#endif // #ifndef _JPEGE_H

