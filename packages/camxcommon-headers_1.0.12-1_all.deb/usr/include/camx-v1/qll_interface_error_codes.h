////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2020 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef __QLL_INTERFACE_ERROR_CODES_H__
#define __QLL_INTERFACE_ERROR_CODES_H__


/**  @addtogroup Return_Values
*  @brief     QLL algorithm return values
*  @{
*/
#define QLL_RET_BASE                 0x08000000                  /**< @return_val Base value for all QLL related errors and warnings */
#define QLL_RET_SUCCESS              (0)                         /**< @return_val Success return value */

#define QLL_RET_ERROR_BASE           (QLL_RET_BASE)               /**< @return_val Error base value - algorithm cannot recover */

#define QLL_RET_FRAME_NOT_PROCESSED  (QLL_RET_ERROR_BASE + 1)     /**< @return_val Frame was not processed */
#define QLL_RET_GENERAL_ERROR        (QLL_RET_ERROR_BASE + 2)     /**< @return_val General error return value */
#define QLL_RET_INVALID_INPUT        (QLL_RET_ERROR_BASE + 3)     /**< @return_val Invalid input */
#define QLL_RET_OUT_OF_MEMORY        (QLL_RET_ERROR_BASE + 4)     /**< @return_val Out of memory error */
#define QLL_RET_MISSING_SAMPLES      (QLL_RET_ERROR_BASE + 5)     /**< @return_val Insuffcient sample count */
#define QLL_RET_ML_TIMEOUT           (QLL_RET_ERROR_BASE + 6)     /**< @return_val Timeout in QL ML processing */
#define QLL_RET_ML_ABORTED           (QLL_RET_ERROR_BASE + 7)     /**< @return_val QL ML processing aborted */
#define QLL_RET_ML_ERROR             (QLL_RET_ERROR_BASE + 8)     /**< @return_val QL ML processing error */

#define QLL_RET_WARN_BASE            (QLL_RET_BASE | 0x100)       /**< @return_val Warning base value - algorithm can recover but results could be sub-optimal */

#define QLL_RET_WARN_INVALID_INPUT   (QLL_RET_WARN_BASE + 1)      /**< @return_val Invalid input */
/** @} */

/**  @addtogroup    Errors_Information
*  @brief         QLL algorithm output errors and warnings enumerators and information
*  @{
*/

/**  @addtogroup    Critical_Errors
*  @brief          Critical errors. Algorithm cannot recover. API will return with the appropriate error code.
*                  Values range: 0000-0511
*  @{
*/

/** \error ERROR QLL0001: Internal assertion failed */
#define QLL_ERR_ASSERTION                    "QLL0001"

/** \error ERROR QLL0002: General error occurred */
#define QLL_ERR_GENERAL_ERROR                "QLL0002"

/** \error ERROR QLL0003: Invalid input was detected */
#define QLL_ERR_INVALID_INPUT                "QLL0003"

/** \error ERROR QLL0004: Memory allocation failed */
#define QLL_ERR_OUT_OF_MEMORY                "QLL0004"

/** \error ERROR QLL0005: Invalid filter status was detected */
#define QLL_ERR_INVALID_FILTER_STATUS        "QLL0005"

/** \error ERROR QLL0007: Out of Order Start for Frame timestamp was detected */
#define QLL_ERR_OOO_SOF                      "QLL0007"

/** \error ERROR QLL0008: Duplicated frame was detected */
#define QLL_ERR_DUPLICATED_FRAMES            "QLL0008"

/** \error ERROR QLL0009: Actual sample rate exceeds the requested sample rate, could cause buffer overflow */
#define QLL_ERR_SAMPLE_RATE_EXCEEDS          "QLL0009"

/** \error ERROR QLL0012: Out of Order frame ID was detected */
#define QLL_ERR_OOO_FRAME_ID                 "QLL0012"

/** \error ERROR QLL0014: Invalid sensor was detected */
#define QLL_ERR_SENSOR_ID_INVALID            "QLL0014"

/** \error ERROR QLL0016: Invalid input, configuration mismatch. Pointer structs are NULL */
#define QLL_ERR_INVALID_INPUT_STAB_TRANSFORM "QLL0016"

/** \error ERROR QLL0017: Invalid input, configuration mismatch. Pointer structs are NULL */
#define QLL_ERR_INVALID_INIT_INPUT           "QLL0017"

/** \error ERROR QLL0018: Sampler detected that many samples are missing */
#define QLL_ERR_SAMPLER_MISSING_MANY_SAMPLES "QLL0018"

/** \error ERROR QLL0019: One of the sensors is missing many sample with respect to other sensor */
#define QLL_ERR_SENSOR_MISSING_MANY_SAMPLES  "QLL0019"

/** @} */

/**  @addtogroup    QLLQ_Warnings
*  @brief           Image Stabilization Quality warnings. Algorithm can recover, however degradation in stabilization quality is expected.
*                   Values range: 0512-1023
*  @{
*/

/** \error ERROR QLL0515: Invalid SOF value */
#define QLL_ERR_SOF_INVALID                  "QLL0515"

/** \error ERROR QLL0516: Invalid frame time value */
#define QLL_ERR_FRAME_TIME_INVALID           "QLL0516"

/** \error ERROR QLL0517: Invalid exposure time value */
#define QLL_ERR_EXPOSURE_TIME_INVALID        "QLL0517"

/** \error ERROR QLL0518: Estimated sample rate is not close to mean sample rate. Might indicate on missing samples or false time-stamps */
#define QLL_ERR_SAMPLE_RATE_EST_VS_AVG       "QLL0518"

/** \error ERROR QLL0519: Estimated sample rate is not close to initial value. Might indicate on false HW configuration */
#define QLL_ERR_SAMPLE_RATE_EST_VS_INIT      "QLL0519"

/** \error ERROR QLL0521: Sampler has detected a missing sample */
#define QLL_ERR_SAMPLER_MISSING_SAMPLE       "QLL0521"

/** \error ERROR QLL0522: Sampler has detected missing samples from beginning of frame */
#define QLL_ERR_SAMPLER_FIRST_MISSING_SAMPLE "QLL0522"

/** \error ERROR QLL0523: Sampler has detected missing samples from end of stream */
#define QLL_ERR_SAMPLER_LAST_MISSING_SAMPLE  "QLL0523"

/** \error ERROR QLL0524: Out of Order sample */
#define QLL_ERR_SAMPLE_OOO                   "QLL0524"

/** \error ERROR QLL0525: Duplicated sample */
#define QLL_ERR_SAMPLE_DUPLICATED            "QLL0525"

/** \error ERROR QLL0526: Gyro samples spacing is too big with respect to estimated frequency. Might indicate on missing gyro samples or false gyro time-stamps */
#define QLL_ERR_SAMPLE_SPACING               "QLL0526"

/** \error ERROR QLL0529: corrupted CSV file was read */
#define QLL_ERR_DUMP_FILE_CORRUPTED          "QLL0529"

/** \error ERROR QLL0530: General warning occurred */
#define QLL_ERR_GENERAL_WARNING              "QLL0530"

/** @} */


/**  @addtogroup    Verbose_Information
*  @brief           Additional information that might indicate on use-cases that might affect the stabilized video
*                   Values range: 1024-1535
*  @{
*/

/** \error VERBOSE QLL1024: QLL mode selection related info */
#define QLL_VRB_MODE_SEL                     "QLL1024"

/** \error VERBOSE QLL1025: QLL TFI buffer related info */
#define QLL_VRB_TFI_BUF                      "QLL1025"

/** \error VERBOSE QLL1026: QLL OIS compensation info */
#define QLL_VRB_OIS_COMP                     "QLL1026"

/** \error VERBOSE QLL1027: General debug information */
#define QLL_VRB_DEBUG_INFO                   "QLL1027"

/** \error VERBOSE QLL1028: Frame drop was detected */
#define QLL_VRB_FRAME_DROP                   "QLL1028"

/** \error VERBOSE IS1029: Invalid input was passed to algorithm destroy function. Could indicate on invalid SW flow */
#define QLL_VRB_DESTROY_INVALID_INPUT                   "QLL1029"


/** @} */

/** @} */

#endif /* __QLL_INTERFACE_ERROR_CODES_H__ */
