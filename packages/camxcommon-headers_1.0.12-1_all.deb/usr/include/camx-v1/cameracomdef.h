//-------------------------------------------------------------------------
// Copyright (c) 2015-2020 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.

//------------------------------------------------------------------------
// @file  cameracomdef.h
// @brief Abstract data types
//------------------------------------------------------------------------

//------------------------------------------------------------------------
// @Edit History
// when              who           what,where,why
// -----             ---           -------------
//
// 01/19/2015        visweshp      Initial version
//------------------------------------------------------------------------

#ifndef _CAMERA_COMDEF_H_
#define _CAMERA_COMDEF_H_

// If C Compiler is above C99
#if (__STDC_VERSION__ >= 199901L) || (_MSC_VER >= 1600)

#include <stdint.h>

#else

#include <stdio.h>
#include <cstdlib>
#include <stdint.h>

#endif

#ifndef _STDBOOL_H
#define _STDBOOL_H

// This code is only here, since stdbool does not exist in VS2012, make sure to not remove when integrating changes from the FW here, since the FW is compiled in VS2013
typedef int                 BOOL;

#ifndef __cplusplus
#define true 1
#define false 0
#endif

// Signal that all the definitions are present.
#define __bool_true_false_are_defined 1

#endif

// typedef uint32_t            UINTPTR32;

#endif //End _CAMERA_COMDEF_H_
