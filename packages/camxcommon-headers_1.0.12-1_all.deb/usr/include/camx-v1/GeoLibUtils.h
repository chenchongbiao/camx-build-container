// NOWHINE ENTIRE FILE
//-------------------------------------------------------------------------
// Copyright (c) 2019-2020 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
//------------------------------------------------------------------------

#ifndef GEOLIBUTILS_H
#define GEOLIBUTILS_H

#include "GeoLib.h"


// Video dump

void Dump_GeoLibVideoStreamInput(
    const GeoLibVideoFlowMode       flowMode,
    const GeoLibHdrFlowMode         hdrMode,
    const GeoLibSensorData          sensorData[],
    const uint32_t                  numSensors,
    const uint32_t                  curSensorIdx,
    const GeoLibVideoStreamIfePort  ifeOutPort,
    const GeoLibImageSize*          ifeOutMinSize,
    const GeoLibImageSize*          fdOutSize,
    const NcLibIcaGrid*             ldFullOutToIn,
    const NcLibIcaGrid*             ldFullInToOut,
    const GeoLibIpeParams           ipeParams[],
    const uint32_t                  ipeParamsLen,
    const float                     maxVsrScaling,
    const GeoLibEisParams*          eisParameters,
    const float                     fovcMarginRatio,
    const uint32_t                  overrideFlags,
    const GeoLibVideoIfeStreamCfg*  secIfeConfig,
    FILE*                           dumpFile);

void Dump_GeoLibVideoIfeStreamCfg(
    const GeoLibVideoIfeStreamCfg*  streamConfig,
    FILE*                           dumpFile);

void Dump_GeoLibVideoIpeStreamCfg(
    const GeoLibVideoIpeStreamCfg*  streamConfig,
    FILE*                           dumpFile);

void Dump_GeoLibVideoCvpStreamCfg(
    const GeoLibVideoCvpStreamCfg*  streamConfig,
    FILE*                           dumpFile);

void Dump_GeoLibVideoIfeFrameCfg(
    const GeoLibVideoIfeFrameCfg*   geoLibIfe,
    const GeoLibROI*                zoomWindow,
    const GeoLibWindowSize*         satWindowSize,
    const float                     eisVsVsrFactor,
    const float                     vsrLimit,
    FILE*                           dumpFile);

void Dump_GeoLibVideoIpeFrameCfg(
    const GeoLibVideoIpeFrameCfg*   geoLibIpe,
    const float                     fovcRatio,
    FILE*                           dumpFile);
void Dump_GeoLibVideoIpeFrameCfg(
    const GeoLibVideoIpeFrameCfg*   geoLibIpe,
    const char*                     prefix,
    FILE*                           dumpFile);

void Dump_GeoLibVideoCvpFrameCfg(
    const GeoLibVideoCvpFrameCfg*   geoLibCvp,
    const float                     cvpDsRatio,
    FILE*                           dumpFile);

void Dump_GeoLibVideoEisFrameCfg(
    const GeoLibVideoEisFrameCfg*   geoLibEis,
    const float                     fovcRatio,
    const char*                     prefix,
    FILE*                           dumpFile);


// Kona Still dump

void Dump_GeoLibStillFrameInput(
    const GeoLibStillFlowMode       flowMode,
    const GeoLibMultiFrameMode      mfMode,
    const GeoLibImageSize*          sensorSize,
    const NcLibIcaGrid*             ldFullOutToIn,
    const NcLibIcaGrid*             ldFullInToOut,
    const GeoLibImageSize*          outSize,
    const GeoLibImageSize*          dispSize,
    const GeoLibImageSize*          regOutSize,
    const GeoLibROI*                zoomWindow,
    FILE*                           dumpFile);

void Dump_GeoLibStillFrameConfig(
    const GeoLibStillFrameConfig*   frameCfg,
    FILE*                           dumpFile);

// Lahaina Still dump

void Dump_GeoLibStillFrameInput(
    const bool                      isMultiFrame,
    const bool                      isMultiFrameExp2,
    const bool                      isMultiFrameExp3,
    const float                     maxSRScaling,
    const float                     fovcRatio,
    const GeoLibImageSize*          sensorSize,
    const NcLibIcaGrid*             ldFullOutToIn,
    const GeoLibImageSize*          stillOutSize,
    const GeoLibImageSize*          dispOutSize,
    const GeoLibImageSize*          regOutSize,
    const GeoLibImageSize*          regOutSizeExp2,
    const GeoLibImageSize*          regOutSizeExp3,
    const GeoLibROI*                zoomWindow,
    const uint32_t                  overrideFlags,
    FILE*                           dumpFile);

void Dump_GeoLibStillMFFrameConfig(
    const GeoLibStillMFFrameConfig* frameCfg,
    const uint32_t                  expId,
    FILE*                           dumpFile);

void Dump_GeoLibStillHDRFrameConfig(
    const GeoLibStillHDRBlendFrameConfig* hdrBlend,
    const GeoLibStillIPEFrameConfig*      hdrLast,
    FILE*                                 dumpFile);


// Video validation

bool Validate_GeoLibVideoIfeStreamInit(
    const GeoLibVideoFlowMode       flowMode,
    const GeoLibHdrFlowMode         hdrMode,
    const GeoLibSensorData          sensorData[],
    const uint32_t                  numSensors,
    const uint32_t                  curSensorIdx,
    const GeoLibVideoStreamIfePort  ifeOutPort,
    const GeoLibImageSize*          ifeOutMinSize,
    const GeoLibImageSize*          fdOutSize,
    const GeoLibIpeParams           ipeParams[],
    const uint32_t                  ipeParamsLen,
    const float                     maxVsrScaling,
    const GeoLibEisParams*          eisParameters,
    const float                     fovcMarginRatio,
    const uint32_t                  overrideFlags,
    const GeoLibVideoIfeStreamCfg*  secIfeConfig,
    GeoLibVideoIfeStreamCfg*        ifeConfig
);

bool Validate_GeoLibVideoIpeInit(
    const GeoLibIpeParams*          ipeParams,
    GeoLibVideoIpeStreamCfg*        ipeConfig
);

bool Validate_GeoLibVideoCvpInit(
    GeoLibVideoCvpStreamCfg*        cvpConfig
);

bool Validate_GeoLibVideoIfeCalcFrame(
    const GeoLibVideoFlowMode       flowMode,
    const float                     digitalZoom,
    const bool                      isSatEnabled,
    const GeoLibVideoIfeFrameCfg*   frameConfig
);

bool Validate_GeoLibVideoIpeCalcFrame(
    const GeoLibVideoIpeFrameCfg*         frameConfig
);

bool Validate_GeoLibVideoIpeHdrCalcFrame(
    GeoLibVideoIpeFrameCfg*         mExpOut,
    GeoLibVideoIpeFrameCfg*         slExpOut
);

bool Validate_GeoLibVideoEisCalcFrame(
    GeoLibVideoEisFrameCfg*         frameConfig
);

bool Validate_GeoLibVideoCvpCalcFrame(
    const GeoLibVideoCvpFrameCfg* frameConfig
);


// Kona Still validation

bool Validate_GeoLibStillCalcFrameInput(
    const GeoLibStillFlowMode      flowMode,
    const GeoLibMultiFrameMode     mfMode,
    const GeoLibImageSize*         sensorSize,
    const NcLibIcaGrid*            ldFullOutToIn,
    const NcLibIcaGrid*            ldFullInToOut,
    const GeoLibImageSize*         ldFullOutSize,
    const GeoLibImageSize*         stillOutSize,
    const GeoLibImageSize*         dispOutSize,
    const GeoLibImageSize*         regOutSize,
    const float                    digitalZoom);

bool Validate_GeoLibStillCalcFrameOutput(
    const GeoLibStillFlowMode       flowMode,
    const GeoLibMultiFrameMode      mfMode,
    const GeoLibImageSize*          dispSize,
    const GeoLibStillFrameConfig*   frameConfig
);


// Lahaina Still validation

bool Validate_GeoLibStillCalcFrameInput(
    const GeoLibStillFlowMode       flowMode,
    const GeoLibHdrFlowMode         hdrMode,
    const GeoLibSensorData*         sensorData,
    const NcLibIcaGrid*             ldFullOutToIn,
    const GeoLibImageSize*          ldFullOutSize,
    const GeoLibIpeParams*          ipeParams,
    const GeoLibImageSize*          regOutSize,
    const GeoLibROI*                zoomWindow,
    const float                     fovcRatio
);

bool Validate_GeoLibStillHdrCalcFrameInput(
    const GeoLibSensorData*         sensorData,
    const NcLibIcaGrid*             ldFullOutToIn,
    const GeoLibImageSize*          ldFullOutSize,
    const GeoLibImageSize*          regOutSizeExp1,
    const GeoLibImageSize*          regOutSizeExp2,
    const GeoLibImageSize*          regOutSizeExp3,
    const GeoLibIpeParams*          ipeParams,
    const GeoLibROI*                zoomWindow,
    const float                     fovcRatio
);

bool Validate_GeoLibStillCalcFrameOutput(
    const bool                      isMultiFrame,
    const bool                      isHDRFlow,
    const GeoLibImageSize*          dispOutSize,
    const GeoLibStillMFFrameConfig* stillConfig
);

bool Validate_GeoLibStillHdrCalcFrameOutput(
    const uint32_t                        expNum,
    const GeoLibStillHDRBlendFrameConfig* hdrBlend,
    const GeoLibStillIPEFrameConfig*      hdrLast
);


// Misc

void SetDefaultsForGeoLibIcaPassMapping(GeoLibIcaPassMapping* icaPassMapping, uint32_t numOfPasses);

#endif // GEOLIBUTILS_H
