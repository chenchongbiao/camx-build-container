////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
// All rights reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
//
// Not a Contribution.
// Copyright (C) 2012 The Android Open Source Project
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @file  camxhal3metadatatags.h
/// @brief Declarations of wrapped HAL3 metadata tag types mirroring.
///
/// Original tag definitions are defined in system/media/camera/include/system/camera_metadata_tags.h
/// Additional documentation on Google defined metadata tags can be found at system/media/camera/docs/docs.html
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// NOWHINE FILE DC012: Enum members not documented.
// NOWHINE FILE GR002: Little extra length == much greater readability

#ifndef CAMXHAL3METADATATAGS_H
#define CAMXHAL3METADATATAGS_H

#include "camxdefs.h"
#include "camera3_metadata_tags.h"
#include "camxtypes.h"

CAMX_NAMESPACE_BEGIN

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Constants
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/// @brief Maximum number of values possible for a metadata tag.
static const UINT MaxTagValues = 40;

// InvalidIndex is assigned an arbitrarily large value
static const UINT32 InvalidIndex = 0xffffffff;

// Default values for JPEG image/thumbnail quality
static const UINT32 JpegImageDefaultQuality     = 100;
static const UINT32 JpegThumbnailDefaultQuality = 85;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Forward Declarations
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Type Declarations
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


/// @brief This is setup to allow us to duplicate the definitions of metadata for certain pools use
enum class MetadataPoolSection : UINT32
{
    /// If any change is made to this enum, same change should be made in chicommon.h
    // Result is implicit, and 0x0000
    Input          = 0x0800, // Input must be bitwise exclusive to the other so we can uniquely identify for both tags and
                             // props
    Usecase        = 0x2000,
    Static         = 0x7000,
    GlobalUsecase  = 0x400
    // 0x3000 - Result Prop
    // 0x4000 - Internal Prop
    // 0x5000 - Usecase Prop
    // 0x6000 - DebugData Prop
};

/// Mask that shows if using special groups
static const UINT32  DriverInternalGroupMask = 0x7C00 << 16;

/// Mask that shows if using property groups
static const UINT32  PropertyGroupMask = 0xF0000000;

/// Mask that shows if the metadata is a vendor tag
static const UINT32 VendorTagMask = 0x80000000;

/// Mask to OR with tags to represent input pool residency
static const UINT32 InputMetadataSectionMask   = static_cast<UINT32>(MetadataPoolSection::Input)   << 16;

/// Mask to OR with tags to represent usecase pool residency
static const UINT32 UsecaseMetadataSectionMask = static_cast<UINT32>(MetadataPoolSection::Usecase) << 16;

/// Mask to OR with tags to represent static pool residency
static const UINT32 StaticMetadataSectionMask = static_cast<UINT32>(MetadataPoolSection::Static) << 16;

/// Mask to OR with tags to represent global pool residency
static const UINT32 GlobalUsecaseMetadataSectionMask = static_cast<UINT32>(MetadataPoolSection::GlobalUsecase) << 16;

/// @brief Main enum for defining camera metadata tags.
/// @note  MUST modify HAL3MetadataUtils::Tag{Elements,Factor,Type} consts to define new tag properties in the proper order
///        Must update for other pool types too
enum Camxhal3Metadatatags  : INT32
{
    InputColorCorrectionMode                          = ColorCorrectionMode                          | InputMetadataSectionMask,
    InputColorCorrectionTransform                     = ColorCorrectionTransform                     | InputMetadataSectionMask,
    InputColorCorrectionGains                         = ColorCorrectionGains                         | InputMetadataSectionMask,
    InputColorCorrectionAberrationMode                = ColorCorrectionAberrationMode                | InputMetadataSectionMask,
    InputColorCorrectionAvailableAberrationModes      = ColorCorrectionAvailableAberrationModes      | InputMetadataSectionMask,
    InputColorCorrectionEnd                           = ColorCorrectionEnd                           | InputMetadataSectionMask,

    InputControlAEAntibandingMode                     = ControlAEAntibandingMode                     | InputMetadataSectionMask,
    InputControlAEExposureCompensation                = ControlAEExposureCompensation                | InputMetadataSectionMask,
    InputControlAELock                                = ControlAELock                                | InputMetadataSectionMask,
    InputControlAEMode                                = ControlAEMode                                | InputMetadataSectionMask,
    InputControlAERegions                             = ControlAERegions                             | InputMetadataSectionMask,
    InputControlAETargetFpsRange                      = ControlAETargetFpsRange                      | InputMetadataSectionMask,
    InputControlAEPrecaptureTrigger                   = ControlAEPrecaptureTrigger                   | InputMetadataSectionMask,
    InputControlAFMode                                = ControlAFMode                                | InputMetadataSectionMask,
    InputControlAFRegions                             = ControlAFRegions                             | InputMetadataSectionMask,
    InputControlAFTrigger                             = ControlAFTrigger                             | InputMetadataSectionMask,
    InputControlAWBLock                               = ControlAWBLock                               | InputMetadataSectionMask,
    InputControlAWBMode                               = ControlAWBMode                               | InputMetadataSectionMask,
    InputControlAWBRegions                            = ControlAWBRegions                            | InputMetadataSectionMask,
    InputControlCaptureIntent                         = ControlCaptureIntent                         | InputMetadataSectionMask,
    InputControlEffectMode                            = ControlEffectMode                            | InputMetadataSectionMask,
    InputControlMode                                  = ControlMode                                  | InputMetadataSectionMask,
    InputControlSceneMode                             = ControlSceneMode                             | InputMetadataSectionMask,
    InputControlVideoStabilizationMode                = ControlVideoStabilizationMode                | InputMetadataSectionMask,
    InputControlAEAvailableAntibandingModes           = ControlAEAvailableAntibandingModes           | InputMetadataSectionMask,
    InputControlAEAvailableModes                      = ControlAEAvailableModes                      | InputMetadataSectionMask,
    InputControlAEAvailableTargetFPSRanges            = ControlAEAvailableTargetFPSRanges            | InputMetadataSectionMask,
    InputControlAECompensationRange                   = ControlAECompensationRange                   | InputMetadataSectionMask,
    InputControlAECompensationStep                    = ControlAECompensationStep                    | InputMetadataSectionMask,
    InputControlAFAvailableModes                      = ControlAFAvailableModes                      | InputMetadataSectionMask,
    InputControlAvailableEffects                      = ControlAvailableEffects                      | InputMetadataSectionMask,
    InputControlAvailableSceneModes                   = ControlAvailableSceneModes                   | InputMetadataSectionMask,
    InputControlAvailableVideoStabilizationModes      = ControlAvailableVideoStabilizationModes      | InputMetadataSectionMask,
    InputControlAWBAvailableModes                     = ControlAWBAvailableModes                     | InputMetadataSectionMask,
    InputControlMaxRegions                            = ControlMaxRegions                            | InputMetadataSectionMask,
    InputControlSceneModeOverrides                    = ControlSceneModeOverrides                    | InputMetadataSectionMask,
    InputControlAEPrecaptureId                        = ControlAEPrecaptureId                        | InputMetadataSectionMask,
    InputControlAEState                               = ControlAEState                               | InputMetadataSectionMask,
    InputControlAFState                               = ControlAFState                               | InputMetadataSectionMask,
    InputControlAFTriggerId                           = ControlAFTriggerId                           | InputMetadataSectionMask,
    InputControlAWBState                              = ControlAWBState                              | InputMetadataSectionMask,
    InputControlAvailableHighSpeedVideoConfigurations = ControlAvailableHighSpeedVideoConfigurations | InputMetadataSectionMask,
    InputControlAELockAvailable                       = ControlAELockAvailable                       | InputMetadataSectionMask,
    InputControlAWBLockAvailable                      = ControlAWBLockAvailable                      | InputMetadataSectionMask,
    InputControlAvailableModes                        = ControlAvailableModes                        | InputMetadataSectionMask,
    InputControlPostRawSensitivityBoostRange          = ControlPostRawSensitivityBoostRange          | InputMetadataSectionMask,
    InputControlPostRawSensitivityBoost               = ControlPostRawSensitivityBoost               | InputMetadataSectionMask,
    InputControlZslEnable                             = ControlZslEnable                             | InputMetadataSectionMask,
    InputControlAFSceneChange                         = ControlAFSceneChange                         | InputMetadataSectionMask,
    InputControlExtendedSceneMode                     = ControlExtendedSceneMode                     | InputMetadataSectionMask,
    InputControlZoomRatio                             = ControlZoomRatio                             | InputMetadataSectionMask,
    InputControlEnd                                   = ControlEnd                                   | InputMetadataSectionMask,

    InputDemosaicMode                                 = DemosaicMode                                 | InputMetadataSectionMask,
    InputDemosaicEnd                                  = DemosaicEnd                                  | InputMetadataSectionMask,

    InputEdgeMode                                     = EdgeMode                                     | InputMetadataSectionMask,
    InputEdgeStrength                                 = EdgeStrength                                 | InputMetadataSectionMask,
    InputEdgeAvailableEdgeModes                       = EdgeAvailableEdgeModes                       | InputMetadataSectionMask,
    InputEdgeEnd                                      = EdgeEnd                                      | InputMetadataSectionMask,

    InputFlashFiringPower                             = FlashFiringPower                             | InputMetadataSectionMask,
    InputFlashFiringTime                              = FlashFiringTime                              | InputMetadataSectionMask,
    InputFlashMode                                    = FlashMode                                    | InputMetadataSectionMask,
    InputFlashColorTemperature                        = FlashColorTemperature                        | InputMetadataSectionMask,
    InputFlashMaxEnergy                               = FlashMaxEnergy                               | InputMetadataSectionMask,
    InputFlashState                                   = FlashState                                   | InputMetadataSectionMask,
    InputFlashEnd                                     = FlashEnd                                     | InputMetadataSectionMask,

    InputFlashInfoAvailable                           = FlashInfoAvailable                           | InputMetadataSectionMask,
    InputFlashInfoChargeDuration                      = FlashInfoChargeDuration                      | InputMetadataSectionMask,
    InputFlashInfoEnd                                 = FlashInfoEnd                                 | InputMetadataSectionMask,

    InputHotPixelMode                                 = HotPixelMode                                 | InputMetadataSectionMask,
    InputHotPixelAvailableHotPixelModes               = HotPixelAvailableHotPixelModes               | InputMetadataSectionMask,
    InputHotPixelEnd                                  = HotPixelEnd                                  | InputMetadataSectionMask,

    InputJPEGGpsCoordinates                           = JPEGGpsCoordinates                           | InputMetadataSectionMask,
    InputJPEGGpsProcessingMethod                      = JPEGGpsProcessingMethod                      | InputMetadataSectionMask,
    InputJPEGGpsTimestamp                             = JPEGGpsTimestamp                             | InputMetadataSectionMask,
    InputJPEGOrientation                              = JPEGOrientation                              | InputMetadataSectionMask,
    InputJPEGQuality                                  = JPEGQuality                                  | InputMetadataSectionMask,
    InputJPEGThumbnailQuality                         = JPEGThumbnailQuality                         | InputMetadataSectionMask,
    InputJPEGThumbnailSize                            = JPEGThumbnailSizeTag                         | InputMetadataSectionMask,
    InputJPEGAvailableThumbnailSizes                  = JPEGAvailableThumbnailSizes                  | InputMetadataSectionMask,
    InputJPEGMaxSize                                  = JPEGMaxSize                                  | InputMetadataSectionMask,
    InputJPEGSize                                     = JPEGSize                                     | InputMetadataSectionMask,
    InputJPEGEnd                                      = JPEGEnd                                      | InputMetadataSectionMask,

    InputLensAperture                                 = LensAperture                                 | InputMetadataSectionMask,
    InputLensFilterDensity                            = LensFilterDensity                            | InputMetadataSectionMask,
    InputLensFocalLength                              = LensFocalLength                              | InputMetadataSectionMask,
    InputLensFocusDistance                            = LensFocusDistance                            | InputMetadataSectionMask,
    InputLensOpticalStabilizationMode                 = LensOpticalStabilizationMode                 | InputMetadataSectionMask,
    InputLensFacing                                   = LensFacing                                   | InputMetadataSectionMask,
    InputLensPoseRotation                             = LensPoseRotation                             | InputMetadataSectionMask,
    InputLensPoseTranslation                          = LensPoseTranslation                          | InputMetadataSectionMask,
    InputLensFocusRange                               = LensFocusRange                               | InputMetadataSectionMask,
    InputLensState                                    = LensState                                    | InputMetadataSectionMask,
    InputLensIntrinsicCalibration                     = LensIntrinsicCalibration                     | InputMetadataSectionMask,
    InputLensRadialDistortion                         = LensRadialDistortion                         | InputMetadataSectionMask,
    InputLensPoseReference                            = LensPoseReference                            | InputMetadataSectionMask,
    InputLensDistortion                               = LensDistortion                               | InputMetadataSectionMask,
    InputLensEnd                                      = LensEnd                                      | InputMetadataSectionMask,

    InputLensInfoAvailableApertures                   = LensInfoAvailableApertures                   | InputMetadataSectionMask,
    InputLensInfoAvailableFilterDensities             = LensInfoAvailableFilterDensities             | InputMetadataSectionMask,
    InputLensInfoAvailableFocalLengths                = LensInfoAvailableFocalLengths                | InputMetadataSectionMask,
    InputLensInfoAvailableOpticalStabilization        = LensInfoAvailableOpticalStabilization        | InputMetadataSectionMask,
    InputLensInfoHyperfocalDistance                   = LensInfoHyperfocalDistance                   | InputMetadataSectionMask,
    InputLensInfoMinimumFocusDistance                 = LensInfoMinimumFocusDistance                 | InputMetadataSectionMask,
    InputLensInfoShadingMapSize                       = LensInfoShadingMapSize                       | InputMetadataSectionMask,
    InputLensInfoFocusDistanceCalibration             = LensInfoFocusDistanceCalibration             | InputMetadataSectionMask,
    InputLensInfoEnd                                  = LensInfoEnd                                  | InputMetadataSectionMask,

    InputNoiseReductionMode                           = NoiseReductionMode                           | InputMetadataSectionMask,
    InputNoiseReductionStrength                       = NoiseReductionStrength                       | InputMetadataSectionMask,
    InputNoiseReductionAvailableNoiseReductionModes   = NoiseReductionAvailableNoiseReductionModes   | InputMetadataSectionMask,
    InputNoiseReductionEnd                            = NoiseReductionEnd                            | InputMetadataSectionMask,

    InputQuirksMeteringCropRegion                     = QuirksMeteringCropRegion                     | InputMetadataSectionMask,
    InputQuirksTriggerAFWithAuto                      = QuirksTriggerAFWithAuto                      | InputMetadataSectionMask,
    InputQuirksUseZslFormat                           = QuirksUseZslFormat                           | InputMetadataSectionMask,
    InputQuirksUsePartialResult                       = QuirksUsePartialResult                       | InputMetadataSectionMask,
    InputQuirksPartialResult                          = QuirksPartialResult                          | InputMetadataSectionMask,
    InputQuirksEnd                                    = QuirksEnd                                    | InputMetadataSectionMask,

    InputRequestFrameCount                            = RequestFrameCount                            | InputMetadataSectionMask,
    InputRequestId                                    = RequestId                                    | InputMetadataSectionMask,
    InputRequestInputStreams                          = RequestInputStreams                          | InputMetadataSectionMask,
    InputRequestMetadataMode                          = RequestMetadataMode                          | InputMetadataSectionMask,
    InputRequestOutputStreams                         = RequestOutputStreams                         | InputMetadataSectionMask,
    InputRequestType                                  = RequestType                                  | InputMetadataSectionMask,
    InputRequestMaxNumOutputStreams                   = RequestMaxNumOutputStreams                   | InputMetadataSectionMask,
    InputRequestMaxNumReprocessStreams                = RequestMaxNumReprocessStreams                | InputMetadataSectionMask,
    InputRequestMaxNumInputStreams                    = RequestMaxNumInputStreams                    | InputMetadataSectionMask,
    InputRequestPipelineDepth                         = RequestPipelineDepth                         | InputMetadataSectionMask,
    InputRequestPipelineMaxDepth                      = RequestPipelineMaxDepth                      | InputMetadataSectionMask,
    InputRequestPartialResultCount                    = RequestPartialResultCount                    | InputMetadataSectionMask,
    InputRequestAvailableCapabilities                 = RequestAvailableCapabilities                 | InputMetadataSectionMask,
    InputRequestAvailableRequestKeys                  = RequestAvailableRequestKeys                  | InputMetadataSectionMask,
    InputRequestAvailableResultKeys                   = RequestAvailableResultKeys                   | InputMetadataSectionMask,
    InputRequestAvailableCharacteristicsKeys          = RequestAvailableCharacteristicsKeys          | InputMetadataSectionMask,
    InputRequestAvailableSessionKeys                  = RequestAvailableSessionKeys                  | InputMetadataSectionMask,
    InputRequestAvailablePhysicalCameraRequestKeys    = RequestAvailablePhysicalCameraRequestKeys    | InputMetadataSectionMask,
    InputRequestCharacteristicKeysNeedingPermission   = RequestCharacteristicKeysNeedingPermission   | InputMetadataSectionMask,
    InputRequestEnd                                   = RequestEnd                                   | InputMetadataSectionMask,

    InputScalerCropRegion                             = ScalerCropRegion                             | InputMetadataSectionMask,
    InputScalerAvailableFormats                       = ScalerAvailableFormats                       | InputMetadataSectionMask,
    InputScalerAvailableJPEGMinDurations              = ScalerAvailableJPEGMinDurations              | InputMetadataSectionMask,
    InputScalerAvailableJPEGSizes                     = ScalerAvailableJPEGSizes                     | InputMetadataSectionMask,
    InputScalerAvailableMaxDigitalZoom                = ScalerAvailableMaxDigitalZoom                | InputMetadataSectionMask,
    InputScalerAvailableProcessedMinDurations         = ScalerAvailableProcessedMinDurations         | InputMetadataSectionMask,
    InputScalerAvailableProcessedSizes                = ScalerAvailableProcessedSizes                | InputMetadataSectionMask,
    InputScalerAvailableRawMinDurations               = ScalerAvailableRawMinDurations               | InputMetadataSectionMask,
    InputScalerAvailableRawSizes                      = ScalerAvailableRawSizes                      | InputMetadataSectionMask,
    InputScalerAvailableInputOutputFormatsMap         = ScalerAvailableInputOutputFormatsMap         | InputMetadataSectionMask,
    InputScalerAvailableStreamConfigurations          = ScalerAvailableStreamConfigurations          | InputMetadataSectionMask,
    InputScalerAvailableMinFrameDurations             = ScalerAvailableMinFrameDurations             | InputMetadataSectionMask,
    InputScalerAvailableStallDurations                = ScalerAvailableStallDurations                | InputMetadataSectionMask,
    InputScalerCroppingType                           = ScalerCroppingType                           | InputMetadataSectionMask,
    InputScalerEnd                                    = ScalerEnd                                    | InputMetadataSectionMask,

    InputSensorExposureTime                           = SensorExposureTime                           | InputMetadataSectionMask,
    InputSensorFrameDuration                          = SensorFrameDuration                          | InputMetadataSectionMask,
    InputSensorSensitivity                            = SensorSensitivity                            | InputMetadataSectionMask,
    InputSensorReferenceIlluminant1                   = SensorReferenceIlluminant1                   | InputMetadataSectionMask,
    InputSensorReferenceIlluminant2                   = SensorReferenceIlluminant2                   | InputMetadataSectionMask,
    InputSensorCalibrationTransform1                  = SensorCalibrationTransform1                  | InputMetadataSectionMask,
    InputSensorCalibrationTransform2                  = SensorCalibrationTransform2                  | InputMetadataSectionMask,
    InputSensorColorTransform1                        = SensorColorTransform1                        | InputMetadataSectionMask,
    InputSensorColorTransform2                        = SensorColorTransform2                        | InputMetadataSectionMask,
    InputSensorForwardMatrix1                         = SensorForwardMatrix1                         | InputMetadataSectionMask,
    InputSensorForwardMatrix2                         = SensorForwardMatrix2                         | InputMetadataSectionMask,
    InputSensorBaseGainFactor                         = SensorBaseGainFactor                         | InputMetadataSectionMask,
    InputSensorBlackLevelPattern                      = SensorBlackLevelPattern                      | InputMetadataSectionMask,
    InputSensorMaxAnalogSensitivity                   = SensorMaxAnalogSensitivity                   | InputMetadataSectionMask,
    InputSensorOrientation                            = SensorOrientation                            | InputMetadataSectionMask,
    InputSensorProfileHueSaturationMapDimensions      = SensorProfileHueSaturationMapDimensions      | InputMetadataSectionMask,
    InputSensorTimestamp                              = SensorTimestamp                              | InputMetadataSectionMask,
    InputSensorTemperature                            = SensorTemperature                            | InputMetadataSectionMask,
    InputSensorNeutralColorPoint                      = SensorNeutralColorPoint                      | InputMetadataSectionMask,
    InputSensorNoiseProfile                           = SensorNoiseProfile                           | InputMetadataSectionMask,
    InputSensorProfileHueSaturationMap                = SensorProfileHueSaturationMap                | InputMetadataSectionMask,
    InputSensorProfileToneCurve                       = SensorProfileToneCurve                       | InputMetadataSectionMask,
    InputSensorGreenSplit                             = SensorGreenSplit                             | InputMetadataSectionMask,
    InputSensorTestPatternData                        = SensorTestPatternData                        | InputMetadataSectionMask,
    InputSensorTestPatternMode                        = SensorTestPatternMode                        | InputMetadataSectionMask,
    InputSensorAvailableTestPatternModes              = SensorAvailableTestPatternModes              | InputMetadataSectionMask,
    InputSensorRollingShutterSkew                     = SensorRollingShutterSkew                     | InputMetadataSectionMask,
    InputSensorDynamicBlackLevel                      = SensorDynamicBlackLevel                      | InputMetadataSectionMask,
    InputSensorDynamicWhiteLevel                      = SensorDynamicWhiteLevel                      | InputMetadataSectionMask,
    InputSensorEnd                                    = SensorEnd                                    | InputMetadataSectionMask,

    InputSensorInfoActiveArraySize                    = SensorInfoActiveArraySize                    | InputMetadataSectionMask,
    InputSensorInfoSensitivityRange                   = SensorInfoSensitivityRange                   | InputMetadataSectionMask,
    InputSensorInfoColorFilterArrangement             = SensorInfoColorFilterArrangement             | InputMetadataSectionMask,
    InputSensorInfoExposureTimeRange                  = SensorInfoExposureTimeRange                  | InputMetadataSectionMask,
    InputSensorInfoMaxFrameDuration                   = SensorInfoMaxFrameDuration                   | InputMetadataSectionMask,
    InputSensorInfoPhysicalSize                       = SensorInfoPhysicalSize                       | InputMetadataSectionMask,
    InputSensorInfoPixelArraySize                     = SensorInfoPixelArraySize                     | InputMetadataSectionMask,
    InputSensorInfoWhiteLevel                         = SensorInfoWhiteLevel                         | InputMetadataSectionMask,
    InputSensorInfoTimestampSource                    = SensorInfoTimestampSource                    | InputMetadataSectionMask,
    InputSensorInfoLensShadingApplied                 = SensorInfoLensShadingApplied                 | InputMetadataSectionMask,
    InputSensorInfoPreCorrectionActiveArraySize       = SensorInfoPreCorrectionActiveArraySize       | InputMetadataSectionMask,
    InputSensorInfoEnd                                = SensorInfoEnd                                | InputMetadataSectionMask,

    InputShadingMode                                  = ShadingMode                                  | InputMetadataSectionMask,
    InputShadingStrength                              = ShadingStrength                              | InputMetadataSectionMask,
    InputShadingAvailableModes                        = ShadingAvailableModes                        | InputMetadataSectionMask,
    InputShadingEnd                                   = ShadingEnd                                   | InputMetadataSectionMask,

    InputStatisticsFaceDetectMode                     = StatisticsFaceDetectMode                     | InputMetadataSectionMask,
    InputStatisticsHistogramMode                      = StatisticsHistogramMode                      | InputMetadataSectionMask,
    InputStatisticsSharpnessMapMode                   = StatisticsSharpnessMapMode                   | InputMetadataSectionMask,
    InputStatisticsHotPixelMapMode                    = StatisticsHotPixelMapMode                    | InputMetadataSectionMask,
    InputStatisticsFaceIds                            = StatisticsFaceIds                            | InputMetadataSectionMask,
    InputStatisticsFaceLandmarks                      = StatisticsFaceLandmarks                      | InputMetadataSectionMask,
    InputStatisticsFaceRectangles                     = StatisticsFaceRectangles                     | InputMetadataSectionMask,
    InputStatisticsFaceScores                         = StatisticsFaceScores                         | InputMetadataSectionMask,
    InputStatisticsHistogram                          = StatisticsHistogram                          | InputMetadataSectionMask,
    InputStatisticsSharpnessMap                       = StatisticsSharpnessMap                       | InputMetadataSectionMask,
    InputStatisticsLensShadingCorrectionMap           = StatisticsLensShadingCorrectionMap           | InputMetadataSectionMask,
    InputStatisticsLensShadingMap                     = StatisticsLensShadingMap                     | InputMetadataSectionMask,
    InputStatisticsPredictedColorGains                = StatisticsPredictedColorGains                | InputMetadataSectionMask,
    InputStatisticsPredictedColorTransform            = StatisticsPredictedColorTransform            | InputMetadataSectionMask,
    InputStatisticsSceneFlicker                       = StatisticsSceneFlicker                       | InputMetadataSectionMask,
    InputStatisticsHotPixelMap                        = StatisticsHotPixelMap                        | InputMetadataSectionMask,
    InputStatisticsLensShadingMapMode                 = StatisticsLensShadingMapMode                 | InputMetadataSectionMask,
    InputStatisticsOISDataMode                        = StatisticsOISDataMode                        | InputMetadataSectionMask,
    InputStatisticsOISTimestamps                      = StatisticsOISTimestamps                      | InputMetadataSectionMask,
    InputStatisticsOISXShifts                         = StatisticsOISXShifts                         | InputMetadataSectionMask,
    InputStatisticsOISYShifts                         = StatisticsOISYShifts                         | InputMetadataSectionMask,
    InputStatisticsEnd                                = StatisticsEnd                                | InputMetadataSectionMask,

    InputStatisticsInfoAvailableFaceDetectModes       = StatisticsInfoAvailableFaceDetectModes       | InputMetadataSectionMask,
    InputStatisticsInfoHistogramBucketCount           = StatisticsInfoHistogramBucketCount           | InputMetadataSectionMask,
    InputStatisticsInfoMaxFaceCount                   = StatisticsInfoMaxFaceCount                   | InputMetadataSectionMask,
    InputStatisticsInfoMaxHistogramCount              = StatisticsInfoMaxHistogramCount              | InputMetadataSectionMask,
    InputStatisticsInfoMaxSharpnessMapValue           = StatisticsInfoMaxSharpnessMapValue           | InputMetadataSectionMask,
    InputStatisticsInfoSharpnessMapSize               = StatisticsInfoSharpnessMapSize               | InputMetadataSectionMask,
    InputStatisticsInfoAvailableHotPixelMapModes      = StatisticsInfoAvailableHotPixelMapModes      | InputMetadataSectionMask,
    InputStatisticsInfoAvailableLensShadingMapModes   = StatisticsInfoAvailableLensShadingMapModes   | InputMetadataSectionMask,
    InputStatisticsInfoEnd                            = StatisticsInfoEnd                            | InputMetadataSectionMask,

    InputTonemapCurveBlue                             = TonemapCurveBlue                             | InputMetadataSectionMask,
    InputTonemapCurveGreen                            = TonemapCurveGreen                            | InputMetadataSectionMask,
    InputTonemapCurveRed                              = TonemapCurveRed                              | InputMetadataSectionMask,
    InputTonemapMode                                  = TonemapMode                                  | InputMetadataSectionMask,
    InputTonemapMaxCurvePoints                        = TonemapMaxCurvePoints                        | InputMetadataSectionMask,
    InputTonemapAvailableToneMapModes                 = TonemapAvailableToneMapModes                 | InputMetadataSectionMask,
    InputTonemapGamma                                 = TonemapGamma                                 | InputMetadataSectionMask,
    InputTonemapPresetCurve                           = TonemapPresetCurve                           | InputMetadataSectionMask,
    InputTonemapEnd                                   = TonemapEnd                                   | InputMetadataSectionMask,

    InputLedTransmit                                  = LedTransmit                                  | InputMetadataSectionMask,
    InputLedAvailableLeds                             = LedAvailableLeds                             | InputMetadataSectionMask,
    InputLedEnd                                       = LedEnd                                       | InputMetadataSectionMask,

    InputInfoSupportedHardwareLevel                   = InfoSupportedHardwareLevel                   | InputMetadataSectionMask,
    InputInfoEnd                                      = InfoEnd                                      | InputMetadataSectionMask,

    InputBlackLevelLock                               = BlackLevelLock                               | InputMetadataSectionMask,
    InputBlackLevelEnd                                = BlackLevelEnd                                | InputMetadataSectionMask,

    InputSyncFrameNumber                              = SyncFrameNumber                              | InputMetadataSectionMask,
    InputSyncMaxLatency                               = SyncMaxLatency                               | InputMetadataSectionMask,
    InputSyncEnd                                      = SyncEnd                                      | InputMetadataSectionMask,

    InputReprocessEffectiveExposureFactor             = ReprocessEffectiveExposureFactor             | InputMetadataSectionMask,
    InputReprocessMaxCaptureStall                     = ReprocessMaxCaptureStall                     | InputMetadataSectionMask,
    InputReprocessEnd                                 = ReprocessEnd                                 | InputMetadataSectionMask,

    InputDepthMaxDepthSamples                         = DepthMaxDepthSamples                         | InputMetadataSectionMask,
    InputDepthAvailableDepthStreamConfigurations      = DepthAvailableDepthStreamConfigurations      | InputMetadataSectionMask,
    InputDepthAvailableDepthMinFrameDurations         = DepthAvailableDepthMinFrameDurations         | InputMetadataSectionMask,
    InputDepthAvailableDepthStallDurations            = DepthAvailableDepthStallDurations            | InputMetadataSectionMask,
    InputDepthDepthIsExclusive                        = DepthDepthIsExclusive                        | InputMetadataSectionMask,
    InputDepthEnd                                     = DepthEnd                                     | InputMetadataSectionMask,
    InputLogicalMultiCameraPhysicalIDs                = LogicalMultiCameraPhysicalIDs                | InputMetadataSectionMask,
    InputLogicalMultiCameraSensorSyncType             = LogicalMultiCameraSensorSyncType             | InputMetadataSectionMask,
    InputLogicalMultiCameraEnd                        = LogicalMultiCameraEnd                        | InputMetadataSectionMask,

    StaticColorCorrectionMode                             = ColorCorrectionMode                             | StaticMetadataSectionMask,
    StaticColorCorrectionTransform                        = ColorCorrectionTransform                        | StaticMetadataSectionMask,
    StaticColorCorrectionGains                            = ColorCorrectionGains                            | StaticMetadataSectionMask,
    StaticColorCorrectionAberrationMode                   = ColorCorrectionAberrationMode                   | StaticMetadataSectionMask,
    StaticColorCorrectionAvailableAberrationModes         = ColorCorrectionAvailableAberrationModes         | StaticMetadataSectionMask,
    StaticColorCorrectionEnd                              = ColorCorrectionEnd                              | StaticMetadataSectionMask,

    StaticControlAEAntibandingMode                        = ControlAEAntibandingMode                        | StaticMetadataSectionMask,
    StaticControlAEExposureCompensation                   = ControlAEExposureCompensation                   | StaticMetadataSectionMask,
    StaticControlAELock                                   = ControlAELock                                   | StaticMetadataSectionMask,
    StaticControlAEMode                                   = ControlAEMode                                   | StaticMetadataSectionMask,
    StaticControlAERegions                                = ControlAERegions                                | StaticMetadataSectionMask,
    StaticControlAETargetFpsRange                         = ControlAETargetFpsRange                         | StaticMetadataSectionMask,
    StaticControlAEPrecaptureTrigger                      = ControlAEPrecaptureTrigger                      | StaticMetadataSectionMask,
    StaticControlAFMode                                   = ControlAFMode                                   | StaticMetadataSectionMask,
    StaticControlAFRegions                                = ControlAFRegions                                | StaticMetadataSectionMask,
    StaticControlAFTrigger                                = ControlAFTrigger                                | StaticMetadataSectionMask,
    StaticControlAWBLock                                  = ControlAWBLock                                  | StaticMetadataSectionMask,
    StaticControlAWBMode                                  = ControlAWBMode                                  | StaticMetadataSectionMask,
    StaticControlAWBRegions                               = ControlAWBRegions                               | StaticMetadataSectionMask,
    StaticControlCaptureIntent                            = ControlCaptureIntent                            | StaticMetadataSectionMask,
    StaticControlEffectMode                               = ControlEffectMode                               | StaticMetadataSectionMask,
    StaticControlMode                                     = ControlMode                                     | StaticMetadataSectionMask,
    StaticControlSceneMode                                = ControlSceneMode                                | StaticMetadataSectionMask,
    StaticControlVideoStabilizationMode                   = ControlVideoStabilizationMode                   | StaticMetadataSectionMask,
    StaticControlAEAvailableAntibandingModes              = ControlAEAvailableAntibandingModes              | StaticMetadataSectionMask,
    StaticControlAEAvailableModes                         = ControlAEAvailableModes                         | StaticMetadataSectionMask,
    StaticControlAEAvailableTargetFPSRanges               = ControlAEAvailableTargetFPSRanges               | StaticMetadataSectionMask,
    StaticControlAECompensationRange                      = ControlAECompensationRange                      | StaticMetadataSectionMask,
    StaticControlAECompensationStep                       = ControlAECompensationStep                       | StaticMetadataSectionMask,
    StaticControlAFAvailableModes                         = ControlAFAvailableModes                         | StaticMetadataSectionMask,
    StaticControlAvailableEffects                         = ControlAvailableEffects                         | StaticMetadataSectionMask,
    StaticControlAvailableSceneModes                      = ControlAvailableSceneModes                      | StaticMetadataSectionMask,
    StaticControlAvailableVideoStabilizationModes         = ControlAvailableVideoStabilizationModes         | StaticMetadataSectionMask,
    StaticControlAWBAvailableModes                        = ControlAWBAvailableModes                        | StaticMetadataSectionMask,
    StaticControlMaxRegions                               = ControlMaxRegions                               | StaticMetadataSectionMask,
    StaticControlSceneModeOverrides                       = ControlSceneModeOverrides                       | StaticMetadataSectionMask,
    StaticControlAEPrecaptureId                           = ControlAEPrecaptureId                           | StaticMetadataSectionMask,
    StaticControlAEState                                  = ControlAEState                                  | StaticMetadataSectionMask,
    StaticControlAFState                                  = ControlAFState                                  | StaticMetadataSectionMask,
    StaticControlAFTriggerId                              = ControlAFTriggerId                              | StaticMetadataSectionMask,
    StaticControlAWBState                                 = ControlAWBState                                 | StaticMetadataSectionMask,
    StaticControlAvailableHighSpeedVideoConfigurations    = ControlAvailableHighSpeedVideoConfigurations    | StaticMetadataSectionMask,
    StaticControlAELockAvailable                          = ControlAELockAvailable                          | StaticMetadataSectionMask,
    StaticControlAWBLockAvailable                         = ControlAWBLockAvailable                         | StaticMetadataSectionMask,
    StaticControlAvailableModes                           = ControlAvailableModes                           | StaticMetadataSectionMask,
    StaticControlPostRawSensitivityBoostRange             = ControlPostRawSensitivityBoostRange             | StaticMetadataSectionMask,
    StaticControlPostRawSensitivityBoost                  = ControlPostRawSensitivityBoost                  | StaticMetadataSectionMask,
#if ((CAMX_ANDROID_API) && (CAMX_ANDROID_API >= 30)) // Android-R or better
    StaticControlAvailableExtendedSceneModeMaxSizes         = ControlAvailableExtendedSceneModeMaxSizes         | StaticMetadataSectionMask,
    StaticControlAvailableExtendedSceneModeZoomRatioRanges  = ControlAvailableExtendedSceneModeZoomRatioRanges  | StaticMetadataSectionMask,
    StaticControlZoomRatioRange                             = ControlZoomRatioRange                             | StaticMetadataSectionMask,
#endif // Android-R or better
    StaticControlEnd                                      = ControlEnd                                      | StaticMetadataSectionMask,

    StaticDemosaicMode                                    = DemosaicMode                                    | StaticMetadataSectionMask,
    StaticDemosaicEnd                                     = DemosaicEnd                                     | StaticMetadataSectionMask,

    StaticEdgeMode                                        = EdgeMode                                        | StaticMetadataSectionMask,
    StaticEdgeStrength                                    = EdgeStrength                                    | StaticMetadataSectionMask,
    StaticEdgeAvailableEdgeModes                          = EdgeAvailableEdgeModes                          | StaticMetadataSectionMask,
    StaticEdgeEnd                                         = EdgeEnd                                         | StaticMetadataSectionMask,

    StaticFlashFiringPower                                = FlashFiringPower                                | StaticMetadataSectionMask,
    StaticFlashFiringTime                                 = FlashFiringTime                                 | StaticMetadataSectionMask,
    StaticFlashMode                                       = FlashMode                                       | StaticMetadataSectionMask,
    StaticFlashColorTemperature                           = FlashColorTemperature                           | StaticMetadataSectionMask,
    StaticFlashMaxEnergy                                  = FlashMaxEnergy                                  | StaticMetadataSectionMask,
    StaticFlashState                                      = FlashState                                      | StaticMetadataSectionMask,
    StaticFlashEnd                                        = FlashEnd                                        | StaticMetadataSectionMask,

    StaticFlashInfoAvailable                              = FlashInfoAvailable                              | StaticMetadataSectionMask,
    StaticFlashInfoChargeDuration                         = FlashInfoChargeDuration                         | StaticMetadataSectionMask,
    StaticFlashInfoEnd                                    = FlashInfoEnd                                    | StaticMetadataSectionMask,

    StaticHotPixelMode                                    = HotPixelMode                                    | StaticMetadataSectionMask,
    StaticHotPixelAvailableHotPixelModes                  = HotPixelAvailableHotPixelModes                  | StaticMetadataSectionMask,
    StaticHotPixelEnd                                     = HotPixelEnd                                     | StaticMetadataSectionMask,

    StaticJPEGGpsCoordinates                              = JPEGGpsCoordinates                              | StaticMetadataSectionMask,
    StaticJPEGGpsProcessingMethod                         = JPEGGpsProcessingMethod                         | StaticMetadataSectionMask,
    StaticJPEGGpsTimestamp                                = JPEGGpsTimestamp                                | StaticMetadataSectionMask,
    StaticJPEGOrientation                                 = JPEGOrientation                                 | StaticMetadataSectionMask,
    StaticJPEGQuality                                     = JPEGQuality                                     | StaticMetadataSectionMask,
    StaticJPEGThumbnailQuality                            = JPEGThumbnailQuality                            | StaticMetadataSectionMask,
    StaticJPEGThumbnailSize                               = JPEGThumbnailSizeTag                            | StaticMetadataSectionMask,
    StaticJPEGAvailableThumbnailSizes                     = JPEGAvailableThumbnailSizes                     | StaticMetadataSectionMask,
    StaticJPEGMaxSize                                     = JPEGMaxSize                                     | StaticMetadataSectionMask,
    StaticJPEGSize                                        = JPEGSize                                        | StaticMetadataSectionMask,
    StaticJPEGEnd                                         = JPEGEnd                                         | StaticMetadataSectionMask,

    StaticLensAperture                                    = LensAperture                                    | StaticMetadataSectionMask,
    StaticLensFilterDensity                               = LensFilterDensity                               | StaticMetadataSectionMask,
    StaticLensFocalLength                                 = LensFocalLength                                 | StaticMetadataSectionMask,
    StaticLensFocusDistance                               = LensFocusDistance                               | StaticMetadataSectionMask,
    StaticLensOpticalStabilizationMode                    = LensOpticalStabilizationMode                    | StaticMetadataSectionMask,
    StaticLensFacing                                      = LensFacing                                      | StaticMetadataSectionMask,
    StaticLensPoseRotation                                = LensPoseRotation                                | StaticMetadataSectionMask,
    StaticLensPoseTranslation                             = LensPoseTranslation                             | StaticMetadataSectionMask,
    StaticLensFocusRange                                  = LensFocusRange                                  | StaticMetadataSectionMask,
    StaticLensState                                       = LensState                                       | StaticMetadataSectionMask,
    StaticLensIntrinsicCalibration                        = LensIntrinsicCalibration                        | StaticMetadataSectionMask,
    StaticLensRadialDistortion                            = LensRadialDistortion                            | StaticMetadataSectionMask,
    StaticLensPoseReference                               = LensPoseReference                               | StaticMetadataSectionMask,
    StaticLensDistortion                                  = LensDistortion                                  | StaticMetadataSectionMask,
    StaticLensEnd                                         = LensEnd                                         | StaticMetadataSectionMask,

    StaticLensInfoAvailableApertures                      = LensInfoAvailableApertures                      | StaticMetadataSectionMask,
    StaticLensInfoAvailableFilterDensities                = LensInfoAvailableFilterDensities                | StaticMetadataSectionMask,
    StaticLensInfoAvailableFocalLengths                   = LensInfoAvailableFocalLengths                   | StaticMetadataSectionMask,
    StaticLensInfoAvailableOpticalStabilization           = LensInfoAvailableOpticalStabilization           | StaticMetadataSectionMask,
    StaticLensInfoHyperfocalDistance                      = LensInfoHyperfocalDistance                      | StaticMetadataSectionMask,
    StaticLensInfoMinimumFocusDistance                    = LensInfoMinimumFocusDistance                    | StaticMetadataSectionMask,
    StaticLensInfoShadingMapSize                          = LensInfoShadingMapSize                          | StaticMetadataSectionMask,
    StaticLensInfoFocusDistanceCalibration                = LensInfoFocusDistanceCalibration                | StaticMetadataSectionMask,
    StaticLensInfoEnd                                     = LensInfoEnd                                     | StaticMetadataSectionMask,

    StaticNoiseReductionMode                              = NoiseReductionMode                              | StaticMetadataSectionMask,
    StaticNoiseReductionStrength                          = NoiseReductionStrength                          | StaticMetadataSectionMask,
    StaticNoiseReductionAvailableNoiseReductionModes      = NoiseReductionAvailableNoiseReductionModes      | StaticMetadataSectionMask,
    StaticNoiseReductionEnd                               = NoiseReductionEnd                               | StaticMetadataSectionMask,

    StaticQuirksMeteringCropRegion                        = QuirksMeteringCropRegion                        | StaticMetadataSectionMask,
    StaticQuirksTriggerAFWithAuto                         = QuirksTriggerAFWithAuto                         | StaticMetadataSectionMask,
    StaticQuirksUseZslFormat                              = QuirksUseZslFormat                              | StaticMetadataSectionMask,
    StaticQuirksUsePartialResult                          = QuirksUsePartialResult                          | StaticMetadataSectionMask,
    StaticQuirksPartialResult                             = QuirksPartialResult                             | StaticMetadataSectionMask,
    StaticQuirksEnd                                       = QuirksEnd                                       | StaticMetadataSectionMask,

    StaticRequestFrameCount                               = RequestFrameCount                               | StaticMetadataSectionMask,
    StaticRequestId                                       = RequestId                                       | StaticMetadataSectionMask,
    StaticRequestInputStreams                             = RequestInputStreams                             | StaticMetadataSectionMask,
    StaticRequestMetadataMode                             = RequestMetadataMode                             | StaticMetadataSectionMask,
    StaticRequestOutputStreams                            = RequestOutputStreams                            | StaticMetadataSectionMask,
    StaticRequestType                                     = RequestType                                     | StaticMetadataSectionMask,
    StaticRequestMaxNumOutputStreams                      = RequestMaxNumOutputStreams                      | StaticMetadataSectionMask,
    StaticRequestMaxNumReprocessStreams                   = RequestMaxNumReprocessStreams                   | StaticMetadataSectionMask,
    StaticRequestMaxNumInputStreams                       = RequestMaxNumInputStreams                       | StaticMetadataSectionMask,
    StaticRequestPipelineDepth                            = RequestPipelineDepth                            | StaticMetadataSectionMask,
    StaticRequestPipelineMaxDepth                         = RequestPipelineMaxDepth                         | StaticMetadataSectionMask,
    StaticRequestPartialResultCount                       = RequestPartialResultCount                       | StaticMetadataSectionMask,
    StaticRequestAvailableCapabilities                    = RequestAvailableCapabilities                    | StaticMetadataSectionMask,
    StaticRequestAvailableRequestKeys                     = RequestAvailableRequestKeys                     | StaticMetadataSectionMask,
    StaticRequestAvailableResultKeys                      = RequestAvailableResultKeys                      | StaticMetadataSectionMask,
    StaticRequestAvailableCharacteristicsKeys             = RequestAvailableCharacteristicsKeys             | StaticMetadataSectionMask,
    StaticRequestAvailableSessionKeys                     = RequestAvailableSessionKeys                     | StaticMetadataSectionMask,
    StaticRequestAvailablePhysicalCameraRequestKeys       = RequestAvailablePhysicalCameraRequestKeys       | StaticMetadataSectionMask,
    StaticRequestCharacteristicKeysNeedingPermission      = RequestCharacteristicKeysNeedingPermission      | StaticMetadataSectionMask,
    StaticRequestEnd                                      = RequestEnd                                      | StaticMetadataSectionMask,

    StaticScalerCropRegion                                = ScalerCropRegion                                | StaticMetadataSectionMask,
    StaticScalerAvailableFormats                          = ScalerAvailableFormats                          | StaticMetadataSectionMask,
    StaticScalerAvailableJPEGMinDurations                 = ScalerAvailableJPEGMinDurations                 | StaticMetadataSectionMask,
    StaticScalerAvailableJPEGSizes                        = ScalerAvailableJPEGSizes                        | StaticMetadataSectionMask,
    StaticScalerAvailableMaxDigitalZoom                   = ScalerAvailableMaxDigitalZoom                   | StaticMetadataSectionMask,
    StaticScalerAvailableProcessedMinDurations            = ScalerAvailableProcessedMinDurations            | StaticMetadataSectionMask,
    StaticScalerAvailableProcessedSizes                   = ScalerAvailableProcessedSizes                   | StaticMetadataSectionMask,
    StaticScalerAvailableRawMinDurations                  = ScalerAvailableRawMinDurations                  | StaticMetadataSectionMask,
    StaticScalerAvailableRawSizes                         = ScalerAvailableRawSizes                         | StaticMetadataSectionMask,
    StaticScalerAvailableInputOutputFormatsMap            = ScalerAvailableInputOutputFormatsMap            | StaticMetadataSectionMask,
    StaticScalerAvailableStreamConfigurations             = ScalerAvailableStreamConfigurations             | StaticMetadataSectionMask,
    StaticScalerAvailableMinFrameDurations                = ScalerAvailableMinFrameDurations                | StaticMetadataSectionMask,
    StaticScalerAvailableStallDurations                   = ScalerAvailableStallDurations                   | StaticMetadataSectionMask,
    StaticScalerCroppingType                              = ScalerCroppingType                              | StaticMetadataSectionMask,
    StaticScalerAvailableRecommendedStreamConfigurations  = ScalerAvailableRecommendedStreamConfigurations  | StaticMetadataSectionMask,
    StaticScalerAvailableRecommendedInputOutputFormatsMap = ScalerAvailableRecommendedInputOutputFormatsMap | StaticMetadataSectionMask,
    StaticScalerEnd                                       = ScalerEnd                                       | StaticMetadataSectionMask,

    StaticSensorExposureTime                              = SensorExposureTime                              | StaticMetadataSectionMask,
    StaticSensorFrameDuration                             = SensorFrameDuration                             | StaticMetadataSectionMask,
    StaticSensorSensitivity                               = SensorSensitivity                               | StaticMetadataSectionMask,
    StaticSensorReferenceIlluminant1                      = SensorReferenceIlluminant1                      | StaticMetadataSectionMask,
    StaticSensorReferenceIlluminant2                      = SensorReferenceIlluminant2                      | StaticMetadataSectionMask,
    StaticSensorCalibrationTransform1                     = SensorCalibrationTransform1                     | StaticMetadataSectionMask,
    StaticSensorCalibrationTransform2                     = SensorCalibrationTransform2                     | StaticMetadataSectionMask,
    StaticSensorColorTransform1                           = SensorColorTransform1                           | StaticMetadataSectionMask,
    StaticSensorColorTransform2                           = SensorColorTransform2                           | StaticMetadataSectionMask,
    StaticSensorForwardMatrix1                            = SensorForwardMatrix1                            | StaticMetadataSectionMask,
    StaticSensorForwardMatrix2                            = SensorForwardMatrix2                            | StaticMetadataSectionMask,
    StaticSensorBaseGainFactor                            = SensorBaseGainFactor                            | StaticMetadataSectionMask,
    StaticSensorBlackLevelPattern                         = SensorBlackLevelPattern                         | StaticMetadataSectionMask,
    StaticSensorMaxAnalogSensitivity                      = SensorMaxAnalogSensitivity                      | StaticMetadataSectionMask,
    StaticSensorOrientation                               = SensorOrientation                               | StaticMetadataSectionMask,
    StaticSensorProfileHueSaturationMapDimensions         = SensorProfileHueSaturationMapDimensions         | StaticMetadataSectionMask,
    StaticSensorTimestamp                                 = SensorTimestamp                                 | StaticMetadataSectionMask,
    StaticSensorTemperature                               = SensorTemperature                               | StaticMetadataSectionMask,
    StaticSensorNeutralColorPoint                         = SensorNeutralColorPoint                         | StaticMetadataSectionMask,
    StaticSensorNoiseProfile                              = SensorNoiseProfile                              | StaticMetadataSectionMask,
    StaticSensorProfileHueSaturationMap                   = SensorProfileHueSaturationMap                   | StaticMetadataSectionMask,
    StaticSensorProfileToneCurve                          = SensorProfileToneCurve                          | StaticMetadataSectionMask,
    StaticSensorGreenSplit                                = SensorGreenSplit                                | StaticMetadataSectionMask,
    StaticSensorTestPatternData                           = SensorTestPatternData                           | StaticMetadataSectionMask,
    StaticSensorTestPatternMode                           = SensorTestPatternMode                           | StaticMetadataSectionMask,
    StaticSensorAvailableTestPatternModes                 = SensorAvailableTestPatternModes                 | StaticMetadataSectionMask,
    StaticSensorRollingShutterSkew                        = SensorRollingShutterSkew                        | StaticMetadataSectionMask,
    StaticSensorOpaqueRawSize                             = SensorOpaqueRawSize                             | StaticMetadataSectionMask,
    StaticSensorEnd                                       = SensorEnd                                       | StaticMetadataSectionMask,

    StaticSensorInfoActiveArraySize                       = SensorInfoActiveArraySize                       | StaticMetadataSectionMask,
    StaticSensorInfoSensitivityRange                      = SensorInfoSensitivityRange                      | StaticMetadataSectionMask,
    StaticSensorInfoColorFilterArrangement                = SensorInfoColorFilterArrangement                | StaticMetadataSectionMask,
    StaticSensorInfoExposureTimeRange                     = SensorInfoExposureTimeRange                     | StaticMetadataSectionMask,
    StaticSensorInfoMaxFrameDuration                      = SensorInfoMaxFrameDuration                      | StaticMetadataSectionMask,
    StaticSensorInfoPhysicalSize                          = SensorInfoPhysicalSize                          | StaticMetadataSectionMask,
    StaticSensorInfoPixelArraySize                        = SensorInfoPixelArraySize                        | StaticMetadataSectionMask,
    StaticSensorInfoWhiteLevel                            = SensorInfoWhiteLevel                            | StaticMetadataSectionMask,
    StaticSensorInfoTimestampSource                       = SensorInfoTimestampSource                       | StaticMetadataSectionMask,
    StaticSensorInfoLensShadingApplied                    = SensorInfoLensShadingApplied                    | StaticMetadataSectionMask,
    StaticSensorInfoPreCorrectionActiveArraySize          = SensorInfoPreCorrectionActiveArraySize          | StaticMetadataSectionMask,
    StaticSensorInfoEnd                                   = SensorInfoEnd                                   | StaticMetadataSectionMask,

    StaticShadingMode                                     = ShadingMode                                     | StaticMetadataSectionMask,
    StaticShadingStrength                                 = ShadingStrength                                 | StaticMetadataSectionMask,
    StaticShadingAvailableModes                           = ShadingAvailableModes                           | StaticMetadataSectionMask,
    StaticShadingEnd                                      = ShadingEnd                                      | StaticMetadataSectionMask,

    StaticStatisticsFaceDetectMode                        = StatisticsFaceDetectMode                        | StaticMetadataSectionMask,
    StaticStatisticsHistogramMode                         = StatisticsHistogramMode                         | StaticMetadataSectionMask,
    StaticStatisticsSharpnessMapMode                      = StatisticsSharpnessMapMode                      | StaticMetadataSectionMask,
    StaticStatisticsHotPixelMapMode                       = StatisticsHotPixelMapMode                       | StaticMetadataSectionMask,
    StaticStatisticsFaceIds                               = StatisticsFaceIds                               | StaticMetadataSectionMask,
    StaticStatisticsFaceLandmarks                         = StatisticsFaceLandmarks                         | StaticMetadataSectionMask,
    StaticStatisticsFaceRectangles                        = StatisticsFaceRectangles                        | StaticMetadataSectionMask,
    StaticStatisticsFaceScores                            = StatisticsFaceScores                            | StaticMetadataSectionMask,
    StaticStatisticsHistogram                             = StatisticsHistogram                             | StaticMetadataSectionMask,
    StaticStatisticsSharpnessMap                          = StatisticsSharpnessMap                          | StaticMetadataSectionMask,
    StaticStatisticsLensShadingCorrectionMap              = StatisticsLensShadingCorrectionMap              | StaticMetadataSectionMask,
    StaticStatisticsLensShadingMap                        = StatisticsLensShadingMap                        | StaticMetadataSectionMask,
    StaticStatisticsPredictedColorGains                   = StatisticsPredictedColorGains                   | StaticMetadataSectionMask,
    StaticStatisticsPredictedColorTransform               = StatisticsPredictedColorTransform               | StaticMetadataSectionMask,
    StaticStatisticsSceneFlicker                          = StatisticsSceneFlicker                          | StaticMetadataSectionMask,
    StaticStatisticsHotPixelMap                           = StatisticsHotPixelMap                           | StaticMetadataSectionMask,
    StaticStatisticsLensShadingMapMode                    = StatisticsLensShadingMapMode                    | StaticMetadataSectionMask,
    StaticStatisticsEnd                                   = StatisticsEnd                                   | StaticMetadataSectionMask,

    StaticStatisticsInfoAvailableFaceDetectModes          = StatisticsInfoAvailableFaceDetectModes          | StaticMetadataSectionMask,
    StaticStatisticsInfoHistogramBucketCount              = StatisticsInfoHistogramBucketCount              | StaticMetadataSectionMask,
    StaticStatisticsInfoMaxFaceCount                      = StatisticsInfoMaxFaceCount                      | StaticMetadataSectionMask,
    StaticStatisticsInfoMaxHistogramCount                 = StatisticsInfoMaxHistogramCount                 | StaticMetadataSectionMask,
    StaticStatisticsInfoMaxSharpnessMapValue              = StatisticsInfoMaxSharpnessMapValue              | StaticMetadataSectionMask,
    StaticStatisticsInfoSharpnessMapSize                  = StatisticsInfoSharpnessMapSize                  | StaticMetadataSectionMask,
    StaticStatisticsInfoAvailableHotPixelMapModes         = StatisticsInfoAvailableHotPixelMapModes         | StaticMetadataSectionMask,
    StaticStatisticsInfoAvailableLensShadingMapModes      = StatisticsInfoAvailableLensShadingMapModes      | StaticMetadataSectionMask,
    StaticStatisticsInfoEnd                               = StatisticsInfoEnd                               | StaticMetadataSectionMask,

    StaticTonemapCurveBlue                                = TonemapCurveBlue                                | StaticMetadataSectionMask,
    StaticTonemapCurveGreen                               = TonemapCurveGreen                               | StaticMetadataSectionMask,
    StaticTonemapCurveRed                                 = TonemapCurveRed                                 | StaticMetadataSectionMask,
    StaticTonemapMode                                     = TonemapMode                                     | StaticMetadataSectionMask,
    StaticTonemapMaxCurvePoints                           = TonemapMaxCurvePoints                           | StaticMetadataSectionMask,
    StaticTonemapAvailableToneMapModes                    = TonemapAvailableToneMapModes                    | StaticMetadataSectionMask,
    StaticTonemapGamma                                    = TonemapGamma                                    | StaticMetadataSectionMask,
    StaticTonemapPresetCurve                              = TonemapPresetCurve                              | StaticMetadataSectionMask,
    StaticTonemapEnd                                      = TonemapEnd                                      | StaticMetadataSectionMask,

    StaticLedTransmit                                     = LedTransmit                                     | StaticMetadataSectionMask,
    StaticLedAvailableLeds                                = LedAvailableLeds                                | StaticMetadataSectionMask,
    StaticLedEnd                                          = LedEnd                                          | StaticMetadataSectionMask,

    StaticInfoSupportedHardwareLevel                      = InfoSupportedHardwareLevel                      | StaticMetadataSectionMask,
    StaticInfoVersion                                     = InfoVersion                                     | StaticMetadataSectionMask,
    StaticInfoSupportedBufferManagementVersion            = InfoSupportedBufferManagementVersion            | StaticMetadataSectionMask,
    StaticInfoEnd                                         = InfoEnd                                         | StaticMetadataSectionMask,

    StaticBlackLevelLock                                  = BlackLevelLock                                  | StaticMetadataSectionMask,
    StaticBlackLevelEnd                                   = BlackLevelEnd                                   | StaticMetadataSectionMask,

    StaticSyncFrameNumber                                 = SyncFrameNumber                                 | StaticMetadataSectionMask,
    StaticSyncMaxLatency                                  = SyncMaxLatency                                  | StaticMetadataSectionMask,
    StaticSyncEnd                                         = SyncEnd                                         | StaticMetadataSectionMask,

    StaticReprocessEffectiveExposureFactor                = ReprocessEffectiveExposureFactor                | StaticMetadataSectionMask,
    StaticReprocessMaxCaptureStall                        = ReprocessMaxCaptureStall                        | StaticMetadataSectionMask,
    StaticReprocessEnd                                    = ReprocessEnd                                    | StaticMetadataSectionMask,

    StaticDepthMaxDepthSamples                            = DepthMaxDepthSamples                            | StaticMetadataSectionMask,
    StaticDepthAvailableDepthStreamConfigurations         = DepthAvailableDepthStreamConfigurations         | StaticMetadataSectionMask,
    StaticDepthAvailableDepthMinFrameDurations            = DepthAvailableDepthMinFrameDurations            | StaticMetadataSectionMask,
    StaticDepthAvailableDepthStallDurations               = DepthAvailableDepthStallDurations               | StaticMetadataSectionMask,
    StaticDepthDepthIsExclusive                           = DepthDepthIsExclusive                           | StaticMetadataSectionMask,
    StaticDepthEnd                                        = DepthEnd                                        | StaticMetadataSectionMask,
    StaticLogicalMultiCameraPhysicalIDs                   = LogicalMultiCameraPhysicalIDs                   | StaticMetadataSectionMask,
    StaticLogicalMultiCameraSensorSyncType                = LogicalMultiCameraSensorSyncType                | StaticMetadataSectionMask,
    StaticLogicalMultiCameraEnd                           = LogicalMultiCameraEnd                           | StaticMetadataSectionMask,
    StaticHEICInfoSupported                               = HEICInfoSupported                               | StaticMetadataSectionMask,
    StaticHEICInfoMaxJpegAppSegmentsCount                 = HEICInfoMaxJpegAppSegmentsCount                 | StaticMetadataSectionMask,
    StaticHEICInfoSupportedEnd                            = HEICInfoEnd                                     | StaticMetadataSectionMask,
};

/// @brief Definition of the starting linear offset of each section
enum SectionLinearTagOffsets
{
    ColorCorrectionOffset       = 0,
    ControlOffset               = (ColorCorrectionOffset      + ColorCorrectionEnd      - MetadataSectionColorCorrectionStart),
    DemosaicOffset              = (ControlOffset              + ControlEnd              - MetadataSectionControlStart),
    EdgeOffset                  = (DemosaicOffset             + DemosaicEnd             - MetadataSectionDemosaicStart),
    FlashOffset                 = (EdgeOffset                 + EdgeEnd                 - MetadataSectionEdgeStart),
    FlashInfoOffset             = (FlashOffset                + FlashEnd                - MetadataSectionFlashStart),
    HotPixelOffset              = (FlashInfoOffset            + FlashInfoEnd            - MetadataSectionFlashInfoStart),
    JPEGOffset                  = (HotPixelOffset             + HotPixelEnd             - MetadataSectionHotPixelStart),
    LensOffset                  = (JPEGOffset                 + JPEGEnd                 - MetadataSectionJPEGStart),
    LensInfoOffset              = (LensOffset                 + LensEnd                 - MetadataSectionLensStart),
    NoiseReductionOffset        = (LensInfoOffset             + LensInfoEnd             - MetadataSectionLensInfoStart),
    QuirksOffset                = (NoiseReductionOffset       + NoiseReductionEnd       - MetadataSectionNoiseReductionStart),
    RequestOffset               = (QuirksOffset               + QuirksEnd               - MetadataSectionQuirksStart),
    ScalerOffset                = (RequestOffset              + RequestEnd              - MetadataSectionRequestStart),
    SensorOffset                = (ScalerOffset               + ScalerEnd               - MetadataSectionScalerStart),
    SensorInfoOffset            = (SensorOffset               + SensorEnd               - MetadataSectionSensorStart),
    ShadingOffset               = (SensorInfoOffset           + SensorInfoEnd           - MetadataSectionSensorInfoStart),
    StatisticsOffset            = (ShadingOffset              + ShadingEnd              - MetadataSectionShadingStart),
    StatisticsInfoOffset        = (StatisticsOffset           + StatisticsEnd           - MetadataSectionStatisticsStart),
    TonemapOffset               = (StatisticsInfoOffset       + StatisticsInfoEnd       - MetadataSectionStatisticsInfoStart),
    LedOffset                   = (TonemapOffset              + TonemapEnd              - MetadataSectionTonemapStart),
    InfoOffset                  = (LedOffset                  + LedEnd                  - MetadataSectionLedStart),
    BlackLevelOffset            = (InfoOffset                 + InfoEnd                 - MetadataSectionInfoStart),
    SyncOffset                  = (BlackLevelOffset           + BlackLevelEnd           - MetadataSectionBlackLevelStart),
    ReprocessOffset             = (SyncOffset                 + SyncEnd                 - MetadataSectionSyncStart),
    DepthOffset                 = (ReprocessOffset            + ReprocessEnd            - MetadataSectionReprocessStart),
    LogicalMultiCameraOffset    = (DepthOffset                + DepthEnd                - MetadataSectionDepthStart),
    DistortionCorrectionOffset  = (LogicalMultiCameraOffset   + LogicalMultiCameraEnd   - MetadataSectionLogicalMultiCameraStart),
    HEICOffset                  = (DistortionCorrectionOffset + DistortionCorrectionEnd - MetadataSectionDistortionCorrectionStart),
    HEICInfoOffset              = (HEICOffset                 + HEICEnd                 - MetadataSectionHEICStart),
    VendorSectionOffset         = (HEICInfoOffset             + HEICInfoEnd             - MetadataSectionHEICInfoStart),
};

/// @brief LUT for each section, allowing for a linear, contiguous id to be generated from tag. See CAMX_TAG_TO_INDEX
static const UINT32 SectionLinearTagLUT[] =
{
    ColorCorrectionOffset,
    ControlOffset,
    DemosaicOffset,
    EdgeOffset,
    FlashOffset,
    FlashInfoOffset,
    HotPixelOffset,
    JPEGOffset,
    LensOffset,
    LensInfoOffset,
    NoiseReductionOffset,
    QuirksOffset,
    RequestOffset,
    ScalerOffset,
    SensorOffset,
    SensorInfoOffset,
    ShadingOffset,
    StatisticsOffset,
    StatisticsInfoOffset,
    TonemapOffset,
    LedOffset,
    InfoOffset,
    BlackLevelOffset,
    SyncOffset,
    ReprocessOffset,
    DepthOffset,
    LogicalMultiCameraOffset,
    DistortionCorrectionOffset,
    HEICOffset,
    HEICInfoOffset,
    VendorSectionOffset,
};

/// @brief Maximum number of google fixed camera metadata tags
static const UINT MaxMetadataTagCount = VendorSectionOffset;

/// @brief Maximum number of available scaler formats
static const UINT MaxScalerFormats = 11;

/// @brief Maximum number of available scaler formats
static const UINT MaxOpaqueRawSizes = 11;

/// @brief Maximum number of available scaler recommended stream configs
static const UINT MaxScalerRecommendedStreamConfigs = 9;

// Number of SensorReferenceIlluminant1 values
static const UINT SensorReferenceIlluminant1ValueCount = 19;


// Number of defined SensorTestPatternMode values.
// Allowed values in the system may be greater as custom patterns are allowed.
static const UINT SensorTestPatternModeValuesCount = 6;

// Number of SyncFrameNumber values.
static const UINT SyncFrameNumberValuesCount = 2;

// Number of SyncMaxLatency values.
static const UINT SyncMaxLatencyValuesCount = 2;

// Maximum number of available depth formats
static const UINT MaxDepthFormats = 4;

/// @brief ICATransformType
enum IPEICATransformType
{
    DefaultTransform    = 0,
    InputTransform      = 1,
    ReferenceTransform  = 2
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// CameraMetadataTagToString
///
/// @brief  Returns a pointer to a const string which is a human readible representation of the metadata tag
///
/// @param  tag         Tag to stringize
/// @param  ppTagPrefix Pointer to a prefix string for the tag name
/// @param  ppTagName   Pointer to the string for the tag name
///
/// @return CamxResult status
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
CamxResult CameraMetadataTagToString(
    CameraMetadataTag   tag,
    const CHAR**        ppTagPrefix,
    const CHAR**        ppTagName);

CAMX_NAMESPACE_END

#endif // CAMXHAL3METADATATAGS_H
