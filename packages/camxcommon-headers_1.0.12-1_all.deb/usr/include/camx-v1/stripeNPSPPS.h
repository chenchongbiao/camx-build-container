#ifndef _STRIPENPSPPS_H_
#define _STRIPENPSPPS_H_

//-------------------------------------------------------------------------
// Copyright (c) 2015-2021 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.

//------------------------------------------------------------------------
// @file  stripeBPSPPS.h
// @brief IpeStripingLibraryOutputPerStripe Algorithm IPE Lower-layer, NPS and PPS
//------------------------------------------------------------------------

/*------------------------------------------------------------------------
*       Include Files
* ----------------------------------------------------------------------- */
#include "list.h"
#include "icpcomdef.h"
#include "modules.h"
#include "scalers.h"
#include "dsx_v10_stripe.h"
#include "stripedebug.h"

#ifdef __cplusplus
extern "C" {
#endif

/*------------------------------------------------------------------------
*       Definitions and Constants
* ----------------------------------------------------------------------- */

/** Defined by HW, line buffer size of IPE pipe */
#define STRIPING_LIB_IPE_LINE_BUFFER_SIZE         336

/** Dimension Constarints */

#define LTM_DC_MIN_WIDTH                           72
#define LTM_DC_MIN_HEIGHT                          54

/*------------------------------------------------------------------------
*       Type Declarations
* ----------------------------------------------------------------------- */

typedef enum _IPE_PASS
{
    IPE_FULL = 0,   // Default is INVALID.
    IPE_DC4,
    IPE_DC16,
    IPE_DC64,
    IPE_PASS_COUNT
} IPE_PASS;

typedef enum _IPE_MCTF_FLOW {
    IPE_MCTF_LEGACY    = 0,       // Default is LEGACY. This supports backward compatibility.
    IPE_MCTF_MIXED_LOOP,
    //IPE_OPEN,
    //IPE_CLOSED,
    IPE_MCTF_FLOW_COUNT           // Must always be last element
} IPE_MCTF_FLOW;

typedef struct _IpeStripingModule1dOutputStorage
{
    MNScaleDownInStruct_V20_1D          videoMndsLuma;
    MNScaleDownInStruct_V20_1D          videoMndsChroma;
    MNScaleDownInStruct_V20_1D          displayMndsLuma;
    MNScaleDownInStruct_V20_1D          displayMndsChroma;
    Upscalev20Striping1dOutputParams    upscalar;
    ChromaUpv201dStripingOutputParams   chromaup;
    LTMV13StripeDCParams                ltmDc;
    LTMV13StripeIPParams_1D             ltmIp;
    ANRv10Striping1dOutputParams        anr;
    TFv10Striping1dOutputParams         tf;
    DSXInStruct_V1D                     dsx;

    ChromaUpv201dStripingOutputParams   mfhdr_chromaup_T1L_MACin1_ICA2;
    ChromaUpv201dStripingOutputParams   mfhdr_chromaup_T2M_MACin2_MFHDR_FE;
    ChromaUpv201dStripingOutputParams   mfhdr_chromaup_T3S_MACin0_TF;
    LTMV13StripeDCParams                mfhdr_ltmDc;
    LTMV13StripeIPParams_1D             mfhdr_ltmIp;
    MNScaleDownInStruct_V20_1D          mfhdr_chromadn;

    CRCv10Striping1dOutputParams        tfFullOutCropLuma;
    CRCv10Striping1dOutputParams        tfFullOutCropChroma;
    CRCv10Striping1dOutputParams        ds4PreCropLuma;
    CRCv10Striping1dOutputParams        ds4PreCropChroma;
    CRCv10Striping1dOutputParams        tfDs4OutCropLuma;
    CRCv10Striping1dOutputParams        tfDs4OutCropChroma;
    CRCv10Striping1dOutputParams        mfhdr_T1L_MACin1_ICA2_preChromaupCropLuma;
    CRCv10Striping1dOutputParams        mfhdr_T1L_MACin1_ICA2_preChromaupCropChroma;
    CRCv10Striping1dOutputParams        mfhdr_T2M_MACin2_MFHDR_FE_preChromaupCropLuma;
    CRCv10Striping1dOutputParams        mfhdr_T2M_MACin2_MFHDR_FE_preChromaupCropChroma;
    CRCv10Striping1dOutputParams        mfhdr_T3S_MACin0_TF_preChromaupCropLuma;
    CRCv10Striping1dOutputParams        mfhdr_T3S_MACin0_TF_preChromaupCropChroma;
    CRCv10Striping1dOutputParams        mfhdrpreChromadnCropLuma;
    CRCv10Striping1dOutputParams        mfhdrpreChromadnCropChroma;
    CRCv10Striping1dOutputParams        preChromaupCropLuma;
    CRCv10Striping1dOutputParams        preChromaupCropChroma;
    CRCv10Striping1dOutputParams        preUpscalarCrop; // YUV 444 (same values for Luma and Chroma)
    CRCv10Striping1dOutputParams        preUpscalarCrop_c; // only for Mimas2.0 (ASF only in Luma path)
    CRCv10Striping1dOutputParams        ltmMultiPass_PostUpscale_Crop;
    // CRCv10Striping1dOutputParams        ltmMultiPass_MaxMin_PostUpscale;
    CRCv10Striping1dOutputParams        videoPreMndsCropLuma;
    CRCv10Striping1dOutputParams        videoPreMndsCropChroma;
    CRCv10Striping1dOutputParams        displayPreMndsCropLuma;
    CRCv10Striping1dOutputParams        displayPreMndsCropChroma;
    CRCv10Striping1dOutputParams        videoOutCropLuma;
    CRCv10Striping1dOutputParams        videoOutCropChroma;
    CRCv10Striping1dOutputParams        displayOutCropLuma;
    CRCv10Striping1dOutputParams        displayOutCropChroma;

    //Waipio+ addition
    MNScaleDownInStruct_V20_1D          appMndsLuma;
    MNScaleDownInStruct_V20_1D          appMndsChroma;
    CRCv10Striping1dOutputParams        appPreMndsCropLuma;
    CRCv10Striping1dOutputParams        appPreMndsCropChroma;
    CRCv10Striping1dOutputParams        appOutCropLuma;
    CRCv10Striping1dOutputParams        appOutCropChroma;

    //Mimas2.0
    CRCv10Striping1dOutputParams        preChromaDs_y;
    CRCv10Striping1dOutputParams        preChromaDs_c;
    MNScaleDownInStruct_V20_1D          chromadn;

    //kailua.s2.50
    CRCv10Striping1dOutputParams        crop1d_catmaphires;
}
IpeStripingModule1dOutputStorage;

typedef struct _IpeStripingLibraryOutputPerStripe
{
    int16_t tfWorkWindowInStart; //?

    // fetch coordinates
    int16_t tfiFetchFirstPixel;
    int16_t tfiFetchLastPixel;
    int16_t mainFetchFirstPixel;
    int16_t mainFetchLastPixel;
    int16_t refFetchFirstPixel;
    int16_t refFetchLastPixel;
    int16_t pdiFetchFirstPixel;
    int16_t pdiFetchLastPixel;
      int16_t lmcFetchFirstByte; //
      int16_t lmcFetchLastByte;
      int16_t lmcFetchFirstPixel[ICA_LMC_CNT];
      int16_t lmcFetchLastPixel[ICA_LMC_CNT];
      int16_t algmFetchFirstPixel;
      int16_t algmFetchLastPixel;
    int16_t mfhdrFetchFirstPixel;
    int16_t mfhdrFetchLastPixel;
    int16_t ltmMaskIn_FetchFirstPixel;
    int16_t ltmMaskIn_FetchLastPixel;
    int16_t ltmMaxMinIn_FetchFirstPixel;
    int16_t ltmMaxMinIn_FetchLastPixel;
    int16_t lenrDs4FetchFirstPixel;
    int16_t lenrDs4FetchLastPixel;
    int16_t blurMapBlurFetchFirstPixel;
    int16_t blurMapBlurFetchLastPixel;
    int16_t blurMapVSEFetchFirstPixel;
    int16_t blurMapVSEFetchLastPixel;
    int16_t blurDs4FetchFirstPixel;
    int16_t blurDs4FetchLastPixel;
    int16_t catmaphiresFetchFirstPixel;
    int16_t catmaphiresFetchLastPixel;
    int16_t catmaploresFetchFirstPixel;
    int16_t catmaploresFetchLastPixel;

    //Kailua
    int16_t HdrLm1FetchFirstPixel;
    int16_t HdrLm1FetchLastPixel;
    int16_t HdrLm2FetchFirstPixel;
    int16_t HdrLm2FetchLastPixel;


    // write coordinates
    int16_t pdiOutFirstPixel;
    int16_t pdiOutLastPixel;
    int16_t tfiOutFirstPixel;
    int16_t tfiOutLastPixel;
      int16_t algmOutFirstPixel;
    int16_t algmOutLastPixel;
    int16_t tfFullOutFirstPixel;
    int16_t tfFullOutLastPixel;
    int16_t LMCOutFirstByte;
    int16_t LMCOutLastByte;
    int16_t tfDs4OutFirstPixel;
    int16_t tfDs4OutLastPixel;
    int16_t ltmMaskDcOut_FirstPixel;
    int16_t ltmMaskDcOut_LastPixel;
    int16_t ltmMaxMinOut_FirstPixel;
    int16_t ltmMaxMinOut_LastPixel;
    int16_t videoOutFirstPixel;
    int16_t videoOutLastPixel;
    int16_t dispOutFirstPixel;
    int16_t dispOutLastPixel;
    int16_t appOutFirstPixel;
    int16_t appOutLastPixel;
    int16_t blurMapOutFirstPixel;
    int16_t blurMapOutLastPixel;

    //Kailua
    int16_t HdrLm1OutFirstPixel;
    int16_t HdrLm1OutLastPixel;
    int16_t HdrLm2OutFirstPixel;
    int16_t HdrLm2OutLastPixel;


    int16_t dummy_field_for_byte_padding;

    // flags
    BOOL leftStripe;
    BOOL rightStripe;
    BOOL leftStripePDI;          // is there corner case where for main input it's at boundary, but not for PDI & TFI?
    BOOL rightStripePDI;
    BOOL leftStripeTFI;
    BOOL rightStripeTFI;
    BOOL useDS4forBlur;      //?

    IpeStripingModule1dOutputStorage    module1d; //
    //===== generic ends here ======

    ANRv10StripingOutputParams      anr;
    TFv10v20StripingOutputParams    tf;
    DSXStripingOutputParams         dsx;
    LENRv10StripingOutputParams     lenr;
    BLURv10StripingOutputParams     blur;
    VSEv10StripingOutputParams      vse;

    CRCv10StripingOutputParams      tfFullOutCropLuma;
    CRCv10StripingOutputParams      tfFullOutCropChroma;
    CRCv10StripingOutputParams      ds4PreCropLuma;
    CRCv10StripingOutputParams      ds4PreCropChroma;
    CRCv10StripingOutputParams      tfDs4OutCropLuma;
    CRCv10StripingOutputParams      tfDs4OutCropChroma;
    CRCv10StripingOutputParams      mfhdr1preChromaupCropLuma;
    CRCv10StripingOutputParams      mfhdr1preChromaupCropChroma;
    CRCv10StripingOutputParams      mfhdr2preChromaupCropLuma;
    CRCv10StripingOutputParams      mfhdr2preChromaupCropChroma;
    CRCv10StripingOutputParams      mfhdr3preChromaupCropLuma;
    CRCv10StripingOutputParams      mfhdr3preChromaupCropChroma;
    CRCv10StripingOutputParams      mfhdrpreChromadnCropLuma;
    CRCv10StripingOutputParams      mfhdrpreChromadnCropChroma;
    CRCv10StripingOutputParams      preChromaupCropLuma;
    CRCv10StripingOutputParams      preChromaupCropChroma;
    CRCv10StripingOutputParams      LtmMultiPass_PostUpscale_Crop;
    CRCv10StripingOutputParams      preUpscalarCrop;     // YUV 444 (same values for Luma and Chroma)
    CRCv10StripingOutputParams      preUpscalarCrop_c;   // Chroma pre cropper (Only for Mimas2.0, Since ASF is only in the Luma path)
    CRCv10StripingOutputParams      videoPreMndsCropLuma;
    CRCv10StripingOutputParams      videoPreMndsCropChroma;
    CRCv10StripingOutputParams      displayPreMndsCropLuma;
    CRCv10StripingOutputParams      displayPreMndsCropChroma;
    CRCv10StripingOutputParams      videoOutCropLuma;
    CRCv10StripingOutputParams      videoOutCropChroma;
    CRCv10StripingOutputParams      displayOutCropLuma;
    CRCv10StripingOutputParams      displayOutCropChroma;

    CRCv10StripingOutputParams      appPreMndsCropLuma;
    CRCv10StripingOutputParams      appPreMndsCropChroma;
    CRCv10StripingOutputParams      appOutCropLuma;
    CRCv10StripingOutputParams      appOutCropChroma;

    ChromaUpv20StripingOutputParams     mfhdr_chromaup_T1L_MACin1_ICA2;
    ChromaUpv20StripingOutputParams     mfhdr_chromaup_T2M_MACin2_MFHDR_FE;
    ChromaUpv20StripingOutputParams     mfhdr_chromaup_T3S_MACin0_TF;
    MFHDRMACv10StripingOutputParams     mfhdr_mac;
    LTMv13StripingOutputParams          mfhdr_ltm;
    MNDSv20StripingOutputParams         mfhdr_chromadn;

    GRAv10stripingOutputParams          gra;
    HNRv10StripingOutputParams          hnr;

    MNDSv20StripingOutputParams         video_mnds_y;
    MNDSv20StripingOutputParams         video_mnds_c;
    MNDSv20StripingOutputParams         display_mnds_y;
    MNDSv20StripingOutputParams         display_mnds_c;
    MNDSv20StripingOutputParams         app_mnds_y;
    MNDSv20StripingOutputParams         app_mnds_c;

    LTMv13StripingOutputParams          ltm;
    LTMv20StripingOutputParams          LtmMultiPass;

    ChromaUpv20StripingOutputParams     chromaup;

    ASFv30StripingOutputParams          asf;

    HDR10PLUSv10StripingOutputParams    hdr10plus;

    Upscalev20StripingOutputParams      upscalar;

    int32_t qosIPEcounter;

    CRCv10StripingOutputParams      catmap;

    CMUSStripingOutputParams   cmus;
    STMPStripingOutputParams   stmp;
    SBLURStripingOutputParams  sblur;

    //Mimas2.0 addition
    int16_t fdOutFirstPixel;
    int16_t fdOutLastPixel;
    MNDSv20StripingOutputParams         fd_mnds_y;
    MNDSv20StripingOutputParams         fd_mnds_c;
    CRCv10StripingOutputParams      fdPreMndsCropLuma;
    CRCv10StripingOutputParams      fdPreMndsCropChroma;
    CRCv10StripingOutputParams      fdOutCropLuma;
    CRCv10StripingOutputParams      fdOutCropChroma;

    WriteEngineStripeParam rsWriteEngineStripeParam;
    WriteEngineStripeParam ltmdcWriteEngineStripeParam;

    CRCv10StripingOutputParams crc_chromaDownscalerCropLuma;
    //CRCv10StripingOutputParams crc_chromaDownscalerCropChroma; // do we really need it ?
    MNDSv20StripingOutputParams                    chromads2;
    iHistv12OutputParam                            ihist;
    RSOutputParams                                rs;
    ABFBPCOutputParams                            abfbpc;
}
IpeStripingLibraryOutputPerStripe;

typedef struct _IpeStripingLibraryOutputPerPass
{
    /* pass-level parameters */
    int16_t tfWorkWindowInStart; //?

    // fetch coordinates
    int16_t tfiFetchFirstLine;
    int16_t tfiFetchLastLine;
    int16_t mainFetchFirstLine;
    int16_t mainFetchLastLine;
    int16_t refFetchFirstLine;
    int16_t refFetchLastLine;
    int16_t pdiFetchFirstLine;
    int16_t pdiFetchLastLine;
      int16_t lmcFetchFirstLine; //initially has only 1 LMC port
      int16_t lmcFetchLastLine;  //later, added 2nd LMC port
      int16_t LmcFetchFirstLine[ICA_LMC_CNT];
      int16_t LmcFetchLastLine[ICA_LMC_CNT];
      int16_t algmFetchFirstLine;
      int16_t algmFetchLastLine;

    int16_t mfhdrFetchFirstLine;
    int16_t mfhdrFetchLastLine;

      int16_t ltmMaskIn_FetchFirstLine;
      int16_t ltmMaskIn_FetchLastLine;
      int16_t ltmMaxminIn_FetchFirstLine;
      int16_t ltmMaxminIn_FetchLastLine;

    int16_t lenrDs4FetchFirstLine;
    int16_t lenrDs4FetchLastLine;
    int16_t blurMapBlurFetchFirstLine;
    int16_t blurMapBlurFetchLastLine;
    int16_t blurMapVSEFetchFirstLine;
    int16_t blurMapVSEFetchLastLine;
    int16_t blurDs4FetchFirstLine;
    int16_t blurDs4FetchLastLine;
    int16_t catmaphiresFetchFirstLine;
    int16_t catmaphiresFetchLastLine;
    int16_t catmaploresFetchFirstLine;
    int16_t catmaploresFetchLastLine;

    //Kailua
    int16_t HdrLm1FetchFirstLine;
    int16_t HdrLm1FetchLastLine;
    int16_t HdrLm2FetchFirstLine;
    int16_t HdrLm2FetchLastLine;


    // write coordinates
    int16_t pdiOutFirstLine;
    int16_t pdiOutLastLine;
    int16_t tfiOutFirstLine;
    int16_t tfiOutLastLine;
      int16_t algmOutFirstLine;
    int16_t algmOutLastLine;
    int16_t tfFullOutFirstLine;
    int16_t tfFullOutLastLine;
    int16_t LMCOutFirstLine;
    int16_t LMCOutLastLine;
    int16_t tfDs4OutFirstLine;
    int16_t tfDs4OutLastLine;
    int16_t ltmMaskDcOut_FirstLine;
    int16_t ltmMaskDcOut_LastLine;
    int16_t ltmMaxMinOut_FirstLine;
    int16_t ltmMaxMinOut_LastLine;
    int16_t videoOutFirstLine;
    int16_t videoOutLastLine;
    int16_t dispOutFirstLine;
    int16_t dispOutLastLine;
    int16_t appOutFirstLine;
    int16_t appOutLastLine;

    int16_t blurMapOutFirstLine;
    int16_t blurMapOutLastLine;

    //Kailua
    int16_t HdrLm1OutFirstLine;
    int16_t HdrLm1OutLastLine;
    int16_t HdrLm2OutFirstLine;
    int16_t HdrLm2OutLastLine;


    int16_t dummy_field_for_byte_padding;

    // flags
    BOOL topPad;
    BOOL bottomPad;
    BOOL topStripePDI;
    BOOL bottomStripePDI;
    BOOL topStripeTFI;
    BOOL bottomStripeTFI;
    BOOL useDS4forBlur; // dummy here for memory alignment

    IpeStripingModule1dOutputStorage module1d;
    //===== generic ends here ======

    int16_t LTMDCEnable;
    int16_t LTMIPEnable;
    int16_t TFenable;
    int16_t                             ppsEnable;

    int16_t videoOutImageLumaWidth;
    int16_t dispOutImageLumaWidth;
    int16_t appOutImageLumaWidth;

    int16_t   refInOffset_x;
    int16_t   refInOffset_y;
    int16_t   ref1frameWidth;
    int16_t   ref4frameWidth;

    // TODO : pack ZoomWindow parameters in a struct
        int16_t   npsImageZoomWindow_isZoomEnable;
        int16_t   npsImageZoomWindow_startX;
        int16_t   npsImageZoomWindow_startY;
        int16_t   npsImageZoomWindow_sizeX;
        int16_t   npsImageZoomWindow_sizeY;
        int16_t   npsRefZoomWindow_isZoomEnable;
        int16_t   npsRefZoomWindow_startX;
        int16_t   npsRefZoomWindow_startY;
        int16_t   npsRefZoomWindow_sizeX;
        int16_t   npsRefZoomWindow_sizeY;
        int16_t   npsPrevRefZoomWindow_isZoomEnable;
        int16_t   npsPrevRefZoomWindow_startX;
        int16_t   npsPrevRefZoomWindow_startY;
        int16_t   npsPrevRefZoomWindow_sizeX;
        int16_t   npsPrevRefZoomWindow_sizeY;
        int16_t   left_stripe_count;
        int16_t   right_stripe_count;
        /* stripes */
    int16_t numStripes; // TODO : change to uint32_t\uint16_t
    ListHandle hStripeList;

    //Mimas2.0 addition
    int16_t fdOutFirstLine;
    int16_t fdOutLastLine;
    int16_t fdOutImageLumaWidth;
    WriteEnginePassParam rsWriteEngineFrameParam;
    WriteEnginePassParam ltmdcWriteEngineFrameParam;

}
IpeStripingLibraryOutputPerPass;

typedef struct _IpeStripingLibraryOutputPerFrame
{
    /* frame-level parameters */

    /* passes */
    int32_t                             numPasses;  // TODO : change to uint32_t
    int32_t dummy_field_for_byte_padding;
    IpeStripingLibraryOutputPerPass*    passes;
}
IpeStripingLibraryOutputPerFrame;

typedef struct _IpeModuleConfig1dInput
{
    // tiering information
    int32_t chip;
    int16_t mctfFlow; //0: legacy, 1: mixed loop
    int16_t datapath_align_step;

    int32_t ANR_CYLPF_dithering_seed_frame;     //initial random seed for dithering in CYLPF
    int32_t ANR_dcnf_dithering_seed_frame;      //initial random seed for dithering in dcnf
    int32_t tf_prngSeed_frame;                  //frame level TF PRNG seed
    int32_t tf_LnrStartIdx_frame;
    int32_t tf_LnrScale;
    BOOL    chromaUp_cosited;
    BOOL    chromaUp_even;
    int16_t mainInFormat;
    int16_t refInFormat;
    int16_t ANRDCInFormat;
    int16_t TFIndFormat;
    int16_t LtmMaskIn_Format;
    int16_t LtmMaxMinIn_Format;
    // waipio.s2.50
    int16_t blurMapBlurInputFormat;
    int16_t blurMapVSEInputFormat;
    int16_t blurMapBlurOutputFormat;
    int16_t blurDs4InDim;
    int16_t tf_ds4_out_address_start;
    int16_t bokehdcinFormat;
    // kailua.s2.50
    StripingPort catmaphiresIn;
    StripingPort catmaploresIn;

    int16_t AlgmInFormat;
    int16_t dispOutFormat;
    int16_t videoOutFormat;
    int16_t appOutFormat;
    int16_t TFOutFormat;
    int16_t DS4OutFormat;
    int16_t LtmMaskDcOut_Format;
    int16_t LtmMaxMinOut_Format;
    int16_t lenrDS4InFormat;
    int16_t mainInDim;
    int16_t videoOutDim;
    int16_t dispOutDim;
    int16_t appOutDim;
    int16_t LtmMaskIn_Dim;
    int16_t LtmMaxMinIn_Dim;
    int16_t DS4OutDim;     //it is a function of the reference frame width
    int16_t lenrDs4InDim;
    int16_t videoDimInSource;
    int16_t dispDimInSource;
    int16_t appDimInSource;

    int16_t ANRDCInDim;
    int16_t TFIndDim;
    int16_t AlgmDim;
    int16_t LtmMaskOut_Dim;
    int16_t LtmMaxMinOut_Dim;
    int16_t lineBufferSize;
    int16_t min_ica_out_size;
    uint16_t kernelLENR;
    int16_t kernelTFDilate;
    int16_t kernelTFErode;
    int16_t kernelTFrefinement;     //this is hidden by the TF kernel but is needed to calculate some coordinate constraints
    int16_t TFenable;
    int16_t passIdx;                //0: full, 1: 1:4, 2: 1:16, 3: 1:64
    int16_t LTMDCEnable;            // for DC collection
    int16_t LTMIPEnable;            // call IP code for striping parameters
    int16_t LTM_MP_Enable;
    int16_t zoomOffsetInSource;
    int16_t tf_dithering_en;
    int16_t ltmDCtableOption;

    int16_t ds4Enable;
    int16_t dsxEnable;
    int16_t refInOffset;
    int16_t npsImageZoomWindow_isZoomEnable;
    int16_t npsImageZoomWindow_start;
    int16_t npsImageZoomWindow_size;
    int16_t npsRefZoomWindow_isZoomEnable;
    int16_t npsRefZoomWindow_start;
    int16_t npsRefZoomWindow_size;
    int16_t npsPrevRefZoomWindow_isZoomEnable;
    int16_t npsPrevRefZoomWindow_start;
    int16_t npsPrevRefZoomWindow_size;

    int16_t mainDimInSource;
    int16_t mainOffsetInSource;
    int16_t mainInConstraint;
    int16_t ANRDCInConstraint;
    int16_t refInConstraint;
    int16_t mfhdrInConstraint;
    int16_t lenrDs4InConstraint;
    int16_t ltm_mask_in_constaint;
    int16_t ltm_maxmin_in_constaint;
    int16_t TFIndConstraint;
    int16_t AlgmInConstraint;
    int16_t TFOutConstraint;
    int16_t ltm_mask_out_constaint;
    int16_t ltm_maxmin_out_constaint;
    int16_t DS4OutConstraint;
    int16_t videoOutConstraint;
    int16_t dispOutConstraint;
    int16_t appOutConstraint;
    int16_t bokehdcinConstraint;

    BOOL    upscaleEnable;
    int16_t tf_lmenable_prevpass;
    BOOL    isLmcEnabled[ICA_LMC_CNT];
    ICAv10InputParams ica1;
    ICAv10InputParams ica2;
    UpscaleInStruct_V11_1D chromaUpFrame_C;
    Upscalev20Striping1dOutputParams upscaleSIMOFrame;
    MNScaleDownInStruct_V20_1D downscaleVideoLumaFrame;
    MNScaleDownInStruct_V20_1D downscaleVideoChromaFrame;
    MNScaleDownInStruct_V20_1D downscaleDispLumaFrame;
    MNScaleDownInStruct_V20_1D downscaleDispChromaFrame;
    MNScaleDownInStruct_V20_1D downscaleAppLumaFrame;
    MNScaleDownInStruct_V20_1D downscaleAppChromaFrame;

    MNScaleDownInStruct_V20_1D downscaleLTMDCFrame;
    DsxStripingInput_1D dsx_luma;
    DsxStripingInput_1D dsx_chroma;

    TFrefinementInputParams TFrefinementFrame;
    GRAv10stripingInputParams gra;
    ANRLNRInputParams anrlnr;


    // mfhdr
    int16_t                             mfhdrInFormat;
    int16_t                             mfhdrInDim;
    ChromaUpv20StripingInputParams      mfhdr_chroma_up_T1L_MACin1;
    ChromaUpv20StripingInputParams      mfhdr_chroma_up_T2M_MACin2;
    ChromaUpv20StripingInputParams      mfhdr_chroma_up_T3S_MACin0;
    UpscaleInStruct_V11_1D              mfhdr_chromaUp1Frame_C;
    UpscaleInStruct_V11_1D              mfhdr_chromaUp2Frame_C;
    UpscaleInStruct_V11_1D              mfhdr_chromaUp3Frame_C;
    MFHDRMACv10StripingInputParams      mfhdr_mac;
    LTMv13StripingInputParams           mfhdr_ltm;
    //MNDSv20StripingInputParams          mfhdr_chromadn;
    MNScaleDownInStruct_V20_1D          mfhdr_chromadn_1d;

    // waipio.s2.50 this needs to get populated with the values in IpeStripingLibraryInput
    BLURv10StripingInputParams          blur;
    VSEv10StripingInputParams           vse;
    HDR10PLUSv10StripingInputParams     hdr10plus;

    // kailus.s2.50
    CMUSStripingInputParams             cmus;
    STMPStripingInputParams             stmp;

    SBLURStripingInputParams            sblur;

}
IpeModuleConfig1dInput;

#define STRIPE_IPE_RANGE_START_IDX      0
#define STRIPE_IPE_RANGE_END_IDX        1
#define STRIPE_IPE_RANGE_MAX_IDX        2

#define STRIPE_IPE_RANGE_START(rng)     (rng[STRIPE_IPE_RANGE_START_IDX])
#define STRIPE_IPE_RANGE_END(rng)       (rng[STRIPE_IPE_RANGE_END_IDX])

typedef struct  _IpeStripeInternalRanges
{
    int16_t                     anrIn[STRIPE_IPE_RANGE_MAX_IDX];
    int16_t                     anrCylpfOut[STRIPE_IPE_RANGE_MAX_IDX];
    int16_t                     anrRnrIn[STRIPE_IPE_RANGE_MAX_IDX];
    int16_t                     tfIn[STRIPE_IPE_RANGE_MAX_IDX];
    int16_t                     tfOutMfhdrOut[STRIPE_IPE_RANGE_MAX_IDX];
    int16_t                     ppsIn[STRIPE_IPE_RANGE_MAX_IDX];
    int16_t                     lenrIn[STRIPE_IPE_RANGE_MAX_IDX];
    int16_t                     blurIn[STRIPE_IPE_RANGE_MAX_IDX]; // waipio.s2.50
    int16_t                     blurOut[STRIPE_IPE_RANGE_MAX_IDX]; // waipio.s2.50
    int16_t                     cacOut_C[STRIPE_IPE_RANGE_MAX_IDX];
    int16_t                     chromaUpIn_C[STRIPE_IPE_RANGE_MAX_IDX];
    int16_t                     chromaUpOut[STRIPE_IPE_RANGE_MAX_IDX];

    int16_t                     asfOutPpsFOV[STRIPE_IPE_RANGE_MAX_IDX];
    int16_t                        vseIn[STRIPE_IPE_RANGE_MAX_IDX];
    int16_t                        vseOut[STRIPE_IPE_RANGE_MAX_IDX];
    int16_t                     usInPpsFOV[STRIPE_IPE_RANGE_MAX_IDX];
    int16_t                     usOutPpsFOV[STRIPE_IPE_RANGE_MAX_IDX];
    //int16_t                     usOutPpsFOV_mpix_padded[STRIPE_IPE_RANGE_MAX_IDX];
    int16_t                     ltm_dc_ds_in_min_rage_start;
    int16_t                     ltm_dc_ds_in;
    int16_t                     ltmDCdsOutNoMPIX[STRIPE_IPE_RANGE_MAX_IDX];
    int16_t                     ltmDCdsOut[STRIPE_IPE_RANGE_MAX_IDX];
    int16_t                     ltmDcRightBound;
    int16_t                     ltmOut[STRIPE_IPE_RANGE_MAX_IDX];

    int16_t                     ltmMpInput[STRIPE_IPE_RANGE_MAX_IDX];
    //int16_t                     ltmDcRightBound;
    //int16_t                     ltmOut[STRIPE_IPE_RANGE_MAX_IDX];


    int16_t                     videoDSinPpsFovLuma[STRIPE_IPE_RANGE_MAX_IDX];
    int16_t                     videoDSinPpsFovChroma[STRIPE_IPE_RANGE_MAX_IDX];
    int16_t                     videoMinDSinPpsFovLuma[STRIPE_IPE_RANGE_MAX_IDX];
    int16_t                     videoMinDSinPpsFovChroma[STRIPE_IPE_RANGE_MAX_IDX];
    int16_t                     videoDSoutPpsFovLuma[STRIPE_IPE_RANGE_MAX_IDX];
    int16_t                     videoDSoutPpsFovChroma[STRIPE_IPE_RANGE_MAX_IDX];
    int16_t                     other_dimension_video_ds_out_y;
    int16_t                     other_dimension_video_ds_out_c;
    int16_t                     videoPrecropIn[STRIPE_IPE_RANGE_MAX_IDX];

    int16_t                     dispDSinPpsFovLuma[STRIPE_IPE_RANGE_MAX_IDX];
    int16_t                     dispDSinPpsFovChroma[STRIPE_IPE_RANGE_MAX_IDX];
    int16_t                     dispMinDSinPpsFovLuma[STRIPE_IPE_RANGE_MAX_IDX];
    int16_t                     dispMinDSinPpsFovChroma[STRIPE_IPE_RANGE_MAX_IDX];
    int16_t                     dispDSoutPpsFovLuma[STRIPE_IPE_RANGE_MAX_IDX];
    int16_t                     dispDSoutPpsFovChroma[STRIPE_IPE_RANGE_MAX_IDX];
    int16_t                     other_dimension_display_ds_out_y;
    int16_t                     other_dimension_display_ds_out_c;
    int16_t                     dispPrecropIn[STRIPE_IPE_RANGE_MAX_IDX];

    int16_t                     appDSinPpsFovLuma[STRIPE_IPE_RANGE_MAX_IDX];
    int16_t                     appDSinPpsFovChroma[STRIPE_IPE_RANGE_MAX_IDX];
    int16_t                     appMinDSinPpsFovLuma[STRIPE_IPE_RANGE_MAX_IDX];
    int16_t                     appMinDSinPpsFovChroma[STRIPE_IPE_RANGE_MAX_IDX];
    int16_t                     appDSoutPpsFovLuma[STRIPE_IPE_RANGE_MAX_IDX];
    int16_t                     appDSoutPpsFovChroma[STRIPE_IPE_RANGE_MAX_IDX];
    int16_t                     other_dimension_app_ds_out_y;
    int16_t                     other_dimension_app_ds_out_c;
    int16_t                     appPrecropIn[STRIPE_IPE_RANGE_MAX_IDX];


    int16_t                     tfRefineBlk[STRIPE_IPE_RANGE_MAX_IDX];

    int16_t                     ds4InPpsFovLuma[STRIPE_IPE_RANGE_MAX_IDX];
    int16_t                     ds4InPpsFovChroma[STRIPE_IPE_RANGE_MAX_IDX];
    int16_t                     ds4OutPpsFovLuma[STRIPE_IPE_RANGE_MAX_IDX];

    int16_t                     mfhdr_MacIn[STRIPE_IPE_RANGE_MAX_IDX];
    int16_t                     mfhdr_PreChromaUpInT1L_MACin1_ICA2[STRIPE_IPE_RANGE_MAX_IDX];
    int16_t                     mfhdr_PreChromaUpInT2M_MACin2_MFHDR_FE[STRIPE_IPE_RANGE_MAX_IDX];
    int16_t                     mfhdr_PreChromaUpInT3S_MACin0_TF[STRIPE_IPE_RANGE_MAX_IDX];
    int16_t                     mfhdr_LtmIn[STRIPE_IPE_RANGE_MAX_IDX];
    int16_t                     mfhdr_ChromaDnIn[STRIPE_IPE_RANGE_MAX_IDX];
}
IpeStripeInternalRanges;        // TODO : rename struct - remove "Internal" part

typedef struct _IpeStripeAllocationResultPerStripe
{
    int16_t tfRefRangeInROI;
    int16_t tfWorkWindowInStart;
    int16_t tfWorkWindowInEnd;
    int16_t tfditheringStart;
    int32_t qosIPEcounter_1d_fetch;
    int32_t qosIPEcounter_1d_usOut;
    int16_t upscalarGoalOutRight;
    int16_t ppsOutOfBoundary;
    int16_t anr_cnrStart;
    int16_t asfStart;
    int16_t edgeStripeLT_PPSFOV;
    int16_t edgeStripeRB_PPSFOV;
    BOOL    edgeStripeLT;
    BOOL    edgeStripeRB;
    int16_t mainFetchFirst;
    int16_t mainFetchLast;
    int16_t lmcFetchFirstByte;
    int16_t lmcFetchLastByte;
    int16_t lmcFetchFirstPixel[ICA_LMC_CNT];
    int16_t lmcFetchLastPixel[ICA_LMC_CNT];
    int16_t lenrDs4FetchFirst;
    int16_t lenrDs4FetchLast;
    int16_t PDIOutFirst;
    int16_t PDIOutLast;
    int16_t TFIOutFirst;
    int16_t TFIOutLast;
    int16_t AlgmOutFirst;
    int16_t AlgmOutLast;
    int16_t LMCOutFirst;
    int16_t LMCOutLast;
    int16_t TFOutFirst;
    int16_t TFOutLast;
    int16_t DS4OutFirst;
    int16_t DS4OutLast;
    int16_t    mndsVideoDropEnd;
    int16_t    mndsDispDropEnd;
    int16_t    mndsAppDropEnd;
    int16_t videoOutLumaFirst;
    int16_t videoOutLumaLast;
    int16_t dispOutLumaFirst;
    int16_t dispOutLumaLast;
    int16_t appOutLumaFirst;
    int16_t appOutLumaLast;

    int16_t blurMapOutFirst; // waipio.s2.50
    int16_t blurMapOutLast; // waipio.s2.50
    int16_t ltmDcRangeFirst;
    int16_t ltmDcRangeLast;
    int16_t mfhdrChromaUpInFirst;
    int16_t mfhdrChromaUpInLast;
    int16_t mfhdrMacInFirst;
    int16_t mfhdrMacInLast;
    int16_t mfhdrLtmInFirst;
    int16_t mfhdrLtmInLast;
    int16_t mfhdrChromaDnInFirst;
    int16_t mfhdrChromaDnInLast;
    int16_t mfhdrOutFirst;
    int16_t mfhdrOutLast;
    int16_t mfhdr_lm1_out[STRIPE_IPE_RANGE_MAX_IDX];
    int16_t mfhdr_lm2_out[STRIPE_IPE_RANGE_MAX_IDX];

    //int16_t ltm_mask_in[STRIPE_IPE_RANGE_MAX_IDX];
    //int16_t ltm_maxmin_in[STRIPE_IPE_RANGE_MAX_IDX];
    int16_t ltm_mask_out[STRIPE_IPE_RANGE_MAX_IDX];
    int16_t ltm_maxmin_out[STRIPE_IPE_RANGE_MAX_IDX];
    int16_t dummy_field_for_byte_padding;
    IpeStripeInternalRanges stripeRanges;
}
IpeStripeAllocationResultPerStripe;

typedef struct _IpeStripeAllocationResultPerPass
{
    IpeModuleConfig1dInput module_config_input_x;
    IpeModuleConfig1dInput module_config_input_y;
    IpeStripeAllocationResultPerStripe allocation_result_y; // common to all stripes because this is vericle component

    /* stripes */
    int16_t    numStripes;
    int16_t dummy_field_for_byte_padding_0;
    int32_t dummy_field_for_byte_padding_1;
    ListHandle hStripeAllocationResultList;
}
IpeStripeAllocationResultPerPass;

typedef struct _IpeStripeAllocationResultPerFrame
{
    /* frame-level parameters */
    int16_t tiering;
    int16_t mux_mode;

    /* passes */
    int32_t numPasses;
    IpeStripeAllocationResultPerPass*   passes;
}
IpeStripeAllocationResultPerFrame;

#pragma pack(push)
#pragma pack(4)

//Kailua IPE SL API: mux information so can know the data flow
//the naming is exactly the same as in mux name in pipeline diagram
typedef struct _IpeStripingLibraryInputMuxInfo
{
    int8_t MFHDR_OUT_SEL;
    int8_t MFHDR_SEL;
    int8_t ICA0_WARPED_CATMAP_EN;
    int8_t OUTPUT_FORMAT_TF_Y_FULL;
    int8_t ARGB_PATH_EN;
    int8_t HDR10_BLUR_WR_OUT_SEL;
    // Mimas 2.0 addition
    int8_t MAIN_IN_SEL; // 0 : Bayer 12b, 1 : YUV420/YUV422 10b
    // mux_mode * 0: ANR input from format mux and TF input from ICA.    *1: ANR input from ICA and TF input from format mux.
}
IpeStripingLibraryInputMuxInfo;



typedef struct _IpeStripingLibraryInput
{
    int16_t                         overrideMaxBufferSize; //moved here to remove byte padding warning

    // top level
    int16_t                             tiering;  //refer to ChipVersion enum for valid num
    int16_t                             mux_mode; //Talos only w/a - detiler mux select
    int16_t                             oneto4PassEnable;
    int16_t                             oneto16PassEnable;
    int16_t                             oneto64PassEnable;
    int16_t                             passSkipThreshold_w;
    int16_t                             passSkipThreshold_h;

    int16_t                             TFfullOutFormat_full;
    int16_t                             TFds4OutFormat[IPE_PASS_COUNT];
    int16_t                             TFds4OutFormat_1to4;

    int16_t                             mctfFlow; //0: legacy, 1: mixed loop

    int16_t                             iir_mfhdr_mode;  //0: disable IIR MFHDR; 1: enable IIR MFHDR;

    // main input
    int16_t                             mainInFormat; //why it is not FwImageFormat as algmOutFormat?
    int16_t                             mainRefInFormat;
    int16_t                             mainInWidth;  //it is applicable to both ICA1 & ICA2
    int16_t                             mainInHeight; //the width/height is after ICA, striping lib input size is after ICA
    int16_t                             zoomEnable;
    int16_t                             zoomFirstPixelInSource;
    int16_t                             zoomFirstLineInSource;
    int16_t                             zoomInWidth;
    int16_t                             zoomInHeight;
    int16_t                             prevZoomEnable;
    int16_t                             prevZoomFirstPixelInSource;
    int16_t                             prevZoomFirstLineInSource;
    int16_t                             prevZoomInWidth;
    int16_t                             prevZoomInHeight;
    int16_t                             mainInStride;

    // algm
    ImageFormat                         algmInFormat; //algm is only for full pass
    int16_t                             algmInWidth;
    int16_t                             algmInHeight;

    // MFHDR Input
    int16_t                             mfhdrInFormat;
    int16_t                             mfhdrInWidth; //it should be same as mainInWidth? algmInWidth?
    int16_t                             mfhdrInHeight;
    int16_t                             mfhdrInFormat_1to4; // deprecated
    int16_t                             mfhdrInWidth_1to4;  // deprecated
    int16_t                             mfhdrInHeight_1to4; // deprecated

    //Kailua
    StripingPort                        mfhdrInPerPass[IPE_PASS_COUNT];

    // 1:4 input frame
    int16_t                             oneToFourInputFormat; //it is possible the Input & RefIn format is different
    int16_t                             oneToFourRefInFormat; //
    int16_t                             oneToFourInputWidth;  //the width/height/stride is
    int16_t                             oneToFourInputHeight; //applicable to both the ICA1
    int16_t                             oneToFourInputStride; //& ICA2

    // 1:16 input frame
    int16_t                             oneToSixteenInputFormat;
    int16_t                             oneToSixteenRefInFormat;
    int16_t                             oneToSixteenInputWidth;
    int16_t                             oneToSixteenInputHeight;
    int16_t                             oneToSixteenInputStride;

    // 1:64 input frame
    int16_t                             oneTo64InputFormat;
    int16_t                             oneTo64RefInFormat;
    int16_t                             oneTo64InputWidth;
    int16_t                             oneTo64InputHeight;
    int16_t                             oneTo64InputStride;

    // IPE_LENR_DS4_IN
    int16_t                             lenrDs4InputFormat;
    //At DC4 pass, the DSX is disabled and send the LENR out through TF_DS4 out port, this is due to the TF_Full out port don't support PD10 before Waipio
                                //At full pass, it is read in through the LENR_DS4 in port
                                //LENR is only used in still flow

    StripingPort                     LtmMaskIn  [IPE_PASS_COUNT];
    StripingPort                     LtmMaxMinIn[IPE_PASS_COUNT];

    // IPE_BLUR_DS4_IN
    int16_t                             bokehdcinFormat[IPE_PASS_COUNT];

    // IPE Blur_Map Input Ports
    int16_t                             blurMapBlurInputFormat; //
    int16_t                             blurMapBlurInputWidth;
    int16_t                             blurMapBlurInputHeight;

    int16_t                             blurMapVSEInputFormat;      //Consider to merge these two into one
    int16_t                             blurMapVSEInputWidth;
    int16_t                             blurMapVSEInputHeight;

    // IPE Bokeh_DC Input Port this is a.k.a DC4
    int16_t                             blurDs4InputWidth; //why it is not an array of 4? Need to check?
    int16_t                             blurDs4InputHeight;

    // ALGM Output
    ImageFormat                         algmOutFormat; //only for full pass
    int16_t                             algmOutWidth;  // Not needed?
    int16_t                             algmOutHeight; // Not needed?

    StripingPort                        LtmMaskDcOut[IPE_PASS_COUNT];
    StripingPort                        LtmMaxMinOut[IPE_PASS_COUNT];

    // display output
    int16_t                             dispOutFormat;
    int16_t                             dispOutWidth;
    int16_t                             dispOutHeight;
    int16_t                             dispOutFirstPixelInSource;
    int16_t                             dispOutFirstLineInSource;
    int16_t                             dispOutWidthInSource;
    int16_t                             dispOutHeightInSource;
    int16_t                             dispOutStride;
    int32_t                             dispPrevFirstPixelInSource;
    int32_t                             dispPrevFirstLineInSource;
                                        //why no dispPrevOutWidthInSource &
    // video output
    int16_t                             videoOutFormat;   //should it be an array due to the VSE?
    int16_t                             videoOutWidth;    //should it be an array due to the VSE?
    int16_t                             videoOutHeight;
    int16_t                             videoOutFirstPixelInSource;
    int16_t                             videoOutFirstLineInSource;
    int16_t                             videoOutWidthInSource;
    int16_t                             videoOutHeightInSource;
    int16_t                             videoOutStride;
    int32_t                             videoPrevFirstPixelInSource;
    int32_t                             videoPrevFirstLineInSource;

    // Blur_Map Output Port
    int16_t                             blurMapBlurOutputFormat;
    int16_t                             blurMapOutWidth;  //should it be an array?
    int16_t                             blurMapOutHeight; //

    uint32_t                            mnds_overlap_min_phase_step[IPE_PASS_COUNT]; // MNDSv23 overlap feature control

    // nps
    ICAv10InputParams                   ica1; //can we assume ICA en/mode is same cross all 4 passes? yes.
    ICAv10InputParams                   ica2;
    ANRv10StripingInputParams           anr[IPE_PASS_COUNT];
    TFv10v20StripingInputParams         tf [IPE_PASS_COUNT];
    DS4v10StripingInputParams           ds4[IPE_PASS_COUNT]; //used up to Kona
    DsxStripingInputParams              dsx[IPE_PASS_COUNT]; //Laihana onward, ds4 is upgraded to dsx

    // mfhdr
    ChromaUpv20StripingInputParams      mfhdr_chroma_up_T1L_MACin1_ICA2; //should it be array of 2 up to waipio?
    ChromaUpv20StripingInputParams      mfhdr_chroma_up_T2M_MACin2_MFHDR_FE;//3 or 4 passes for waipio+
    ChromaUpv20StripingInputParams      mfhdr_chroma_up_T3S_MACin0_TF;
    MFHDRMACv10StripingInputParams      mfhdr_mac;
    LTMv13StripingInputParams           mfhdr_ltm;
    MNDSv20StripingInputParams          mfhdr_chromadn;

    // pps
    ChromaUpv20StripingInputParams      chroma_up; //in video/still flow, PPS modules are only enabled in full pass
    CACv22StripingInputParams           cac;       //should we make it an array?
    LTMv13StripingInputParams           ltm;
    LTMv20StripingInputParams           ltmMultiPass[IPE_PASS_COUNT];
    ASFv30StripingInputParams           asf;
    HDR10PLUSv10StripingInputParams     hdr10plus;
    // waipio.s2.50 values in this blur struct need to make their way into ipeconfigmodule1d input struct
    BLURv10StripingInputParams          blur[IPE_PASS_COUNT];
    VSEv10StripingInputParams           vse[IPE_PASS_COUNT];
    GRAv10stripingInputParams           gra;
    Upscalarv20StripingInputParams      upscalar;
    MNDSv20StripingInputParams          mndsInVideo;
    MNDSv20StripingInputParams          mndsInDisplay;
    HNRInputParam                       hnr;
    CMUSStripingInputParams             cmus[IPE_PASS_COUNT];
    STMPStripingInputParams             stmp[IPE_PASS_COUNT];
    SBLURStripingInputParams            sblur[IPE_PASS_COUNT];

    // Mimas 2.0
    MNDSv20StripingInputParams     chromadn;
    ABFBPCInputParams              abfbpc;
    BasicModuleInput               demosaic;
    iHistv12InputParam             ihist;
    RSInputParams                  rs;

    // debug
    // TODO : find a way to remove below variables
    //int16_t                         overrideMaxBufferSize;
    BOOL                            forceEvenStripe; //Hana has 2 instance of IPE. that is the reason it need be even. no longer needed after Hana
    BOOL                            enforceMinOutputConstraint; //? Napali has HW bug to have a workaround in striping lib. every stripe output at least 130 bytes in case of UBWC

    //waipio+ addition
    int32_t flow_id;         //base flow ID
    int32_t flow_adder;      //1 bits per flow adder, total 3 bits used so far
    //int32_t mux_field;       //1 bits per mux, total
    int32_t clc_enable[IPE_PASS_COUNT][8];   //1 bits per CLC/FE/WB, must be set if flow_id is custom.

    IpeStripingLibraryInputMuxInfo     Mux[IPE_PASS_COUNT];

    //3rd YUV out
    MNDSv20StripingInputParams          mndsInApp;
    // APP output
    StripingPort                        appOut;
    //int16_t                             appOutFormat;
    //int16_t                             appOutWidth;
    //int16_t                             appOutHeight;
    int16_t                             appOutFirstPixelInSource;
    int16_t                             appOutFirstLineInSource;
    int16_t                             appOutWidthInSource;
    int16_t                             appOutHeightInSource;
    int16_t                             appOutStride;
    int32_t                             appPrevFirstPixelInSource;
    int32_t                             appPrevFirstLineInSource;

    //int16_t                             mfhdrInFormatWPlus[IPE_PASS_COUNT];
    //int16_t                             mfhdrInWidthWPlus[IPE_PASS_COUNT];
    //int16_t                             mfhdrInHeightWPlus[IPE_PASS_COUNT];

    StripingPort                       catmaphiresIn[IPE_PASS_COUNT];
    StripingPort                       catmaploresIn[IPE_PASS_COUNT];


}
IpeStripingLibraryInput;


int dbg_printIPEFrameInput(const IpeStripingLibraryInput *pFirmwareInput, userIPEArgs *pUserIPEArgs);
int dbg_printStripeNPSPPSOutput(const IpeStripingLibraryOutputPerFrame *pFrameOut, userIPEArgs *pUserIPEArgs);



#pragma pack(pop)

#ifdef __cplusplus
}
#endif

#endif /* _STRIPENPSPPS_H_ */
