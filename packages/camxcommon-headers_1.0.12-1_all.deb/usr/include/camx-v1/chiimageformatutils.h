////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2021-2022 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @file   chiimageformatutils.h
///
/// @brief  Common Utility functions for camera image formats.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef CHIIMAGEFORMATUTILS_H
#define CHIIMAGEFORMATUTILS_H

#include "camxcommontypes.h"
#include "camxdebugprint.h"
#include "camxutils.h"

CAMX_NAMESPACE_BEGIN

/// @brief This enumerates pixel formats.
enum class Format
{
    Jpeg               = 0,          ///< JPEG format.
    Y8                 = 1,          ///< Luma only, 8 bits per pixel.
    Y16                = 2,          ///< Luma only, 16 bits per pixel.
    YUV420NV12         = 3,          ///< YUV 420 format as described by the NV12 fourcc.
    YUV420NV21         = 4,          ///< YUV 420 format as described by the NV21 fourcc.
    YUV422NV16         = 5,          ///< YUV 422 format as described by the NV16 fourcc
    Blob               = 6,          ///< Any non image data
    RawYUV8BIT         = 7,          ///< Packed YUV/YVU raw format. 16 bpp: 8 bits Y and 8 bits UV.
                                     ///< U and V are interleaved as YUYV or YVYV.
    RawPrivate         = 8,          ///< Private RAW formats where data is packed into 64bit word. P0 is stored at LSB.
                                     ///  8BPP:  64-bit word contains 8 pixels p0-p7, p0 is stored at LSB.
                                     ///  10BPP: 64-bit word contains 6 pixels p0-p5, most significant 4 bits are set to 0.
                                     ///  12BPP: 64-bit word contains 5 pixels p0-p4, most significant 4 bits are set to 0.
                                     ///  14BPP: 64-bit word contains 4 pixels p0-p3, most significant 8 bits are set to 0.
    RawMIPI            = 9,          ///< MIPI RAW formats based on MIPI CSI-2 specification.
                                     ///  8BPP: Each pixel occupies one bytes, starting at LSB.
                                     ///        Output width of image has no restrictions.
                                     ///  10BPP: 4 pixels are held in every 5 bytes.
                                     ///         Output width of image must be a multiple of 4 pixels.
    RawMIPI10          = RawMIPI,    ///< By default 10-bit, RawMIPI10
    RawPlain16         = 10,         ///< Plain16 RAW format. Single pixel is packed into two bytes,little endian format.
                                     ///  Not all bits may be used as RAW data is generally 8 or 10 bits per pixel.
                                     ///  Lower order bits are filled first.
    RawPlain16LSB10bit = RawPlain16, ///< By default 10-bit, RawPlain16LSB10bit
    RawMeta8BIT        = 11,         ///< Generic 8-bit raw meta data for internal camera usage.
    UBWCTP10           = 12,         ///< UBWC TP10 format (as per UBWC2.0 design specification)
    UBWCNV12           = 13,         ///< UBWC NV12 format (as per UBWC2.0 design specification)
    UBWCNV124R         = 14,         ///< UBWC NV12-4R format (as per UBWC2.0 design specification)
    YUV420NV12TP10     = 15,         ///< YUV 420 format 10bits per comp tight packed format.
    YUV420NV21TP10     = 16,         ///< YUV 420 format 10bits per comp tight packed format.
    YUV422NV16TP10     = 17,         ///< YUV 422 format 10bits per comp tight packed format.
    PD10               = 18,         ///< PD10 format
    RawMIPI8           = 19,         ///< 8BPP: Each pixel occupies one bytes, starting at LSB.
                                     ///  Output width of image has no restrictions.
    P010               = 22,         ///< P010 format.
    RawPlain64         = 23,         ///< RawPlain64 format
    UBWCP010           = 24,         ///< UBWC P010 format (as per UBWC2.0 design specification)
    UBWCNV12FLEX       = 25,         ///< UBWC NV12 FLEX format (as per UBWC2.0 design specification)
    RawMIPI12          = 26,         ///< 12BPP: 2 pixels are held in every 3 bytes.
                                     ///         Output width of image must be a multiple of 2 pixels.
    RawPlain16LSB12bit = 27,         ///< Plain16 RAW format. 12 bits per pixel.
    RawMIPI14          = 28,         ///< 14BPP: 4 pixels are held in every 7 bytes.
                                     ///         Output width of image must be a multiple of 4 pixels.
    RawPlain16LSB14bit = 29,         ///< Plain16 RAW format. 14 bits per pixel.
    YUV420NV12FLEX     = 30,         ///< YUV 420 format used in HFR cases.
    RawPlain32         = 31,         ///< 31 bit format
    YUY2               = 32,         ///< YUY2 forma
	// LMC                = 32,         ///< DMM map used for LMC. 64 bits per 8x8 block, including two MVs (X and Y).
    BlurMap            = 33,         ///< Plain8 format for Blur map. Its stride need 2 more pixels than its width.
    P010LSB            = 34,         ///< P010 format LSB aligned.
    ARGB               = 35,         ///< ARGB format, each pixel occupies 4 or 8 bytes.
                                     ///< ARGB8888 and ARGB 2101010 are 4 bytes, ARGB16161616 are 8 bytes.
    InvalidFormat      = 36,         ///< Invalid Format to identify
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief Structure to define a format
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
struct CamImageFormat
{
    Format          format;             ///<  Color format
    UINT32          width;              ///< Width of the image in pixels.
    UINT32          height;             ///< Height of the image in pixels.
    ChiStreamFormat pixelFormat;        ///< Pixel format
    UINT64          grallocUsage;       ///< Gralloc usage flags
};

struct StrideScanAlignment
{
    UINT32          strideAlignment;    ///<  Unique stride requirement for the format
    UINT32          scanlineAlignment;  ///<  Unique scanline requirement for the format
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief Static utility class for image format information.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
class CAMX_VISIBILITY_PUBLIC ChiImageFormatUtils
{
public:

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// GetFormatAlignment
///
/// @brief  Get Stride and Scanline for perticular Plane
///
/// @param  planeId               Plane ID for which we need alignment
/// @param  rcamImageFormat       CamImage format info
/// @param  useGralloc            Check for call to mapper or internal
///
/// @return Stride and Scan Alignment for the given planeId and format
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static StrideScanAlignment GetFormatAlignment(
    UINT                        planeId,
    const CamX::CamImageFormat& rcamImageFormat,
    BOOL                        useGralloc);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// GetImageSize
///
/// @brief  Get Image Size for perticular Plane
///
/// @param  rcamImageFormat   CamImage format info
///
/// @return size based on the given format
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static size_t GetImageSize(
    const CamX::CamImageFormat& rcamImageFormat);
};

CAMX_NAMESPACE_END

#endif // CHIIMAGEFORMATUTILS_H
