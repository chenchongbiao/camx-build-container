// NOWHINE ENTIRE FILE
//-------------------------------------------------------------------------
// Copyright (c) 2017-2020 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
//------------------------------------------------------------------------


#ifndef __TF_REGISTERS680_H__
#define __TF_REGISTERS680_H__

#include <stdint.h>


struct IPETFRegCmd680;

// Validates the settings of the registers
// Returns 0 if success
// Else, returns the number of invalid settings
int32_t ValidatePacked_TF21_REG( IPETFRegCmd680* regStruct );
// Set the default values of struct
// This function set the internal struct fields and not the packed register
// Therefore, the function PackREG should be called before using the final value of the registers
void SetDefaultValPacked_TF21_REG( IPETFRegCmd680* regStruct );

#endif //__TF_REGISTERS680_H__

